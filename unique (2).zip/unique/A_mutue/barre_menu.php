<style type="text/css">
	/* Conteneur principal */
.BarreDeMenu {
    display: flex;
    flex-wrap: wrap; /* Permet aux éléments de passer à la ligne si nécessaire */
    gap: 10px; /* Espacement entre les éléments */
    width: 100%;
    padding: 5px;
    background-color: #003958;
    box-sizing: border-box;
}

/* Éléments enfants */
.z_unique, .z_logoEts, .z_Aca, .z_Menus, .z_FormRecherche1 {
    flex: 1 1 auto; /* Les éléments prennent uniquement l'espace nécessaire */
    box-sizing: border-box;
    text-align: center;
    color: #fff;
    border: solid 0px #ff0000;
}

/* .z_unique : Texte important */
.z_unique {
    font-size: 1.5em; /* Taille de police pour le titre */
    font-weight: bold;
    flex: 0 0 auto; /* Permet de s'adapter à l'espace disponible */
}

/* .z_logoEts : Logo */
.z_logoEts {
    flex: 0 0 auto; /* Ne dépasse pas la taille de son contenu */
    align-self: center; /* Centrage vertical dans le flex container */
}
/* .z_Aca : Texte académique */
.z_Aca {
    font-size: 0.9em;
    flex: 1 1 auto;
    text-align: center;
    padding-top: 2px;
}

/* .z_Menus : Menus */
.z_Menus {
    display: flex;
    gap: 25px;
    justify-content: center; /* Centrer les éléments du menu */
    flex-wrap: wrap;
    flex: 1 1 auto; /* Prend l'espace disponible */
}

.logoEts {
    width: 30px; /* Taille maximale du logo */
    height: auto;
}

.icon_menu {
    width: 35px; /* Taille maximale icon menu */
    height: auto;
    padding-top: 2px;
}

/* Boutons du menu */
.z_menu {
    flex: 0 0 auto;
    cursor: pointer;
    transition: background-color 0.3s;
}



/* Formulaire de recherche */
.z_FormRecherche1 {
    flex: 1 1 auto; /* S'adapte à l'espace disponible */
    text-align: center;
    padding: 0px;
}

/* Adaptation pour petits écrans */
@media screen and (max-width: 768px) {
    .BarreDeMenu {
        flex-direction: column; /* Les éléments s'empilent */
    }

    .z_unique, .z_logoEts, .z_Aca, .z_Menus, .z_FormRecherche1 {
        flex: 1 1 100%; /* Prend toute la largeur */
        text-align: center;
    }

    .z_Menus {
        justify-content: center;
    }
}

</style>
<div class="BarreDeMenu">
    <!-- Logo et sigle -->
    <div class="z_unique">
        UNIQUE - <?php echo $_SESSION['sigle_tb_etablissement']; ?>
    </div>
    <div class="z_logoEts">
        <img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo" class="logoEts"/>
    </div>
    <!-- Année académique -->
    <div class="z_Aca">
        <samp>Année académique<br/>
        <b style="font-size:14px"> <?php echo $_SESSION['idAnAca']; ?></b></samp>
    </div>
    <!-- Menus -->
    <div class="z_Menus">
        <div class="z_menu">
            <a href="?accueil"><img src="A_mutue/accueil.png" alt="Accueil" class="icon_menu" /></a>
        </div>
        <div class="z_menu">
            <?php include("A_mutue/menu_profil_user.php"); ?>
        </div>
    </div>
    <!-- Formulaire de recherche -->
    <div class="z_FormRecherche1">
        <?php 
        	include("A_mutue/f_rchrch.php"); 
        	include("B_mbindi/Biamunda/rqt/rqt_ResultatDeLa_chrch.php");
        ?>
    </div>
</div>
