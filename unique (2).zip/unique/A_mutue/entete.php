<style type="text/css">
	.diventete{
		display: none;
	}
</style>
<div class="diventete" >
	<table width="100%">
		<tr>
			<td>
				<div class="divlogEts" >
					<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" id="logoEts"/> 
				</div >
				<div class="divtexteTitreEts" align="center">
					
					<div align="center"><strong style="font-size:30PX;">UNIQUE</strong></div>
					<div id="ets">
						<strong style="font-size:30PX;"><?php echo $nom_etablissement; ?></strong>
					</div>
					<div align="center"><?php echo $sigle_tb_etablissement; ?></div>
					
				</div>
				<div class="divLogUnique" >
					<div style="width:100%;height:100px;"> 
						<img src="B_mbindi/Biamunda/icon/unique.png"  id="logoEts"/>
					</div>
				</div>
			</td>
		</tr>
	</table>
</div>

<?php 
	include("A_mutue/barre_menu.php"); 
?>
 
