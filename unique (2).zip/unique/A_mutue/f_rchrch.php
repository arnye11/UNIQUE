<style type="text/css">
    /* Conteneur principal du formulaire */
    .search-container {
        display: flex;
        align-items: center; /* Aligne les éléments verticalement */
        border-radius: 14px;
        border: 0px solid #ff0000;
        background-color: #fff;
        padding: 0; /* Retirer tout padding interne */
        box-sizing: border-box;
        overflow: hidden; /* Assure que tout reste à l'intérieur */
    }

    /* Zone de saisie */
    #search-input {
        flex: 1; /* Permet au champ de saisie de s'étendre */
        border: none; /* Pas de bordure interne */
        padding: 10px;
        font-size: 16px;
        color: #333;
        background-color: #fff;
        outline: none;
        box-sizing: border-box;
    }

    #search-input:focus {
        border-color: #04a900;
    }

    /* Bouton de recherche */
    #search-button {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 50px; /* Largeur fixe */
        height: 100%; /* Correspond à la hauteur du conteneur */
        padding: 9px;
        background-color: #fff;
        border: none; /* Pas de bordure */
        border-left: 0px solid #ff0000; /* Lien visuel entre le champ et le bouton */
        cursor: pointer;
        outline: none;
        transition: background-color 0.3s ease-in-out, border-color 0.3s ease-in-out;
    }

    #search-button:hover {
        background-color: #f2f2f2;
    }

    #search-button svg {
        fill: none;
        stroke: #003958;
        stroke-width: 1.5;
        transition: stroke 0.3s ease-in-out;
    }

    #search-button:hover svg {
        stroke: #04a900;
    }

    /* Compatibilité mobile */
    @media (max-width: 600px) {
        .search-container {
            flex-wrap: nowrap; /* Empêche les éléments de passer à la ligne */
        }

        #search-button {
            flex-shrink: 0; /* Le bouton ne rétrécit pas */
        }
    }
    
</style>

<div class="search-container">
    <form method="post" name="SearchForm" style="display: flex; width: 100%;">
        <input type="text" name="conten" id="search-input" placeholder="Saisissez le matricule de l'étudiant" 
            value="<?php  if (isset($_POST["BtChercher"])) {echo $_POST["conten"] ;} ?>">
        <button type="submit" name="BtChercher" id="search-button" title="Rechercher">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="8" cy="8" r="7" stroke="#003958" stroke-width="2"/>
                <line x1="13" y1="13" x2="19" y2="19" stroke="#003958" stroke-width="2"/>
            </svg>
        </button>
    </form>
</div>
<?php  ?>
