<?php 
	header ('location: http://192.168.100.1/istia-kabinda/');

 ?>