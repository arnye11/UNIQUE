<style type="text/css">
    /* Conteneur principal */
    .user-menu {
        position: relative;
        display: inline-block;
    }

    /* Bouton du menu */
    #user-menu-button {
        display: flex;
        align-items: center;
        background: #003958;
        border: 0px solid #0de900;
        cursor: pointer;
        font-size: 14px;
        color: #fff;
        outline: none;
        transition: background-color 0.3s;
    }

    
    /* Avatar de l'utilisateur */
    .user-avatar {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        margin-right: 8px;
        border: 1px solid #fff;
    }
    .user-name{
        margin-right: 5px;
    }
    /* Menu déroulant */
    .dropdown-menu {
        position: absolute;
        top: 100%;
        right: 0;
        background: #003958;
        border: 1px solid #003958;
        margin-top: 0px;
        padding: 0;
        list-style: none;
        width: auto;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        display: none;
        z-index: 1000;
    }

    .dropdown-menu li {
        border-bottom: 1px solid #f0f0f0;

    }

    .dropdown-menu li:last-child {
        border-bottom: none;
    }

    /* Liens du menu */
    .dropdown-menu li a {
        display: block;
        padding: 10px;
        color: #fff;
        text-decoration: none;
        font-size: 14px;
        transition: background-color 0.3s, color 0.3s;
    }

    .dropdown-menu li a:hover {
        background-color: #006897;
        font-weight: bold;
    }

    /* Affichage du menu au survol */
    .user-menu:hover .dropdown-menu {
        display: block;
    }

</style>
<div class="user-menu">
    <button id="user-menu-button">
        <img src="logoprofil2.png" alt="photo" class="user-avatar"> <!-- Placez l'image de l'utilisateur ici -->
        <span class="user-name"><?php echo $_SESSION['prenom']; ?></span>
        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
    </button>
    <ul class="dropdown-menu">
        <li><a href="?gerer_admin&aDmini5TratIF&id=<?php echo $_SESSION['idAutoDec']; ?>">Profil</a></li>
        <li><a href="?dc10=10f0000010">Se déconnecter</a></li>
    </ul>
</div>
 