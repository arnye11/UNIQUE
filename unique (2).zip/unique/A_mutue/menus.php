
<div class="divmenu" >
	<div class="zonFormRecherche1" >
	
	<?php 
		include("B_mbidndi/Biamunda/f_rchrch.php"); 
	 ?>
	</div>
	<div class="zonAca" >
		<samp>Ann&eacute;e acad&eacute;mique <br/>
		<b style="font-size:14px"> <?php echo $_SESSION['idAnAca']; ?></b></samp>
	</div>
<div id="monmenu">
    <!--________________ Menu � d�ploiement vertical _________________________-->
  <UL class="niveau1" style="display:inline">
		<LI class="menus_prince">
			<A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?accueil">
				<img src='B_mbindi/Biamunda/icon/accue.gif' class='icon' />
				&ensp; Accueil 
			</A>
		</LI>
		<!--MENU CONTROLE-->
		<?php if ($_SESSION['NivAc'] >= 0 || $_SESSION['NivAc'] <= 5){ ?>
		<LI class="menus_prince">&nbsp; Contr&ocirc;le &dArr;
			<UL class="niveau2" style="LEFT: 0px; TOP: 22px">
				<LI class="plus">
					<A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?ctrl&misession=E1">Pour la Mi-Session</A> 
				</LI>
				<LI class="plus">
					<A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?ctrl&1session">Pour la 1<sup>&egrave;re</sup> Session</A> 
				</LI>
				<LI class="plus">
					<A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?ctrl&deliberation">Pour la D&eacute;liberation</A> 
				</LI>
				<LI class="plus">
					<A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?ctrl&2session">Pour la 2<sup>&egrave;me</sup> Session</A> 
				</LI>
				<?php 
				if ($_SESSION['NivAc']>2)
					{ ?>
					<LI class="plus"><!--<A href="<?php //$_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?ctrl&rapport">--><img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/3.png" />Rapport des Frais ><!--</A>--> 
						<UL class="niveau3">
							<LI><A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?rapport&fr_journalier"> > Journalier</A></LI>
							<LI><A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?rapport&fr_periodique"> > P&eacute;riodique</A></LI>
							<LI><A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?rapport&fr_annuel&inscrition"> > Annuel</A></LI>
						</UL>
					</LI>
			 		<?php 
					} 
					?>
			 </UL>
		</LI>
		<?php }?>
		<!------------------------------------------------------------>
		<!--MENU INSCRIPTION-->
		<?php if ($_SESSION['NivAc']>=0){ ?>
		<LI class="menus_prince"><img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/note16.ico" />&nbsp; Inscription 
			<UL class="niveau2" style="LEFT: 0px; TOP: 22px">
				<LI><A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?inscrition_inscrition#i"><img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/note16.ico" />&nbsp; Incription</A></LI>
				<LI><A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?inscrition_reinscription"><img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/note14.ico" />&nbsp; Reinscription</A></LI>
				<LI><A href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?inscrition_situation"><img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/3.png" />&nbsp; Situation</A></LI>
			</UL>
		</LI>
		<?php } ?>
		<!----------------------------------------------------------->
		<!--MENU GERER-->
		<LI class="menus_prince" ><img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/parametr.png" />&nbsp; Gerer 
			<UL class="niveau2" style="LEFT: 0px; TOP: 22px">
				<?php 
				if ($_SESSION['NivAc']>=0)
					{ 
					?>
					<LI><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_departement&ajouter_dep">Facult&eacute;</A></LI>
					<?php 
					} 

				if ($_SESSION['NivAc']>=0)
					{ 
					?>
					<LI><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_option&ajouter_op">Option</A></LI>
					<?php 
					}

				 if ($_SESSION['NivAc']>=0)
				 	{ 
					?>
					<LI><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_promotion&ajouter_pro">Promotion</A></LI>
					<?php 
					} 

				if ($_SESSION['NivAc']>=0)
					{ ?>
					<LI><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_aca&ajouter_aca">Ann&eacute;e Acad&eacute;mique</A></LI>
					<?php 
					}

				if ($_SESSION['NivAc']>=0)
					{ 
					?>
					<LI><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&ajouter_fr"><img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/dollards.gif" />&nbsp; Frais</A></LI>
					<?php 
					} 

				if ($_SESSION['NivAc']>=0)
					{ ?>
					<LI ><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_cours&ajouter_cours"><img class="icon" src="A_mutue/cours.ico" />&nbsp;Cours</A></LI>
					<?php 
					} 

				if ($_SESSION['NivAc']>=0)
					{ 
					?>
					<LI >
						<A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_cote&fIcHeScoTe">
						<img class="icon" src="A_mutue/cote.png" />&nbsp;Cotes
						</A>
					</LI>
					<?php 
					} 

				if ($_SESSION['NivAc']>=0)
					{ 
					?>
					<LI >
						<A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_admin&aDmini5TratIF">
						<img class="icon" src="A_mutue/cote.png" />&nbsp;Administratifs
						</A>
					</LI>
					<?php 
					}
 
					?>
					<LI style="border-top:solid #999999 1px">
						<A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?dc10=10f0000010">
							<img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/w95mbx01.ico" />&nbsp;D&eacute;connect&eacute;(<span style="font-size:10px;"><?php echo $_SESSION['loginSession']; ?></span>)
						</A>
					</LI>

			</UL>
					
		</LI>
		<!------------------------------------------------------------>

  </UL>
</div>
</div>
