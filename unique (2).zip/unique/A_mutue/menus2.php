<div id="monmenu">
	<!--________________ Menu � d�ploiement vertical _________________________-->
	<UL class="niveau1" style="display:inline">
		<!--MENU GERER-->
		<LI class="menus_prince">
			<A href="?accueil">
				<svg xmlns='http://www.w3.org/2000/svg' width='30' height='30' viewBox='0 0 30 30'>
					<path stroke='#235a81' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/>
				</svg>
			</A>
		</LI>
		<LI class="menus_prince">
			<A href="?accueil">
				<img src='B_mbidndi/Biamunda/icon/accue.gif' class='icon' />
				&ensp; Accueil 
			</A>
		</LI>
		<!--MENU GERER-->
		<LI class="menus_prince" >
			<img class="icon" src="A_mutue/parametr.png" />&nbsp; G&eacute;rer 
			<UL class="niveau2" style="LEFT: 0px; TOP: 22px">
				<?php 
					if ($_SESSION['NivAc']>=0){ 
						echo "<LI>";
						echo "<A href='?gerer_departement&ajouter_dep'>Facult&eacute;</A>";
						echo "</LI>";
					} 
					
					if ($_SESSION['NivAc']>=0){ 
						echo "<LI>";
						echo "<A href='?gerer_option&ajouter_op'>Option</A>";
						echo "</LI>";
					}
	 			 	
	 			 	if ($_SESSION['NivAc']>=0){
						echo "<LI>";
						echo "<A href='?gerer_promotion&ajouter_pro'>Promotion</A>";
						echo "</LI>";
					} 

					if ($_SESSION['NivAc']>=0){
						echo "<LI>";
						echo "<A href='?gerer_aca&ajouter_aca'>Ann&eacute;e Acad&eacute;mique</A>";
						echo "</LI>";
					}

					if ($_SESSION['NivAc']>=0){ 
						echo "<LI>";
						echo "<A href='?gerer_admin&aDmini5TratIF'>";
						echo "<img class='icon' src='A_mutue/cote.png'/>&nbsp;Utilisateurs";
						echo "</A>";
						echo "</LI>";
					}
					 
				?>
				<LI style="border-top:solid #999999 1px">
					<A href="?dc10=10f0000010">
						<img class="icon" src="A_mutue/w95mbx01.ico" />
						&nbsp;D&eacute;connect&eacute;
						(<span style="font-size:10px;"><?php echo $_SESSION['loginSession']; ?></span>)
					</A>
				</LI>
			</UL>
		</LI>
	</UL>
	
	
</div>
