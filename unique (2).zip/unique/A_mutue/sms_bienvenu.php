	<!--*******************  ZONE SMS BIENVENU  *******************************-->
	<!--_______________________________________________________________________-->
	<div class="zonImgProfilInternaute1_SmsBienvenu" id="ms01011">
			<?php 
				if(($champsLog != false) and ($conx !=false))
					{ 
					?>
			<!--************SI INTERNAUTE EST CONNECTE  *********************---->
			<div class="zonImgProfilInternaute1">
				<img class="ImgProfilInternaute1" src="<?php $url_istia;?>/<?php if($_SESSION['AvatarEtud'] !=""){echo $_SESSION['AvatarEtud'] ;}else{if($_SESSION['sexeetud']=='M'){echo 'pecimistM.gif';}else{echo 'pecimistM.gif';}}?>" title="<?php echo $_SESSION['prenometud'].'&nbsp;&nbsp;'.$_SESSION['nometud'].'&nbsp;'.$_SESSION["postnometud"];?>" />
			</div>
			
			<?php 	}?>
			
			<!--******************* SMS BIENVENU ************************************
			<div id="0101" class="<?php /* if(($conx ==false)){echo "zonSmsBienvenu1";}else{echo "zonSmsBienvenu2";}*/?>">
				<marquee behavior="alternate" class="sms_bievenu">Bienvenue chez nous!</marquee>
			</div>
			--->
	        <div class="divAprpos" style="color:#FFFFFF"><a href="?apropos#apropos" style="font-size:14px; color:#FFFFFF;">A propos</a></div>
	</div>
	<!--_______________________FIN SMS BIENVUNUE____________________________________-->
