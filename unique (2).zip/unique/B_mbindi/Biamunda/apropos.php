<div align="center" id="apropos">
	<div style="width:380px;height:350px;overflow:scroll;padding-right:3px;	background:#000033;	border:solid 1px #FFCC33;color:#FF6633; margin-top:30px;margin-bottom:10px; box-shadow:0px 9px 9px 0px #003300;" align="center">
<!--<marquee direction="up" behavior="alternate" vspace="100" truespeed="truespeed" align="middle" >-->
		A propos <br />
		________________________________
		<h3>ArnyeSoft</h3>
		<h1>UNIQUE</h1>
		<p>Universit&eacute; num&eacute;rique<br>
		Cette Plate-forme est encore en Version Expresse  ! 
		Elle est con&ccedil;ue pour pallier aux besoins pr&eacute;sent&eacute;s  par le Directeur G&eacute;n&eacute;ral de l&rsquo;Institut Sup&eacute;rieur Technique d&rsquo;Informatique  Applique, en sigle ISTIA/Kabinda&nbsp; sur : <br> &laquo; LA GESTION DES FRAIS &raquo;, mais le march&eacute; n'a pas &eacute;t&eacute; conclu. Aujourd'hui, r&eacute;orient&eacute; pour l'Universit&eacute;&eacute; Notre dame de Lomami en sigle UNILO. </p>
		<h2>Avertisement : </h2>
		<p>Ce Programme est prot&eacute;g&eacute; par la loi relative au droit d'auteur et par les conventions internationales. Toute Reproduction ou Distribution partielle ou totale du Logiciel, par quelque moyen que ce soit, est strictement interdite. Toute personne ne respectant pas ces dispositions se rendra coupable du d&eacute;lit de contrefa&ccedil;on et sera passible des sanctions p&eacute;nales pr&eacute;vue par la loi. <br/>Un Homme avertu ...!</p>
		<p id="arnye">________________________________<br>
		  Con&ccedil;ue par&nbsp;:</p>
		<p><img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>B_mbindi/Biamunda/icon/arn.jpg" alt="arnyee" width="100%" height="auto" /><br/>
		  Augu Roger NYEMBO MPAMPI
		  <br/>Ing&eacute;nieur en CSI<br/>
		  2017 arnye, tous droits r&eacute;serv&eacute;s. &nbsp;</p>
		<div style="margin:20px;">
			<a href="licence/Contrat_licence_UNIQUE_UKA_21082023.pdf">
				<div style="color:#FFFFFF;">Veuillez lire aussi le contrat de licence ci-joint</div>
			</a>
		</div>
<!-- </marquee>-->
	</div>
	<div style="margin:20px;"><a href="licence/Contrat_licence_UNIQUE_UKA_21082023.pdf">Votre licence</a></div>
	<div style="margin-bottom:10px;">
		<form action="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>" method="get">
		<input name="" type="submit" value="OK" />
		</form>
	</div>
</div>



