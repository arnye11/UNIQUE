<?php 
//dans cours.php

	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['atTribuEr'])){?>

		<div >
			<h3>Attributione des cours <br/> Promotion : <?php echo $idPromoOrgV."&ensp;".$designOpOrgV;?><br> Ann&eacute;e acad&eacute;mique : <?php echo $an_aca;?> </h3>
			<?php 
			if(isset($_POST['BtAttCours'])){ echo $sms_gerer; }
			if(isset($_POST['BtModifierCoursProgram'])){ echo $sms_gerer; }
			if(isset($_GET['sms_gerer'])){ echo "<span class='reussite'>".$_GET['sms_gerer']."</span>"; }
			
			?>
			<table width="100%" border="1" cellpadding="2" cellspacing="0" style="font-size:13px;">
				<tr style="background:#999999; text-align:center; ">
					<td width="3%">N&deg;</td>
					<td width="50%">D&eacute;signation cours</td>
					<td width="3%">HT</td>
					<td width="3%">HP</td>
					<td width="4%">TOT.</td>
					<td width="26%">Enseignant</td>
					<td width="10%">Action </td>
				</tr>
				<?php 
				$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";//COURS 
				//$rqt_list_cours = "SELECT * FROM  tb_program_cours ORDER BY designCours ";//COURS 
				if($exe_rqt_slct_cours_Program = mysqli_query($con, $rqt_slct_cours_Program)){
					if(mysqli_num_rows($exe_rqt_slct_cours_Program)>0){
						$num=0;
						while($tb_programme_cours = mysqli_fetch_assoc($exe_rqt_slct_cours_Program)){
							$num = $num+1;
							$idEns = "";
							$nomEns = "";
							$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns = tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$tb_programme_cours['idCours']."') AND ((tb_attribution.idPromo)='".$idPromoOrgV."') AND ((tb_attribution.idOp)='".$idOpOrgV."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ORDER BY nomEns ASC";
							if($exe_rqt_slct_ens= msqli_query($con, $rqt_slct_ens)){
								if($tb_ens = mysqli_fetch_assoc($exe_rqt_slct_ens)){
										$idEns = $tb_ens['idEns'];
										$nomEns = $tb_ens['idGrad']."&nbsp;".$tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns']."&nbsp;|&nbsp;".$tb_ens['domainEtudEns'];
								}
								else{
									$nomEns ="<div class='erreur'>Non attribu&eacute;.</div>";
								}
							}
							else{
									$nomEns ="Erreur.";
							}
							if(isset($_GET['modIf']) and isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"] and !isset($_POST['BtAttCours'])){ ?>
								<tr>
									<td><div align="right"><?php echo $num; ?></div></td>
									<td><?php echo $tb_programme_cours["designCours"] ; ?></td>
									<td><div align="right"><?php echo $tb_programme_cours["ht"]; ?></div></td>
									<td><div align="right"><?php echo $tb_programme_cours["hp"]; ?></div></td>
									<td><div align="right"><?php echo $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; ?></div></td>
									<td colspan="2">
										<div align="right">
											<form action="" method="post" name="formProgramCours">
												<input name="idCours" type="hidden"  value="<?php echo $tb_programme_cours["idCours"]; ?>">
												<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
												<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
												<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
												<select name="idEns" style="width:60%;">
													<option value="<?php echo $idEns; ?>"><?php echo $nomEns; ?></option>
													<?php 
													$rqt_ens = "SELECT * FROM tb_enseignant ORDER BY nomEns ASC";
													if($exe_rqt_ens = mysqli_query($con, $rqt_ens)){
														if(mysqli_num_rows($exe_rqt_ens)>0){
															while($tb_ens = mysqli_fetch_assoc($exe_rqt_ens)){
																echo "<option value='".$tb_ens['idEns']."'>".$tb_ens['idGrad']."&nbsp;".$tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns']."&nbsp;|&nbsp;".$tb_ens['domainEtudEns']."</option>";
															}
														}
														else{
															echo "<option value=''>Aucun enseignant enregistr&eacute;.</option>";
														}
													}
													else{
															echo "<option value=''>Erreur.</option>";
														}
													?>
													
													
												</select>
												<input name="BtAttCours" type="submit" value="Attribuer" style="width:38%;"> <br>
												<a  href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr";?>">Annuler</a>								</form>
										</div>		
									</td>
								</tr>
							<?php
							}
							else{
								?>
								<tr>
									<td><div align="right"><?php echo $num; ?> </div></td>
									<td><?php echo $tb_programme_cours["designCours"]; ?></td>
									<td><div align="right"><?php echo $tb_programme_cours["ht"]; ?></div></td>
									<td><div align="right"><?php echo $tb_programme_cours["hp"]; ?></div></td>
									<td><div align="right"><?php echo $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; ?></div></td>
									<td><?php echo $nomEns; ?></td>
									<td>
									<?php 
										if ($idEns ==""){ ?>
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&modIf&iDcOurs=".$tb_programme_cours["idCours"] ?>">
												<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/note14.ico" class="icon" align="left" alt="Attrib." title="Attribuer" style="margin-left:5px;"/>
											</a>
											<?php 
										}
										else{?>
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&sUpp&iDcOurs=".$tb_programme_cours["idCours"] ?>">
											<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/supp.gif" class="icon" align="right" alt="Sup." title="Retirer" style="margin-right:5px;"/></a>
											<?php 
										}
										?>
									</td>
								</tr>
								<?php 
							}
						}
					}
					else{
						?>
						<tr align="left" style="">
							<td colspan="7" style="color:#FF99CC;">Aucun cours n'est encore programm&eacute;</td>
						</tr>
						<?php 
					} 
				}
				else{
					?>
					<tr align="left" style="">
						<td colspan="7" style="color:#FF0000;">Erreur lors de r&eacute;cuperation des cours programm&eacute;</td>
					</tr>
					<?php 
				} ?>
			</table>
		</div>
<?php }?>