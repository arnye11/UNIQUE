<?php 
	if (isset($_GET['fAculTe'])){
		$accueil=false;
	}
 ?>
<style type="text/css">
	/* Réinitialisation générale */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Conteneur principal */
.z_corps {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    border: 1px solid #FF0000;
    padding: 10px;
    background-color: #f9f9f9;
}

/* Divisions enfants */
.divList_Info {
    flex: 1 1 25%;
    max-height: 86vh;
    overflow-y: auto;
    border: 1px solid #FF0000;
    padding: 10px;
    background-color: #ffffff;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.div_Form_AMS {
    flex: 1 1 70%;
    max-height: 86vh;
    overflow-y: auto;
    border: 1px solid #FF0000;
    padding: 10px;
    background-color: #ffffff;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* Responsiveness */
@media screen and (max-width: 768px) {
    .z_corps {
        flex-direction: column;
    }

    .divList_Info,
    .div_Form_AMS {
        flex: 1 1 100%;
        max-height: unset;
    }
}

</style>
<div class="z_corps">
    <div align="center">		
	    <?php 
			include("B_mbindi/Biamunda/faculte.php");
			if (!isset($_GET['fAculTe'])){
				
				if (isset($_GET['apropos'])){
					$accueil=false;
					include("B_mbindi/Biamunda/apropos.php"); 
				}
				if (isset($_GET['accueil']) || isset($_GET['ajouteraJOuterFacSeCt']) || $accueil==true){ ?>
					<div style="width:100%; height:auto;">
						<?php 
							include("B_mbindi/Biamunda/faculte_list.php");
						?>
					</div>
					<?php 
				}
				if (isset($_GET['oP_cPtablE82Zxs']) ){ ?>
					<div style="width:100%; height:auto;">
						<?php 
							include("B_mbindi/makuta/op_cptb/op_cptb.php");
						?>
					</div>
					<?php 
				}
				
			}
		?>			
    </div>
</div>
 
<?php 
	include("B_mbindi/profilEtudiant/profil_details.php");
?>