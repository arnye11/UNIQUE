
<?php 
//dans rqt_verification_promo_op
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])){?>
		<style type="text/css">
			<!--
			.menuInscription{
				width:110px; height:auto; display:inline; float:left; font-family:'Century Schoolbook'; text-align:left; margin:5px; text-align:center; 
			}
			#s_menuInscriptionSlct{
				padding:5px; box-shadow:0px 2px 2px 0px #333399;
			}
			.divFormInscript, .divInfoInscript{
				height:auto; display:inline; float:left; border:solid 1px #CCCCCC; padding:5px; 
			}
			.divFormInscript{
				width:60%;   
			}
			.divInfoInscript{
				width:36%; 
			}
			-->
		</style>
		 
		 <?php 
		 
		 ?>
		 
		 <table width="100%">
			<tr>
				<td>
					<div class="menuInscription" <?php if (isset($_GET['pRograMe'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe" ?>">Programme</a> 
					</div>
					<div class="menuInscription" <?php if (isset($_GET['atTribuEr'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr" ?>">Attribuer</a> 
					</div>
					<div class="menuInscription" <?php if (isset($_GET['aLigner'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&aLigner" ?>">Aligner</a> 
					</div>
				</td>
			</tr>
		</table>

		<table width="100%">
			<tr>
				<td>
					<div class="divFormInscript">
						<?php 
							include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/B_mbindi/programme_cours.php"); 
							include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/B_mbindi/attribution_cours.php"); 
						?>
					</div>
					<div class="divInfoInscript">
						<?php 
						include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/B_mbindi/f_ajouter_cours.php");
						include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/B_mbindi/rqt/rqt_list_cours.php");
						?>
					</div>
				
				</td>
			</tr>
		</table>

		 <?php 	
	}

?>