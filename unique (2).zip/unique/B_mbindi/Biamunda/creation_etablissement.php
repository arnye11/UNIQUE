<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//FR" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<link rel="icon" href="B_mbidndi/Biamunda/icon/unique.ico" />
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>UNIQUE - Cr&eacute;er votre &eacute;tablissement</title>
		<style type="text/css">
			<!--
			.d1, .d2, .d3 {margin:4px;text-align:left; }
			.d1{width:96%; height:auto; border:solid 1px #C1C1C1;margin-bottom: 15px;}
			.d2{width:98.4%; height:28px;  background:#F2F2F2;}
			.d3{height:22px;  display:inline; float:left; }
			#dDesig{width:30%; }
			#dJ{width:15%; }
			#dM{width:28%; }
			#dA{width:17%; }
			#dT{width:30%; text-align:left; }
			#dBtEnr{width:30%; float:right; }
			
			.imgPreview{
			  	max-width:120px;
			  	max-height:120px;
			}
			-->
		</style>
		<script type="text/javascript" >
			function createThumbnail(sFile,sId) {
			  var oReader = new FileReader();
			  oReader.addEventListener('load', function() {
				var oImgElement = document.createElement('img');
				oImgElement.classList.add('imgPreview') 
				oImgElement.src = this.result;
				document.getElementById('preview-'+sId).appendChild(oImgElement);
			  }, false);
			
			  oReader.readAsDataURL(sFile);
			
			}//function
			function changeInputFil(oEvent){
			  var oInputFile = oEvent.currentTarget,
				  sName = oInputFile.name,
				  aFiles = oInputFile.files,
				  aAllowedTypes = ['png', 'jpg', 'jpeg', 'gif'], imgType;  
			  document.getElementById('preview-'+sName).innerHTML ='';
			  for (var i = 0 ; i < aFiles.length ; i++) {
				imgType = aFiles[i].name.split('.');
				imgType = imgType[imgType.length - 1];
				if(aAllowedTypes.indexOf(imgType) != -1) {
				  createThumbnail(aFiles[i],sName);
				}//if
			  }//for
			}//function 
			
			document.addEventListener('DOMContentLoaded',function(){
			 var aFileInput = document.forms['myForm'].querySelectorAll('[type=file]');
			  for(var k = 0; k < aFileInput.length;k++){
				aFileInput[k].addEventListener('change', changeInputFil, false);
			  }//for
			});
		</script>
	</head>
	<body> 
		<div align="center" style="font-size:1.3em;">
			<h1>UNIQUE</h1>
			<h1>Cr&eacute;er votre &eacute;tablissement</h1>
			<div>
				<?php if(isset($_POST['BtCreerEts'])){ echo $sms_gerer;} ?>
			</div>
			<div>
				<form name="myForm" method="post" enctype="multipart/form-data" >
					<table width="">
						<tr>
							<td><div align="right">Code unique: </div></td>
							<td>
								<div align="left">
									<input name="codEts" type="text" value="<?php if(isset($_POST['BtCreerEts'])){ echo $_POST['codEts'];} ?>" />
								</div>
							</td>
				  		</tr>
				 		<tr>
							<td>
								<div align="right">Nom de l'&eacute;tablissement : </div>
							</td>
							<td>
								<div align="left">
									<input name="nomEts" type="text" value="<?php if(isset($_POST['BtCreerEts'])){ echo $_POST['nomEts'];} ?>"/>
								</div>
							</td>
						</tr>
						<tr>
							<td><div align="right">Sigle de l'&eacute;tablissement : </div></td>
							<td><div align="left">
							  <input name="sigleEts" type="text" value="<?php if(isset($_POST['BtCreerEts'])){ echo $_POST['sigleEts'];} ?>"/>
						    </div></td>
						</tr>
						<tr>
						  <td><div align="right">Adresse de l'&eacute;tablissement : </div></td>
						  <td><div align="left">
						    <input name="adressEts" type="text" style="width:300px;" value="<?php if(isset($_POST['BtCreerEts'])){ echo $_POST['adressEts'];} ?>"/>
					      </div></td>
						</tr>
						<tr>
						  <td><div align="right">Ville de l'&eacute;tablissement : </div></td>
						  <td><div align="left">
						    <input name="villeEts" type="text" value="<?php if(isset($_POST['BtCreerEts'])){ echo $_POST['villeEts'];} ?>"/>
					      </div></td>
						</tr>
						<tr>
						  <td><div align="right">Num&eacute;ro t&eacute;l&eacute;phonique  : </div></td>
						  <td><div align="left">
						    <input name="telEts" type="text" value="<?php if(isset($_POST['BtCreerEts'])){ echo $_POST['telEts'];} ?>"/>
					      </div></td>
						</tr>
						<tr>
						  <td><div align="right">E-mail de l'&eacute;tablissement : </div></td>
						  <td><div align="left">
						    <input name="emailEts" type="text" value="<?php if(isset($_POST['BtCreerEts'])){ echo $_POST['emailEts'];} ?>"/>
						  </div></td>
						</tr>
						<tr>
                          <td><div align="right">Type d'&eacute;tablissement : </div></td>
						  <td>
						  	<div align="left">  
	                          	<select name="typEts" style="width:100%;" >
									<option value="">Sel&eacute;ctionner </option>
									<?php 
									$rqt_slct_typEts = "select * from  tb_type_etablissement ORDER BY designTypEts ";
									if($exe_rqt_slct_typEts = mysqli_query($con, $rqt_slct_typEts)){
										if(mysqli_num_rows($exe_rqt_slct_typEts)>0){
											while($tb_typEts=mysqli_fetch_assoc($exe_rqt_slct_typEts)){
												echo "<option value='".$tb_typEts["idTypEts"]."'>".$tb_typEts["designTypEts"]."</option>";
											}
										}
										else{
											echo "<option value=e>Aucun typs trouv&eacute;</option>";
										} 
									}
									else{
										echo "<option value=''>Erreur </option>";
									}?>
								</select>
                          	</div>
                      	  </td>
						</tr>
						<tr>
						  <td valign="top"><div align="right">Logo de l'&eacute;tablissement : </div></td>
						  <td>
							  <div align="left">
								<input name="file" type="file" multiple accept=".png, .jpg, .jpeg, .gif" required />
							  </div>
							  <div id="preview-file" style="width:120px; height:120px; border:solid 1px #CCCCCC; overflow:hidden;"></div>							
						  </td>
						</tr>
						
						<tr>
							<td>&nbsp;</td>
							<td>
								<div align="right">
									<input type="submit" name="BtCreerEts" value="Cr&eacute;er" />
								</div>
							</td>
						</tr>
					</table>
				</form>
			</div>
			
		</div>
	</body>
</html>

