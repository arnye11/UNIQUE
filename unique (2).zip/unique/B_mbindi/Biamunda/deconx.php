<?php 
if(isset($_GET['dc10']) && $_GET['dc10'] == "10f0000010")
	{
/*	$periode_connexion = "UPDATE personn SET connecte = 0, temps_connecte = NOW() WHERE IdPerso =".$_SESSION['idetud']."";

	if($exe_periode_connexion = mysql_query($periode_connexion))
		{
		// ????????????????????????????????
		}
	else
		{
		//sms � l'Adm : "Impossible de controler le temps de connexion de l'internaut"
		}
		
*/	
	
	// On d�truit les variables de session
	session_unset ();
	// On d�truit  session
	//session_destroy ();
	//destruiction des cookies
	unset($_COOKIE['LoginCookies']);
	unset($_COOKIE['PasswordCookies']);
	
	setcookie("LoginCookies","",time()-60, "/", "", false, true);
	setcookie("PasswordCookies","",time()-60, "/", "", false, true);
	$conx = false;
	setcookie("anne_academique","",time()-60, "/", "", false, true);
	setcookie("idAnAca","",time()-60, "/", "", false, true);
	
	header ('location:?accueil');
	
/*	if($ip_visiteur != ip_serveur)
		{
		//header ('location: http://localhost/unilo/');
		}
	else
		{
		header ('location: http://localhost/unilo/');
		}
*/	
	}

?>