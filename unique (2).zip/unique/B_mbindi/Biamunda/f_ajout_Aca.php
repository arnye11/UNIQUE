
<div style="margin:20px;" >
	<?php if (isset($_POST['BtsaveAca'])){echo $sms_gerer;} ?>
</div>
<div style="border:solid 1px #C1C1C1;">
	<form action="" method="post" name="f_ajout_Aca">
		<table style="width: 100%;" cellspacing="10">
			<tr >
				<td>
					<div align="right">
						Date début Ann&eacute;e Acad&eacute;mique :
					</div>
				</td>
				<td>
					<div align="left">
						<input type="date" name="dateDAca" value="<?php echo $dateDAca; ?>" style="width:160px; height:30px; font-size: 1.3em;" />
					</div>
				</tdd>
			</tr>
			<tr>
				<td>
					<div align="right">
						Date fin Ann&eacute;e Acad&eacute;mique : 
					</div>
				</td>
				<td>
					<div align="left">
				  		<input type="date" name="dateFAca" value="<?php echo $dateFAca; ?>" style="width:160px; height:30px;font-size: 1.3em;" />
				  	</div>
				</td>
			</tr>
			<tr>
				<td  colspan="2">
					<div style="text-align:center;">
						<input type="submit" name="BtsaveAca" value="OK" style="width:120px; height:30px;" />
					</div>
					
				</td>
			</tr>
		</table>
	</form>
</div>