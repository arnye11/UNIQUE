<?php 
	if(isset($_GET["eNseIgnAnt"]) and !isset($_GET["modIf"]) and !isset($_GET["iDenS"])){ 
?>
<h2>Ajouter un enseignant</h2>
<?php if(isset($_POST['BtEnregEns'])){ echo $sms_gerer;}?>
<form method="post" name="f_ajout_ens">
    <input type="hidden" name="iDfaC" value="<?php echo $_GET["iDfaC"]; ?>">    
	<table width="100%" border="0" cellspacing="1" cellpadding="1" style="font-size:12px;">
	  <tr>
		<td><div align="right">Nom :<sup style="color:#FF0000">*</sup> </div></td>
		<td>
		  <div align="left">
			<input type="text" name="nomEns" value="<?php if(isset($_POST['BtEnregEns'])){echo $nomEns;}?>">    
		  </div></td>
	  </tr>
	  <tr>
		<td><div align="right">Postnom :<sup style="color:#FF0000">*</sup> </div></td>
		<td><div align="left">
		  <input type="text" name="postnomEns" value="<?php if(isset($_POST['BtEnregEns'])){echo $postnomEns;}?>">
		</div></td>
	  </tr>
	  <tr>
		<td><div align="right">Prenom :<sup style="color:#FF0000">*</sup> </div></td>
		<td><div align="left">
		  <input type="text" name="prenomEns"  value="<?php if(isset($_POST['BtEnregEns'])){echo $prenomEns;}?>">
		</div></td>
	  </tr>
	  <tr>
		<td><div align="right">Sexe :<sup style="color:#FF0000">*</sup> </div></td>
		<td>
			<div align="left">
			  <select name="sexeEns" >
				<option value="<?php if(isset($_POST['BtEnregEns'])){echo $sexeEns;}?>"><?php if(isset($_POST['BtEnregEns'])){echo $sexeEns;}?></option>
				<option value="M">M</option>
				<option value="F">F</option>
			  </select>
			</div></td>
	  </tr>
	  <tr>
		<td><div align="right">Grade :<sup style="color:#FF0000">*</sup> </div></td>
		<td><div align="left">
		  <select name="gradeEns">
			<option value="<?php if(isset($_POST['BtEnregEns'])){echo $gradeEns;}?>"><?php if(isset($_POST['BtEnregEns'])){echo $gradeEns;}?></option>
			<?php 
			$rqt_grad = "SELECT * FROM tb_grade ORDER BY designGrad  ";//COURS 
				if($exe_rqt_grad = mysqli_query($con, $rqt_grad)){
					if(mysqli_num_rows($exe_rqt_grad)>0){
						while($tb_grade = mysqli_fetch_assoc($exe_rqt_grad)){
							echo "<option value='".$tb_grade["idGrad"]."'>".$tb_grade["designGrad"]."</option>";
						}
					}
					else{
						echo "<option value=''>Aucun grande enregistr�</option>";
					}
				}
				else{
					echo "<option value=''>Erreur</option>";
				}
	
				?> 
		  </select>
		</div></td>
	  </tr>
	  <tr>
		<td><div align="right">Domaine d'&eacute;tude :<sup style="color:#FF0000">*</sup> </div></td>
		<td><div align="left">
		  <input type="text" name="domaineEtudEnse" placeholder = "Par exemple(Droit)" value="<?php if(isset($_POST['BtEnregEns'])){echo $domaineEtudEnse;}?>">
		</div></td>
	  </tr>
	  <tr>
		<td><div align="right">Visiteut ou Local :<sup style="color:#FF0000">*</sup></div></td>
		<td><div align="left">
		  <select name="typeEns">
            <option value="<?php if(isset($_POST['BtEnregEns'])){echo $typeEns;}?>"><?php if(isset($_POST['BtEnregEns'])){echo $typeEns;}?></option>
            <option value="V">Visiteur</option>
            <option value="L">Local</option>
          </select>
		  </div></td>
	  </tr>
	  <tr>
		<td><div align="right">Date d'engagement : </div></td>
		<td><div align="left">
		  <input type="date" name="dateEngagEns" placeholder = "Format (jj-mm-aaaa)" value="<?php if(isset($_POST['BtEnregEns'])){echo $dateEngagEns;}?>">
		</div></td>
	  </tr>
	  <tr>
		<td><div align="right">T&eacute;l&eacute;phone :</div></td>
		<td><div align="left">
			  <!-- <input type="text" name="telEns" />-->
			  <textarea name="telEns" placeholder = "2 ou 3 num&eacute;ros de t&eacute;l&eacute;phone" ><?php if (isset($_POST['BtEnregEns'])){ echo $telEns;} ?></textarea>
		</div></td>
	  </tr>
	  <tr>
		<td>&nbsp;</td>
		<td><div align="left">
		  <input type="submit" name="BtEnregEns" value="Enregistrer">
		</div></td>
	  </tr>
	</table>

	<div style="font-style:italic"><sup style="color:#FF0000">*</sup> champ obligatoire</div>
</form>
<?php }?>