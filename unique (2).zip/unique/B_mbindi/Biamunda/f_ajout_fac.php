<?php 
  if ((isset($_GET['ajouteraJOuterFacSeCt'])) || (isset($_GET['ajouter_dep']))){
    ?>
    <h3 id="fmAjFS">ajouter une <?php if($typEts=="UN"){ echo "Facult&eacute;";}else{ echo "Section";} ?></h3>
    <div >
    	<?php if (isset($_POST['BtAjouterFacSec'])){echo $sms_gerer;} ?>
    </div>
    <form action="" method="post" name="f_ajout_dep">
      <table border="0">
        <tr>
          <td scope="col"><span>Code de la <?php if($typEts=="UN"){ echo "Faculté";}else{ echo "Section";} ?>: </span></td>
          <td scope="col"><input type="text" name="codDep"></td>
        </tr>
        <tr>
          <td>D&eacute;sigmation : </td>
          <td><input type="text" name="designDep"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input type="submit" name="BtsaveDep" value="Enregistrer"></td>
        </tr>
      </table>
    </form>
    <?php 
  }
?>
