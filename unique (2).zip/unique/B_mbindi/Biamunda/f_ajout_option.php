<?php 
	if ((isset($_GET['gerer_option'])) and (isset($_GET['ajouter_op']))){
		?>
		<script type="text/JavaScript">
			function MM_jumpMenu(targ,selObj,restore){ //v3.0
			  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
			  if (restore) selObj.selectedIndex=0;
			}
		</script>

		<h3 >Ajouter une Option</h3>
		<div >
			<?php if (isset($_POST['BtsaveOp'])){echo $sms_gerer;} ?>
		</div>
		<form action="" method="post" name="f_ajout_dep">
			<table border="0">
			  <tr>
			    <td scope="col">Code Option: </td>
			    <td scope="col"><div align="left"><input type="text" name="codOp"></div></td>
			  </tr>
			  <tr>
			    <td>D&eacute;sigmation : </td>
			    <td><div align="left"><input type="text" name="designOp" style="width:293px"></div></td>
			  </tr>
			  <tr>
			    <td>Facult&eacute; : </td>
			    <td>
						<div align="left">
						  <select name="idFac"  style="width:300px;">
						    <?php 
									$rqt_list_fac = "select * from  tb_faculte order by designFac";
									if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
									  echo "<option value=''></option>";
										while($tab_fac = mysqli_fetch_assoc($exe_rqt_list_fac)){
											?>
									    	<option value="<?php echo $tab_fac['idFac']; ?>">
									    		<?php echo $tab_fac['designFac']; ?>
									    	</option>
								    	<?php 
											}
										}
									else
										{
										echo  "<option value=''> <div style='color:FF0000'> Impossible d&acute;atteindre les d&eacute;partement organis&eacute;s . <br/>SVP, contacter urigement l&acute;Administrateur pour l&acute;assistance.</div> < /option>";
										}
								?>
					    </select>
				    </div>
				  </td>
			  </tr>
			  <tr>
			    <td>&nbsp;</td>
			    <td>
			    	<div align="left"><input type="submit" name="BtsaveOp" value="Enregistrer"></div>
			    </td>
			  </tr>
			</table>
		</form>
		<?php 
	}
?>
