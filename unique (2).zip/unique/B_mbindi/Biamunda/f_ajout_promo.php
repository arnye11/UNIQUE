<?php 
if ((isset($_GET['gerer_promotion'])) and (isset($_GET['ajouter_pro']))){
?>
<h3 >ajouter une Promotion</h3>
<div >
	<?php if (isset($_POST['BtsavePro'])){echo $sms_gerer;} ?>
</div>
<form action="" method="post" name="f_ajout_pro">

<table border="0">
  <tr>
    <th scope="col"><div align="right"><span>Code Promotion : </span></div></th>
    <th scope="col">
		<div align="left">
		  <input name="codPro" style="width:60px;">
          </div></th>
  </tr>
  <tr>
    <td><div align="right">D&eacute;sigmation : </div></td>
    <td><div align="left">
      <input type="text" name="designPro">
    </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="left">
      <input type="submit" name="BtsavePro" value="Enregistrer">
    </div></td>
  </tr>
</table>

</form>
<?php 
}
?>
