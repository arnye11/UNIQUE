<?php 
if ((isset($_GET['gerer_cours'])) and (isset($_GET['ajouter_cours']))){
?>

<h3 >Ajouter un Cours </h3>
<div >
	<?php if (isset($_POST['BtsaveCours'])){echo $sms_gerer;} ?>
</div>
<form action="" method="post" name="f_ajout_Cours">

<table border="0">
  <tr>
    <th><div align="right"><span>Code  : </span></div></th>
    <th><div align="left">
      <input type="text" name="codCours">
    </div></th>
  </tr>
  <tr>
    <td><div align="right">D&eacute;sigmation : </div></td>
    <td><div align="left">
        <input type="text" name="designCours">
    </div></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td>
		<div align="left">
		  <input type="submit" name="BtsaveCours" value="Enregistrer" />
		</div>	</td>
  </tr>
</table>

</form>
<?php 
}
?>
