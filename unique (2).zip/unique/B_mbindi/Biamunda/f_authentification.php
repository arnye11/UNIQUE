<!-- FORMULAIRE DE CONNEXION -->

<style type="text/css">
	<!--
		/******__________AUTHATIFICATION___________________________________*******/
		.z_authentification{
			width: 100%;
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}
		.zonFormAthatification_et_sms{
			height:auto; 
			border:solid 0px #c3c3c3; 
			color: #003858;
			width: 30%;
		}
		.logoEts{
			max-width:5%; 
		}
		.zonFormAuthantification{
			margin: 20px;
			height:auto;
		}
		.zonInputEmail, .zonInputMotdePasse, .zonBtConnexion{
			height:auto; 
			margin:20px;
		}

		#inputEmail, #InputMotdePasse, .InputBtConnexion{
			width:100%;
			height:50px;
			border: solid 1px #c3c3c3;
			background:#FFFFFF;
			font-size:1.5em;
			margin-bottom: 20px;
		}
		.inputEmailIncorrect, .InputMotdePasseIncorrect{
			background:#FFFFFF;
			border:solid 1px #FF0000;
			box-shadow:0px 2px 2px 0px #FF0000;
		}
		.InputBtConnexion	{
			background:#003858;
			border-radius:9px;
			color:#FFFFFF;
			cursor:pointer;
			
		}

		@media (max-width : 75em){
			.zonFormAthatification_et_sms{
				width: 53%;
			}
			footer  .rubrique{
	            width: 100%;
	        }
		}
		@media (max-width : 65em){
			.zonFormAthatification_et_sms{
				width: 56%;
			}
			#inputEmail, #InputMotdePasse, {
				width:100%;
				height:3em;
				background:#FFFFCC;
				font-size:1.3em;
			}
			
			
		}
		.piedpg{
			width: 50%;
			height:auto; 
			color: #000000;
			font-size: 1em; 
			text-align: center; 
			top: auto;
		}
		.toutdroit{
	       padding:20px;
	    }
	    @media (max-width: 48em){
	        .zonFormAthatification_et_sms{
				width: 100%;
			}
			footer  .rubrique{
	            display: block;
	            width: 100%;
	        }
	        .toutdroit{
	            font-size: 12px;
	        }
	    }
	-->
</style>
<div class="z_authentification">
	<div class="z_logo_ets">
		<a href="?accueil">
			<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="Logo Ets" class="logoEts" />
		</a>
	</div>
	<div>
		<?php echo $sigle_tb_etablissement; ?>
	</div>
	<div class="zonFormAthatification_et_sms">
		<div style="height:50px; font-size:2em; text-align: center; line-height:50px;">
			Connectez-vous
		</div>
	 	<!-- ZONE DES NOTIFICATIONS SI LA CONNEXION ECHOUE -->
	  	<div style="height:auto; font-size:1.5em; color:#ff0000; text-align: center; margin: 20px;" >
			<?php 
				if(isset($_POST['BtConx'])){ 
					?>				
		     			<samp><?php echo $sms_authatification;?></samp>	    		
			  		<?php
				}
			?>
		</div>
		<div class="zonFormAuthantification">
			<form name="F_se_connecter" method="post" action="">
		 		<div class="zonInputEmail">
					<input type="text" name="login" class="<?php if(isset($_POST['BtConx']) and $conx ==false){echo 'inputEmailIncorrect';}?>" id="inputEmail" title="Entre votre Login ici" size="30" placeholder="Saisissez votre compte"  value="<?php echo $login;?>" autofocus />
				</div>
				<div class="zonInputMotdePasse">
					<input  type="password" name="motdepasse" class="<?php if(isset($_POST['BtConx']) and $conx ==false){echo 'InputMotdePasseIncorrect';}?>" id="InputMotdePasse" title="Saisissez votre mot de passe ici" size="15" placeholder="Votre mot de passe ici" value="<?php echo $password; ?>"/>
				</div>
			  	
				<div class="zonBtConnexion" >
					<input type="submit"  name="BtConx" class="InputBtConnexion" value="Connexion"/>
				</div>
			</form>
		</div>
	</div>
	<!-- FIN DU FORMULAIRE DE CONNEXION -->


	<div class="piedpg">
		<div class="toutdroit">
			UNIQUE -  <?php echo $annee_encours; ?> | Tout droit r&eacute;serv&eacute; au 
			<a href="?apropos#arnye" style="color:#003958;"><strong>CRTN</strong></a> |
			<a href="licence/Contrat_licence_UNIQUE_UKA_21082023.pdf">Lisez le termes de licence</a>
			<br>Contacts : +243 823664195,  +243 847423368,  +243 998022336
		</div>
		
		<div  align="center" style="width:72px;height:33px; border-radius:50px; position:fixed; top:auto; bottom:2%; left:auto; right:1%; font-size:12px; font-family:'Century Schoolbook'; border:solid 1px #A0A0A4; color:#A0A0A4; ">
			UNIQUE <br>v.<?php echo $version; ?>
		</div>
	</div>
</div>