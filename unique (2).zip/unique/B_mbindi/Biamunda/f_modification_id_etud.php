<div align="center" style=" width:99%; background:#DDDDDD; border:solid 1px #000088;">
<div align="center" style="border-bottom:solid 1px #000088; font-size:20px;">Modification d'identit�s<br/>
	<?php if($champ == false and isset($_POST['BtEnreg'])){echo $sms_updt_id;} ?>
</div>
<form method="post">
		<table border="0">
		  
		  <tr>
			<td><div align="right">Nom<sup class="echec">*</sup> : </div></td>
			<td>
				<div align="left">
				  <input type="text" name="nom" value="<?php echo $result_slct_etud['nomEtud'];?>" />
				</div></td>
		  </tr>
		  <tr>
		    <td><div align="right">Postnom<sup class="echec">*</sup> : </div></td>
		    <td>
				<div align="left">
				  <input type="text" name="postnom" value="<?php echo $result_slct_etud['postnomEtud'];?>"/>
		        </div></td>
	      </tr>
		  <tr>
		    <td><div align="right">Pr&eacute;nom<sup class="echec">*</sup> : </div></td>
		    <td>
				<div align="left">
				  <input type="text" name="prenom" value="<?php echo $result_slct_etud['prenomEtud'];?>"/>
		        </div></td>
	      </tr>
		  <tr>
		    <td><div align="right">Sexe<sup class="echec">*</sup> : </div></td>
		    <td>
				<div align="left">
				  <select name="sexe">
				    <option value="<?php echo $result_slct_etud['sexeEtud'];?>"><?php echo $result_slct_etud['sexeEtud'];?></option>
				    <option value="M">M</option>
				    <option value="F">F</option>
			      </select>
		        </div></td>
	      </tr>
		  <tr>
		    <td><div align="right">Date de naissance<sup class="echec">*</sup> : </div></td>
		    <td>
				<div align="left">Jour 
				  <select name="jrNaiss">
				    <option value="<?php echo $result_slct_etud['jrNais'];?>">
				      <?php if ($result_slct_etud['jrNais']<10){ echo "0".$result_slct_etud['jrNais'];}else{echo $result_slct_etud['jrNais'];}?>
			        </option>
				    <?php 
					$jrNaiss=0;
					for($jrNaiss = 1; $jrNaiss<32; $jrNaiss++)
						{
						echo "<option value='".$jrNaiss."'>"; 
						if($jrNaiss<10){ echo "0".$jrNaiss;}else{echo $jrNaiss;}
						echo "</option>";
						}
					?>
			        </select>
				Moi 
				<select name="moiNaiss">
				  <option value="<?php echo $result_slct_etud['mmNais'];?>">
				    <?php 
						switch ($result_slct_etud['mmNais'])
							{ 
							case 1 : echo "Janvier";
								break;
							case 2 : echo "F�vrier";
								break;
							case 3 : echo "Mars";
								break;
							case 4 : echo "Avril";
								break;
							case 5 : echo "Mai";
								break;
							case 6 : echo "Juin";
								break;
							case 7 : echo "Juillet";
								break;
							case 8 : echo "Ao�t";
								break;
							case 9 : echo "Septembre";
								break;
							case 10 : echo "Octobre";
								break;
							case 11 : echo "Novembre";
								break;
							case 12 : echo "D�cembre";
								break;
							default:
								echo "Inconnu";
							
							}
						?>
			      </option>
				  <?php 
					$mNaiss=0;
					for($mNaiss = 1; $mNaiss<13; $mNaiss++)
						{
						echo "<option value='".$mNaiss."'>"; 
						switch ($mNaiss)
							{ 
							case 1 : echo "Janvier";
								break;
							case 2 : echo "F�vrier";
								break;
							case 3 : echo "Mars";
								break;
							case 4 : echo "Avril";
								break;
							case 5 : echo "Mai";
								break;
							case 6 : echo "Juin";
								break;
							case 7 : echo "Juillet";
								break;
							case 8 : echo "Ao�t";
								break;
							case 9 : echo "Septembre";
								break;
							case 10 : echo "Octobre";
								break;
							case 11 : echo "Novembre";
								break;
							case 12 : echo "D�cembre";
								break;
							default:
								echo "Inconnu";
							
							}
						echo "</option>";
						}
					?>
				  </select>
				Ann�e
                <select name="aNaiss">
                  <option value="<?php echo $result_slct_etud['aaaaNais'];?>"><?php echo $result_slct_etud['aaaaNais'];?></option>
                  <?php 
					$aNaiss=0;
					for($aNaiss = 1970; $aNaiss<$annee_encours; $aNaiss++)
						{
						echo "<option value='".$aNaiss."'>".$aNaiss."</option>";
						}
					?>
                </select>
			    </div></td>
	      </tr>
		  <tr>
		    <td><div align="right">Lieu de naissance<sup class="echec">*</sup> : </div></td>
		    <td>			  <div align="left">
		      <input type="text" name="lieuNaiss" value="<?php echo $result_slct_etud['lieunaisEtud'];?>"/>            
	        </div></td>
	      </tr>
		  <tr>
		    <td><div align="right">Adresse d'habutation : </div></td>
		    <td>
				<div align="left">
				  <textarea name="adressH" style="width:260px; height:30px"><?php echo $result_slct_etud['adresseEtud'];?></textarea>
		        </div></td>
	      </tr>
		  <tr>
		    <td><div align="right">Num�ro de t�l�phone : </div></td>
		    <td>
				<div align="left">
				  <input type="text" name="tel" value="<?php echo $result_slct_etud['telEtud'];?>"/>
		        </div></td>
	      </tr>
		  <tr>
		    <td><div align="right">E-mail : </div></td>
		    <td>
				<div align="left">
				  <input type="text" name="email" value="<?php echo $result_slct_etud['emailEtud'];?>"/>
		        </div></td>
	      </tr>
		  <tr>
		    <td colspan="2"><div align="center"><span style="font-size:12px; font-family:'Times New Roman'; font-style:italic; color:#FF6600">Tout champ signal&eacute; par <sup class="echec">*</sup> est obligatoire. </span></div></td>
	      </tr>
		  <tr>
		    <td><a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&modification_profil" > <div align="center" style="width:100%; height:22px; color:#EEEEEE; background:#000077; border-radius:10px;">Annuler</div></a></td>
		    <td>
				<input type="submit" name="BtEnreg" value="Enregistrer les modifications" style="width:100%; height:25px; color:#EEEEEE; background:#000077; border-radius:10px;"/>			</td>
	      </tr>
		</table>
</form>
</div>