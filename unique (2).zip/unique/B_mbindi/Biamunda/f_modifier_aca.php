<?php 
if (isset($_GET['gerer_aca']) and isset($_GET['modifier_aca']) and isset($_GET['aca']) and $idAca_modif != true)
	{ 
	function mois_lettre_select_option($mois){
		switch($mois)
			{
			case 1:
				echo"Janvier";
				break;
			case 2:
				echo"F&eacute;vrier";
				break;
			case 3:
				echo"Mars";
				break;
			case 4:
				echo"Avril";
				break;
			case 5:
				echo"Mai";
				break;
			case 6:
				echo"Juin";
				break;
			case 7:
				echo"Juillet";
				break;
			case 8:
				echo"Ao&ucirc;t";
				break;
			case 9:
				echo"Septembre";
				break;
			case 10:
				echo"Octobre";
				break;
			case 11:
				echo"Novembre";
				break;
			case 12:
				echo"D&eacute;cembre";
				break;
			}				

	}
?>

<h2>Modification de l'Ann&eacute;e acad&eacute;mique <br /><?php echo $idAca_a_modif; ?></h2>
<span>Surtout faites attention</span><br/><br/>
<?php if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo $sms_gerer;}else{ echo $sms_gerer;}?>
<form action="" method="post" name="f_updt_Aca">

<table border="0">
  <tr>
    <td scope="col"><div align="right"><span>Date d'ouverture &nbsp; </span></div></td>
    <td scope="col">
		<div align="left">
		<!--Jour -->
		J :  
		  <select name="jrD" style="width:50px;">
		    <option value="<?php if ($idAca_modif == false){echo $jrD_a_modif;} ?>">
				<?php if($idAca_modif == false){ if($jrD_a_modif<10){echo "0".$jrD_a_modif;}else{echo $jrD_a_modif;}} ?>
			</option>
			<?php jours_select_option();//voir var.php ?>
	      </select>
		<!--Mois -->
		&nbsp;&nbsp;M :
		  <select name="mmD" style="width:100px;">
		    <option value="<?php if ($idAca_modif == false){echo $mmD_a_modif;} ?>"><?php if ($idAca_modif == false){mois_lettre_select_option($mmD_a_modif);} ?></option>
				<?php mois_selct_option();//voir var.php ?>
		   </select>
		<!--Ann�e -->
		&nbsp;&nbsp;A :
     		<input type="text" name="aaaaD" value="<?php if ($idAca_modif == false){echo $aaaaD_a_modif;} ?>" style="width:35px;">
        </div>
		</td>
  </tr>
  <tr>
    <td><div align="right">Date de fermeture &nbsp; </div></td>
    <td>
	<div align="left">
		<!--Jour -->
		&nbsp;J : 
		  <select name="jrF" style="width:50px;">
		    <option value="<?php if ($idAca_modif == false){echo $jrF_a_modif;} ?>">
				<?php if($idAca_modif == false){ if($jrF_a_modif<10){echo "0".$jrF_a_modif;}else{echo $jrF_a_modif;}} ?>
			</option>
			<?php jours_select_option();//voir var.php ?>
	      </select>
		<!--Mois -->
		&nbsp;&nbsp;M :
		  <select name="mmF" style="width:100px;">
		    <option value="<?php if ($idAca_modif == false){echo $mmF_a_modif;} ?>">
				<?php if ($idAca_modif == false){mois_lettre_select_option($mmF_a_modif);} ?>
			</option>
			<?php mois_selct_option();//voir var.php ?>
		  </select>
		<!--Ann�e -->
		&nbsp;&nbsp;A :
     	 <input type="text" name="aaaaF" value="<?php if ($idAca_modif == false){echo $aaaaF_a_modif;} ?>" style="width:35px;">
    </div>
	</td>
  </tr>
  <tr>
    <td><div align="center" style="border:solid 1px #2A3F55;"><a href='?gerer_aca&modifier_aca'>ANNULER</a></div></td>
    <td>
      <div align="right">
        <input type="submit" name="BtUpdateAca" value="Enregistrer">
        </div></td></tr>
</table>

</form>

<?php 
	}
if($idAca_modif == true)
	{
	echo $sms_gerer;
	}
?>
