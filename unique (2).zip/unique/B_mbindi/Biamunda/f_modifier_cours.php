<?php 
if ((isset($_GET['gerer_cours'])) and (isset($_GET['modifier_cours'])) and (isset($_GET['cours'])))
	{ 
?>

<h2>Modification de Cours </h2>
<?php if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo $sms_gerer;}else{ echo $sms_gerer;}?>
<form action="" method="post" >

<table border="0">
  <tr>
    <td><div align="right"><span>Code  : </span></div></td>
    <td><div align="left">
	<?php if($idCoursCote == true){?>
      <input type="text" name="codCours"value="<?php if ($champs == true){ echo $codCours;} ?>">
	  <?php }else{ ?>
      <input type="text" disabled="disabled" value="<?php if ($champs == true){ echo $codCours;} ?>">
      <input type="hidden" name="codCours"value="<?php if ($champs == true){ echo $codCours;} ?>">
	  <?php }?>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">D&eacute;sigmation : </div></td>
    <td><div align="left">
        <input type="text" name="designCours" value="<?php if ($champs == true){ echo $designCours;} ?>">
    </div></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td>
		<div align="left">
		  <input type="submit" name="BtUpdtCours" value="Enregistrer" />
		</div>	</td>
  </tr>
</table>

</form>
<?php 
	}
?>
