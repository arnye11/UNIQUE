<?php 
if (isset($_GET['gerer_departement']) and isset($_GET['modifier_dep']) and isset($_GET['dep']))
	{ 
?>

<h2>Modification de la Facult&eacute;</h2>
<?php if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo $sms_gerer;}else{ echo $sms_gerer;}?>
<form action="" method="post">
  <table border="0">
  <tr>
    <th scope="col"><div align="right">code : </div></th>
    <th scope="col"><div align="left">
	<?php if($idfac_modif_op == true){?>
      <input type="text"  name="codfac" value="<?php if ($champs == true){ echo $idfac;} ?>">
	  <?php }else{ ?>
	  <input type="text" disabled="disabled" value="<?php if ($champs == true){ echo $idfac;} ?>"> 
	  <input type="hidden"  name="codfac" value="<?php if ($champs == true){ echo $idfac;} ?>"> 
	  <?php }?>
	  
    </div></th>
  </tr>
  <tr>
    <th scope="col"><div align="right">D&eacute;signation : </div></th>
    <th scope="col"><div align="left">
      <input type="text" name="DesignFacModf" value="<?php if ($champs == true){ echo $designFac;} ?>">
    </div></th>
  </tr>
  <tr>
    <th scope="col"><div align="right" style="border:solid 1px #2A3F55;"><a href='?gerer_departement&modifier_dep'>ANNULER</a></div></th>
    <th scope="col"><div align="right">
      <input type="submit" name="BtUpdateFac" value="Mettre &agrave; jour">
    </div></th>
  </tr>
</table>

</form>
<?php 
	}
?>
