<?php 
  if (isset($_GET['gerer_option']) and isset($_GET['modifier_op']) and isset($_GET['op'])){ 
    ?>
    <h2>Modification de l&acute;Option</h2>
    <?php 
      if(isset($_GET['sms_gerer'])){
        $sms_gerer = $_GET['sms_gerer']; 
        echo $sms_gerer;
      }
      else{ 
        echo $sms_gerer;
      }
    ?>
    <form action="" method="post">
      <table border="0">
        <tr>
          <td scope="col"><div align="right">code : </div></td>
          <td scope="col">
            <div align="left">
              <?php 
                if($idOp_modif_inscrit == true){
                  ?>
                  <input type="text" name="codOp" value="<?php if ($champs == true){ echo $idOp;} ?>">
                  <?php 
                }
                else{ 
                  echo $idOp;
                  ?>
                  <input type="hidden" name="codOp" value="<?php if ($champs == true){ echo $idOp;} ?>">
                  <?php 
                }
              ?>
            </div>
          </td>
        </tr>
        <tr>
          <td scope="col"><div align="right">D&eacute;signation : </div></td>
          <td scope="col">
            <div align="left">
              <input type="text" name="DesignOpModf" value="<?php if ($champs == true){ echo $designOp;} ?>">
            </div>
          </td>
        </tr>
        <tr>
          <td scope="col">Facult&eacute;: </td>
          <td scope="col">
            <div align="left">
              <select name="idFac"  style="width:300px;">
                <?php 
            			$rqt_list_fac = "select * from  tb_faculte";
            			if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
            			  	echo "<option value=''></option>";
            				while($tb_faculte = mysqli_fetch_assoc($exe_rqt_list_fac)){
                      ?>
                      <option value="<?php echo $tb_faculte['idFac']; ?>">
                        <?php echo $tb_faculte['designFac']; ?>
                      </option>
                      <?php 
            				}
            			}
            			else{
            				echo  "<option value=''> <div style='color:FF0000'> Impossible d&acute;atteindre la facult&eacute; organis&eacute;s . <br/>SVP, contacter urigement l&acute;Administrateur pour l&acute;assistance.</div> < /option>";
            			}
          		  ?>
              </select>
            </div>
          </th>
        </tr>
        <tr>
          <th scope="col"><div align="right"><a href=''>ANNULER</a></div></th>
          <th scope="col">
            <div align="right">
              <input type="submit" name="BtUpdateOp" value="Mettre &agrave; jour">
            </div>
          </th>
        </tr>
      </table>
    </form>
    <?php 
	}
?>
