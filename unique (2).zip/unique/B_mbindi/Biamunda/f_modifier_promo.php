<?php 
if (isset($_GET['gerer_promotion']) and isset($_GET['modifier_pro']) and isset($_GET['pro']))
	{ 
?>

<h2>Modification de la Promotion</h2>
<?php if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo $sms_gerer;}else{ echo $sms_gerer;}?>
<form action="" method="post">
  <table border="0">
  <tr>
    <th scope="col"><div align="right">code : </div></th>
    <th scope="col">
		<div align="left"><?php  echo $idpro;?></div>
      	<input type="hidden" name="codPro" value="<?php if ($champs != true){ echo $idpro;} ?>">
	</th>
  </tr>
  <tr>
    <th scope="col"><div align="right">D&eacute;signation : </div></th>
    <th scope="col"><div align="left">
      <input type="text" name="DesignProModf" value="<?php if ($champs != true){ echo $designpro;} ?>">
    </div></th>
  </tr>
  <tr>
    <th scope="col"><div align="right"><a href=''>ANNULER</a></div></th>
    <th scope="col"><div align="right">
      <input type="submit" name="BtUpdatePro" value="Mettre &agrave; jour">
    </div></th>
  </tr>
</table>

</form>
<?php 
	}
?>
