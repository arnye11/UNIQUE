<form action="" method="post">
Promotion 
      <select name="idPromo"  style="width:5%;">
        <?php 
			$rqt_list_promotion = "select * from  tb_promotion ORDER BY idPromo ASC";
			if($exe_rqt_list_promotion = $conDb->query($rqt_list_promotion))
				{
				echo "<option value='".$idPromo."'>".$idPromo."</option>";
				while($result_exe_rqt_list_promotion = $exe_rqt_list_promotion->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{?>
					<option value="<?php echo $result_exe_rqt_list_promotion['idPromo']; ?>"><?php echo $result_exe_rqt_list_promotion['idPromo']; ?></option>
					<?php 
					}
				}
			else
				{?>
				<option style="color:#FF3333;" value="" >Impossible d'atteindre les promotions organis�es. SVP, contacter urigement l'Administrateur pour l'assistance.</option>
				<?php 
				}
		  
		  ?>
      </select>
	  
Option 
		<select name="idOp"  style="width:40%;">
		<?php 
			$rqt_list_option = "select * from  tb_option order by designOp";
			if($exe_rqt_list_option = $conDb->query($rqt_list_option))
				{
			  	echo "<option value='".$idOp."'>".$designOp."</option>";
				while($result_exe_rqt_list_option = $exe_rqt_list_option->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{?>
					<option value="<?php echo $result_exe_rqt_list_option['idOp']; ?>"><?php echo $result_exe_rqt_list_option['designOp']; ?></option>
					<?php 
					}
				}
			else
				{
				echo  "<option style='color:FF0000' value=''>Impossible d'atteindre les options organis�es. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.</option>";
				}
		  
		  ?>
		</select>
		<?php if(isset($_GET['gRillDelib'])){?>
		S1<input type="radio" name="session" value="s1" <?php if ($session=="s1"){ echo "checked"; }?> />&nbsp;&nbsp;
		S2<input type="radio" name="session" value="s2" <?php if ($session=="s2"){ echo "checked"; }?> />
		<?php }?>
<input name="BtChargerNomEtd" type="submit" value="Charger " />	 
</form>