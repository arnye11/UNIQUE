<?php 
if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and ($_GET['iDfaC'] != "")) {
?>
<!-- Ajout du lien vers Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Styles supplémentaires pour les colonnes -->
<style>
    .custom-scroll {
        max-height: 80vh; /* Limite la hauteur à 75% de la hauteur de la fenêtre */
        overflow-y: auto; /* Active le défilement vertical */
    }
</style>

<!-- Conteneur principal avec Bootstrap -->
<div class="container-fluid py-0">
    <div class="row g-3">
        <!-- Colonne gauche : divList_Info -->
        <div class="col-md-3 col-12 custom-scroll border p-3 bg-light shadow-sm">
            <?php 
                include("B_mbindi/Biamunda/faculte_volet1.php");
                include("B_mbindi/Biamunda/rqt/rqt_list_option.php");
                include("B_mbindi/Biamunda/rqt/rqt_list_promo.php");
                include("B_mbindi/Biamunda/rqt/rql_list_aca.php");
                include("B_mbindi/makuta/rql_list_fr.php");
                include("B_mbindi/Biamunda/rqt/rqt_slct_l_inscrit.php");
                include("B_mbindi/makuta/rqt_fr_exige_pour_exames.php");
                include("B_mbindi/batumikishi/rqt_list_administratifs.php");
                include("B_mbindi/Biamunda/rqt/rqt_promo_op_org.php");
            ?>
        </div>

        <!-- Colonne droite : div_Form_AMS -->
        <div class="col-md-9 col-12 custom-scroll border p-3 bg-white shadow-sm">
            <?php 
                include("B_mbindi/Biamunda/faculte_volet2.php");
                include("B_mbindi/Biamunda/gerer_D_O_P_A_I_F_E.php");
                if (!isset($_GET["fAculTe"])) {
                    include("B_mbindi/Biamunda/menuAMS.php");
                }
                include("B_mbindi/Biamunda/rqt/rqt_list_opt_a_modifier.php");
                include("B_mbindi/Biamunda/rqt/rqt_list_promo_a_modifier.php");
                include("B_mbindi/Biamunda/rqt/rqt_list_aca_a_modifier.php");
                include("B_mbindi/makuta/rqt_list_fr_a_modifier.php");
                include("B_mbindi/Biamunda/rqt/rqt_slct_list_op_a_sup.php");
                include("B_mbindi/Biamunda/rqt/rqt_slct_list_promo_a_sup.php");
                include("B_mbindi/Biamunda/rqt/rqt_slct_list_aca_a_sup.php");
                include("B_mbindi/makuta/rqt_slct_list_fr_a_sup.php");
                include("B_mbindi/makuta/rql_list_fr_a_fix.php");
                include("B_mbindi/Inscription/rqt_situation_inscription_critere.php");
                include("B_mbindi/makuta/rqt_ctrl_etudiant_en_ordre.php");
                include("B_mbindi/makuta/rqt_rapport_fr.php");
                include("B_mbindi/Biamunda/f_ajout_option.php");
                include("B_mbindi/Biamunda/f_ajout_promo.php");

                if (isset($_GET['gerer_aca']) and isset($_GET['ajouter_aca'])) {
                    include("B_mbindi/Biamunda/f_ajout_aca.php");
                }

                include("B_mbindi/makuta/f_ajout_fr.php");
                include("B_mbindi/batumikishi/f_ajout_utiliseur.php");
                include("B_mbindi/Biamunda/f_modifier_op.php");
                include("B_mbindi/Biamunda/f_modifier_promo.php");
                include("B_mbindi/Biamunda/f_modifier_aca.php");
                include("B_mbindi/makuta/f_modifier_fr.php");
                include("B_mbindi/batumikishi/profil_administratif.php");
                include("B_mbindi/Biamunda/organisation_op_promo.php");
            ?>
        </div>
    </div>
</div>
<?php  
}
?>
