<?php 
	if ((isset($_GET['accueil']) || $accueil==true)){ 
		?>
		<style type="text/css">
			<!--
			.facOrg{
				width:99%;
			}
			.faculte1{
				display:inline-block;
				width:20%;
				margin: 10px;
				background: #005f7e;
			}
			.faculte{
				width:100%; 
				height: auto; 
				border: solid 1px #cdcdcd;
				overflow: hidden;
				background: #F2F0F0;
				color: #005F7E;
			}
			.faculte:hover {
				color: #005f7e;
				box-shadow: 0px 2px 6px 0px #005f7e;
				border: solid 1px #005f7e;
				background: #005f7e;
				color: #ffffff;
				
			}
			.faculte :hover #imag{
				color: #005f7E;
				
			}
			.edit{
				display: inline-block;
				position: relative;
				float: right;
				width: 20px;
				height: 18px;
				margin-top: -117px; 
				padding-top: 2px
			}
			.edit:hover{
				border-left:solid 1px #cdcdcd;
				border-bottom:solid 1px #cdcdcd;
				box-shadow: 2px 2px 6px 0px #005f7e;
			}
			.fac {
				margin-bottom:5px; 
				background:#F0F0F0; 
				text-transform:none;
				color: #10076b;
			}
			.fac:hover {
				text-transform: uppercase;
				height: auto;
				background: #ccccff;
				color: #0033cc;
			}
			.supFiliere{
				display:inline-block;
				width: 40px;
				height: 34px; 
				position:relative;
				float: left;
				line-height: 40px;
				padding-top: 6px;
			}
			.supFiliere:hover{
				background: #ff0000;
			}

			@media (max-width : 70em){
				.fac{
					width:98%;
				}
				.facOrg{
					width:98%;
				}
				.faculte1{
					width:22%;
				}
				
			}
			@media (max-width : 60em){
				.faculte1{
					width:30%;
				}
				
			}
			@media (max-width : 50em){
				.faculte1{
					width:40%;
				}
				
			}
			-->
		</style>
		<div style='border-bottom:groove'>
			<h2>
				<?php 
					if ($_SESSION['typEts']=="UN") 
						echo "FACULTES ORGANISEES";
					
					else if ($_SESSION['typEts']=="IS" || $_SESSION['typEts']=="ES") 
						echo "SECTIONS ORGANISEES";
					
					else
						echo "PROMOTIONS ORGANISEES";
				?>
			</h2>
		</div>
		<div class='facOrg' style="">
			<?php
				if (isset($_GET["sms"])) {
					echo "<div style='color:#009900'>".$_GET["sms"]."</div>";
				}
				$rqt_list_fac = "SELECT * FROM  tb_faculte WHERE idEts ='".$idEts."'  ORDER BY designFac";
				if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
					if($exe_rqt_list_fac->num_rows>0){
						while($result_rqt_list_fac = mysqli_fetch_assoc($exe_rqt_list_fac)) {
							if($_SESSION['FacAttach']==$result_rqt_list_fac['idFac'] or $_SESSION['FacAttach']=="TOUTES"){
								if (isset($_GET['EditFacSec']) and isset($_GET['id']) and $_GET['id']  == $result_rqt_list_fac['idFac'] and $_SESSION['idAutoDec']=="admin1"){
									$code = $result_rqt_list_fac['idFac'];
									?>
									<div class="faculte1" style="" id="<?php echo  $result_rqt_list_fac['idFac']; ?>">
										<form method="post">
											<div class="faculte" style="background: #005f7e;">
												<div id="imag" style="height:75px; font-size: 15px;background: #FFFFFF; color:#005F7E">
													<div>
														<?php 
															if (isset($_POST['BtModifFacSec']))
																echo $sms_gerer;
															else
																echo "Modifier la Fili&egrave;re"; 
														?>
													</div>
													<input type="hidden" name="idEts" value="<?php echo $idEts; ?>">
													<input type="hidden" name="idFac" value="<?php echo $code; ?>">
													<textarea rows="2" name="designFac" style="width:94%; font-size: 1.1em;" autofocus placeholder="Exemple : Economie"><?php echo $result_rqt_list_fac['designFac']; ?></textarea>	
												</div>
												<div style="height:40px; line-height:40px;">
													<?php 
														$rqt_VerifOpFil = "select * from tb_option where idFac = '".$result_rqt_list_fac['idFac']."'";
														if($ex_rqt_VerifOpFil = mysqli_query($con, $rqt_VerifOpFil)){
															 if($ex_rqt_VerifOpFil->num_rows<=0){
																?>
																<div style="" class="supFiliere" title="Supprimer">
																	<a href="?SupPriMfIlIerE&idFiliERe=<?php echo $result_rqt_list_fac['idFac'] ; ?>">
																		<img src="B_mbindi/Biamunda/icon/sup.gif" style="max-width: 70%; max-height: 70%;">
																	</a>
																</div>
																<?php
															}
															
														}
														
													?>
													
													
													<a href="?" title="" style="color:#FFFFFF;">Fermer</a>&nbsp;&nbsp;
													<input type="submit" name="BtModifFacSec" value="OK" style="width:30%;">			
												</div>
											</div>
										</form>
									</div>
									<?php 
								}
								else{
									?>
									<div class="faculte1" style="" id="<?php echo  $result_rqt_list_fac['idFac']; ?>">
										<a href="?fAculTe&iDfaC=<?php echo $result_rqt_list_fac['idFac'] ;?>">
											<div class="faculte" style="">
												<div id="imag" style="height:75px; line-height: 75px; font-size: 2em; font-weight:bold;background: #FFFFFF; color:#005F7E">
													<img src="B_mbindi/Biamunda/icon/.png" alt="<?php echo substr($result_rqt_list_fac['designFac'], 0, 4)."."; ?>" style="max-width: 100%; max-height: 100%;">
												</div>
												<div style="height:40px;<?php if (strlen($result_rqt_list_fac['designFac'])<24){?> line-height: 40px;<?php } ?>">
													<?php 
														echo $result_rqt_list_fac['designFac'] ;
													?>
												</div>
											</div>
										</a>
										<?php 
											if($_SESSION['idAutoDec']=="admin1"){
												?>
												<div class="edit" id="">
													<a href="?EditFacSec&id=<?php echo  $result_rqt_list_fac['idFac']; ?>#<?php echo  $result_rqt_list_fac['idFac']; ?>"><img src='B_mbindi/Biamunda/icon/edit.gif' class='icon' alt='Edit.' title='Modifier' /></a>
												</div>	
												<?php  
											}
										?>
									</div>
									<?php 
								} 
							}
						}
					}
					else{
						if($_SESSION['idAutoDec']=="admin1"){
							echo "<div style='font-size: 1em;margin:20px;'>Pri&eacute;re de cliquer sur le <b>+</b> pour ajouter les Fili&eacute;res</div>";
						}
						else{
							echo "<div style='font-size: 1em;margin:20px;'>Aucune Fili&eacute;res n'est organis&eacute;e jusque et l&agrave;</div>";
						}
					}
					if($_SESSION['idAutoDec']=="admin1"){
						if (isset($_GET['ajouteraJOuterFacSeCt'])){
							$code = "F".random_int(100, 9999).$version ;
							?>
							<div class="faculte1" style="" id="fmAjFS">
								<form method="post">
									<div class="faculte" style="background: #005f7e;">
										<div id="imag" style="height:75px; font-size: 15px;background: #FFFFFF; color:#005F7E">
											<div>
												<?php echo $sms_gerer; ?>
											</div>
											<input type="hidden" name="idEts" value="<?php echo $idEts; ?>">
											<input type="hidden" name="idFac" value="<?php echo $code; ?>">
											<textarea rows="2" name="designFac" style="width:94%; font-size: 1.1em;" autofocus placeholder="Exemple : Economie"></textarea>	
										</div>
										<div style="height:40px; line-height:40px;">
											<a href="?" title="" style="color:#FFFFFF;">Fermer</a>&nbsp;&nbsp;
											<input type="submit" name="BtAjouterFacSec" value="OK" style="width:40%;">			
										</div>
									</div>
								</form>
							</div>
							
							<?php 
						} 
						?>
						<a href="?ajouteraJOuterFacSeCt#fmAjFS" title="Ajouter une fili&eacute;re">
							<div class="faculte" style="display:inline-block;width:70px;height:70px; line-height: 70px; font-size: 3em;margin: 10px;">+</div>
							
						</a>
						<?php 
					}
				}
				else{
					echo  "Impossible d'atteindre les facult�s organis�es . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
				}
				
			?>
		</div>
		<div>
			<?php 
				if ($_SESSION['idFonctAutoDec']=="CPTBL" || $_SESSION['idFonctAutoDec']=="CAIS" || $_SESSION['idAutoDec']=="admin1") {
					?>
					<div class="faculte1" style="" id="">
						<a href="?oP_cPtablE82Zxs">
							<div class="faculte" style="">
								<div id="imag" style="height:75px; line-height: 75px; font-size: 2em; font-weight:bold;background: #FFFFFF; color:#005F7E">
									<img src="B_mbindi/Biamunda/icon/.png" alt="Finances" style="max-width: 100%; max-height: 100%;">
								</div>
								<div style="height:40px;">Op&eacute;rations comptables</div>
							</div>
						</a>
						
					</div>
					<?php  
				}
			?>
		</div>
		<?php
	}
?>
