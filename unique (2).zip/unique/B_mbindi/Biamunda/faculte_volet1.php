<?php 
	if(isset($_GET['fAculTe']) and isset($_GET['iDfaC'])){
		if($_SESSION['FacAttach']==$_GET['iDfaC'] or $_SESSION['FacAttach']=="TOUTES"){
			?>
			<style type="text/css">
				<!--
				.divFacOpOrg, .DesignfacOpOrg, .PromoOpOrg{
					height:auto; margin-bottom:5px; text-align:left;
				}
				.divFacOpOrg{ 
					 background:#F0F0F0; border:solid 1px #666666; 
				}
				.DesignfacOpOrg{
					background:#5B5B5B; 
					color:#FFFFFF; 
					padding:5px;
				}
				.edit{
					display: inline-block;
					position: relative;
					float: right;
					width: 20px;
					height: 18px;
					/*margin-top: -117px; 
					padding-top: 2px*/
				}
				.edit:hover{
					border-left:solid 1px #cdcdcd;
					border-bottom:solid 1px #cdcdcd;
					box-shadow: 2px 2px 6px 0px #005f7e;
				}
				.menFac{
					width:25px; 
					height:25px; 
					display:inline-block; 
					float: left;  
					margin-right:20px;
				}
				.DesignOpOrg, .PromoOpOrg{
					 
				}
				.DesignOpOrg{
					padding: 5px;
					background:#E3E3E3; 
					text-transform:uppercase; 
					font-style:oblique;

				}
				.PromoOpOrg {
					background:#F0F0F0; 
					text-transform:lowercase; 
					border-bottom:solid 2px #FFFFFF;
					padding: 5px;
				}
				.PromoOpOrg:hover {
					 
					text-transform:none; 
					background:#FFFFFF; 
					border-bottom:groove 2px #0000FF;
					
				}
				.PromoOpOrg a {
					color: #10076b;
				}
				
				.PromoOrg{
					text-transform:uppercase; 
				}
				.supOp{
					width: 20px;
					height: 20px;
					display: inline-block;
					position: relative;
					float: right;
					border: solid 1px #ffbe9a;
					background: #ffbe9a;
				}
				.supOp:hover{
					background: #ff0000;
				}
				<?php 
					if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) ){?>
						#idPromoOpOrg{
							background:#ccccff; 
							border-bottom:groove 2px #0000FF;
							text-transform:none; 
							font-weight: bold;
						}
						
						<?php 
					}
				?>

				@media (max-width : 70em){
				   	.divFacOpOrg{
					width:98%;
					}
					.DesignfacOpOrg{
					width:99%;
					}					
					.PromoOpOrg{
					width:80%;
					}
					.autresFac{
						display: none;
					}
				}

				-->
			</style>

			<?php
			$idFac = $_GET["iDfaC"];
			$designFac = "";
			$NbrOpOrg =0;
			$rqt_list_fac = "select * from  tb_faculte WHERE idFac = '".$idFac."' and idEts = '".$idEts."'";
			if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
				if(mysqli_num_rows($exe_rqt_list_fac)>0){
					while($tb_faculte = mysqli_fetch_assoc($exe_rqt_list_fac)){
						$_SESSION["idFac"]=$idFac = $tb_faculte['idFac'];
						$_SESSION["designFac"] = $designFac = $tb_faculte['designFac'];
						?>
						<div style="text-transform:uppercase; font-weight:bold; font-size: 1.1em;margin-top: 10px; margin-bottom:5px;" align="left">
							<?php 
								if ($_SESSION['typEts']=="UN") 
									echo "FACULTE ";
								else 
									echo "SECTION ";

								if(substr($designFac, 0, 1)=="A" || substr($designFac, 0, 1)=="a" || substr($designFac, 0, 1)=="E" || substr($designFac, 0, 1)=="e" || substr($designFac, 0, 1)=="é" || substr($designFac, 0, 1)=="I" || substr($designFac, 0, 1)=="i" || substr($designFac, 0, 1)=="O" || substr($designFac, 0, 1)=="o" || substr($designFac, 0, 1)=="U" || substr($designFac, 0, 1)=="u" || substr($designFac, 0, 1)=="Y" || substr($designFac, 0, 1)=="y" || substr($designFac, 0, 1)=="H"|| substr($designFac, 0, 1)=="h") 
									echo "D'".$designFac;
								else
									echo "DE ".$designFac;
							?>
							<?php 
								if($_SESSION['idAutoDec']=="admin1"){
									?>
									<div class="edit" id="">
										<a href="?EditFacSec&id=<?php echo  $_SESSION["idFac"]; ?>#<?php echo  $_SESSION["idFac"]; ?>"><img src='B_mbindi/Biamunda/icon/edit.gif' class='icon' alt='Edit.' title='Modifier' /></a>
									</div>	
									<?php  
								}
							?>
						</div>
						<div align="left" style="margin-bottom: 5px;">
							<table style="width: 100%;" border="0">
								<tr>
									<td>
										<div class="menFac">
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&fIxefR" ?>">
												<img src='B_mbindi/Biamunda/icon/monnaie.png' alt='Frais.' title='Finances' style="max-width:100%; max-height: 100%;" />
											</a>
										</div>
										<div class="menFac">
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&eNseIgnAnt" ?>">
												<img src='B_mbindi/Biamunda/icon/enseignant.png' alt='Enseig.' title='Enseignants' style="max-width:100%; max-height: 100%;" />
											</a>
											
										</div>
										<div class="menFac">
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&atTrIbutIoNs" ?>">
												<img src='B_mbindi/Biamunda/icon/attribution.png' alt='Attrib.' title='Attributions' style="max-width:100%; max-height: 100%;" />
											</a>
											
										</div>
										<div class="menFac">
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&palMaresFac" ?>">
												<img src='B_mbindi/Biamunda/icon/palmares.png' alt='Enseig.' title='Palmares' style="max-width:100%; max-height: 100%;" />
											</a>
											
										</div>
										
									</td>
								</tr>
							</table>
						</div>
							
						<div class='divFacOpOrg'>
							<a href="?fAculTe&iDfaC=<?php echo $idFac; ?>">
								<div class='DesignfacOpOrg'>
									<img src="B_mbindi/Biamunda/icon/accue.gif" class="icon" />&ensp;Options et Promotion organisées
								</div>
							</a>
							<?php
								$rqt_list_op = "select * from  tb_option where idFac = '".$idFac."' ORDER BY designOp ASC";
								if($exe_rqt_list_op = mysqli_query($con, $rqt_list_op)){
									if(mysqli_num_rows($exe_rqt_list_op)>0){
										while($tb_option = mysqli_fetch_assoc($exe_rqt_list_op)){
											?>
											<div style="border:solid 1px #cdcdcd;margin:10px;" id="<?php echo $tb_option['idOp']; ?>">
												<div class='DesignOpOrg'>
													<div> 
														<?php 
															if(!isset($_GET["EdItoPtiOn"])) echo $tb_option['designOp']; 

															//MODIFICATION OPTION
															if($_SESSION['idAutoDec']=="admin1"){
																if(isset($_GET["EdItoPtiOn"]) and $tb_option['idOp'] == $_GET["EdItoPtiOn"]){
																	?>
																	<div align="center" style="margin:0px;">
																		<div style="width: 98%;">
																			<form method="post">
																				<div style="height:20px;">
																					<?php echo $sms_gerer; ?>
																				</div>
																				<div >
																					<input type="hidden" name="idFac" value="<?php echo $idFac; ?>">
																					<input type="hidden" name="idOp" value="<?php echo $tb_option['idOp']; ?>">
																					<textarea name="designOp" rows="2" style="width:94%; font-size: 1.1em;" autofocus placeholder="Exemple : Economie monaitaire"><?php echo $tb_option['designOp']; ?></textarea>
																				</div>
																				<div style="padding: 5px;">
																					<a href="?fAculTe&iDfaC=<?php echo $idFac ;?>" title="Fermer" style="color:#005f7e;">Fermer</a>&nbsp;&nbsp;&nbsp;&nbsp;
																					<input type="submit" name="BtUpdateOp" value="OK" style="width:40%;">
																				</div>
																			</form>
																		</div>
																	</div>	
																	<?php
																}
																else{
																	?>
																	<div class="edit" id="">
																		<a href="?fAculTe&iDfaC=<?php echo  $_SESSION["idFac"]; ?>&EdItoPtiOn=<?php echo  $tb_option['idOp']; ?>#<?php echo $tb_option['idOp']; ?>"><img src='B_mbindi/Biamunda/icon/edit.gif' class='icon' alt='Edit.' title='Modifier' /></a>
																	</div>	
																	<?php
																}  
															}
															else{
																
															}
														?>
														</div>
												</div>
												<?php
												$rqt_verification = "SELECT * FROM tb_organisation_option  where idOp ='".$tb_option["idOp"]."' AND  idAnAca = '".$an_aca."' ORDER BY idPromo ASC ";
												if($exe_rqt_list_opOrg = mysqli_query($con, $rqt_verification)){
													if(mysqli_num_rows($exe_rqt_list_opOrg)>0){
														while($result_rqt_list_opOrg = mysqli_fetch_assoc($exe_rqt_list_opOrg)) {
															?>
															<div class="PromoOpOrg" <?php if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and ($_GET['pRomotIon'] == $result_rqt_list_opOrg['idPromo'] and $_GET['oPtiOn']== $tb_option["idOp"])){ echo " id='idPromoOpOrg'" ;} ?>>
																<?php 
																	$btSup = 0;
																	//Vérification inscription
																	$rqt_verif_tb_inscription = "SELECT * FROM tb_inscription WHERE idOp = '".$tb_option["idOp"]."' AND idProm = '".$result_rqt_list_opOrg['idPromo']."' AND idAca = '".$an_aca."'";
																	if($tb_inscription = mysqli_query($con, $rqt_verif_tb_inscription)){
																		if($tb_inscription->num_rows>0){
																			$btSup += 1;
																		}
																	}
																	//Vérification programme de cours
																	$rqt_tb_program_cours = "SELECT * FROM tb_program_cours WHERE idOp = '".$tb_option["idOp"]."' AND idPromo = '".$result_rqt_list_opOrg['idPromo']."' AND idAnAca = '".$an_aca."'";
																	if($tb_program_cours = mysqli_query($con, $rqt_tb_program_cours)){
																		if($tb_program_cours->num_rows>0){
																			$btSup += 1;
																		}
																	}
																	if ($btSup==0 and $_SESSION['idAutoDec']=="admin1") {
																		?>
																		<div style="" class="supOp" title="Supprimer">
																			<a href="?fAculTe&iDfaC=<?php echo $idFac; ?>&pRomotIon=<?php echo $result_rqt_list_opOrg['idPromo'] ; ?>&oPtiOn=<?php echo $tb_option["idOp"]; ?>&SupPriMeRPromOtIonEtoPtionOrgansiEe&aca=<?php echo $an_aca; ?>">
																				<img src="B_mbindi/Biamunda/icon/sup.gif" style="max-width: 100%; max-height: 100%;">
																			</a>
																		</div>
																		<?php 
																	} 
																?>
																<a href="?fAculTe&iDfaC=<?php echo $idFac; ?>&pRomotIon=<?php echo $result_rqt_list_opOrg['idPromo'] ; ?>&oPtiOn=<?php echo $tb_option["idOp"]; ?>&inScriPtion">
																	<div>
																		<font class='PromoOrg'><?php echo $result_rqt_list_opOrg['idPromo']; ?></font><?php echo "&nbsp;&nbsp;".$tb_option['designOp']; ?>
																	</div>
																</a>
																
															</div>
															<?php
														}
													}
													else{
														echo "<div class='PromoOpOrg' style='color:#5B5B5B;'>Aucune promotion organis&eacute;e</div>";
													}
													//Form ajout promotion - option 
													if($_SESSION['idAutoDec']=="admin1"){
														if ((isset($_GET["iDoPtIOn"]) and $_GET['iDoPtIOn']==$tb_option["idOp"]) and isset($_GET["ajOUTer_pRomotion"])) {
															?>
															<div align="center" style="border-top:solid 1px #cdcdcd;">
																<div style="height: 20px;margin: 5px;"><?php echo $sms_gerer; ?></div>
																<div style="margin-bottom: 20px;">
																	<form method="post">
																		<input type="hidden" name="idOp" value="<?php echo $tb_option["idOp"]; ?>">
																		<select name="idPromo" style="width:50%;">
																			<?php 
																				$rqt_list_promotion = "SELECT * FROM  tb_promotion ORDER BY systPromo AND nivPromo ASC";
																				if($exe_rqt_list_promotion = $conDb->query($rqt_list_promotion)){
																					echo "<option value=''></option>";
																					while($tab_promotion = $exe_rqt_list_promotion->fetch_assoc()){
																						$rqt_verif_OrgOp = "SELECT * FROM tb_organisation_option WHERE idPromo = '".$tab_promotion['idPromo']."' AND idOp = '".$tb_option["idOp"]."' AND idAnAca = '".$an_aca."'";
																						if($exe_rqt_slct_OrgOp = mysqli_query($con, $rqt_verif_OrgOp)){
																							if($exe_rqt_slct_OrgOp->num_rows<=0){
																								?>
																								<option value="<?php echo $tab_promotion['idPromo']; ?>">
																									<?php echo $tab_promotion['idPromo']." ".$tb_option['designOp']; ?>
																								</option>
																								<?php 
																							}
																						}
																						else{
																							echo "<option value='' class='echec'>Erreur</option>"; 
																						}
																					}
																				}
																				else{
																					?>
																					<option style="color:#FF3333;" value="" class="echec" >Erreur.</option>
																					<?php 
																				}
																			?>
																		</select>
																		<input type="submit" name="BtOrganiPromo" value="OK" style="width:10%;"> &nbsp;
																		<a href="?fAculTe&iDfaC=<?php echo $idFac; ?>">Fermer</a>
																	</form>
																</div>
															</div>
															<?php
														}
														else{
															?>
															<a href="?fAculTe&iDfaC=<?php echo $idFac ;?>&iDoPtIOn=<?php echo $tb_option["idOp"] ;?>&ajOUTer_pRomotion#<?php echo $tb_option['idOp']; ?>" title="Ajouter une promotion">
																<div align="center" style='font-size:0.9em;margin:20px;'>Ajouter une promotion</div>
															</a>
															<?php
														}	
													}
													
												}
												else{
													echo  "Impossible de v&eacute;rifier les option organisées. <br/>SVP, contacter urigement l'Administrateur.";
												}
												?>
											</div>
											<?php
										}
									}
									else{
										if($_SESSION['idAutoDec']=="admin1"){
											?>
											<div align="center" style='font-size:0.9em;margin:20px;'>Cliquer sur le <b>+</b> pour ajouter une Option</div>
											<?php	
										}
										else{
											echo "<div class='DesignOpOrg'>Aucune option organis&eacute;e</div>";
										}
									}
									if($_SESSION['idAutoDec']=="admin1"){
										if (isset($_GET["ajOUTer_oPtIOn"])) {
											$idOp = $idFac."O".random_int(10, 99).$version ;
											?>
											<div align="center" style="margin:10px;" id="ajouterFS">
												<div style="width: 98%;border: solid 1px #005f7e;">
													<form method="post">
														<div style="height:20px;">
															<?php echo $sms_gerer; ?>
														</div>
														<div style="padding-top:10px;">
															<input type="hidden" name="idFac" value="<?php echo $idFac; ?>">
															<input type="hidden" name="idOp" value="<?php echo $idOp; ?>">
															<textarea name="designOp" rows="2" style="width:94%; font-size: 1.1em;" autofocus placeholder="Exemple : Economie monaitaire"></textarea>
														</div>
														<div style="padding: 10px;">
															<a href="?fAculTe&iDfaC=<?php echo $idFac ;?>" title="Fermer" style="color:#005f7e;">Fermer</a>&nbsp;&nbsp;
															<input type="submit" name="BtAjouterOp" value="OK" style="width:40%;">
														</div>
													</form>
												</div>
											</div>
											<?php
										}
										else{
											?>
											<div align="center" style="border-top:solid 1px #cdcdcd; margin-top:20px;">
												<a href="?fAculTe&iDfaC=<?php echo $idFac ;?>&ajOUTer_oPtIOn#ajouterFS" title="Ajouter une option">
													<div style="display: inline-block; width:15%; height:40px; line-height:40px; font-size: 2em;background: #cdcdcd;margin: 10px;">+</div>
												</a>
											</div>
											<?php
										}
									}
									
								}
								else{
									echo  "<div class='erreur'>Echec de trouver les options</div>";
								}
							?>
						</div>
						<?php
					}
				}
				else{
					echo "<div class='divFacOpOrg' >Aucune faculté organis&eacute;e</div>";
				}
			}
			else{
				echo  "Impossible d'atteindre les département organisés . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
			}
		}
		else{
			echo "<div class='divFacOpOrg' >Vous n'avez pas droit à cette information</div>";
		}
		
		//*************************************************************
		//AUTRES FACULTES ORGANISEES


		if($_SESSION['idAutoDec']=="admin1" || $_SESSION['FacAttach']=="TOUTES" ){
			echo "<div class='autresFac'>";
			echo "<div style='border-bottom:groove'>AUTRES FACULTES ORGANISEES</div>";
			$rqt_list_fac = "SELECT * FROM tb_faculte WHERE idEts='".$idEts."' ORDER BY designFac";
			if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
				while($tb_faculte = mysqli_fetch_assoc($exe_rqt_list_fac)){
					if($tb_faculte['idFac'] != $_GET['iDfaC']){
						echo "<a href='?fAculTe&iDfaC=".$tb_faculte['idFac']."'>";
						echo "<div align='left' style='margin-bottom:5px; background:#F0F0F0; text-transform:lowercase;'><h2>".$tb_faculte['designFac']."</h2></div>";
						echo "</a>";
					}
				}
			}
			else{
				echo  "Impossible d'atteindre les facultés organisées . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
			}	
			echo "</div>";
				
		}
	}
?>