<?php 
//dans pg_apres_conx
	if(isset($_GET['fAculTe']) and isset($_GET['iDfaC'])){
		if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and !isset($_GET['pRomotIon']) and !isset($_GET['oPtiOn'])){
			echo "<h2 align ='left'>&nbsp;";
			if ($_SESSION['typEts']=="UN") 
				echo "FACULTE : ";
			else
				echo "SECTION : ";

			echo $designFac."</h2>";

			include("B_mbindi/Biamunda/menuAMS.php");
			include("B_mbindi/Biamunda/enseignants.php");

			//MODULE
			include("B_mbindi/makuta/makuta.php");
			include("B_mbindi/Cours/attribution_cours_Fac.php");
			include("B_mbindi/pue/palmares/palmares_LMD_FAC.php"); 
			
		}	
		include("B_mbindi/Biamunda/rqt/rqt_verification_promo_op.php");
		include("B_mbindi/pue/cote.php"); 

		
	}
	
?>
	
