<?php 
if (isset($_GET['gerer'])){
?>

<h2>S�l�ctionner un param�tre</h2>
<div align="left"><img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/parametr.png" />&nbsp; Gerer :
  <ul>
      <li>
        <il><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_departement&ajouter_dep">Facult&eacute;</A></il>
        <il></il>
      </li>
	      <li>
	        <il><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_option&ajouter_op">Option</A></il>
      </li>
	      <li>
	        <il><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_promotion&ajouter_pro">Promotion</A></il>
      </li>
	      <li>
	        <il><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_aca&ajouter_aca">Ann�e Acad�mique</A></il>
      </li>
	      <li><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_inscription&modif_inscrit"><img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/note16.ico" />&nbsp;Inscription</A> </li>
	      <li>
	        <il><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&ajouter_fr"><img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/dollards.gif" />&nbsp; Frais</A></il>
	      </LI>
	      <li>
	        <il><A href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_etudiant"><img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>A_mutue/misc28.ico" />&nbsp;Etudiants</A></il>
      </li>
  </ul>
  </li>
</div>
<?php }?>