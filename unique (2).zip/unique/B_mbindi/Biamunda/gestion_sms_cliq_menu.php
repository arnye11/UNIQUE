<?php 
if ((isset($_GET['ctrl']))){ $sms = "CONTROLE";}
if (isset($_GET['misession'])){ $sms = "CONTROLE POUR LA MI-SESSION";}
if (isset($_GET['1session'])){ $sms = "CONTROLE POUR LA 1<sup>�re</sup> SESSION";}
if (isset($_GET['deliberation'])){ $sms = "CONTROLE POUR LA DELIBERATION";}
if (isset($_GET['2session'])){ $sms = "CONTROLE POUR LA 2<sup>�me</sup> SESSION";}
if (isset($_GET['rapport'])){ $sms = "RAPPORT DES FRAIS";}
if (isset($_GET['inscrition'])){ $sms = "INSCRIPTION";}
if (isset($_GET['inscrition_inscrition'])){ $sms = "INSCRIPTION";}
if (isset($_GET['inscrition_reinscription'])){ $sms = "REINSCRIPTION";}
if (isset($_GET['inscrition_situation'])){ $sms = "SITUATION DES INSCRIPTIONS";}
if (isset($_GET['gerer'])){ $sms = "GERER";}
if (isset($_GET['gerer_departement'])){ $sms = "GESTION DES FACULTES";}
if (isset($_GET['gerer_option'])){ $sms = "GESTION DES OPTIONS";}
if (isset($_GET['gerer_promotion'])){ $sms = "GESTION DES PROMOTIONS";}
if (isset($_GET['gerer_aca'])){ $sms = "GESTION DES ANNEES ACADEMIQUES";}
if (isset($_GET['gerer_inscription'])){ $sms = "GESTION DES INSCRIPTIONS";}
if (isset($_GET['gerer_frais'])){ $sms = "GESTION DES FRAIS";}
if (isset($_GET['gerer_etudiant'])){ $sms = "GESTION DES ETUDIANTS";}
if (isset($_GET['gerer_cours'])){ $sms = "GESTION DES COURS";}


?>