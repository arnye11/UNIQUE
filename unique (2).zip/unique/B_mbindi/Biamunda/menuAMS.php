<?php
	if (isset($_GET['gerer_departement'])|| isset($_GET['gerer_option'])|| isset($_GET['gerer_promotion'])|| isset($_GET['gerer_aca'])|| isset($_GET['gerer_inscription'])|| isset($_GET['gerer_frais'])|| isset($_GET['gerer_etudiant']) || isset($_GET['gerer_cours'])|| isset($_GET['fAculTe'])){?>
		<style type="text/css">
		/*_________________   DIV :  FORM_AMS ___________________________________*/
		.divMenuAMS{
			 border-bottom:solid 1px #FFFFFF; width:100%; height:auto; background:#E6E6E6; text-align:center;
		}
		<?php 
			if (isset($_GET['gerer_frais'])||isset($_GET['gerer_option'])||isset($_GET['gerer_cours'])||isset($_GET['fAculTe'])){ ?>
				.dviMenuAjt, .dviMenuModf, .dviMenuSup, .dviMenuFixPr, .dviMenuOrgOp, .dvipRogramMer, .dviinScriPtion{
					display:inline; border-bottom:solid 2px #999999; float:left;width:120px;
				}
				<?php 
			}
			else{?>
				.dviMenuAjt, .dviMenuModf, .dviMenuSup{
					display:inline; border-bottom:solid 2px #999999; float:left;width:150px;
				}
				<?php 
			}
		?>
		#divMenuAMSActif{
			height:auto; box-shadow:3px 0px 3px 0px #ffffff; border-radius:10px 10px 0px 0px; border:solid 1px;border-bottom:solid 1px #FFFFFF; background:#FFFFFF
		}
		
		</style>
	<!--__________________________________________________________________________________________________________-->
		<div class="divMenuAMS">
			<table width="100%" style="border-bottom:solid 1px #FFFFFF; padding:0px;">
				<tr>
					<td>
					<?php
						if (isset($_GET['gerer_departement'])|| isset($_GET['gerer_option'])|| isset($_GET['gerer_promotion'])|| isset($_GET['gerer_aca'])|| isset($_GET['gerer_inscription'])|| isset($_GET['gerer_frais'])|| isset($_GET['gerer_etudiant']) || isset($_GET['gerer_cours']))
						{?>
							<div id="<?php  if ((isset($_GET['ajouter_dep'])|| (isset($_GET['ajouter_op'])) || (isset($_GET['ajouter_pro']))|| (isset($_GET['ajouter_aca']))|| (isset($_GET['ajouter_fr']))  ) || (isset($_GET['ajouter_cours'])) ){echo "divMenuAMSActif";} ?>" class="dviMenuAjt"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site; 
								if (isset($_GET['gerer'])){ echo "?gerer";}
								if (isset($_GET['gerer_departement'])){ echo "?gerer_departement&ajouter_dep";}
								if (isset($_GET['gerer_option'])){ echo "?gerer_option&ajouter_op";}
								if (isset($_GET['gerer_promotion'])){ echo "?gerer_promotion&ajouter_pro";}
								if (isset($_GET['gerer_aca'])){ echo "?gerer_aca&ajouter_aca";}
								if (isset($_GET['gerer_inscription'])){ echo "?gerer_inscription&ajouter_inscrit";}
								if (isset($_GET['gerer_frais'])){ echo "?gerer_frais&ajouter_fr";}
								if (isset($_GET['gerer_cours'])){ echo "?gerer_cours&ajouter_cours";}
								if (isset($_GET['gerer_etudiant'])){ echo "?gerer_etudiant&ajouter_etud";}?>">Ajouter</a>
							</div>
							<div id="<?php  if ((isset($_GET['modifier_dep']))||(isset($_GET['modifier_op'])) || (isset($_GET['modifier_pro']))|| (isset($_GET['modifier_aca']))|| (isset($_GET['modifier_fr'])) || (isset($_GET['modifier_cours'])) ){echo "divMenuAMSActif";} ?>"  class="dviMenuModf"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;
								if (isset($_GET['gerer'])){ echo "?gerer";}
								if (isset($_GET['gerer_departement'])){ echo "?gerer_departement&modifier_dep";}
								if (isset($_GET['gerer_option'])){ echo "?gerer_option&modifier_op";}
								if (isset($_GET['gerer_promotion'])){ echo "?gerer_promotion&modifier_pro";}
								if (isset($_GET['gerer_aca'])){ echo "?gerer_aca&modifier_aca";}
								if (isset($_GET['gerer_inscription'])){ echo "?gerer_inscription&modifier_inscrit";}
								if (isset($_GET['gerer_frais'])){ echo "?gerer_frais&modifier_fr";}
								if (isset($_GET['gerer_cours'])){ echo "?gerer_cours&modifier_cours";}
								if (isset($_GET['gerer_etudiant'])){ echo "?gerer_etudiant&modifier_etud";}?>">Modifier</a>
							</div>
							<div id="<?php  if ((isset($_GET['sup_dep']))|| (isset($_GET['sup_op'])) || (isset($_GET['sup_pro']))|| (isset($_GET['sup_aca']))|| (isset($_GET['sup_fr']))|| (isset($_GET['sup_cours']))  ){echo "divMenuAMSActif";} ?>"  class="dviMenuSup"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;
								if (isset($_GET['gerer'])){ echo "?gerer";}
								if (isset($_GET['gerer_departement'])){ echo "?gerer_departement&sup_dep";}
								if (isset($_GET['gerer_option'])){ echo "?gerer_option&sup_op";}
								if (isset($_GET['gerer_promotion'])){ echo "?gerer_promotion&sup_pro";}
								if (isset($_GET['gerer_aca'])){ echo "?gerer_aca&sup_aca";}
								if (isset($_GET['gerer_inscription'])){ echo "?gerer_inscription&sup_inscrit";}
								if (isset($_GET['gerer_frais'])){ echo "?gerer_frais&sup_fr";}
								if (isset($_GET['gerer_cours'])){ echo "?gerer_cours&sup_cours";}
								if (isset($_GET['gerer_etudiant'])){ echo "?gerer_etudiant&sup_etud";}?>">Supprmer</a>
							</div>
					
							<?php  
							if (isset($_GET['gerer_frais'])){?>
								<div id="<?php  if (isset($_GET['fix_pr'])){echo "divMenuAMSActif";} ?>"  class="dviMenuFixPr">
									<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site; if (isset($_GET['gerer_frais'])){ echo "?gerer_frais&fix_pr";}?>">Fixer le Prix</a>
								</div>
								<?php 
							}

							if (isset($_GET['gerer_option'])){?>
								<div id="<?php  if (isset($_GET['OrgOp'])){echo "divMenuAMSActif";} ?>"  class="dviMenuOrgOp">
									<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site; if (isset($_GET['gerer_option'])){ echo "?gerer_option&OrgOp";}?>">Organiser</a>
								</div>
								<?php 
							}

							

						}

						//*************************** MENUS - FACULTE **************************************************************
						if (isset($_GET['fAculTe']) and isset($_GET['iDfaC'])){
							if (isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])){?>
								<div id="<?php  if (isset($_GET['inScriPtion'])){echo "divMenuAMSActif";} ?>"  class="dviinScriPtion">
									<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&inScriPtion" ?>">Inscription</a>
								</div>
								<div id="<?php  if (isset($_GET['cOuRs'])){echo "divMenuAMSActif";} ?>"  class="dviinScriPtion">
									<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours" ?>">Cours</a>
								</div>
								<div id="<?php  if (isset($_GET['cOTe'])){echo "divMenuAMSActif";} ?>"  class="dviinScriPtion">
									<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe" ?>">C&ocirc;te</a>
								</div>
								<div id="<?php  if (isset($_GET['rAppoRtfrais'])){echo "divMenuAMSActif";} ?>"  class="dviinScriPtion">
									<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&rAppoRtfrais" ?>">Rapport Frais</a>
								</div>
								<?php 
							}
							else{
							?>
							
							<div id="<?php  if (isset($_GET['fIxefR'])){echo "divMenuAMSActif";} ?>"  class="dviinScriPtion">
								<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&fIxefR" ?>">Fixation frais</a>
							</div>
							<div id="<?php  if (isset($_GET['eNseIgnAnt'])){echo "divMenuAMSActif";} ?>"  class="dviinScriPtion">
								<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&eNseIgnAnt" ?>">Enseignants </a><br>
							</div>
							<div id="<?php  if (isset($_GET['atTrIbutIoNs'])){echo "divMenuAMSActif";} ?>"  class="dviinScriPtion">
								<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&atTrIbutIoNs" ?>">Attributions</a><br>
							</div>
							<?php 
							}
						}

					?>
					</td>
				</tr>
			</table>
		</div>
		
		<?php 
		
	}
?>