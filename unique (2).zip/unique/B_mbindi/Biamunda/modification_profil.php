<?php
if($_SESSION['loginSession'] == "Apparitaire" ||$_SESSION['loginSession'] == "DG" || $_SESSION['loginSession'] == "admin")
	{
	 if(isset($_GET['profil']) and isset($_GET['modification_profil']))
		{
		?>
<style>	
<!--
	.profil_modification_photo1, .profil_modification_photo2{
		display:inline; float:left; height:182px; margin:2px; border:solid 1px #9900CC; 
	}

	.profil_modification_photo{border:solid 1px #00FF33;width:98.5%; height:190px; margin:2px; background:#EEEEEE;}
	.profil_modification_photo1{ width:180px;background:#FFFFFF;}
	.zone_titre_photo_profil{border:solid 1px #FFCC00; width:96%; height:18px;margin:2px; background:#BBBBBB;}
	.zone_photo_profil_mod{border:solid 1px #FFCC00; width:96%; height:125px; margin:2px;}
	.zone_lien_modifier_photo_profil{border:solid 1px #FFFFFF; width:96%; height:19px; margin:2px; background:#005500; color:#EEEEEE; box-shadow:0px 5px 5px 0px #003300;}
	.profil_modification_photo2{ width:59%; }
	.lien_modifier_photo_profil{color:#EEEEEE;}
	.ClassBtTelecharger{color:#EEEEEE; background:#6666FF; font-family:"Times New Roman", Times, serif; border-radius:12px;}
	.ClassAvatarEtud{border:solid 1px #BBBBBB; border-radius:12px; background:#FFFFFF;}
-->
</style>

		<h2 align="left" style="margin-left:20px; ">ID : &nbsp;&nbsp; <?php echo $result_slct_etud['matricEtud'];?> </h2>
		<div class="profil_modification_photo"><!--debut div modification photo profil-->
			<div class="profil_modification_photo1" align="center"><!--debut div titre-photo-lien modifier la photo-->
				<div class="zone_titre_photo_profil" align="center"><!--div avec le nom de l'�tudiant-->
					<?php echo $result_slct_etud['prenomEtud'];?>
				</div>
				<div  class="zone_photo_profil_mod" align="center"><!--div de la photo de l'�tudiant-->
					<img  src="B_mbidndi/Biamunda/media/<?php echo $result_slct_etud['matricEtud']."/".$result_slct_etud['avantarEtud'];?>" alt="Pas de Photo" width="99%" height="99%" />
				</div>
				<div class="zone_lien_modifier_photo_profil" align="center"><!--div lien modifier la photo-->
					<a class="lien_modifier_photo_profil" href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&modification_profil&photo">Modifier la photo</a>
				</div>
			</div><!--fin div titre-photo-lien modifier le photo-->
			<div class="profil_modification_photo2" align="center"><!--div formulaire selct photo du profil-->
			<?php if (isset($_GET['modification_profil']) and isset($_GET['photo'])){ ?>
				<p>
				<?php if (isset($_POST['BtTelAv'])){ echo $sms_avatar;} else { echo "Veuillez s�lectionner une photo.";} ?>
				</p>
				<form action="" method="post" enctype="multipart/form-data" >
					<input type="hidden" name="matriculEtud" value="<?php echo $_GET['id'];?>" />
					<input class="ClassAvatarEtud" type="file" name="avatr" style="width:260px;"/>
					<input class="ClassBtTelecharger" type="submit" name="BtTelAv" value="T&eacute;l&eacute;charger la photo" style="width:260px;"/>
				</form>
				<?php }?>
			</div><!--fin div form selct photo du profil-->
		</div><!--fin div modification photo profil-->
		
		<div align="left" style="background:#DDDDDD; padding:2px;"><!--debut div id �tud-->
			<?php 
			//FORMULAIRE DE MODIFICATION D'IDENTITES DE L'ETUDIANT
			if((isset($_GET['mod']) and $_GET['mod']==1) and $champ == false)
				{
				include($_SERVER['DOCUMENT_ROOT']."/B_mbidndi/Biamunda/f_modification_id_etud.php");
				}
			else
				{
				if($champ == true and isset($_POST['BtEnreg']))
					{
					echo "<div align='center' style='border:solid 1px #FF9900;background:#FFFF99;'>".$sms_updt_id."</div>";
					} 
				?>
				<div align="left"><h3>IDENTITES</h3></div>
				<table border="0">
				  <tr>
					<td>Nom  </td>
					<td>: 
						<?php echo $result_slct_etud['nomEtud'];?>
					</td>
				  </tr>
				  <tr>
					<td>Postnom </td>
					<td>: 
						<?php echo $result_slct_etud['postnomEtud'];?>&nbsp;&nbsp; 
					</td>
				  </tr>
				  <tr>
					<td>Pr&eacute;nom  </td>
					<td>: 
						<?php echo $result_slct_etud['prenomEtud'];?>&nbsp;&nbsp; 
					</td>
				  </tr>
				  <tr>
					<td>Sexe  </td>
					<td>:
						 <?php if ($result_slct_etud['sexeEtud']=="M"){ echo "Homme";}else { echo "Femme";}?>&nbsp;&nbsp; 
					</td>
				  </tr>
				  <tr>
					<td>Date de naissance  </td>
					<td>:
						 <?php if ($result_slct_etud['jrNais']<10){ echo "0".$result_slct_etud['jrNais'];}else{echo $result_slct_etud['jrNais'];} echo "/" ; if ($result_slct_etud['mmNais']<10){ echo "0".$result_slct_etud['mmNais'];}else{echo $result_slct_etud['mmNais'];} echo "/ ".$result_slct_etud['aaaaNais'];?>&nbsp;&nbsp; 
					</td>
				  </tr>
				  <tr>
					<td>Lieu de naissance  </td>
					<td>:
						 <?php echo $result_slct_etud['lieunaisEtud'];?>&nbsp;&nbsp; 
					</td>
				  </tr>
				  <tr>
					<td>Adresse d'habutation  </td>
					<td>:
						 <?php echo $result_slct_etud['adresseEtud'];?> &nbsp;&nbsp; 
					</td>
				  </tr>
			  <tr>
				<td><div align="left">Num�ro de t�l�phone  </div></td>
				<td>
					<div align="left">: <?php echo $result_slct_etud['telEtud'];?></div>
				</td>
			  </tr>
			  <tr>
				<td><div align="left">E-mail  </div></td>
				<td>
					<div align="left">: <?php echo $result_slct_etud['emailEtud'];?></div>
				</td>
			  </tr>
				</table>
				<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&modification_profil&mod=1">
					<div align="center" style="width:100%; height:22px; color:#EEEEEE; background:#000077; border-radius:10px;">Modifier son identit�</div>
				</a>
				<?php 
				}
			?>
		</div>
		
		<div align="left" style="background:#DDDDDD; padding:2px;"><!--debut div id �tud-->
			<div align="left"><h3>INSCRIPTION </h3></div>
			<table>
				<tr>
					<td><div align="left">Promotion </div></td>
					<td><div align="left">: <?php echo $idPromo; ?></div></td>
				</tr>
				<tr>
					<td><div align="left">Option </div></td>
					<td><div align="left">: <?php echo $designOp; ?></div></td>
				</tr>
			</table>
			<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&modification_profil&mod=2">
				<div align="center" style="width:100%; height:22px; color:#EEEEEE; background:#000077; border-radius:10px;">Modifier son inscription</div>
			</a>
			<div align="center" style=" width:99%; background:#DDDDDD; border:solid 1px #000088;">
				<div align="center" style="border-bottom:solid 1px #000088; font-size:20px;">Modification de son inscription<br/>
					<?php if($champ == false and isset($_POST['BtEnreg'])){echo $sms_updt_id;} ?>
				</div>
				<form method="post">
					<table>
						<tr>
							<td><div align="left">Promotion </div></td>
							<td><div align="left">: <?php echo $idPromo; ?></div></td>
						</tr>
						<tr>
							<td><div align="left">Option </div></td>
							<td><div align="left">: <?php echo $designOp; ?></div></td>
						</tr>
					</table>
				</form>
			</div>
			
		</div>
	<?php
		}
	}
else
	{
	echo "Vous n'avez pas le droit de faire cette op�ration";
	}
 
 ?>