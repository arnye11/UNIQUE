<?php 
	if (isset($_GET['gerer_option']) and isset($_GET['OrgOp'])){
		?>
		<style type="text/css">
			<!--
			.divOrgOp{
				width:98%;margin:2px; color: 
			} 
			.divOrgOp, .divOrgOpContenu1{
				border:solid 1px #9A9A9A; margin:0px; padding:0px; 
			} 
			.divOrgOpCorps, .divOrgOpContenu1, .divOrgOpContenu2, .divOrgOpContenu3, #divOrgOpTitre{
				width:99%; height:auto;
			}
			.divOrgOpContenu2{
				height:20px;  margin-top:5px;
			}
			#divOrgOpTitre{
				height:auto; background:#D6D6D6; 
			}
			.Fac, .Op{
				width:60%; 
			}
			.Fac{
				text-transform:uppercase;
			}
			#enteteOrgOp{
				width:100%;border:solid 0px; background:#003333; color:#FFFFFF;margin-bottom:10px; padding:0px,
			}
			#Fac{
				background:#EBEBEB;
			}
			.Op{
				text-transform:lowercase;
			}
			.Promo{
				width:35%; text-align:center; font-size:12px;
			}
			.cellulePromo{
				width:20px; border:solid 1px #FF0000; margin-left:2px; margin-right:2;
			}
		
			-->
		</style>
		<div class="divOrgOpCorps" id="divOrgOpTitre">
			<h2>Organiser les options dans les promotions </h2>
		</div>
		<?php 
			if(isset($_GET['gerer_option']) and isset($_GET['OrgOp']) and isset($_GET['iDproMo']) and isset($_GET['iDop']) ){
				echo $sms_gerer;
			}
		?>
	 	<div class="divOrgOp">
			<div class="divOrgOpCorps"  id="enteteOrgOp">
				<table class="divOrgOpContenu2">
					<tr>
						<td class="Fac">Facult&eacute;/Options</td>
						<td class="Promo">
							<div class="divOrgOpContenu3">Promotions</div>
							<table class="divOrgOpContenu3">
								<tr>
									<?php 
									$rqt_promo = "SELECT idPromo FROM tb_promotion  ORDER BY idPromo ASC";
									$nbL = 0;
									if($exe_rqt_promo = mysqli_query($con, $rqt_promo)){
										$nbL =mysqli_num_rows($exe_rqt_promo);
										//echo "<td>".$nbL."</td>";
										while($tb_promotion = mysqli_fetch_assoc($exe_rqt_promo)){
											echo "<td class='cellulePromo'>".$tb_promotion["idPromo"]."</td>";
										}
										
									}
									else{
										echo "<td>Erreur lors de sel&eacute;ction des promotions.</td>";
									}
									?>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</div>
		<?php 
			$rqt_fac = "SELECT * FROM tb_faculte  ORDER BY designFac ASC";
			if($exe_rqt_fac = mysqli_query($con, $rqt_fac)){
				//$nbL =$exe_rqt_promo->num_rows;
				while($tb_fac = mysqli_fetch_assoc($exe_rqt_fac)){
					echo "<div class='divOrgOpCorps'>";
					echo "<div class='divOrgOpContenu1' id='Fac'>".$tb_fac["designFac"]."</div>";
					$rqt_Op = "SELECT * FROM tb_option WHERE idFac = '".$tb_fac["idFac"]."' ORDER BY designOp ASC";
					if($exe_rqt_Op = mysqli_query($con, $rqt_Op)){
						//$nbL =$exe_rqt_promo->num_rows;
						while($tb_Op = mysqli_fetch_assoc($exe_rqt_Op)){
							?>
							<table class="divOrgOpContenu2">
								<tr>
									<td class="Op"><?php echo $tb_Op["designOp"]; ?></td>
									<td class="Promo">
										<table class="divOrgOpContenu3">
											<tr>
												<?php 
												$rqt_promo = "SELECT idPromo FROM tb_promotion  ORDER BY idPromo ASC";
												//$nbL = 0;
												if($exe_rqt_promo = mysqli_query($con, $rqt_promo)){
													$nbL = mysqli_num_rows($exe_rqt_promo);
													while($tb_promo = mysqli_fetch_assoc($exe_rqt_promo)){
														echo "<td class='cellulePromo' title='en ".$tb_promo["idPromo"]."'>";
														$rqt_v_tbOrgOp = "SELECT * FROM tb_organisation_option  where idPromo = '".$tb_promo["idPromo"]."' AND idOp ='".$tb_Op["idOp"]."' AND  idAnAca = '".$_SESSION['idAnAca']."' ";
														if($exe_rqt_v_tbOrgOp = mysqli_query($con, $rqt_v_tbOrgOp)){
															if($tb_promotion = mysqli_fetch_assoc($exe_rqt_v_tbOrgOp)){
																echo "<a href='?gerer_option&OrgOp&iDproMo=".$tb_promo["idPromo"]."&iDop=".$tb_Op["idOp"]."&moins'>-</a>";
															}
															else{
																echo "<a href='?gerer_option&OrgOp&iDproMo=".$tb_promo["idPromo"]."&iDop=".$tb_Op["idOp"]."&plus'>+</a>";
															}
														}
														else{
															echo "Error";
														}
														echo "</td>";
													}
													
												}
												else{
													echo "<td>Erreur lors de sel&eacute;ction des promotions.</td>";
												}
												?>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<?php 
						}
					}
					else {
						echo "<div class='divOrgOpContenu1'>Erreur lors de sel&eacute;ction des options;.</div>";
					}
					echo "</div>";					
				}
			}
			else {
				echo "<div class='divOrgOpContenu2'>Erreur lors de sel&eacute;ction des Facult&eacute;.</div>";
			} ?>
	 </div>
		<?php 
	}
?>