<?php 
//dans index
		
	if(isset($_GET["imPRessIoN"])){
		include("B_mbindi/Impression/impression.php");
	}
	else{
		include("A_mutue/entete.php"); 
		include("B_mbindi/Biamunda/list_aca.php");
		include("B_mbindi/Biamunda/corps.php"); 
		//include("C_mikolo/C_mikolo.php"); 
	}
?>
