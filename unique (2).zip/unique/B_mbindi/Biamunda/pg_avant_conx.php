<style type="text/css">
	/****** ENTÊTE AVANT CONNEXION ******/
	.div-entete {
		height: auto;
		border-bottom: 1px solid #c3c3c3;
		color: #003958;
		box-shadow: 0 4px 4px #c3c3c3;
	}
	.div-accueil, .div-bienvenu {
		display: inline-block;
		float: left;
		height: auto;
	}
	.div-accueil {
		width: 5%;
		height: 60px;
	}
	.div-bienvenu {
		height: 60px;
		line-height: 60px;
		font-size: 1.6em;
		font-style: italic;
		font-weight: bold;
		font-family: "Palatino Linotype", serif;
		color: #003858;
		margin-left: 10px;
	}
	.div-apropos {
		display: inline-block;
		float: right;
		text-align: center;
		padding: 10px;
		margin-top: 15px;
		margin-right: 20px;
		border: 1px solid #c3c3c3;
		border-radius: 4px;
		box-shadow: 0 4px 4px #c3c3c3;
	}
	.btn-deliberation {
	    display: inline-block;
	    padding: 10px 20px;
	    font-size: 1em;
	    color: white;
	    background-color: #003958; /* Couleur de fond */
	    border: none;
	    border-radius: 5px;
	    text-align: center;
	    text-decoration: none;
	    cursor: pointer;
	    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
	    transition: background-color 0.3s ease;
	}

	.btn-deliberation:hover {
	    background-color: #00225e; /* Couleur au survol */
	}

	.div-form-auth, .et-unique {
		display: none;
		visibility: hidden;
	}
	.mikolo {
		display: none;
		position: absolute;
		visibility: hidden;
	}

	/* MEDIA QUERY POUR TAILLES PLUS PETITES */
	@media (max-width: 60em) {
		.div-entete, .div-bienvenu, .div-apropos, .corps-aut {
			visibility: hidden;
			display: block;
			position: absolute;
		}
		.et-unique {
			background: #003958;
			color: #fff;
			display: block;
			visibility: visible;
			width: 100%;
			height: auto;
			box-shadow: 0 5px 8px #000;
		}
		.unique {
			width: 100%;
			font-size: 3em;
			text-align: left;
			margin-bottom: 20px;
		}
		.aca {
			width: 30%;
			font-size: 1em;
			text-align: center;
			position: absolute;
			right: 1em;
			top: 1.2em;
			float: right;
			font-style: italic;
		}
		.div-form-auth {
			display: block;
			visibility: visible;
			width: 100%;
			margin: 20px 0;
		}
		.mikolo {
			display: block;
			position: relative;
			visibility: visible;
			text-align: center;
		}
	}
</style>
<div class="div-entete">
	<table width="100%">
		<tr>
			<td>
				<div class="div-accueil">
					<a href="?accueil">
						<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="Logo Ets" style="max-width:100%; max-height:100%;" />
					</a>
				</div>
				<div class="div-bienvenu">
					<div><?php echo $nom_etablissement; ?></div>
				</div>
				<div class="div-apropos">
					<a href="?apropos" style="color:#003858">À propos</a>
				</div>
			</td>
		</tr>
	</table>
</div>

<div class="et-unique" align="left">
	<a href="?accueil" style="color:#fff">
		<div class="unique"><strong><?php echo $sigle_tb_etablissement; ?></strong></div>
	</a>
	<div class="aca"><?php echo $an_aca; ?></div>
</div>

<div style="margin-top:10px;">
    <a href="<?php echo '?resultat_de_deliberation'; ?>" class="btn-deliberation">Résultat de délibération</a>
</div>


<div class="corps-aut" align="center" style="width:100%; height:100%">
	<?php if (!isset($_GET["resultat_de_deliberation"])) { ?>
		<div style="margin:20px;">
			<table style="width: 100%;">
				<tr>
					<td valign="top">
						<div style="display:inline-block; float:left; width:60%;" align="center">
							<?php 
								if (isset($_GET['apropos'])) {
									include("B_mbindi/Biamunda/apropos.php");
								} else { ?>
									<img src="B_mbindi/Biamunda/icon/unique.gif" style="max-width: 100%; max-height: 100%;" />
								<?php } ?>
							<div align="center">
								<?php include("C_mikolo/C_mikolo.php"); ?>
							</div>
						</div>
						
						<div style="display:inline-block; float:left; width:30%;" align="center">
							<?php include("B_mbindi/Biamunda/f_authentification.php"); ?>
						</div>
					</td>
				</tr>
			</table>
		</div>
	<?php } ?>
</div>

<?php 
	if (isset($_GET["resultat_de_deliberation"])) {
		include("B_mbindi/pue/pv/resultat_deliberation.php");
	} 
	else { 
		?>
		<div class="div-form-auth">
			<?php include("B_mbindi/Biamunda/f_authentification.php"); ?>
		</div>
		<?php 
	} 
?>

<div align="center" class="mikolo">
	<?php include("C_mikolo/C_mikolo.php"); ?>
</div>
