<?php
//dans cours.php 
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['pRograMe'])){
		$httot = 0;
		$hptot = 0;
		$htot = 0;
		?>
		
		<script language="JavaScript" type="text/javascript">
		var ht = 0;
		var hp = 0;
		var htot = 0;
			function txtht(t){
				ht = parseInt(t);
				//htot = ht + parseInt(hp);
				//document.formProgramCours.tot.value = htot;

				document.formProgramCours.tot.value = ht ;
				//document.formProgramCours.tot.value = parseInt(document.formProgramCours.ht.value) + parseInt(document.formProgramCours.hp.value);
			}
			function txthp(p){
				hp = parseInt(p);
				htot = ht + hp;
				document.formProgramCours.tot.value = htot;
				//document.formProgramCours.tot.value = hp + parseInt(document.formProgramCours.ht.value);
			}
		</script>

		<div >
			<h3>Programme des cours de : <?php echo $idPromoOrgV."&ensp;".$designOpOrgV;?><br> Pour l'ann&eacute;e acad&eacute;mique : <?php echo $an_aca;?> </h3>
			<?php 
			if(isset($_POST['BtProgramCours'])){ echo $sms_gerer; }
			if(isset($_POST['BtModifierCoursProgram'])){ echo $sms_gerer; }
			if(isset($_GET['sms_gerer'])){ echo "<span class='reussite'>".$_GET['sms_gerer']."</span>"; }
			
			?>
			<table width="100%" border="1" cellpadding="2" cellspacing="0">
				<tr style="background:#999999; text-align:center; ">
					<td width="4%">N&deg;</td>
					<td width="63%">D&eacute;signation</td>
					<td width="5%">HT</td>
					<td width="5%">HP</td>
					<td width="7%">TOT.</td>
					<td width="15%">Action </td>
				</tr>
				<?php 
				$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";//COURS 
				//$rqt_list_cours = "SELECT * FROM  tb_program_cours ORDER BY designCours ";//COURS 
				if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
					if($exe_rqt_slct_cours_Program->num_rows>0){
						$num=0;
						while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
							$num = $num+1;
							$httot = $httot + $tb_programme_cours["ht"];
							$hptot = $hptot + $tb_programme_cours["hp"];
							if(isset($_GET['modIf']) and isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"] and !isset($_POST['BtModifierCoursProgram'])){ ?>
								<form action="" method="post" name="formProgramCours">
									<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
									<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
									<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
									<tr>
										<td> <?php echo $num; ?></td>
										<td>
											<input name="idCours" type="hidden"  value="<?php echo $tb_programme_cours["idCours"]; ?>">
												<?php echo $tb_programme_cours["designCours"] ; ?>
										</td>
										<td><input name="ht" type="text" size="2" value="<?php echo $tb_programme_cours["ht"]; ?>" onchange="txtht(this.value)"></td>
										<td><input name="hp" type="text" size="2" value="<?php echo $tb_programme_cours["hp"]; ?>" onchange="txthp(this.value)" ></td>
										<td colspan="2">
											<div align="center">
												<input name="BtModifierCoursProgram" type="submit" value="Modifier" style="width:48%;"> 
												<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe";?>">Annuler</a>
											</div>
										</td>
									</tr>
								</form> <?php
							}
							else{
								?>
								<tr>
									<td><?php echo $num; ?> </td>
									<td><?php echo $tb_programme_cours["designCours"]; ?></td>
									<td><div align="right"><?php echo $tb_programme_cours["ht"]; ?></div></td>
									<td><div align="right"><?php echo $tb_programme_cours["hp"]; ?></div></td>
									<td><div align="right"><?php echo $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; ?></div></td>
									<td>
										<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe&modIf&iDcOurs=".$tb_programme_cours["idCours"] ?>">
											<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbidndi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" style="margin-left:10px;"/> 
										</a>
										<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbidndi/Biamunda/icon/supp.gif" class="icon" align="right" alt="Sup." title="Retirer" style="margin-right:10px;"/> &nbsp;&nbsp;&nbsp;&nbsp;
									</td>
								</tr>
								<?php 
							}
						}
						?>
						<tr align="left" style="background:#A0A0A4;">
							<td colspan="2"><div align="right">HEURE TOTALE :  </div></td>
							<td ><div align="right"><?php echo $httot; ?></div></td>
							<td ><div align="right"><?php echo $hptot; ?></div></td>
							<td ><div align="right"><?php  $htot=$httot+$hptot; echo $htot;?></div></td>
							<td >&nbsp;</td>
						</tr>
						<?php 
					}
					else{
						?>
						<tr align="left" style="">
							<td colspan="6" style="color:#FF99CC;">Aucun cours n'est encore programm&eacute; cette ann&eacute;e. </td>
						</tr>
						<?php 
					} 
				}
				else{
					?>
					<tr align="left" style="">
						<td colspan="6" style="color:#FF0000;">Erreur lors de r&eacute;cuperation des cours programm&eacute;s cette ann&eacute;e </td>
					</tr>
					<?php 
				} ?>

					<tr>
						<td colspan="6" style="color:#666666; font-size:18px;" align="center">Ajouter un cours au programme de cette ann&eacute;e </td>
					</tr>
				<form action="" method="post" name="formProgramCours">
					<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
					<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
					<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
					<tr>
						<td colspan="2">
							<select name="idCours" style="width:100%;" >
								<option value="">Sel&eacute;ctionner le cours</option>
								<?php 
								$rqt_cours_a_prog = "select * from  tb_cours WHERE idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designCours ";//COURS 
								if($exe_rqt_cours_a_prog = $conDb->query($rqt_cours_a_prog)){
									if($exe_rqt_cours_a_prog->num_rows>0){
										while($result_rqt_cours_a_prog = $exe_rqt_cours_a_prog->fetch_assoc()){
											echo "<option value='".$result_rqt_cours_a_prog["idCours"]."'>".$result_rqt_cours_a_prog["designCours"]."</option>";
										}
									}
									else{
										echo "<option value=''>Aucun cours trouv&eacute;</option>";
									} 
								}
								else{
									echo "<option value=''>Erreur lors de sel&eacute;ction des cours</option>";
								}?>
							</select>
						</td>
						<td><input name="ht" type="text" size="2" onchange="txtht(this.value)"></td>
						<td><input name="hp" type="text" size="2" onchange="txthp(this.value)" ></td>
						<td><input name="tot" type="text" size="2" disabled="disabled" ></td>
						<td><input name="BtProgramCours" type="submit" value="Programmer" style="width:100%;"></td>
					</tr>
				</form>
			</table>
		</div>
<?php }?>