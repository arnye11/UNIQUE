<?php
  //$conx_srvr_loclhost = mysqli_connect("localhost","root","","unilo");
	//$slctl_db = mysql_select_db("unilo");
	/*try{
		$conDb = new PDO('mysql:host=localhost; dbname = unilo; charset=utf8', 'root', '');
		}
	catch (Exception $e)
		{ 
			die('Erreur de connextion au Server  '.$e->getMessage());
		}
	//$ConDb = null;*/
	
/*	try{
	$conDb = new mysqli('localhost', 'rootp', 'mysarnye', 'kitako_kia_bintu');
	}
	catch (Exception $e){
		die('Erreur de connextion au Server  '.$conDb->connect_error);
	}
*/	
	/*$conDb = new mysqli('localhost', 'rootp', 'mysarnye', 'kitako_kia_bintu');
	try{
		if($conDb->connect_error)
			{
				die('Erreur de connextion au Server  '.$conDb->connect_error);
			}
	}
	catch (Exception $e){
		die('Erreur de connextion au Server  '.$conDb->connect_error);
	}*/

	//___________________________________________________________________________
	/*
	try {
		$conDb = new mysqli('localhost', 'root', 'mysarnye', 'kitako_kia_bintu');
		if($conDb->connect_error){
			//die('Erreur de connextion au Server  '.$conDb->connect_error);
			exit('Erreur de connextion au Server  '.$conDb->connect_error);
		}	
	} catch (Exception $e) {
		exit('Erreur de connextion au Server  '.$e);
	}
	*/
	//--------------------------------------------------------------------------
	$serv = "localhost";
	$db = "kitako_kia_bintu";
	
	//en ligne
	//$user = "arnyenet";
	//$pw = "3YU#eGx10Uaj4:";
	
	//en local
	$user = "root";
	$pw = "mysarnye";
	
	//UKA
	//$user = "arnye";
	//$pw = "ukaarnye2023";
	
	function virifier_tb($c, $bdd, $table){
      $query = "SHOW TABLES FROM ".$bdd ;
      $runQuery = mysqli_query($c, $query);
      
      $tables = array();
      while($row = mysqli_fetch_row($runQuery)){
        $tables[] = $row[0];
      }
      
      if(in_array($table, $tables)){ return TRUE; }
      else{return false;}

    }
	
	//___________________________________________________________________________________
	if($con= mysqli_connect($serv,$user,$pw)){
		/*************************************************************/
			//include("rqt_inistialierlesysteme.php");
		/************************************************************/
		if (mysqli_select_db($con,$db)) {
			$connexion = true;
			include("B_mbindi/Biamunda/rqt/rqt_creation_tab.php");
		}
		else{
			$rqt_ceatDb = "CREATE DATABASE IF NOT EXISTS `".$db."` DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci";
			if(mysqli_query($con, $rqt_ceatDb)){
				if (mysqli_select_db($con,$db)) {
					include("B_mbindi/Biamunda/rqt/rqt_creation_tab.php");
				}
			}
			else{
				echo "Veuillez créer manuellement la base de données '<strong>".$db."</strong>'<br>";
			}
		}

		//CONNEXION POO__________________________________________________________
		try {
			$conDb = new mysqli($serv, $user, $pw, $db);
			if($conDb->connect_error){
				//die('Erreur de connextion au Server  '.$conDb->connect_error);
				exit('Erreur de connextion au Server  '.$conDb->connect_error);
			}	
		} catch (Exception $e) {
			exit('Erreur de connextion au Server  '.$e);
		}
		//______________________________________________________________________
	}
	else{
		echo "<strong>arnye</strong> n'arrive pas à se connecter au serveur de données.<br>";
		echo "Veuillez appeler d'urigence ce numéro : +243 823664195.";
		//echo  mysqli_connect_error() ;
	}
?>