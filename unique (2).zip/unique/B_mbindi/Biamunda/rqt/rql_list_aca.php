<?php 
if (isset($_GET['gerer_aca']))
	{ 
	echo "<div style='border-bottom:groove'><h3>Ann&eacute;es Acad&eacute;miques v&eacute;cues</h></div>";
	$rqt_list_aca = "SELECT idAnAca, DAY(datedebutAnAca) AS jrD, MONTH(datedebutAnAca) AS mmD, YEAR(datedebutAnAca) AS aaaaD, DAY(datefinAnAca) AS jrF, MONTH(datefinAnAca) AS mmF, YEAR(datefinAnAca) AS aaaaF, tauxannuel from  tb_an_aca ORDER BY idAnAca  DESC";
	if($exe_rqt_list_aca = $conDb->query($rqt_list_aca))
		{
		while($result_rqt_list_aca = $exe_rqt_list_aca->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
			{
			$background = "#5B5B5B";
			$border = "solid 2px #5B5B5B";

					$jr_D= $result_rqt_list_aca['jrD'];
					$mois_D= $result_rqt_list_aca['mmD'];
					$jr_F= $result_rqt_list_aca['jrF'];
					$mois_F= $result_rqt_list_aca['mmF'];
					
					if($jr_D<10){$jr_D="0".$jr_D;}
					if($mois_D<10){$mois_D="0".$mois_D;}
					if($jr_F<10){$jr_F="0".$jr_F;}
					if($mois_F<10){$mois_F="0".$mois_F;}

					$dateDebut = $jr_D."-".$mois_D."-".$result_rqt_list_aca['aaaaD'];
					$dateFin = $jr_F."-".$mois_D."-".$result_rqt_list_aca['aaaaF'];

			//$dateDebut = $result_rqt_list_aca['jrD']."-".$result_rqt_list_aca['mmD']."-".$result_rqt_list_aca['aaaaD'];
			//$dateFin = $result_rqt_list_aca['jrF']."-".$result_rqt_list_aca['mmF']."-".$result_rqt_list_aca['aaaaF'];
			
			if($an_aca==$result_rqt_list_aca['idAnAca']){
				$background = "#669999";
				$border = "solid 2px #669999";
			} 
			
			echo "<div align='left' title='code : ".$result_rqt_list_aca['idAnAca']."' style='border:".$border."; margin-bottom:5px; background:#F0F0F0; text-transform:lowercase;'>";
			echo "<div align='left' style='background:".$background."; color:#FFFFFF; padding-left:5px;'>".$result_rqt_list_aca['idAnAca']."</div>";
			echo "<div align='left' style='margin-bottom:5px;margin-left:20px; border-bottom:solid 2px #FFFFFF; background:#F0F0F0;'>Date d'ouverture &nbsp; : ".$dateDebut." <br/>Date de fermeture : ".$dateFin."<br/>Taux annuel : ".$result_rqt_list_aca['tauxannuel']." </div>";
			echo "</div>";
			}
		}
	else
		{
		echo  "Impossible d'atteindre les ann&eacute;es v&eacute;cues. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}

			

	}


?>

