<?php 
//-------------------dans index-------------------------------
//-------------------------------------------------------------


include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_save_aca.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_slct_aca_encours.php");

include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/batumikishi/rqt_verification_log.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/deconx.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/gestion_sms_cliq_menu.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_ajout_fac.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_ajout_promo.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_save_op.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_insrt_sup_OrgOp.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_ajout_ens.php");

include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_updt_fac_slct.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_updt_op_slct.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_updt_promo_slct.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_updt_aca_slct.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_updt_id_etud.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_updt_id_administratif.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_updt_avantar_administratif.php");
include("B_mbindi/Biamunda/rqt/rqt_updata_ens.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/rqt_updt_idEtudiant.php");

include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_sup_fac_slct.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_sup_op_slct.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_sup_promo_slct.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_sup_aca_slct.php");


include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/rqt_rchrch.php");

//modiles
//UTULISATEURS
include("B_mbindi/batumikishi/rqt_aujout_utlisateur.php");

//Inscrition
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/rqt_inscription_etud.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/rqt_reinscription_etud.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/rqt_supprimerEtud.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/rqt_updt_inscription_etud.php");
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/rqt_updt_avantar_etud.php");
include("B_mbindi/Inscription/rqt_annuler_inscription.php");

include("B_mbindi/profilEtudiant/rqt_aujouter_dos.php");

//MAKUTA
include("B_mbindi/makuta/rqt_fr.php");
include("B_mbindi/makuta/op_cptb/rqt_creation_cpt.php");
include("B_mbindi/makuta/op_cptb/rqt_ajouter_oper.php");

//COURS
include("B_mbindi/Cours/rqt_sup_cours_slct.php");
include("B_mbindi/Cours/rqt_ajouter_cours.php");
include("B_mbindi/Cours/rqt_ajouter_UE.php");
include("B_mbindi/Cours/rqt_ajout_cours_au_programme.php");
include("B_mbindi/Cours/rqt_attribuer_cours.php");
include("B_mbindi/Cours/rqt_retirerAttrib_cours.php");
include("B_mbindi/Cours/rqt_updt_cours_programme.php");
include("B_mbindi/Cours/rqt_updt_UE.php");
include("B_mbindi/Cours/rqt_updt_EC.php");
include("B_mbindi/Cours/rqt_retire_EC_au_programme.php");
include("B_mbindi/Cours/rqt_sup_EC.php");
include("B_mbindi/Cours/rqt_sup_UE.php");
include("B_mbindi/Cours/rqt_fixer_TH.php");

//PUE
include("B_mbindi/pue/fiche_cote/rqt_cotes.php");
//include("B_mbindi/pue/grille/rqt_deliberation.php");




?>