<style type="text/css">
    /* Div des r�sultats de recherche */
    .z_Result_rchrch {
        display: none; /* Masqu� par d�faut */
        position: absolute;
        right: 0;
        margin-top: 2px;
        background: #fff;
        color: #003958;
        border: 1px solid #003958;
        padding: 0px;
        border-radius: 7px;
        z-index: 1000;
        box-sizing: border-box;
    }

    /* Un seul r�sultat de recherche */
    .resultat {
        display: flex;
        border: 1px solid #FF66CC;
        border-radius: 7px;
        padding: 5px;
        background-color: #f9f9f9;
        box-sizing: border-box;
        
    }

    .profil_Result_rchrch, .identite_Result_rchrch {
        display: flex;
        border:solid 1px #FF66CC; 
        box-sizing: border-box;
    }

    .profil_Result_rchrch{
       display: flex;
       width: 60px; /* Largeur fixe */
       height: 100%; /* Correspond � la hauteur du conteneur */
        
    }

    .profil_Result_rchrch img {
    	width: 60px; /* L'image ne d�passe jamais la largeur du conteneur */
        height: auto; /* Conserve le ratio d'aspect de l'image */
        border-radius: 50%; /* Image circulaire */
    }

    .identite_Result_rchrch {
        flex: 1; /* Prendre tout l'espace disponible pour les informations */
        font-size: 14px;
        color: #333;
    }

    /* Messages d'�chec ou autres */
    .echec {
        color: #ff0000;
        font-size: 14px;
        text-align: center;
    }

    /* Adaptabilit� mobile */
    @media (max-width: 600px) {
        .resultat {
            flex-direction: column;
            align-items: flex-start;
        }

        .profil_Result_rchrch,
        .identite_Result_rchrch {
            flex: 1;
            text-align: left;
        }
    }

    <?php if (isset($_POST["BtChercher"])) { ?>
    .z_Result_rchrch {
        display: flex; /* Rend visible la zone lors d'une recherche */
    }
    <?php } ?>
</style>

<?php
if (isset($_POST["BtChercher"])) {
    ?>
    <div class="z_Result_rchrch">
        <?php
        if (empty($recherche)) { // Si aucune recherche
            echo "<div class='resultat'><p class='echec'>$SmsRchrch</p></div>";
        } else {
            $slct_etud = "SELECT * FROM tb_etudiant WHERE matricEtud = '".$contenu."'";
            if ($exe_slct_etud = $conDb->query($slct_etud)) {
                if ($result_slct_etud = $exe_slct_etud->fetch_assoc()) {
                    ?>
                    <a href="?profil&id=<?php echo $result_slct_etud['matricEtud']; ?>">
                    <div class="resultat">
                        <div class="profil_Result_rchrch">
                            <img src="<?php echo (!empty($result_slct_etud['avantarEtud']) 
                                    ? "B_mbidndi/Biamunda/media/".$result_slct_etud['avantarEtud'] 
                                    : 'logoprofil2.png'); ?>" 
                                alt="Photo" />
                        </div>
                        <div class="identite_Result_rchrch">
                            <?php 
                            echo $result_slct_etud['nomEtud']." ".$result_slct_etud['postnomEtud']." ".$result_slct_etud['prenomEtud']."<br/>";
                            echo "Matricule : ".$result_slct_etud['matricEtud']."<br/>";
                            // Afficher la promotion ou un message d'erreur (gestion dynamique)
                        	$slct_etud_incrit = "select * from tb_inscription where matricEtud = '".$result_slct_etud['matricEtud']."' and idAca = '".$an_aca."'";
							if($exe_slct_etud_incrit = $conDb->query($slct_etud_incrit)){
                                if($exe_slct_etud_incrit->num_rows>0){
    								if($result_slct_etud_inscrit = $exe_slct_etud_incrit->fetch_assoc()){
    									echo $idPromo=$result_slct_etud_inscrit['idProm']."&ensp;";
                                        $slct_op = "select * from tb_option where idOp = '".$result_slct_etud_inscrit['idOp']."'";//RQT SELECTION DE L'OPTION
    									if($exe_slct_op = $conDb->query($slct_op)){
    										if($result_slct_op = $exe_slct_op->fetch_assoc()){
                                                echo $designOp=$result_slct_op['designOp']."<br/>";
    											$slct_fac = "select * from tb_faculte where idFac = '".$result_slct_op['idFac']."'";//RQT SELECTION DEPARTEMENT
    											if($exe_slct_fac = $conDb->query($slct_fac)){
    												if($result_slct_fac = $exe_slct_fac->fetch_assoc()){
    													$idFc=$result_slct_fac['idFac'];
    													$_SESSION["designFac"]= $designFc=$result_slct_fac['designFac'];
    													$idOp=$result_slct_op['idOp'];
    													$idPromo=$result_slct_etud_inscrit['idProm'];
    													$designOp=$result_slct_op['designOp'];
    													//echo $idPromo."&ensp;".$designOp."<br/>";
    												}
    											}
    										}
    									}
    								}
    								else{
    									echo "<font color='#FF0000'>Errreur Option </font >";
    								}
                                }
                                else{
    								if($_SESSION['idAnAca'] != $an_aca){
    									echo "<br ><font color='#FF0000'>";		
    									if ($result_slct_etud['sexeEtud']=="M"){ echo "Ancien &eacute;tudiant.";}else { echo "Ancienne &eacute;tudiante.";};
    									echo "</font >";
    									$_SESSION['carteEtud'] = false ;		
    								}
    								echo "<font color='#FF0000'>";      
                                    if ($result_slct_etud['sexeEtud']=="M"){ echo "Ancien &eacute;tudiant.";}else { echo "Ancienne &eacute;tudiante.";};
                                    echo "</font >";
                                }
    						}
    						else{
    							echo "<p class='erreur'>Erreur</p>";
    						}
                            ?>
                        </div>
                    </div>
                    </a>
                    <?php
                } else {
                    echo "<p class='echec'>Aucune information trouv�e pour : <b><i>\"".$contenu."\"</i></b>. Essayez avec un autre mot !</p>";
                }
            } else {
                echo "<p class='echec'>Erreur lors de la recherche de l'�tudiant.</p>";
            }
        }
        ?>
    </div>
    <?php
}
?>

