<?php 
$iDfaC="";
$nomEns="";
$postnomEns="";
$prenomEns="";
$gradeEns="";
$domaineEtudEnse="";
$telEns="";
$dateEngagEns= "";

$sexeEns="";
$typeEns="";

if(isset($_POST['BtEnregEns'])){
	//filtratage des donn�es du formulaire
	$iDfaC = filter_input(INPUT_POST,'iDfaC', FILTER_SANITIZE_SPECIAL_CHARS);
	$nomEns = filter_input(INPUT_POST,'nomEns', FILTER_SANITIZE_SPECIAL_CHARS);
	$postnomEns = filter_input(INPUT_POST,'postnomEns', FILTER_SANITIZE_SPECIAL_CHARS);
	$prenomEns = filter_input(INPUT_POST,'prenomEns', FILTER_SANITIZE_SPECIAL_CHARS);
	$gradeEns = filter_input(INPUT_POST,'gradeEns', FILTER_SANITIZE_SPECIAL_CHARS);
	$domaineEtudEnse = filter_input(INPUT_POST,'domaineEtudEnse', FILTER_SANITIZE_SPECIAL_CHARS);
	$telEns = filter_input(INPUT_POST,'telEns', FILTER_SANITIZE_SPECIAL_CHARS);
	$dateEngagEns = filter_input(INPUT_POST,'dateEngagEns', FILTER_SANITIZE_SPECIAL_CHARS);

	$sexeEns=$_POST['sexeEns'];
	$typeEns=$_POST['typeEns'];
	
	if($iDfaC!="" and $nomEns!="" and $postnomEns!="" and $prenomEns!="" and $sexeEns!="" and $typeEns!="" and $gradeEns!="" and $domaineEtudEnse!="" )
		{
		//$idEns = "ES".time();
		$idEns = "ES".random_int(100, 9999);
		$rqt_insrt_cours = "INSERT INTO tb_enseignant VALUES ('".$idEns."','".$nomEns."','".$postnomEns."','".$prenomEns."','".$sexeEns."','".$domaineEtudEnse."','".$telEns."','".$gradeEns."','".$iDfaC."','".$typeEns."','".$dateEngagEns."')";
		if($exe_rqt_insrt_cours = mysqli_query($con, $rqt_insrt_cours))
			{
			$sms_gerer = "<div style='color:#009900'>Enseignant enregistr&eacute; avec succ&egrave;s.</div>";
			$nomEns="";
			$postnomEns="";
			$prenomEns="";
			$gradeEns="";
			$domaineEtudEnse="";
			$telEns="";
			
			$jrEngagEns="";
			$moiEngagEns="";
			$AnEngagEns="";
			$dateEngagEns= "";
			
			$sexeEns="";
			$typeEns="";
			}
		else
			{
			$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
	else
		{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}

}
?>