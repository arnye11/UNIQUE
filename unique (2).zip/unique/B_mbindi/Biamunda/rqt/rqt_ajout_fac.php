<?php
	if(isset($_GET['ajouteraJOuterFacSeCt'])){
		$sms_gerer = "Sesissez la fili&egrave;re" ;
		if(isset($_POST['BtAjouterFacSec'])){
			$idEts = filter_input(INPUT_POST,'idEts', FILTER_SANITIZE_SPECIAL_CHARS);
			$idFac = filter_input(INPUT_POST,'idFac', FILTER_SANITIZE_SPECIAL_CHARS);
			$designFac = filter_input(INPUT_POST,'designFac', FILTER_SANITIZE_SPECIAL_CHARS);

			if($idFac!="" and $designFac!=""){
				$rqt_insrt_fac = "insert into tb_faculte values ('".$idFac."','".$designFac."','".$idEts."')";
				if($exe_rqt_insrt_fac = mysqli_query($con, $rqt_insrt_fac)){					
					$sms_gerer = "<div style='color:#009900'>Fili&egrave;re ajout&eacute;e</div>";
				}
				else{
					$sms_gerer = "<div style='color:#FF0000'>Echec</div>";
				}
			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Veuillez saisir la Fili&egrave;re</div>";
			}

		}
	}
?>