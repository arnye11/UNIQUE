<?php 
if(isset($_POST['BtsavePro']))
	{
	$codPro = filter_input(INPUT_POST,'codPro', FILTER_SANITIZE_SPECIAL_CHARS);
	$designPro = filter_input(INPUT_POST,'designPro', FILTER_SANITIZE_SPECIAL_CHARS);

	if($codPro!="" and $designPro!="")
		{
		$rqt_insrt_pro = "INSERT INTO tb_promotion VALUES('".$codPro."','".$designPro."')";
		if($exe_rqt_insrt_pro = $conDb->query($rqt_insrt_pro))
			{
			$sms_gerer = "<div style='color:#009900'>Promotion enregistr� avec succ�s.</div>";
			}
		else
			{
			$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op�ration. veuillez reaisseyer.</div>";
			}
		}
	else
		{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}

}
?>