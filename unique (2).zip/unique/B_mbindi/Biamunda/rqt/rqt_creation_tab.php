<?php 
	//TABLE tb_an_aca
	if (!virifier_tb($con, $db, 'tb_an_aca')) {
		$tb_an_aca= "
			CREATE TABLE IF NOT EXISTS `tb_an_aca` (
				`idAnAca` varchar(9) NOT NULL,
				`datedebutAnAca` date NOT NULL,
				`datefinAnAca` date NOT NULL,
				`tauxannuel` int(10) NOT NULL,
				PRIMARY KEY (`idAnAca`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_an_aca)){
			echo "Veuillez créer manuellement le Table '<strong>Année académique</strong>'<br>";
		} 
	}

	//TABLE tb_attribution
	if (!virifier_tb($con, $db, 'tb_attribution')) {
		$tb_attribution= "
			CREATE TABLE IF NOT EXISTS `tb_attribution` (
			  `idAt` int(11) NOT NULL AUTO_INCREMENT,
			  `idCours` varchar(10) NOT NULL,
			  `idEns` varchar(15) NOT NULL,
			  `idPromo` varchar(10) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `idAnAca` varchar(10) NOT NULL,
			  `dateAt` date NOT NULL,
			  PRIMARY KEY (`idAt`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_attribution)){
			echo "Veuillez créer manuellement le Table '<strong>Attribution</strong>'<br>";
		} 
	}

	//TABLE tb_auto_dec
	if (!virifier_tb($con, $db, 'tb_auto_dec')) {
		$tb_auto_dec= "
			CREATE TABLE IF NOT EXISTS `tb_auto_dec` (
			  `idAutoDec` varchar(20) NOT NULL,
			  `nomAutoDec` varchar(20) NOT NULL,
			  `postnomAutoDec` varchar(20) NOT NULL,
			  `prenomAutoDec` varchar(20) NOT NULL,
			  `sexeAutoDec` varchar(1) NOT NULL,
			  `telAutoDec` varchar(20) NOT NULL,
			  `avantarAutoDec` varchar(200) NOT NULL,
			  `loginAutoDec` varchar(50) NOT NULL,
			  `paswordAutoDec` varchar(50) NOT NULL,
			  `idFonctAutoDec` varchar(10) NOT NULL,
			  `NivAc` int(1) NOT NULL,
			  `NivInter` int(11) NOT NULL,
			  `idFac` varchar(20) NOT NULL,
			  PRIMARY KEY (`idAutoDec`),
			  UNIQUE KEY `loginAutoDec` (`loginAutoDec`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_auto_dec)){
			echo "Veuillez créer manuellement le Table '<strong>Autorité décanale</strong>'<br>";
		} 
		else{
			$rqt_insrt_auto_dec = "INSERT INTO `tb_auto_dec` (`idAutoDec`, `nomAutoDec`, `postnomAutoDec`, `prenomAutoDec`, `sexeAutoDec`, `telAutoDec`, `avantarAutoDec`, `loginAutoDec`, `paswordAutoDec`, `idFonctAutoDec`, `NivAc`, `NivInter`, `idFac`) VALUES('admin1', 'NYEMBO', 'MPAMPI', 'Augu Roger', 'M', '0823664195', '', 'admin', 'admin2', 'admin', 2, 4, 'TOUTES')";
			if(!mysqli_query($con, $rqt_insrt_auto_dec)){
				echo "Veuillez inserer manuellement l'\'<strong>Autorité décanale</strong>'<br>";
			}
		}
	}
	
	//TABLE tb_compte 
	if (!virifier_tb($con, $db, 'tb_compte')) {
		$tb_compte= "
			CREATE TABLE IF NOT EXISTS `tb_compte` (
			  `idCpt` varchar(20) NOT NULL,
			  `designCpt` varchar(100) NOT NULL,
			  `idAutoDec` varchar(20) NOT NULL,
			  `dateCreationCpt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			  PRIMARY KEY (`idCpt`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_compte)){
			echo "Veuillez créer manuellement le Table '<strong>Compte</strong>'<br>";
		} 
	}
	
	//TABLE tb_cote
	if (!virifier_tb($con, $db, 'tb_cote')) {
		$tb_cote= "
			CREATE TABLE IF NOT EXISTS `tb_cote` (
			  `idCote` INT(11) NOT NULL AUTO_INCREMENT,
			  `matricEtud` varchar(13) NOT NULL,
			  `cote_s1` int(2) NOT NULL,
			  `cote_s2` int(2) NOT NULL,
			  `idCours` varchar(20) NOT NULL,
			  `idPromo` varchar(20) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `idAca` varchar(20) NOT NULL,
			  `idAutoDec` varchar(20) NOT NULL,
			  `dateAjoutCote` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			  PRIMARY KEY (`idCote`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_cote)){
			echo "Veuillez créer manuellement le Table '<strong>Côte</strong>'<br>";
		} 
		/*$rqt_altr_tb_cotIdCote="ALTER TABLE `tb_cote` ADD `idCote` INT(11) NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`idCote`)"; 	
		if(!mysqli_query($con, $rqt_altr_tb_cotIdCote)){
			echo "Veuillez créer manuellement la colonne '<strong>idCote</strong>'<br>";
		}*/
	}
	
	//TABLE tb_cours
	if (!virifier_tb($con, $db, 'tb_cours')) {
		$tb_cours= "
			CREATE TABLE IF NOT EXISTS `tb_cours` (
			  `idCours` varchar(20) NOT NULL,
			  `designCours` varchar(200) NOT NULL,
			  `idUE` varchar(20) NOT NULL,
			  `idPromo` varchar(20) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  PRIMARY KEY (`idCours`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_cours)){
			echo "Veuillez créer manuellement le Table '<strong>Cours</strong>'<br>";
		} 		
	}

	//TABLE tb_credit_ue
	$tb = "tb_credit_ue";
	if (!virifier_tb($con, $db, $tb)) {
		$tb_cours= "
			CREATE TABLE IF NOT EXISTS $tb(
			  `idCreditUE` int(11) NOT NULL AUTO_INCREMENT,
			  `creditUE` int(2) NOT NULL,
			  `idPromo` varchar(20) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `idAca` varchar(20) NOT NULL,
			  PRIMARY KEY (`idCreditUE`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_cours)){
			echo "Veuillez créer manuellement le Table '<strong>".$tb."</strong>'<br>";
		} 		
	}
	//TABLE tb_deliberation
	if (!virifier_tb($con, $db, 'tb_deliberation')) {
		$tb_deliberation= "
			CREATE TABLE IF NOT EXISTS `tb_deliberation` (
			  `idDel` int(11) NOT NULL AUTO_INCREMENT,
			  `matricEtud` varchar(20) NOT NULL,
			  `idPromo` varchar(20) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `idAnAca` varchar(20) NOT NULL,
			  `prctg` int(11) NOT NULL,
			  `mention` varchar(4) NOT NULL,
			  `session` varchar(4) NOT NULL,
			  `datedel` datetime NOT NULL,
			  `idAutoDec` varchar(20) NOT NULL,
			  PRIMARY KEY (`idDel`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_deliberation)){
			echo "Veuillez créer manuellement le Table '<strong>deliberation</strong>'<br>";
		} 		
	}
	//TABLE tb_dossier
	if (!virifier_tb($con, $db, 'tb_dossier_etud')) {
		$tb_dossier_etud= "
			CREATE TABLE IF NOT EXISTS `tb_dossier_etud` (
			  `idDosEtud` int(11) NOT NULL AUTO_INCREMENT,
			  `designDosEtud` varchar(200) NOT NULL,
			  `idTypDosEtud` varchar(20) NOT NULL,
			  `matricEtud` varchar(13) NOT NULL,
			  `dateDos` date NOT NULL,
			 PRIMARY KEY (`idDosEtud`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_dossier_etud)){
			echo "Veuillez créer manuellement le Table '<strong>Dossier etudiant</strong>'<br>";
		} 		
	}
	
	//TABLE tb_enseignant
	if (!virifier_tb($con, $db, 'tb_enseignant')) {
		$tb_enseignant= "
			CREATE TABLE IF NOT EXISTS `tb_enseignant` (
			  `idEns` varchar(15) NOT NULL,
			  `nomEns` varchar(50) NOT NULL,
			  `postnomEns` varchar(50) NOT NULL,
			  `prenomEns` varchar(50) NOT NULL,
			  `sexeEns` varchar(1) NOT NULL,
			  `domainEtudEns` varchar(100) NOT NULL,
			  `telEns` varchar(100) CHARACTER SET utf8 NOT NULL,
			  `idGrad` varchar(10) NOT NULL,
			  `idFac` varchar(10) NOT NULL,
			  `typeEns` varchar(1) CHARACTER SET utf8 NOT NULL,
			  `dateEngagEns` varchar(10) NOT NULL,
			  PRIMARY KEY (`idEns`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_enseignant)){
			echo "Veuillez créer manuellement le Table '<strong>Enseignant</strong>'<br>";
		} 		
	}
	
	//TABLE tb_etablissement
	if (!virifier_tb($con, $db, 'tb_etablissement')) {
		$tb_etablissement= "
			CREATE TABLE IF NOT EXISTS `tb_etablissement` (
			  `idEts` varchar(20) NOT NULL,
			  `nomEts` varchar(200) NOT NULL,
			  `sigleEts` varchar(30) NOT NULL,
			  `adresseEts` varchar(200) NOT NULL,
			  `villeEts` varchar(100) NOT NULL,
			  `telEts` varchar(60) NOT NULL,
			  `emailEts` varchar(100) NOT NULL,
			  `etatEts` tinyint(1) NOT NULL,
			  `typEts` varchar(20) NOT NULL,
			  `logoEts` varchar(100) NOT NULL,
			  `dateCreationEts` date NOT NULL,
			  PRIMARY KEY (`idEts`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";
		
		if(!mysqli_query($con, $tb_etablissement)){
			echo "Veuillez créer manuellement le Table '<strong>Etablissement</strong>'<br>";
		} 		
	}
	/*else{
		$tb = array("idEts","nomEts","sigleEts","adresseEts","villeEts","telEts","emailEts","etatEts","typEts","logoEts","dateCreationEts");
		
		$villeEts=false;
		$results = mysqli_query($con, "DESCRIBE tb_etablissement");
        while($arr = mysqli_fetch_array($results)){
        	if($arr['0']=="villeEts"){
        		$villeEts = true;
        		echo $arr['0']." - villeEts<br>";
        	}
        }
        if($villeEts == false){
    		$rqt="ALTER TABLE tb_etablissement ADD villeEts varchar(60) AFTER adresseEts";
    		if(!mysqli_query($con, $rqt)){
				echo "Veuillez inserer manuellement la colonne '<strong>villeEts</strong> après <strong>adresseEts</strong>', Type et taille : varchar(60) <br>";
			}
			else{
				$results = mysqli_query($con, "DESCRIBE tb_etablissement");
		        $i = 0;
		        while($arr = mysqli_fetch_array($results)){
		        	if($arr['0']!=$tb[$i]){
		        		$rqt = "ALTER TABLE tb_etablissement CHANGE ".$arr['0']." ".$tb[$i]." ".$arr['1'];
		        		if(!mysqli_query($con, $rqt)){
							echo "Veuillez modifier manuellement la colonne '<strong>".$arr['0']."</strong> en <strong>".$tb[$i]."</strong>', Taille : ".$arr['1']."<br>";
						}
		        	}
		        	$i++;
		        }
			}
    	}

        
        echo "<br>";	
	}
	*/
	
	//TABLE tb_etudiant
	if (!virifier_tb($con, $db, 'tb_etudiant')) {
		$tb_etudiant= "
			CREATE TABLE IF NOT EXISTS `tb_etudiant` (
			  `matricEtud` varchar(20) NOT NULL,
			  `MatriculeManuel` varchar(30) NOT NULL,
			  `nomEtud` varchar(20) NOT NULL,
			  `postnomEtud` varchar(20) NOT NULL,
			  `prenomEtud` varchar(20) NOT NULL,
			  `sexeEtud` varchar(1) NOT NULL,
			  `datenaissEtud` date NOT NULL,
			  `lieunaisEtud` varchar(100) NOT NULL,
			  `sectionSuiviEtud` varchar(100) NOT NULL,
			  `pourctgEtud` varchar(5) NOT NULL,
			  `telEtud` varchar(20) NOT NULL,
			  `emailEtud` varchar(50) NOT NULL,
			  `adresseEtud` varchar(500) NOT NULL,
			  `avantarEtud` varchar(500) NOT NULL,
			  `dateinscritEtud` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			  `nomPereEtud` varchar(50) NOT NULL,
			  `nomMereEtud` varchar(50) NOT NULL,
			  PRIMARY KEY (`matricEtud`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_etudiant)){
			echo "Veuillez créer manuellement le Table '<strong>Etudiant</strong>'<br>";
		} 		
	}
	
	//TABLE tb_faculte
	if (!virifier_tb($con, $db, 'tb_faculte')) {
		$tb_faculte= "
			CREATE TABLE IF NOT EXISTS `tb_faculte` (
			  `idFac` varchar(10) NOT NULL,
			  `designFac` varchar(200) NOT NULL,
			  `idEts` varchar(20) NOT NULL,
			  PRIMARY KEY (`idFac`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_faculte)){
			echo "Veuillez créer manuellement le Table '<strong>Faculte</strong>'<br>";
		} 		
	}
	
	//TABLE tb_fixation_prix
	if (!virifier_tb($con, $db, 'tb_fixation_prix')) {
		$tb_fixation_prix= "
			CREATE TABLE IF NOT EXISTS `tb_fixation_prix` (
			  `idFixPrix` int(11) NOT NULL AUTO_INCREMENT,
			  `idPromo` varchar(20) NOT NULL,
			  `idFac` varchar(10) NOT NULL,
			  `idAca` varchar(9) NOT NULL,
			  `idFr` varchar(20) NOT NULL,
			  `montantFix` int(10) NOT NULL,
			  PRIMARY KEY (`idFixPrix`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_fixation_prix)){
			echo "Veuillez créer manuellement le Table '<strong>Fixation frais</strong>'<br>";
		} 		
	}
	
	//TABLE tb_fonction
	if (!virifier_tb($con, $db, 'tb_fonction')) {
		$tb_fonction= "
			CREATE TABLE IF NOT EXISTS `tb_fonction` (
			  `idFonct` varchar(15) NOT NULL,
			  `designFonc` varchar(100) NOT NULL,
			  PRIMARY KEY (`idFonct`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_fonction)){
			echo "Veuillez créer manuellement le Table '<strong>Fonction</strong>'<br>";
		}
		else{
			$tb_fonction= "INSERT INTO `tb_fonction` (`idFonct`, `designFonc`) VALUES
			('OPS', 'Opérateur de saisie'), 
			('APPARIT', 'Apparitaire Central'), 
			('CPTBL', 'Comptable'), 
			('CAIS', 'Caissier(e)'), 
			('ENCODJ', 'Encodeur du Jury'), 
			('SECFAC', 'Secrétaire facultaire')";
			if(!mysqli_query($con, $tb_fonction)){
				echo "Veuillez inserer manuellement les '<strong>Fonctions</strong>'<br>";
			}
		} 		
	}
	
	//TABLE tb_frais
	if (!virifier_tb($con, $db, 'tb_frais')) {
		$tb_frais= "
			CREATE TABLE IF NOT EXISTS `tb_frais` (
			  `idFr` varchar(20) NOT NULL,
			  `designFr` varchar(50) NOT NULL,
			  `idTypFr` varchar(20) NOT NULL,
			  PRIMARY KEY (`idFr`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_frais)){
			echo "Veuillez créer manuellement le Table '<strong>Frais</strong>'<br>";
		}
		else{
			$tb_frais= "INSERT INTO `tb_frais` (`idFr`, `designFr`, `idTypFr`) VALUES
			('FAT1', '1ère TRANCHE', 'TF1'),
			('FAT2', '2ème TRANCHE', 'TF1'),
			('FAT3', '3ème TRANCHE', 'TF1'),
			('FCIRol', 'Inscription au rôle ', 'TF2'),
			('FCIMiS', 'Inscription à la Mi-Session', 'TF2')";
			if(!mysqli_query($con, $tb_frais)){
				echo "Veuillez inserer manuellement les '<strong>Frais</strong>'<br>";
			}
		} 		
	}
	
	//TABLE tb_grade
	if (!virifier_tb($con, $db, 'tb_grade')) {
		$tb_grade= "
			CREATE TABLE IF NOT EXISTS `tb_grade` (
			  `idGrad` varchar(10) NOT NULL,
			  `designGrad` varchar(50) NOT NULL,
			  PRIMARY KEY (`idGrad`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_grade)){
			echo "Veuillez créer manuellement le Table '<strong>Grade</strong>'<br>";
		}
		else{
			$tb_grade= "INSERT INTO `tb_grade` (`idGrad`, `designGrad`) VALUES
			('AS1', 'Assistant 1er mandat'),
			('AS2', 'Assistant 2è mandat'),
			('CT', 'Chef de Travaux'),
			('PA', 'Professeur Associé'),
			('P', 'Professeur'),
			('PO', 'Professeur Ordinnaire')";
			if(!mysqli_query($con, $tb_grade)){
				echo "Veuillez inserer manuellement les '<strong>Grades</strong>'<br>";
			}
		} 		
	}
	
	//TABLE tb_inscription
	if (!virifier_tb($con, $db, 'tb_inscription')) {
		$tb_inscription= "
			CREATE TABLE IF NOT EXISTS `tb_inscription` (
			  `idInscrit` int(11) NOT NULL AUTO_INCREMENT,
			  `matricEtud` varchar(20) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `idProm` varchar(5) NOT NULL,
			  `idAca` varchar(9) NOT NULL,
			  `idAutoDec` varchar(50) NOT NULL,
			  `dateInscrit` datetime NOT NULL,
			  PRIMARY KEY (`idInscrit`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_inscription)){
			echo "Veuillez créer manuellement le Table '<strong>Inscription</strong>'<br>";
		}		
	}
	
	//TABLE tb_operation
	if (!virifier_tb($con, $db, 'tb_operation')) {
		$tb_operation= "
			CREATE TABLE IF NOT EXISTS `tb_operation` (
			  `idOper` int(11) NOT NULL AUTO_INCREMENT,
			  `idCpt` varchar(20) NOT NULL,
			  `idTypOper` varchar(20) NOT NULL,
			  `montantOper` int(11) NOT NULL,
			  `deviseOper` varchar(5) NOT NULL,
			  `idAutoDec` varchar(20) NOT NULL,
			  `motifOper` varchar(100) NOT NULL,
			  `dateOper` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			  PRIMARY KEY (`idOper`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_operation)){
			echo "Veuillez créer manuellement le Table '<strong>Op&eacute;ration</strong>'<br>";
		} 
	}
	
	//TABLE tb_option
	if (!virifier_tb($con, $db, 'tb_option')) {
		$tb_option= "
			CREATE TABLE IF NOT EXISTS `tb_option` (
			  `idOp` varchar(20) NOT NULL,
			  `designOp` varchar(500) NOT NULL,
			  `idFac` varchar(50) NOT NULL,
			  PRIMARY KEY (`idOp`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_option)){
			echo "Veuillez créer manuellement le Table '<strong>Option</strong>'<br>";
		}		
	}
	
	//TABLE tb_organisation_option
	if (!virifier_tb($con, $db, 'tb_organisation_option')) {
		$tb_organisation_option= "
			CREATE TABLE IF NOT EXISTS `tb_organisation_option` (
			  `idOrgOp` int(10) NOT NULL AUTO_INCREMENT,
			  `idPromo` varchar(10) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `idAnAca` varchar(10) NOT NULL,
			  PRIMARY KEY (`idOrgOp`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_organisation_option)){
			echo "Veuillez créer manuellement le Table '<strong>Organisation des options</strong>'<br>";
		}		
	}
	
	//TABLE tb_program_cours
	if (!virifier_tb($con, $db, 'tb_program_cours')) {
		$tb_program_cours= "
			CREATE TABLE IF NOT EXISTS `tb_program_cours` (
			  `idProgC` int(11) NOT NULL AUTO_INCREMENT,
			  `idCours` varchar(20) NOT NULL,
			  `idPromo` varchar(20) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `ht` int(11) NOT NULL,
			  `hd` int(11) NOT NULL,
			  `hp` int(11) NOT NULL,
			  `idAnAca` varchar(10) NOT NULL,
			  `dateProgC` date NOT NULL,
			  PRIMARY KEY (`idProgC`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_program_cours)){
			echo "Veuillez créer manuellement le Table '<strong>Program des cours</strong>'<br>";
		}		
	}
	
	//TABLE tb_promotion
	$tab = "tb_promotion";
	if (!virifier_tb($con, $db, $tab)) {
		$rqt= "
			CREATE TABLE IF NOT EXISTS $tab (
			  `idPromo` varchar(10) NOT NULL,
			  `designPromo` varchar(50) NOT NULL,
			  `nivPromo` int(2) NOT NULL,
			  `systPromo` varchar(1) NOT NULL,
			  PRIMARY KEY (`idPromo`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $rqt)){
			echo "Veuillez créer manuellement le Table '<strong>Promotion</strong>'<br>";
		}
		else{
			$rqt= "INSERT INTO $tab (`idPromo`, `designPromo`,`nivPromo`,`systPromo`) VALUES
			('G1', '1er Graduat', '1', 'A'),
			('G2', '2&egrave;me Graduat', '2', 'A'),
			('G3', '3&egrave;me Graduat', '3', 'A'),
			('L1A', '1&egrave;re Licence', '4', 'A'),
			('L2A', '2&egrave;me Licence', '5', 'A'),
			('D1', 'Doctorat 1', '4', 'A'),
			('D2', 'Doctorat 2', '5', 'A'),
			('D3', 'Doctorat 3', '6', 'A'),
			('D4', 'Doctorat 4', '7', 'A'),
			('L0', 'Prop&eacute;deutique', '0', 'N'),
			('L1', '1&egrave;re Licence LMD', '1', 'N'),
			('L2', '2&egrave;me Licence LMD', '2', 'N'),
			('L3', '3&egrave;me Licence LMD', '3', 'N'),
			('L4', '4&egrave;me Licence LMD', '4', 'N'),
			('M1', 'Master 1', '5', 'N'),
			('M2', 'Master 2', '6', 'N')
			";
			if(!mysqli_query($con, $rqt)){
				echo "Veuillez inserer manuellement les '<strong>Promotions</strong>'<br>";
			}
		}		
	}
	//TABLE tb_Semestre
	if (!virifier_tb($con, $db, 'tb_semestre')) {
		$tb_Semestre= "
			CREATE TABLE IF NOT EXISTS `tb_semestre` (
			  `idSem` varchar(5) NOT NULL,
			  `designSem` varchar(60) NOT NULL,
			  PRIMARY KEY (`idSem`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_Semestre)){
			echo "Veuillez créer manuellement le Table '<strong>Semestre</strong>'<br>";
		}
		else{
			$tb_Semestre= "INSERT INTO `tb_semestre` (`idSem`, `designSem`) VALUES
			('SEM1', '1er Semestre'),
			('SEM2', '2ème Semestre')";
			if(!mysqli_query($con, $tb_Semestre)){
				echo "Veuillez inserer manuellement les '<strong>Semestre</strong>'<br>";
			}
		}		
	}
	
	//TABLE tb_taux_horaire
	if (!virifier_tb($con, $db, 'tb_taux_horaire')) {
		$tb_taux_horaire= "CREATE TABLE IF NOT EXISTS `tb_taux_horaire` (
		  `idTh` int(11) NOT NULL AUTO_INCREMENT,
		  `idGrad` varchar(10) NOT NULL,
		  `montantTh` int(11) NOT NULL,
		  `idFac` varchar(20) NOT NULL,
		  `idAnAca` varchar(10) NOT NULL,
		  `dateTh` datetime NOT NULL,
		  PRIMARY KEY (`idTh`)
		) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
		";

	 	if(!mysqli_query($con, $tb_taux_horaire)){
			echo "Veuillez créer manuellement le Table '<strong>tb taux horaire</strong>'<br>";
		}		
	}
	//TABLE tb_type_dossier_etud
	if (!virifier_tb($con, $db, 'tb_type_dossier_etud')) {
		$tb_type_dossier_etud= "
			CREATE TABLE IF NOT EXISTS `tb_type_dossier_etud` (
			  `idTypDosEtud` varchar(20) NOT NULL,
			  `designTypDosEtud` varchar(200) NOT NULL,
			  PRIMARY KEY (`idTypDosEtud`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_type_dossier_etud)){
			echo "Veuillez créer manuellement le Table '<strong>Type dossier etudiant</strong>'<br>";
		} 
		else{
			$tb_type_dossier_etud= "INSERT INTO `tb_type_dossier_etud` (`idTypDosEtud`, `designTypDosEtud`) VALUES
			('BIL5eM', 'Bulletin 5&egrave;me'),
			('BIL6eM', 'Bulletin 6&egrave;me'),
			('DipETA', 'Diplome d&rsquo;&eacute;tat ou son &eacute;quivalant'),
			('AttApPhysiq', 'Attestation d&rsquo;aptitude physique'),
			('AttBVieM', 'Attestation de bonne vie et moeurs'),
			('FichInsc', 'Fiche d&rsquo;iscription'),
			('CE', 'Carte d&rsquo;&eacute;lecteur'),
			('AttFreq', 'Attestation de fr&eacute;quentation'),
			('RelvCot', 'Releve ou Bulletin de cote')";
			if(!mysqli_query($con, $tb_type_dossier_etud)){
				echo "Veuillez inserer manuellement les '<strong> El&eacute;ment du dosssier de l'&eacute;tudiant</strong>'<br>";
			}
		}		
	}
	
	//TABLE tb_type_etablissement
	if (!virifier_tb($con, $db, 'tb_type_etablissement')) {
		$tb_type_etablissement= "
			CREATE TABLE IF NOT EXISTS `tb_type_etablissement` (
			  `idTypEts` varchar(20) NOT NULL,
			  `designTypEts` varchar(60) NOT NULL,
			  PRIMARY KEY (`idTypEts`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_type_etablissement)){
			echo "Veuillez créer manuellement le Table '<strong>Type établissement</strong>'<br>";
		}
		else{ 
			$tb_type_etablissement= "INSERT INTO `tb_type_etablissement` (`idTypEts`, `designTypEts`) VALUES('UN', 'Universit&eacute;'),('IS', 'Institut sup&eacute;rieur'),('ES', 'Ecole secondaire'),('EP', 'Ecole primaire')";
			if(!mysqli_query($con, $tb_type_etablissement)){
				echo "Veuillez inserer manuellement le '<strong>Type établissement</strong>'<br>";
			}
		}		
	}
	
	//TABLE tb_type_frais
	if (!virifier_tb($con, $db, 'tb_type_frais')) {
		$tb_type_frais= "
			CREATE TABLE IF NOT EXISTS `tb_type_frais` (
			  `idTypFr` varchar(10) NOT NULL,
			  `designTypFr` varchar(50) NOT NULL,
			  PRIMARY KEY (`idTypFr`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_type_frais)){
			echo "Veuillez créer manuellement le Table '<strong>Type des frais</strong>'<br>";
		}
		else{
			$tb_type_frais= "INSERT INTO `tb_type_frais` (`idTypFr`, `designTypFr`) VALUES
			('TF1', 'FRAIS ACADEMIQUES'),
			('TF2', 'FRAIS CONNEXES'),
			('TF3', 'AUTRES FRAIS CONNEXES')";
			if(!mysqli_query($con, $tb_type_frais)){
				echo "Veuillez inserer manuellement le '<strong>Type  des frais</strong>'<br>";
			}
		}		
	}
	
	//TABLE tb_type_operation
	if (!virifier_tb($con, $db, 'tb_type_operation')) {
		$tb_type_operation= "
			CREATE TABLE IF NOT EXISTS `tb_type_operation` (
			  `idTypOper` varchar(20) NOT NULL,
			  `designTypOper` varchar(30) NOT NULL,
			  PRIMARY KEY (`idTypOper`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_type_operation)){
			echo "Veuillez créer manuellement le Table '<strong>Type op&eacute;ration</strong>'<br>";
		} 
		else{
			$tb_type_operation= "INSERT INTO `tb_type_operation` (`idTypOper`, `designTypOper`) VALUES
			('Entr1', 'Entr&eacute;e de fond'),
			('Sort2', 'Sortie de fond')";
			if(!mysqli_query($con, $tb_type_operation)){
				echo "Veuillez inserer manuellement les '<strong>Types d'op&eacute;ration</strong>'<br>";
			}
		}
	}
	
	//TABLE tb_ue
	if (!virifier_tb($con, $db, 'tb_ue')) {
		$tb_ue= "
			CREATE TABLE IF NOT EXISTS `tb_ue` (
			  `idUE` varchar(20) NOT NULL,
			  `designUE` varchar(200) NOT NULL,
			  `idSem` varchar(5) NOT NULL,
			  `idPromo` varchar(20) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  PRIMARY KEY (`idUE`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_ue)){
			echo "Veuillez créer manuellement le Table '<strong>UE</strong>'<br>";
		}		
	}
	
	//TABLE tb_versement
	if (!virifier_tb($con, $db, 'tb_versement')) {
		$tb_versement= "
			CREATE TABLE IF NOT EXISTS `tb_versement` (
			  `idVers` int(100) NOT NULL AUTO_INCREMENT,
			  `matEtud` varchar(20) NOT NULL,
			  `idPromo` varchar(10) NOT NULL,
			  `idOp` varchar(20) NOT NULL,
			  `idAca` varchar(10) NOT NULL,
			  `idFr` varchar(20) NOT NULL,
			  `montantVers` int(10) NOT NULL,
			  `dateVers` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
			  `idAutoDec` varchar(10) NOT NULL,
			  PRIMARY KEY (`idVers`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci
		";

	 	if(!mysqli_query($con, $tb_versement)){
			echo "Veuillez créer manuellement le Table '<strong>Versement</strong>'<br>";
		}		
	}


 ?>