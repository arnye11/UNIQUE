<?php 
if(isset($_POST['BtCreerEts'])){
	$codEts = filter_input(INPUT_POST,'codEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$nomEts = filter_input(INPUT_POST,'nomEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$sigleEts = filter_input(INPUT_POST,'sigleEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$adressEts = filter_input(INPUT_POST,'adressEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$villeEts = filter_input(INPUT_POST,'villeEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$telEts = filter_input(INPUT_POST,'telEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$emailEts = filter_input(INPUT_POST,'emailEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$typEts = filter_input(INPUT_POST,'typEts', FILTER_SANITIZE_SPECIAL_CHARS);
	$logoEts = filter_input(INPUT_POST,'file', FILTER_SANITIZE_SPECIAL_CHARS);

	if(($codEts!="" and $nomEts!="" and $sigleEts!="" and $villeEts!="" and $typEts!="") ){
		/************************************************************
		* Definition des constantes / tableaux et variables			*
		************************************************************/
		// Constantes
		define('TARGET', '/B_mbindi/Biamunda/icon/'); // Repertoire cible
		define('MAX_SIZE', 1099511627776); // Taille max en octets du fichier
		define('WIDTH_MAX', 800000); // Largeur max de l'image en pixels
		define('HEIGHT_MAX', 1200000); // Hauteur max de l'image en pixels
		// Tableaux de donnees
		$tabExt = array('jpg','gif','png','jpeg'); // Extensions autorisees
		$infosImg = array();
		// Variables
		$sms_modif ="";
		$photo = "";
		$extension = '';
		$message = '';
		$nomImage = '';
		/************************************************************
		* Creation du repertoire cible si inexistant				*
		*************************************************************/
		if( !is_dir( $_SERVER['DOCUMENT_ROOT'].TARGET) ){
			if( !mkdir( $_SERVER['DOCUMENT_ROOT'].TARGET, 0755) ) {
				exit('Erreur : le r&eacute;pertoire cible ne peut-&ecirc;tre cr&eacute;&eacute; ! V&eacute;rifiez que vous diposiez des droits suffisants pour le faire ou cr&eacute;ez le manuellement !');
			}
		}
		/************************************************************
		* Script d'upload
		*************************************************************/
		// On verifie si le champ est rempli
		if(!empty($_FILES['file']['name'])){
			$sms_avatar = "xxxx";
			// Recuperation de l'extension du fichier
			$extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
			// On verifie l'extension du fichier
			if(in_array(strtolower($extension),$tabExt)){
				// On recupere les dimensions du fichier
				$infosImg = getimagesize($_FILES['file']['tmp_name']);
				// On verifie le type de l'image
				if($infosImg[2] >= 0 && $infosImg[2] <= 100000){
					// On verifie les dimensions et taille de l'image
					if(($infosImg[0] <= WIDTH_MAX) && ($infosImg[1] <= HEIGHT_MAX) && (filesize($_FILES['file']['tmp_name']) <= MAX_SIZE)){
						// Parcours du tableau d'erreurs
						if(isset($_FILES['file']['error']) && UPLOAD_ERR_OK === $_FILES['file']['error']){
							// On renomme le fichier
							$nomImage = $codEts.md5(uniqid()).'.'. $extension;
							$logoEts = $nomImage; 
							if(move_uploaded_file($_FILES['file']['tmp_name'],$_SERVER['DOCUMENT_ROOT'].TARGET.$nomImage)){
								$sms_gerer = "<div style='color:#009900'>Le logo est mise &agrave; jour.</div>";
								$rqt_insrt_fac = "insert into tb_etablissement values ('".$codEts."','".$nomEts."', '".$sigleEts."', '".$adressEts."', '".$villeEts."', '".$telEts."', '".$emailEts."', '1', '".$typEts."', '".$logoEts."', NOW())";
								if($exe_rqt_insrt_fac = mysqli_query($con, $rqt_insrt_fac)){
									$sms_gerer = "<div style='color:#009900'>Etablissement enregistr&eacute;e avec succ&egrave;s.</div>";
									//include("B_mbindi/Biamunda/rqt/rqt_save_aca.php");

										
								}
								else{
									$sms_gerer = "<div style='color:#FF0000'>Impossible d&acute;effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
								}
							}
							else{
								$sms_gerer = "<div style='color:#FF0000'>erreur de t&eacute;l&eacute;chargement du logo</div>";
							}
						}
						else{
							$sms_gerer = "<div style='color:#FF0000'>Erreur lors de r&eacute;cup&eacute;ration de la photo</div>";
						}
					}
					else{
						$sms_gerer = "<div style='color:#FF0000'>La taille de votre photo est tr&egrave;s Exorbitante! S.V.P. chercher une autre.</div>";
					}
				}
				else{
					// Sinon erreur sur les dimensions et taille de l'image
					$sms_gerer = "<div style='color:#FF0000'>La photo que vous voulez t&eacute;l&eacute;charg&eacute;&eacute; depasse 2Mb!</div>";
				}
			}
			else{
				// Sinon erreur sur le type de l'image
				$sms_gerer = "<div style='color:#FF0000'>Le fichier &agrave; t&eacute;l&eacute;charger n'est pas une image !</div>";
			}
		}
		else{
			// Sinon on affiche une erreur pour l'extension
			$sms_gerer = "<div style='color:#FF0000'>Vous n'avez pas indiqu&eacute; la photo!</div>";
		}
	}
	else{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		include("B_mbindi/Biamunda/rqt/rqt_save_aca.php");
	}
}
?>