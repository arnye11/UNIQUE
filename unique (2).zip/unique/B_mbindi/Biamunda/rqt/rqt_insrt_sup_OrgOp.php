<?php
	if(isset($_POST['BtOrganiPromo'])){
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idAca = $_SESSION['idAnAca'];

		if($idOp!="" and $idPromo!=""){
			$rqt_verif_OrgOp = "SELECT * FROM tb_organisation_option WHERE idPromo = '".$idPromo."' AND idOp = '".$idOp."' AND idAnAca = '".$idAca."'";
			if($exe_rqt_slct_OrgOp = mysqli_query($con, $rqt_verif_OrgOp)){
				if($exe_rqt_slct_OrgOp->num_rows>0){
					$sms_gerer = "<div class='erreur'>Cette promotion est d&eacute;j&agrave; organis&eacute;e</div>";
				}
				else{
					$rqt_insrt_OrgOp = "INSERT INTO tb_organisation_option VALUES(NULL, '".$idPromo."', '".$idOp."', '".$idAca."')";
					if($exe_rqt_insrt_OrgOp = mysqli_query($con, $rqt_insrt_OrgOp)){
						$sms_gerer = "<div class='reussite'>Promotion organis&eacute;e</div>";
					}
					else{
						$sms_gerer = "<div class='erreur'>Echec d'organiser cette promotion</div>";
					}
				}
			}
			else{
				$sms_gerer = "<div class='erreur'>Echec de v&eacute;rifivation.</div>";
			}
		}
		else{
			$sms_gerer = "<div class='erreur'>Veuillez s&eacute;lectionner une promotion</div>";
		}
	} 
	//SUPRESSION 
	if(isset($_GET['fAculTe']) AND isset($_GET['iDfaC']) AND isset($_GET['pRomotIon']) AND isset($_GET['oPtiOn']) and isset($_GET['SupPriMeRPromOtIonEtoPtionOrgansiEe']) AND isset($_GET['aca']) ){
		
		$idPromo = $_GET['pRomotIon'];
		$idOp = $_GET['oPtiOn'] ;
		$an_aca = $_GET['aca'] ;

		if($_SESSION['idAutoDec']=="admin1" ){
			$rqt_verif_OrgOp = "SELECT * FROM tb_organisation_option WHERE idPromo = '".$idPromo."' AND idOp = '".$idOp."' AND idAnAca = '".$an_aca."' ";
			if($exe_rqt_slct_OrgOp = mysqli_query($con, $rqt_verif_OrgOp)){
				if($tb_OrgOp = mysqli_fetch_assoc($exe_rqt_slct_OrgOp)){
					$Sup = 0;
					//V�rification inscription
					$rqt_verif_tb_inscription = "SELECT * FROM tb_inscription WHERE idOp = '".$idOp."' AND idProm = '".$idPromo."' AND idAca = '".$an_aca."'";
					if($tb_inscription = mysqli_query($con, $rqt_verif_tb_inscription)){
						if($tb_inscription->num_rows>0){
							$Sup += 1;
						}
					}
					//V�rification programme de cours
					$rqt_tb_program_cours = "SELECT * FROM tb_program_cours WHERE idOp = '".$idOp."' AND idPromo = '".$idPromo."' AND idAnAca = '".$an_aca."'";
					if($tb_program_cours = mysqli_query($con, $rqt_tb_program_cours)){
						if($tb_program_cours->num_rows>0){
							$Sup += 1;
						}
					}
					
					//SI L'OPTION EST organis�e, on la supprime de la table 
					if($Sup==0){
						$rqt_dlt_OrgOp = "DELETE FROM tb_organisation_option WHERE idPromo='".$_GET['pRomotIon']."' AND idOp='".$_GET['oPtiOn']."' AND idAnAca='".$_GET['aca']."'";
						if($exe_rqt_dlt_OrgOp = mysqli_query($con, $rqt_dlt_OrgOp)){
							header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&sms=La promotion a �t� r�tir�e');
						}
						else{
							header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&sms=Impossible de returer cette promotion');
						}
					}
					else{
						header ("location:?fAculTe&iDfaC=".$_GET['iDfaC']."&sms=La promotion est d�j� utilis�e");
					}
				}
				else{
					header ("location:?fAculTe&iDfaC=".$_GET['iDfaC']."&sms=La promotion n'est plus organis�e");
				}
			}
			else{
				header ("location:?fAculTe&iDfaC=".$_GET['iDfaC']."&sms=Echec de v�rification de la promotion");
			}
		}
		else{
			header ("location:?fAculTe&iDfaC=".$_GET['iDfaC']."&sms=Vous n'avez pas le droit de faire cette op�ration");
		}
	}
?>