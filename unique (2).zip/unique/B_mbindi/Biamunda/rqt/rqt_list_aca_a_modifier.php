<?php 
if (isset($_GET['gerer_aca']) and isset($_GET['modifier_aca']) and !isset($_GET['aca']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Modifier une Ann&eacute;e acad&eacute;mique </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
	
	$rqt_list_aca_a_modif = "select idAnAca, DAY(datedebutAnAca) AS jrD, MONTH(datedebutAnAca) AS mmD, YEAR(datedebutAnAca) AS aaaaD, DAY(datefinAnAca) AS jrF, MONTH(datefinAnAca) AS mmF, YEAR(datefinAnAca) AS aaaaF, tauxannuel   from  tb_an_aca ORDER BY idAnAca  DESC";
	if($exe_rqt_list_aca_a_modif = $conDb->query($rqt_list_aca_a_modif))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;"><div align="left">Ann&eacute;e acad&eacute;mique</div></th>
			<th scope="col" style="font-size:15px;"><div align="center">Date</div></th>
			<th scope="col" style="font-size:15px;"><div align="center">Action</div></th>
		  </tr>
		  <?php 
		  	while($result_rqt_list_aca_a_modif = $exe_rqt_list_aca_a_modif->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{		
				?>
				<tr align="left" style="">
					<th scope="col" style="border-bottom:solid 1px">
					  <?php echo $result_rqt_list_aca_a_modif['idAnAca']; ?>
					</th>
					<th scope="col" style="border-bottom:solid 1px">
					<?php 
					$jr_modifD= $result_rqt_list_aca_a_modif['jrD'];
					$mois_modifD= $result_rqt_list_aca_a_modif['mmD'];
					$jr_modifF= $result_rqt_list_aca_a_modif['jrF'];
					$mois_modifF= $result_rqt_list_aca_a_modif['mmF'];
					
					if($jr_modifD<10){$jr_modifD="0".$jr_modifD;}
					if($mois_modifD<10){$mois_modifD="0".$mois_modifD;}
					if($jr_modifF<10){$jr_modifF="0".$jr_modifF;}
					if($mois_modifF<10){$mois_modifF="0".$mois_modifF;}

					$dateOuverture = $jr_modifD."-".$mois_modifD."-".$result_rqt_list_aca_a_modif['aaaaD'];
					$dateFerture = $jr_modifF."-".$mois_modifD."-".$result_rqt_list_aca_a_modif['aaaaF'];

					echo "<div align='left' title='code : ".$result_rqt_list_aca_a_modif['idAnAca']."' style='margin-bottom:5px; background:#F0F0F0; text-transform:lowercase;'>";
					echo "<div align='left' style='margin-bottom:5px; border-bottom:solid 2px #FFFFFF; background:#F0F0F0;'>Date d'ouverture &nbsp; : ".$dateOuverture." <br/>Date de fermeture : ".$dateFerture."</div>";
					echo "</div>";
		 			?>
					
					</th>
					<th scope="col" style="border-bottom:solid 1px"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_aca&modifier_aca&aca=<?php echo $result_rqt_list_aca_a_modif['idAnAca']; ?>">Modifier</a></th>
				</tr>
				<?php 
				} 
				?>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les ann�es v�cues . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}


?>