<?php 
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['eNseIgnAnt'])){ ?>
		<h2>Liste enseignants</h2>
		<?php
		$typensVL = "L";
		for($typens = 1; $typens<=2; $typens++){
			if($typens == 1){ echo "<h3>ENSEIGNANTS LOCAUX</h3>";}else{echo "<h3>ENSEIGNANTS VISITEURS</h3>"; $typensVL = "V";}
			$rqt_list_ens = "SELECT * FROM  tb_enseignant WHERE idFac = '".$_GET['iDfaC']."' and typeEns = '".$typensVL."' ORDER BY nomEns  ";//COURS 
			if($exe_rqt_list_ens = mysqli_query($con, $rqt_list_ens)){?>
				<table width="100%" border="1" cellpadding="2" cellspacing="0" style="font-size:12px;">
				  <tr style="background:#CCCCCC;">
					<td>N&deg;</td>
					<td>NOM, POSTNOM ET PRENOM </td>
					<td>SEXE</td>
					<td>GRADE</td>
					<td>DOMA. ETUD. </td>
					<td>DATE ANG. </td>
					<td>TEL</td>
					<td>&nbsp;</td>
				  </tr>
				  <?php
				  if(mysqli_num_rows($exe_rqt_list_ens)>0){
					  $num=0;
						while($tb_ens = mysqli_fetch_assoc($exe_rqt_list_ens)){
							$num = $num+1;
							if(isset($_GET["eNseIgnAnt"]) and isset($_GET["modIf"]) and (isset($_GET["iDenS"]) and $_GET["iDenS"] == $tb_ens["idEns"]) and $updt_ens == false){
								if(isset($_POST["BtModifEns"]) and $updt_ens == false){
									?>
									  <tr id="<?php echo $tb_ens["idEns"]; ?>" style="background:#FF0033; color:#FFFFFF; font-style:italic; font-size:15px;">
										<td colspan="9"><?php echo $sms_updt_ens; ?></td>
									  </tr>
									<?php 
								}
								?>
								<form action="" method="post">
								  <tr id="<?php echo $tb_ens["idEns"]; ?>" style="background:#FFCC99;">
									<td><div align="right"><?php echo $num; ?></div></td>
									<td>
										<input type="hidden" name="idFac"  value="<?php echo $tb_ens["idFac"]; ?>"/>
										<input type="hidden" name="idEns"  value="<?php echo $tb_ens["idEns"]; ?>"/> 

										<input type="text" name="nomEns" placeholder="Nom" value="<?php echo $tb_ens["nomEns"]; ?>" style="width:90%;"/>* 
										<input type="text" name="postnomEns" placeholder="Postnom" value="<?php echo $tb_ens["postnomEns"]; ?>" style="width:90%;"/>* 
										<input type="text" name="prenomEns" placeholder="Prenom" value="<?php echo $tb_ens["prenomEns"]; ?>" style="width:90%;"/>* 
										<br/>
										<select name="typeEns">
											<option value="<?php echo $tb_ens["typeEns"]; ?>"><?php if($tb_ens["typeEns"]=="L"){echo "Local";}else{echo "Visiteur";}?></option>
											<option value="V">Visiteur</option>
											<option value="L">Local</option>
										</select>
									</td>
									<td>
										<select name="sexeEns" style="width:95%;" >
											<option value="<?php echo $tb_ens["sexeEns"]; ?>"><?php echo $tb_ens["sexeEns"]; ?></option>
											<option value="M">M</option>
											<option value="F">F</option>
										</select>
									</td>
									<td>
										<select name="gradeEns" style="width:95%;">
											<option value="<?php echo $tb_ens["idGrad"]; ?>"><?php echo $tb_ens["idGrad"]; ?></option>
											<?php 
												$rqt_grad = "SELECT * FROM tb_grade ORDER BY designGrad  ";//grade 
												if($exe_rqt_grad = mysqli_query($con, $rqt_grad)){
													if(mysqli_num_rows($exe_rqt_grad)>0){
														while($tb_grade =mysqli_fetch_assoc($exe_rqt_grad)){
															echo "<option value='".$tb_grade["idGrad"]."'>".$tb_grade["designGrad"]."</option>";
														}
													}
													else{
														echo "<option value=''>Aucun grande enregistr�</option>";
													}
												}
												else{
													echo "<option value=''>Erreur</option>";
												}
											?> 
										</select>
									</td>
									<td>
										<input type="text" name="domainEtudEns" placeholder="Domaine d&eacute;tude" value="<?php echo $tb_ens["domainEtudEns"]; ?>" style="width:93%;"/>*
									</td>
									<td>
									<input type="text" name="dateEngagEns" placeholder = "Format (jj-mm-aaaa)" value="<?php echo $tb_ens["dateEngagEns"];?>" style="width:95%;">
									</td>
									<td> <textarea name="telEns" placeholder = "1 ou plusieurs num&eacute;ros" style="width:95%;" ><?php echo $tb_ens["telEns"]; ?></textarea></td>
									<td>
										<input type="submit" name="BtModifEns" value="OK" style="width:95%;"/>
										<br/><br/><br/>
										<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&eNseIgnAnt"?>">Annuler</a>	
									</td>
								  </tr>
								</form>
								<?php 
							}							
							else{?>
							  	<tr id="<?php echo $tb_ens["idEns"]; ?>" <?php if (isset($_GET['iDeNseIgnAnt']) and ($_GET['iDeNseIgnAnt'] == $tb_ens["idEns"])){?> style="background:#E6FFF5; <?php }?>">
									<td><div align="right"><?php echo $num; ?></div></td>
									<td><?php echo $tb_ens["nomEns"]."&emsp;".$tb_ens["postnomEns"]."&emsp;".$tb_ens["prenomEns"]; ?></td>
									<td><div align="center"><?php echo $tb_ens["sexeEns"]; ?></div></td>
									<td><?php echo $tb_ens["idGrad"]; ?></td>
									<td><?php echo $tb_ens["domainEtudEns"]; ?></td>
									<td><?php echo $tb_ens["dateEngagEns"]; ?></td>
									<td><?php echo $tb_ens["telEns"]; ?></td>
									<td>
										<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&eNseIgnAnt&modIf&iDenS=".$tb_ens["idEns"]."#".$tb_ens["idEns"] ?>">
											<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier"/>
										</a>
									</td>
							  	</tr>
								<?php 
							}
						}
				  }
				  else{ 
						?>
						  <tr>
							<td colspan="9">Aucun enseignant enregistr&eacute;</td>
						  </tr>
						<?php 
				  }?>
				</table>
			<?php 
			}
		}
	}
?>