<?php 
	if (isset($_GET['gerer_option']) and isset($_GET['modifier_op']) and !isset($_GET['op'])){ 
		echo "<div style='border-bottom:groove; padding: 5px'>";
			echo "<h3>Modifier une Option </h3>";
			if(isset($_GET['sms_gerer'])){
				$sms_gerer = $_GET['sms_gerer']; 
				echo "<div style='color:#009900'>".$sms_gerer."</div>";
			}
			else{ 
				echo $sms_gerer;
			}
		echo "</div>";
		$rqt_list_fac = "select * from  tb_faculte order by idFac";
		if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
			while($tab_faculte = mysqli_fetch_assoc($exe_rqt_list_fac)){	
				echo "<div align='left' title='code : ".$tab_faculte['idFac']."' style='margin-bottom:5px;  border:solid 2px #666666;'>";
				echo "<div align='left' style='background:#CCCCCC; color:#666666; padding-left:5px;text-transform:uppercase;'><i>".$tab_faculte['idFac']."&nbsp;&nbsp;".$tab_faculte['designFac']."</i></div>";
		
				$rqt_list_op = "select * from  tb_option where idFac = '".$tab_faculte['idFac']."' ORDER BY idFac";
				if($exe_rqt_list_op = mysqli_query($con, $rqt_list_op)){
					?>
					<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
						<tr align="left">
							<th scope="col" style="font-size:15px;">Code</th>
							<th scope="col" style="font-size:15px;">D&eacute;signation</th>
							<th scope="col" style="font-size:15px;">Action</th>
						</tr>
						<?php 
							while($tab_option = mysqli_fetch_assoc($exe_rqt_list_op)){		
						  		?>
								<tr align="left" style="">
									<td scope="col" style="border-bottom:solid 1px">
									  <?php echo $tab_option['idOp']; ?>
									</td>
									<td scope="col" style="border-bottom:solid 1px">
										<?php echo $tab_option['designOp']; ?>
									</td>
									<td scope="col" style="border-bottom:solid 1px">
										<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_option&modifier_op&op=<?php echo $tab_option['idOp']; ?>">Modifier</a>
									</td>
								</tr>
								<?php 
							} 
						?>
					</table>
					<?php 
				}
				else{
					echo  "Impossible d'atteindre les d�partement organis�s . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
				}
			echo "</div>";
			}
		}
	}
?>