<?php 
if (isset($_GET['gerer_option']) and isset($_GET['ajouter_op'])||isset($_GET['modifier_op'])||isset($_GET['sup_op']) ){ 
	echo "<div style='border-bottom:groove'>OPTIONS ORGANISEES<br/></div>";
	$rqt_list_fac = "select * from  tb_faculte order by idFac";
	if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
		while($tab_faculte = mysqli_fetch_assoc($exe_rqt_list_fac)){
			echo "<div align='left' title='code : ".$tab_faculte['idFac']."' style='margin-bottom:5px; background:#F0F0F0; text-transform:uppercase; border:solid 2px #666666;'>";
			echo "<div align='left' style='background:#5B5B5B; color:#FFFFFF; padding-left:5px;'>".$tab_faculte['designFac']."</div>";
	
			$rqt_list_op = "select * from  tb_option where idFac = '".$tab_faculte['idFac']."' ORDER BY idOp";
			if($exe_rqt_list_op = mysqli_query($con, $rqt_list_op)){
				while($tab_option = mysqli_fetch_assoc($exe_rqt_list_op)){
					echo "<div align='left' title='code : ".$tab_option['idOp']."' style='margin-bottom:5px;margin-left:20px; border-bottom:solid 2px #FFFFFF; background:#F0F0F0; text-transform:lowercase;'>".$tab_option['designOp']."</div>";
					}
				}
			else
				{
				echo  "Impossible d'atteindre les option organis�es dans ce d�partement. <br/>SVP, contacter urigement l'Administrateur pour trouver solution � ce probl�me.";
				}
			echo "</div>";
			}
		}
	else
		{
		echo  "Impossible d'atteindre les d�partement organis�s . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}

			

	}


?>