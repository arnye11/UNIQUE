<?php 
if (isset($_GET['gerer_promotion']))
	{?>
	<style type="text/css">
		<!--
		.taille{ width:99%; }
		
		-->
	</style>
	
	<?php 
	echo "<div style='border-bottom:groove'>PROMOTIONS ORGANISEE</div>";
	echo "<table class='taille'>";
	$rqt_list_pro = "select * from  tb_promotion";
	if($exe_rqt_list_pro = $conDb->query($rqt_list_pro))
		{
		echo "<tr>";
		echo "<td>Code</td>";
		echo "<td>D&eacute;signation</td>";
		echo "</tr>";
		while($result_rqt_list_pro = $exe_rqt_list_pro->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
			{
			?>
			<tr style=' background:#F0F0F0; text-transform:lowercase;'>
				<td align="center"><?php echo $result_rqt_list_pro['idPromo']; ?></td>
				<td><?php echo $result_rqt_list_pro['designPromo']; ?></td>
			</tr>
			<?php 
			}
		}
	else
		{
		echo "<tr style=' background:#F0F0F0; text-transform:lowercase;'>";
			echo "<td>Ereur de sel&eacute;ction des promotion. <br/>SVP, contacter urigement l'Administrateur pour l'assistance. </td>";
		echo "<tr>";	
		}
	echo "</table>";		

	}


?>