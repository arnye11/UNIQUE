<?php 
if (isset($_GET['gerer_promotion']) and isset($_GET['modifier_pro']) and !isset($_GET['pro']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Modifier une Promotion </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
	$rqt_list_pro = "select * from  tb_promotion ORDER BY idPromo";
	if($exe_rqt_list_pro = $conDb->query($rqt_list_pro))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Code</th>
			<th scope="col" style="font-size:15px;">D&eacute;signation</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		  <?php 
		  	while($result_rqt_list_pro = $exe_rqt_list_pro->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{		
		  ?>
		<tr align="left" style="">
		  	<th scope="col" style="border-bottom:solid 1px">
			  <?php echo $result_rqt_list_pro['idPromo']; ?>
			</th>
			<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_pro['designPromo']; ?></th>
			<th scope="col" style="border-bottom:solid 1px"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_promotion&modifier_pro&pro=<?php echo $result_rqt_list_pro['idPromo']; ?>">Modifier</a></th>
		</tr>
		<?php } ?>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les prootions organis&eacute;s . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}


?>