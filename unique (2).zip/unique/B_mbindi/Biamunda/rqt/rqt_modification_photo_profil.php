<?php

if(isset($_POST["BtTelAv"]))
	{

/************************************************************
* Definition des constantes / tableaux et variables
*************************************************************/
// Constantes
define('TARGET', '/B_mbndi/Biamunda/media/'); // Repertoire cible
define('MAX_SIZE', 1099511627776); // Taille max en octets du fichier
define('WIDTH_MAX', 80000); // Largeur max de l'image en pixels
define('HEIGHT_MAX', 80000); // Hauteur max de l'image en pixels
// Tableaux de donnees
$tabExt = array('jpg','gif','png','jpeg'); // Extensions autorisees
$infosImg = array();
// Variables
$sms_modif ="";
$photo = "";
$extension = '';
$message = '';
$nomImage = '';
/************************************************************
* Creation du repertoire cible si inexistant
*************************************************************/
if( !is_dir( $_SERVER['DOCUMENT_ROOT'].TARGET) )
	{
	if( !mkdir( $_SERVER['DOCUMENT_ROOT'].TARGET, 0755) ) 
		{
		exit('Erreur : le r�pertoire cible ne peut-�tre cr�� ! V�rifiez que vous diposiez des droits suffisants pour le faire ou cr�ez le manuellement !');
		}
	}
/************************************************************
* Script d'upload
*************************************************************/
	// On verifie si le champ est rempli
	if(!empty($_FILES['avatr']['name']))
		{
		$sms_avatar = "xxxx";
		// Recuperation de l'extension du fichier
		$extension = pathinfo($_FILES['avatr']['name'], PATHINFO_EXTENSION);
		// On verifie l'extension du fichier
		if(in_array(strtolower($extension),$tabExt))
			{
			// On recupere les dimensions du fichier
			$infosImg = getimagesize($_FILES['avatr']['tmp_name']);
			// On verifie le type de l'image
			if($infosImg[2] >= 0 && $infosImg[2] <= 1000)
				{
				// On verifie les dimensions et taille de l'image
				if(($infosImg[0] <= WIDTH_MAX) && ($infosImg[1] <= HEIGHT_MAX) && (filesize($_FILES['avatr']['tmp_name']) <= MAX_SIZE))
					{
					// Parcours du tableau d'erreurs
					if(isset($_FILES['avatr']['error']) && UPLOAD_ERR_OK === $_FILES['avatr']['error'])
						{
						// On renomme le fichier
						$nomImage = $result_slct_etud['matricEtud'].'.'. $extension;
						// Si c'est OK, on teste l'upload
						if(move_uploaded_file($_FILES['avatr']['tmp_name'],$_SERVER['DOCUMENT_ROOT'].TARGET.$nomImage))
							{
							//si le t�l�chargement s'est bien pass�, l'envoi de l'avatar dans le r�pertoire : 'istia-kabinda/B_mbidndi/Biamunda/media/'
							$AvatarEtud = $nomImage; 
							$sms_avatar = "La photo est  prise en charge";	
							}
						else
							{
							$sms_avatar = "erreur de t�l�chargement de l'avatar";
							}
						}
					else
						{
						$sms_avatar = "D�sol�! le fichier que vous avez indiqu� n'est pas une photo";
						}
					}
				else
					{
					$sms_avatar = "La taille de votre photo est tr�s Exorbitante! S.V.P. chercher une autre.";
					}
				}
			else
				{
				// Sinon erreur sur les dimensions et taille de l'image
				$sms_avatar = "le fichier que vous voulez t�l�charg� n'a pas une bonne dimensio!";
				}
			}
		else
			{
			// Sinon erreur sur le type de l'image
			$sms_avatar = "Le fichier � t�l�charger n'est pas une image !";
			}
		}
	else
		{
		// Sinon on affiche une erreur pour l'extension
		$AvatarEtud = "";
		$sms_avatar = "Vous n'avez pas indiqu� sa photo!";
		}
	}
	

?>



