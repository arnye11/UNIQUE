<?php 
	if ((isset($_GET['gerer_option']) and isset($_GET['OrgOp']))||(isset($_GET['gerer_cours']) and isset($_GET['pRogramMer']))){
		?>
		<style type="text/css">
			<!--
			.divFacOpOrg, .DesignfacOpOrg, .PromoOpOrg{
				width:98; height:auto; margin-bottom:5px; text-align:left;
			}
			.divFacOpOrg{
				 background:#F0F0F0; border:solid 2px #666666; 
			}
			.DesignfacOpOrg{
				background:#5B5B5B; padding-left:5px; text-transform:uppercase; color:#FFFFFF; 
			}
			.DesignOpOrg, .PromoOpOrg{
				 margin:5px;
			}
			.DesignOpOrg{
				margin-left:20px;background:#E3E3E3; text-transform:uppercase; font-style:oblique;
			}
			.PromoOpOrg{
				margin-left:40px; background:#F0F0F0; text-transform:lowercase; border-bottom:solid 2px #FFFFFF;
			}
			.PromoOrg{
				text-transform:uppercase; 
			}
			-->
		</style>
		
		<?php
		$rqt_list_fac = "select * from  tb_faculte order by designFac ASC";
		if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac)){
			if(mysqli_num_rows($exe_rqt_list_fac)>0){
				while($tb_faculte = mysqli_fetch_assoc($exe_rqt_list_fac)){
					echo "<div class='divFacOpOrg'>";
					echo "<div class='DesignfacOpOrg'><img src='B_mbindi/Biamunda/icon/accue.gif' class='icon' />".$tb_faculte['designFac']."</div>";
			
					$rqt_list_op = "select * from  tb_option where idFac = '".$tb_faculte['idFac']."' ORDER BY designOp ASC";
					if($exe_rqt_list_op = mysqli_query($con, $rqt_list_op)){
						if(mysqli_num_rows($exe_rqt_list_op)>0){
							while($tb_option = mysqli_fetch_assoc($exe_rqt_list_op)){
								echo "<div class='DesignOpOrg'>";
								echo "<div>".$tb_option['designOp']."</div>";
								echo "</div>";
								$rqt_verification = "SELECT * FROM tb_organisation_option  where idOp ='".$tb_option["idOp"]."' AND  idAnAca = '".$_SESSION['idAnAca']."' ORDER BY idPromo ASC ";
								if($tb_organisation_option = mysqli_query($con, $rqt_verification)){
									if(mysqli_num_rows($tb_organisation_option)>0){ 
										while($result_rqt_list_opOrg =mysqli_fetch_assoc($tb_organisation_option)) {
											echo "<div class='PromoOpOrg'>";
											echo "<a href='?fAculTe&iDfaC=".$tb_faculte['idFac']."&pRomotIon=".$result_rqt_list_opOrg['idPromo']."&oPtiOn=".$tb_option["idOp"]."''>";
											echo "<div><font class='PromoOrg'>".$result_rqt_list_opOrg['idPromo']."</font>&nbsp;&nbsp;".$tb_option['designOp']."</div>";
											echo "</a>";
											echo "</div>";
										}
										
									}
									else{
										echo "<div class='PromoOpOrg' >Aucune promotion organis&eacute;e</div>";
									}
									
								}
								else{
									echo  "Impossible de v&eacute;rifier les option organis�es. <br/>SVP, contacter urigement l'Administrateur.";
								}
							}
						}
						else{
							echo "<div class='DesignfacOpOrg' >Aucune option organis&eacute;e</div>";
						}
					}
					else{
						echo  "Impossible d'atteindre les option organis�es dans ce d�partement. <br/>SVP, contacter urigement l'Administrateur pour trouver solution � ce probl�me.";
					}
					echo "</div>";
				}
			}
			else{
				echo "<div class='divFacOpOrg' >Aucune facult� organis&eacute;e</div>";
			}
		}
		else{
			echo  "Impossible d'atteindre les d�partement organis�s . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
			}
	}


?>