
<?php
/******************* BOUTON "Chercher *******************************************************/ 
	if(isset($_POST["BtChercher"]))
		{
		$contenu = filter_input(INPUT_POST,'conten', FILTER_SANITIZE_SPECIAL_CHARS);
		if(($contenu == "Matricule de l&#39;Etudiant")||($contenu == ""))
			{ 
			$recherche =false;
			//on prepare le Sms
			if($contenu == "Matricule de l&#39;Etudiant")
				{
				$SmsRchrch = "<p align = 'center' class = 'echec'>Veillez saisir le Matricule de l'Etudiant!</p>";
				}
			else if($contenu == "")
				{
				$SmsRchrch = "<p align = 'center' class = 'echec'>Le champ est vide. Veillez saisir le Matricule de l'Etudiant!</p>";
				}
			}
		else
			{
			$recherche = true;
			}
		}
		
?>
