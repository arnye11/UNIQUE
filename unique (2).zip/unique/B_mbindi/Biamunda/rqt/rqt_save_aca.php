<?php 
$idAca ="";
$dateDAca = "";
$dateFAca = "";
if(isset($_POST['BtsaveAca']) or isset($_POST['BtCreerEts'])){
	$dateDAca = filter_input(INPUT_POST,'dateDAca', FILTER_SANITIZE_SPECIAL_CHARS);
	$dateFAca = filter_input(INPUT_POST,'dateFAca', FILTER_SANITIZE_SPECIAL_CHARS);
	$tauxannuel = 0;

	if($dateDAca!="" and $dateFAca!=""){
		$aaaaD = substr($dateDAca, 0, 4);
		$aaaaF = substr($dateFAca, 0, 4);
		if((($aaaaF-$aaaaD)>=0) and (($aaaaF-$aaaaD)<=1)){
			$idAca = $aaaaD."-".$aaaaF;
			$rqt_insrt_aca = "insert into tb_an_aca values ('".$idAca."','".$dateDAca."','".$dateFAca."','".$tauxannuel."')";
			if(mysqli_query($con, $rqt_insrt_aca)){
				$sms_gerer = "<div style='color:#009900'> Ann&eacute;e Acad&eacute;mique <b>".$idAca."</b> est planifi&eacute;e.</div>";
			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Mauvais formant de l'ann&eacute;e. veuillez reaisseyer.</div>";
		}
	}
	else{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
	}

}
?>