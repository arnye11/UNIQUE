<?php 
if(isset($_POST['BtAjouterOp']))
	{
	$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
	$designOp = filter_input(INPUT_POST,'designOp', FILTER_SANITIZE_SPECIAL_CHARS);
	$idFac = filter_input(INPUT_POST,'idFac', FILTER_SANITIZE_SPECIAL_CHARS);

	if($idOp!="" and $designOp!="" and $idFac!=""){
		$rqt_insrt_op = "insert into tb_option values ('".$idOp."','".$designOp."','".$idFac."')";
		if($exe_rqt_insrt_op = mysqli_query($con, $rqt_insrt_op))
			{
			$sms_gerer = "<div style='color:#009900'> Option ajout&eacute;e.</div>";
			}
		else
			{
			$sms_gerer = "<div style='color:#FF0000'>L'opération a echouée</div>";
			}
		}
	else
		{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez saisir l'option.</div>";
		}

}
?>