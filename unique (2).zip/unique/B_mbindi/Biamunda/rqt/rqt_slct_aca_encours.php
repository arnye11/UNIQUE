<?php 
	$date_encours = $annee_encours.'-'.$moi.'-'.$jour ;
	$rqt_aca_encours = "SELECT * FROM tb_an_aca WHERE datedebutAnAca <= '".$date_encours."' AND datefinAnAca >= '".$date_encours."'";
	$result = mysqli_query($con, $rqt_aca_encours);
	if(mysqli_num_rows($result) >= 0){
		if($result_exe_rqt_aca_encours = mysqli_fetch_assoc($result)) {
			$_SESSION['idAnAca']=$result_exe_rqt_aca_encours['idAnAca'];
			$an_aca = $_SESSION['idAnAca'];
			$_SESSION['tauxannuel']=$result_exe_rqt_aca_encours['tauxannuel'];
			$anne_academique = true;
			$_SESSION['anne_academique'] = $anne_academique;

		}
		else{
			$an_aca = "Inconnu.";
			$sms_an_aca = "D&eacute;sol&eacute;! Delait de l'ann&eacute;e acad&eacute;mique imparti";
		}
	} 
	else{
		$an_aca = "Impossible.";
		$sms_an_aca = "Impossible de retrouver l'ann&eacute;e encours.";
	}
	
//_________________________________________________________________________________________

	if(isset($_POST['BtUtiliserCeteAnAca'])){
		$annee = filter_input(INPUT_POST,'annee', FILTER_SANITIZE_SPECIAL_CHARS);
		if($annee != ""){
			$_SESSION['idAnAca'] = $annee;
			$an_aca = $_SESSION['idAnAca'];
			$anne_academique = true;
			$_SESSION['anne_academique'] = $anne_academique;
			setcookie("anne_academique", $_SESSION['anne_academique'], time()+(60), "/", "", false, true);
			setcookie("idAnAca", $_SESSION['idAnAca'], time()+(60), "/", "", false, true);
		}
	}
	if(isset($_COOKIE['anne_academique']) and isset($_COOKIE['idAnAca'])){
		$anne_academique = filter_var($_COOKIE['anne_academique'], FILTER_SANITIZE_SPECIAL_CHARS);
		$idAnAca = filter_var($_COOKIE['idAnAca'], FILTER_SANITIZE_SPECIAL_CHARS);
		$_SESSION['idAnAca'] = $idAnAca;
		$an_aca = $_SESSION['idAnAca'];

	}
		
	if(isset($_GET['aca'])){
		$an_aca = $_GET['aca'];
	}
		

?>