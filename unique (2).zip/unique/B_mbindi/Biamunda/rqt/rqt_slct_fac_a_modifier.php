<?php 
if (isset($_GET['gerer_departement']) and isset($_GET['modifier_dep']) and !isset($_GET['dep']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Modifier une Facult&eacute; </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
	$rqt_list_dep = "select * from  tb_faculte ORDER BY idFac";
	if($exe_rqt_list_dep = mysqli_query($con, $rqt_list_dep))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Code</th>
			<th scope="col" style="font-size:15px;">D&eacute;signation</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		  <?php 
		  	while($result_rqt_list_dep = mysqli_fetch_assoc($exe_rqt_list_dep)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{		
		  ?>
		<tr align="left" style="">
		  	<th scope="col" style="border-bottom:solid 1px">
			  <?php echo $result_rqt_list_dep['idFac']; ?>
			</th>
			<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_dep['designFac']; ?></th>
			<th scope="col" style="border-bottom:solid 1px"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_departement&modifier_dep&dep=<?php echo $result_rqt_list_dep['idFac']; ?>">Modifier</a></th>
		</tr>
		<?php } ?>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d&acute;atteindre les Facult�s organis&eacute;es . <br/>SVP, contacter urigement l&acute;Administrateur pour l&acute;assistance.";
		}
			
	}


?>