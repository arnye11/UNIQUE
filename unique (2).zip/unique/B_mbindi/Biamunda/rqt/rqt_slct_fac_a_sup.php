<?php 
if (isset($_GET['gerer_departement']) and isset($_GET['sup_dep']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Supprimer une Facult&eacute; </h3>";
	if(isset($_GET['sup_dep']) and isset($_GET['supprimer'])){ echo $sms_gerer;}
	echo "</div>";
	$rqt_list_fac = "select * from  tb_faculte ORDER BY designFac";
	if($exe_rqt_list_fac = mysqli_query($con, $rqt_list_fac))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Code</th>
			<th scope="col" style="font-size:15px;">D�signation</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		  <?php 
		  	while($result_rqt_list_fac = mysqli_fetch_assoc($exe_rqt_list_fac)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{		
		  ?>
		<tr align="left" style="">
		  	<th scope="col" style="border-bottom:solid 1px">
			  <?php echo $result_rqt_list_fac['idFac']; ?>
			</th>
			<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_fac['designFac']; ?></th>
			<th scope="col" style="border-bottom:solid 1px" align="center"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_departement&sup_dep&supprimer=<?php echo $result_rqt_list_fac['idFac']; ?>">&nbsp;<img class="icon" src='B_mbindi/Biamunda/icon/trash01.ico' />Supprimer</a></th>
		</tr>
		<?php } ?>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les d�partement organis�s . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}


?>