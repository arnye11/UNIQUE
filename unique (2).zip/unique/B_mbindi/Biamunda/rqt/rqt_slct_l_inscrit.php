
<?php 
if ((isset($_GET['inscrition_inscrition']) or isset($_GET['inscrition'])) and isset($_POST['BtInscrir']) and $inscription_etud == true)
	{ ?>
	<div style="background:#FFFFCC; padding-left:5px; padding-right:5px; margin-bottom:5px; border-bottom:solid 5px #BBBBBB; ">
	<?php 
	//SELECTION D'IDENTITES DE L'ETUDIANT INSCRIT
	$rqt_slct_l_inscrit = "select * from etudiant where matricEtud = '".$matriculEtud."'";
	if($exe_rqt_slct_l_inscrit = mysql_query($rqt_slct_l_inscrit))
		{
		if($result_exe_rqt_slct_l_inscrit = mysql_fetch_assoc($exe_rqt_slct_l_inscrit))
			{
			$nom_postnom_prenom = $result_exe_rqt_slct_l_inscrit['nomEtud']."&nbsp;".$result_exe_rqt_slct_l_inscrit['postnomEtud']."&nbsp;".$result_exe_rqt_slct_l_inscrit['prenomEtud'];
			?>
			<div>
				
				  <div class="profil_apercu_inscrit1"><img src="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>B_mbidndi/Biamunda/media/<?php echo $result_exe_rqt_slct_l_inscrit['avantarEtud'];?>" alt="Pas de Photo" width="100%" height="100%" /></div>
				  <div class="profil_apercu_inscrit2" align="left"><?php echo "<a href='?profil&id=".$result_exe_rqt_slct_l_inscrit['matricEtud']."''>".$nom_postnom_prenom."</a>	.<br/> Matr. : ".$result_exe_rqt_slct_l_inscrit['matricEtud']; ?></div>
			  	
			  <div align="left">
			  	<?php if ($result_exe_rqt_slct_l_inscrit['sexeEtud']=="M"){ echo "N� � ";}else { echo "N�e � ";} echo $result_exe_rqt_slct_l_inscrit['lieunaisEtud'].", le ".$result_exe_rqt_slct_l_inscrit['datenaissEtud']."."; ?>
			  </div>		  
			</div>
			<?php
			//VERIFICATION ETUDIANT SI IL EST INSCRIT
			$rqt_verification_inscription = "select * from inscription where  matricEtud = '".$matriculEtud."' and idAca = '".$_SESSION['idAnAca']."'";
			if($exe_rqt_verification_inscription = mysql_query($rqt_verification_inscription))
				{
				if($result_exe_rqt_verification_inscription = mysql_fetch_assoc($exe_rqt_verification_inscription))
					{
					//VERIFICATION DE L'OPTION DANS LAQUELLE L'ETUDIANT EST INSCRIT
					$rqt_verification_option = "select * from optionn where idOp = '".$result_exe_rqt_verification_inscription['idOp']."'";
					if($exe_rqt_verification_option = mysql_query($rqt_verification_option))
						{
						if($result_exe_rqt_verification_option = mysql_fetch_assoc($exe_rqt_verification_option))
							{
							//VERIFICATION DU DEPARTEMENT DANS LEQUEL L'ETUDIANT EST INSCRIT
							$rqt_verification_fac = "select * from faculte where idFac = '".$result_exe_rqt_verification_option['idFac']."'";
							if($exe_rqt_verification_fac = mysql_query($rqt_verification_fac))
								{
								if($result_exe_rqt_verification_fac = mysql_fetch_assoc($exe_rqt_verification_fac))
									{
									?>
									<div align="left" style="border-bottom:solid 1px #8E8E8E;">
									<?php 
										if ($result_exe_rqt_slct_l_inscrit['sexeEtud']=="M"){ echo "est inscrit dans : ";}else { echo "est inscite dans : ";}
										echo "<br/> Promotion : ".$result_exe_rqt_verification_inscription['idProm'];
										echo "<br/> Option : ".$result_exe_rqt_verification_option['designOp'];
										echo "<br/> Facult� : ".$result_exe_rqt_verification_fac['designFac'];
										echo "<br/> Ann�e Acand�mique :  ".$_SESSION['idAnAca']; 
									//VERIFICATION DE FRAIS D'INSCRIPTION
									$rqt_verification_fr_inscri_vers = "select * from versement where matEtud = '".$result_exe_rqt_slct_l_inscrit['matricEtud']."' and idAca = '".$_SESSION['idAnAca']."' and idFr = 'F004'";
									if($exe_rqt_verification_fr_inscri_vers = mysql_query($rqt_verification_fr_inscri_vers))
										{
										if($result_exe_rqt_verification_fr_inscri_vers = mysql_fetch_assoc($exe_rqt_verification_fr_inscri_vers))
											{
											echo "<br/> Frais d'inscription :  ".$result_exe_rqt_verification_fr_inscri_vers['montantVers']." $"; 
											}
										else
											{
											echo "<br/>L'ETUDIANT N'A PAS PAYE LE FRAIS D'INSCRIPTION";
											}
										}
									else
										{
										echo "<br/>IMPOSSIBLE DE VERIFIER SI L'ETUDIANT A VERSE LE FRAIS D'INSCRIPTION";
										}
?>
									</div>
									<div align="left" style="border-bottom:solid 1px #8E8E8E;">
										Adresse d'habitation : <?php echo $result_exe_rqt_slct_l_inscrit['adresseEtud']; ?><br/>
										Num�ro de T�l�phone : <?php echo $result_exe_rqt_slct_l_inscrit['telEtud']; ?><br/>
										E-mail : <?php echo $result_exe_rqt_slct_l_inscrit['emailEtud']; ?><br/>
									</div>	
									<a href="?profil&id=<?php echo $result_exe_rqt_slct_l_inscrit['matricEtud'] ?>&modification_profil">Modifier</a>
			

									<?php
									}
								else
									{
									echo "<br/>AUCUN DEPARTEMENT DANS LEQUEL L'ETUDIANT EST INSCRIT TROUVE";
									}
								}
							else
								{
								echo "<br/>IMPOSSIBLE DE VERIFIER LE DEPARTEMENT DANS LEQUEL L'ETUDIANT EST INSCRIT";
								}
							}
						else
							{
							echo "<br/>AUCUNE OPTION DANS LAQUELLE L'ETUDIANT EST INSCRIT TROUVE";
							}

						}
					else
						{
						echo "<br/>IMPOSSIBLE D'ATTEINDRE L'OPTION DANS LAQUELLE L'ETUDIANT EST INSCRIT TROUVE";
						}
					}
				else
					{
					echo "<br/>L'ETUDIANT N'A ETE INSCRIT";
					}
				}
			else
				{
				echo "<br/>IMPOSSIBLE DE VERIFIER L'INSCRIPTION DE L'ETUDIANT";
				}
			}
		else
			{
			echo "<br/>AUCUNE INFORMATION TROUVEE POUR L'ETUDIANT ENREGISTRE";
			}
		}
	else
		{
		echo "<br/>IMPOSSIBLE D'ENREGISTRER L'ETUDIANT";
		}?> 
	</div>
<?php
	 }
?>
