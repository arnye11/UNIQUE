<?php 
if (isset($_GET['gerer_aca']) and isset($_GET['sup_aca']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Supprimer une Promotion </h3>";
	if(isset($_GET['sup_aca']) and isset($_GET['supprimer'])){ echo $sms_gerer;}
	echo "</div>";
	$rqt_slct_list_aca_a_sup = "select * from  tb_an_aca ORDER BY idAnAca  DESC";
	if($exe_rqt_slct_list_aca_a_sup = $conDb->query($rqt_slct_list_aca_a_sup))
		{
		  ?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Ann&eacute;e acad&eacute;mique</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		  <?php 
		  	while($result_rqt_slct_list_aca_a_sup = $exe_rqt_slct_list_aca_a_sup->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{		
		  ?>
		<tr align="left" style="">
		  	<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_slct_list_aca_a_sup['idAnAca']; ?></th>
			<th scope="col" style="border-bottom:solid 1px" align="center"><a href="?gerer_aca&sup_aca&supprimer=<?php echo $result_rqt_slct_list_aca_a_sup['idAnAca']; ?>">&nbsp;<img src='B_mbidndi/Biamunda/icon/trash01.ico' />Supprimer</a></th>
		</tr>
		<?php } ?>
		</table>
		<?php 
		}
	else
		{
		echo  "<div style = 'color:#ff0000;'>Impossible d'atteindre les Promotions organis�es . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.</div>";
		}
			

	}


?>