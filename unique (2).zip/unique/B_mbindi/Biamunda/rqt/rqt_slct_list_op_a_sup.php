<?php 
if (isset($_GET['gerer_option']) and isset($_GET['sup_op'])){ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Supprimer une Option </h3>";
	if(isset($_GET['sup_op']) and isset($_GET['supprimer'])){ echo $sms_gerer;}
	echo "</div>";
	$rqt_slct_list_op_a_sup = "select * from  tb_option ORDER BY idFac";
	if($exe_rqt_slct_list_op_a_sup = mysqli_query($con, $rqt_slct_list_op_a_sup))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Code</th>
			<th scope="col" style="font-size:15px;">D&eacute;signation</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		 <?php 
		  	while($tb_option = mysqli_fetch_assoc($exe_rqt_slct_list_op_a_sup)) {
				?>
				<tr align="left" style="">
				  	<td scope="col" style="border-bottom:solid 1px">
					  <?php echo $tb_option['idOp']; ?>
					</td>
					<td scope="col" style="border-bottom:solid 1px">
						<?php echo $tb_option['designOp']; ?>
					</td>
					<td scope="col" style="border-bottom:solid 1px" align="center">
						<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_option&sup_op&supprimer=<?php echo $tb_option['idOp']; ?>">&nbsp;<img src='B_mbindi/Biamunda/icon/trash01.ico' class="icon" />Supprimer
						</a>
					</td>
				</tr>
				<?php 
			} 
		?>
		</table>
		<?php 
		}
	else
		{
		echo  "<div style = 'color:#ff0000;'>Impossible d'atteindre les Options organis�es . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.</div>";
		}
			

	}


?>