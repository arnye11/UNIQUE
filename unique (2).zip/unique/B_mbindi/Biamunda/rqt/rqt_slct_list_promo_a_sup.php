<?php 
if (isset($_GET['gerer_promotion']) and isset($_GET['sup_pro']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Supprimer une Promotion </h3>";
	if(isset($_GET['sup_pro']) and isset($_GET['supprimer'])){ echo $sms_gerer;}
	echo "</div>";
	$rqt_slct_list_pro_a_sup = "select * from  tb_promotion ORDER BY idPromo";
	if($exe_rqt_slct_list_pro_a_sup = $conDb->query($rqt_slct_list_pro_a_sup))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Code</th>
			<th scope="col" style="font-size:15px;">D�signation</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		  <?php 
		  	while($result_rqt_slct_list_pro_a_sup = $exe_rqt_slct_list_pro_a_sup->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{		
		  ?>
		<tr align="left" style="">
		  	<th scope="col" style="border-bottom:solid 1px">
			  <?php echo $result_rqt_slct_list_pro_a_sup['idPromo']; ?>
			</th>
			<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_slct_list_pro_a_sup['designPromo']; ?></th>
			<th scope="col" style="border-bottom:solid 1px" align="center"><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_promotion&sup_pro&supprimer=<?php echo $result_rqt_slct_list_pro_a_sup['idPromo']; ?>">&nbsp;<img src='B_mbidndi/Biamunda/icon/trash01.ico' />Supprimer</a></th>
		</tr>
		<?php } ?>
		</table>
		<?php 
		}
	else
		{
		echo  "<div style = 'color:#ff0000;'>Impossible d'atteindre les Promotions organis�es . <br/>SVP, contacter urigement l'Administrateur pour l'assistance.</div>";
		}
			

	}


?>