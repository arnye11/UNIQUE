<?php 
if (isset($_GET['gerer_aca']) and isset($_GET['sup_aca']) and isset($_GET['supprimer']))
	{ 
	$idAca_a_sup = $_GET['supprimer'];
	$idAca_utilise = false;
	
	if ($idAca_a_sup != "")
		{
		
				//verification de l'id aca dans inscription
				$rqt_slct_aca_sup_inscrit = "select * from  tb_inscription where idAca = '".$idAca_a_sup."'";
				if(
				$exe_rqt_slct_aca_sup_inscrit = $conDb->query($rqt_slct_aca_sup_inscrit)
				)
					{
					 if($result_rqt_slct_aca_sup_inscrit = $exe_rqt_slct_aca_sup_inscrit->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idAca_modif = true;
						$sms_gerer = "Vous n'avez pas les droits de supprimer cette ann�e acad�mique ".$idAca_a_sup.". Contacter l'Administrateur pour une assistance.";
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad�mique indiqu�e. ";
					}
				//verification de l'id aca dans versement
				$rqt_slct_aca_sup_vers = "select * from  tb_versement where idAca = '".$idAca_a_sup."'";
				if($exe_rqt_slct_aca_sup_vers = $conDb->query($rqt_slct_aca_sup_vers))
					{
					 if($result_rqt_slct_aca_sup_vers = $exe_rqt_slct_aca_sup_vers->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idAca_modif = true;
						$sms_gerer = "Vous n'avez pas les droits de supprimer cette ann�e acad�mique ".$idAca_a_sup.". Contacter l'Administrateur pour une assistance.";
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad�mique indiqu�e. ";
					}
				//verification de l'id aca dans fixation_prix
				$rqt_slct_aca_sup_fix = "select * from  tb_fixation_prix where idAca = '".$idAca_a_sup."'";
				if($exe_rqt_slct_aca_sup_fix  = $conDb->query($rqt_slct_aca_sup_fix ))
					{
					 if($result_rqt_slct_aca_sup_fix  = $exe_rqt_slct_aca_sup_fix->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idAca_modif = true;
						$sms_gerer = "Vous n'avez pas les droits de supprimer cette ann�e acad�mique ".$idAca_a_sup.". Contacter l'Administrateur pour une assistance.";
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad�mique indiqu�e. ";
					}
					
		//SUPPRESION DE L'ANNEE
		if($idAca_modif !=true) //SI EXECUTION, ON RECUPERE LES INFORMATION 
			{
			$rqt_sup_dep_slct = "DELETE FROM tb_an_aca WHERE idAnAca =  '".$idAca_a_sup."'";
			if($exe_rqt_sup_dep_slct = $conDb->query($rqt_sup_dep_slct))
				{
				$sms_gerer = "<div style='color:#009900'><img src='B_mbidndi/Biamunda/icon/info.ico' />&nbsp;&nbsp;L'ann�e acad�mique ".$idAca_a_sup." est supprim� avec succ�s.</div>";
				}
			else
				{
				$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/info.ico' /> Impossible de supprimer l'ann�e acad�mique indiqu�. Contacter d'urigence l'Administrateur pour trouver solution � ce probl�me. </div>";
				}
			}
		}
	else
		{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/info.ico' />Vous n'avez pas indiqu� l'ann�e � Supprimer</div>.";
		}
				

	}

?>