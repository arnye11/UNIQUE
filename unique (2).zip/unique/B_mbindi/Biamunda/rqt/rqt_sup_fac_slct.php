<?php 
	if (isset($_GET['SupPriMfIlIerE']) and isset($_GET['idFiliERe']) and $_SESSION['idFonctAutoDec']=="admin"){ 
		$idfac = $_GET['idFiliERe'];
		if($idfac != ""){
			$rqt_slct_fac_a_sup = "select * from tb_option where idFac = '".$idfac."'";
			if($ex_rqt_slct_fac_a_sup =  mysqli_query($con, $rqt_slct_fac_a_sup)){
				if($ex_rqt_slct_fac_a_sup->num_rows>0){
					$sms_gerer = "<div style='color:#ff0000'>Demande rejet&eacute;e.</div>";
				}
				else{
					$rqt_sup_fac_slct = "DELETE FROM tb_faculte WHERE idFac =  '".$idfac."'";
					if($exe_rqt_sup_fac_slct = mysqli_query($con, $rqt_sup_fac_slct)){
						$sms_gerer = "La Filiere est supprimee";
						header ('location:?accueil&sms='.$sms_gerer);
					}
					else{
						$sms_gerer = "<div style='color:#ff0000'>Echec de mise &agrave; jour</div>";
					}
				}
			}
			else{
				$sms_gerer = "<div style='color:#ff0000'>Fili&eacute;re introuvable</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#ff0000'>Vous n'avez pas s&eacute;lection&eacute; la fili&eacute;re </div>";
		}
	}

?>