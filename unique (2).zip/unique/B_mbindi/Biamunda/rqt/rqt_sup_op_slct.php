<?php 
if (isset($_GET['gerer_option']) and isset($_GET['sup_op']) and isset($_GET['supprimer'])){ 
	$idOp = $_GET['supprimer'];
	if ($idOp != ""){
		//verification si une option est enregistr�e avec son id
		$rqt_slct_op_a_sup_inscrit = "select * from tb_inscription where idOp = '".$idOp."'";
		if($ex_verif_inscrit = mysqli_query($con, $rqt_slct_op_a_sup_inscrit)){
			if(mysqli_fetch_assoc($ex_verif_inscrit)){
				$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/w95mbx03.ico' width='20' height='20' />&nbsp; Plusieurs &eacute;tudiant sont inscrits dans cette optionn et vous n'avez pas les droits de la supprimer. Nous vous recommandons de contacter l'Administrateur.</div>";
			}
			else{
				$rqt_sup_Op_slct = "DELETE FROM tb_option WHERE idOp =  '".$idOp."'";
				if(mysqli_query($con, $rqt_sup_Op_slct)){
					$sms_gerer = "<div style='color:#009900'><img src='B_mbindi/Biamunda/icon/info.ico' />&nbsp;&nbsp;L&acute;option a &eacute;t&eacute; supprim&eacute; avec succ&egrave;s.</div>";
				}
				else{
					$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' /> Impossible de supprimer l&acute;option indiqu&eacute;e. Contacter d&acute;urigence l&acute;Administrateur pour trouver solution &agrave; ce probl&egrave;me. </div>";
				}
			}
		}
		else{
			$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' />Impossible de supprimer cette option parce que nous avons eu du mal &agrave; v&eacute;rifier les &eacute;tudiants inscrtits dans celui-ci. d&acute;urigence, consultez l&acute;Administrateur pour trouver solution &agrave; ce probl&egrave;me.</div>";
		}	
	}
	else{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' class='icone' />Vous n&acute;avez pas indiqu&eacute; l&acute;option &agrave; Supprimer</div>. &nbsp;<a href='?gerer_option&sup_op'>Reaisseyez</a> ";
	}
}

?>