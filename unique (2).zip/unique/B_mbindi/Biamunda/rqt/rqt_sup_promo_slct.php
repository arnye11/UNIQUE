<?php 
if (isset($_GET['gerer_promotion']) and isset($_GET['sup_pro']) and isset($_GET['supprimer']))
	{ 
	$idpro = $_GET['supprimer'];
	if ($idpro != "")
		{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/w95mbx03.ico' />&nbsp; Vous n'avez pas les droits de supprimer une promotion. Nous vous recommandons de contacter l'Administrateur.</div>";
		}
	else
		{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/info.ico' />Vous n'avez pas indiqu� la promotion � Supprimer</div>. &nbsp;<a href='?gerer_promotion&sup_pro'>Reaisseyez</a> ";
		}
				

	}

?>