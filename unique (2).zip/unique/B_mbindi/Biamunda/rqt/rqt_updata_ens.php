<?php 
	$updt_ens = false;
	$sms_updt_ens = "";
	if(isset($_GET["eNseIgnAnt"]) and isset($_GET["modIf"]) and isset($_GET["iDenS"]) and isset($_POST["BtModifEns"])){ 
		$idEns = filter_input(INPUT_POST,'idEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$nomEns = filter_input(INPUT_POST,'nomEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$postnomEns = filter_input(INPUT_POST,'postnomEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$prenomEns = filter_input(INPUT_POST,'prenomEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$typeEns = filter_input(INPUT_POST,'typeEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$sexeEns = filter_input(INPUT_POST,'sexeEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$gradeEns = filter_input(INPUT_POST,'gradeEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$domainEtudEns = filter_input(INPUT_POST,'domainEtudEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$dateEngagEns = filter_input(INPUT_POST,'dateEngagEns', FILTER_SANITIZE_SPECIAL_CHARS);
		$telEns = filter_input(INPUT_POST,'telEns', FILTER_SANITIZE_SPECIAL_CHARS);
		
	
		if($nomEns!="" and $postnomEns!="" and $prenomEns!="" and $sexeEns!="" and $typeEns!="" and $gradeEns!="" and $domainEtudEns!="" ){
			$rqt_updt_ens = "UPDATE tb_enseignant SET nomEns='".$nomEns."', postnomEns='".$postnomEns."', prenomEns='".$prenomEns."', sexeEns='".$sexeEns."', domainEtudEns='".$domainEtudEns."', telEns='".$telEns."', idGrad='".$gradeEns."', typeEns='".$typeEns."', dateEngagEns='".$dateEngagEns."' WHERE idEns = '".$idEns."'";
			if($exe_updt_ens = mysqli_query($con, $rqt_updt_ens)){
				$updt_ens = true;
				header ("location:?fAculTe&iDfaC=".$_GET['iDfaC']."&eNseIgnAnt"."&iDeNseIgnAnt=".$idEns);
			}
			else{
				$sms_updt_ens = "Impossible d'effectuer cette op&eacute;ration.";
			}
		}
		else{
			$sms_updt_ens = "Veuillez remplir tous les champs signal&eacute;s par *";
			}
	}


?>