<?php 
if (isset($_GET['gerer_aca']) and isset($_GET['modifier_aca']) and isset($_GET['aca']) and !isset($_POST['BtUpdateAca']))
	{ 
	$idAca_a_modif = $_GET['aca'];
	if ($idAca_a_modif != "")
		{
		$rqt_slct_aca_a_modif = "select idAnAca, DAY(datedebutAnAca) AS jrD, MONTH(datedebutAnAca) AS mmD, YEAR(datedebutAnAca) AS aaaaD, DAY(datefinAnAca) AS jrF, MONTH(datefinAnAca) AS mmF, YEAR(datefinAnAca) AS aaaaF   from  tb_an_aca where idAnAca = '".$idAca_a_modif."'";
		if($exe_rqt_slct_aca_a_modif = $conDb->query($rqt_slct_aca_a_modif))
			{
			while($result_exe_rqt_slct_aca_a_modif = $exe_rqt_slct_aca_a_modif->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{
				$idAca_a_modif = $result_exe_rqt_slct_aca_a_modif['idAnAca'];
				$jrD_a_modif = $result_exe_rqt_slct_aca_a_modif['jrD'];
				$mmD_a_modif = $result_exe_rqt_slct_aca_a_modif['mmD'];
				$aaaaD_a_modif = $result_exe_rqt_slct_aca_a_modif['aaaaD'];

				$jrF_a_modif = $result_exe_rqt_slct_aca_a_modif['jrF'];
				$mmF_a_modif = $result_exe_rqt_slct_aca_a_modif['mmF'];
				$aaaaF_a_modif = $result_exe_rqt_slct_aca_a_modif['aaaaF'];
	
				//verification de l'id aca dans versement
				$rqt_slct_aca_modif_vers = "select * from  tb_versement where idAca = '".$idAca_a_modif."'";
				if($exe_rqt_slct_aca_modif_vers = $conDb->query($rqt_slct_aca_modif_vers))
					{
					 if($result_rqt_slct_aca_modif_vers = $exe_rqt_slct_aca_modif_vers->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idAca_modif = true;
						$sms_gerer = "Vous n'avez pas les droits de modifier cette ann�e acad�mique ".$idAca_a_modif.". Contacter l'Administrateur pour une assistance.";
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad&eacute;mique indiqu�e. ";
					}
				//verification de l'id aca dans inscription
				$rqt_slct_aca_modif_inscrit = "select * from  tb_inscription where idAca = '".$idAca_a_modif."'";
				if($exe_rqt_slct_aca_modif_inscrit = $conDb->query($rqt_slct_aca_modif_inscrit))
					{
					 if($result_rqt_slct_aca_modif_inscrit = $exe_rqt_slct_aca_modif_inscrit->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idAca_modif = true;
						$sms_gerer = "Vous n'avez pas les droits de supprimer cette ann&eacute;e acad&eacute;mique ".$idAca_a_modif.". Contacter l'Administrateur pour une assistance.";
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad�mique indiqu�e. ";
					}
				//verification de l'id aca dans fix
				$rqt_slct_aca_modif_fix = "select * from  tb_fixation_prix where idAca = '".$idAca_a_modif."'";
				if($exe_rqt_slct_aca_modif_fix  = $conDb->query($rqt_slct_aca_modif_fix ))
					{
					 if($result_rqt_slct_aca_modif_fix  = $exe_rqt_slct_aca_modif_fix->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idAca_modif = true;
						$sms_gerer = "Vous n'avez pas les droits de supprimer cette ann�e acad�mique ".$idAca_a_modif.". Contacter l'Administrateur pour une assistance.";
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad�mique indiqu�e. ";
					}
					
				}	
			}
		else
			{
			echo  "Impossible d'atteindre l'ann�e acad�mique. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
			}
	
		}
	else
		{
		$sms_gerer = "Vous n'avez pas indiqu� l'ann�e acad�mique � modifier. &nbsp;<a href='?gerer_option&modifier_op'>Reaisseyez</a> ";
		}
				

	}
///____________________________________________________________________________________________________________________________________________
if (isset($_GET['gerer_aca']) and isset($_GET['modifier_aca']) and isset($_GET['aca']) and isset($_POST['BtUpdateAca']))
	{ 
	$idAca_a_modif = $_GET['aca'];
	$idAcaUpdt1 = $idAca_a_modif;
	
	$jrDUpdt = filter_input(INPUT_POST,'jrD', FILTER_SANITIZE_SPECIAL_CHARS);
	$mmDUpdt = filter_input(INPUT_POST,'mmD', FILTER_SANITIZE_SPECIAL_CHARS);
	$aaaaDUpdt = filter_input(INPUT_POST,'aaaaD', FILTER_SANITIZE_SPECIAL_CHARS);
	
	$jrFUpdt = filter_input(INPUT_POST,'jrF', FILTER_SANITIZE_SPECIAL_CHARS);
	$mmFUpdt = filter_input(INPUT_POST,'mmF', FILTER_SANITIZE_SPECIAL_CHARS);
	$aaaaFUpdt = filter_input(INPUT_POST,'aaaaF', FILTER_SANITIZE_SPECIAL_CHARS);

	if($jrDUpdt !="" and $mmDUpdt!="" and $aaaaDUpdt!="" and $jrFUpdt!="" and $mmFUpdt!="" and $aaaaFUpdt!="" )
		{
		if($aaaaDUpdt>2008 and $aaaaFUpdt>2009)
			{
			if($aaaaDUpdt != $aaaaFUpdt and ($aaaaFUpdt > $aaaaDUpdt ) and ($aaaaFUpdt - $aaaaDUpdt )== 1)
				{
				$idAcaUpdt = $aaaaDUpdt."-".$aaaaFUpdt;
				$dateDUpdt = $aaaaDUpdt."-".$mmDUpdt."-".$jrDUpdt;
				$dateFUpdt = $aaaaFUpdt."-".$mmFUpdt."-".$jrFUpdt;
								
				echo $idAcaUpdt."<br/>";
				echo $dateDUpdt."<br/>";
				echo $dateFUpdt."<br/>";
								
				$rqt_updt_aca_modif = "UPDATE tb_an_aca  SET idAnAca = '".$idAcaUpdt."', datedebutAnAca = '".$dateDUpdt."', datefinAnAca = '".$dateFUpdt."' where idAnAca = '".$idAca_a_modif."'";
				if($exe_updt_slct_aca_modif = $conDb->query($rqt_updt_aca_modif))
					{
					$sms_gerer = "Les inofrmations de l'ann�e acad�mique ".$idAca_a_modif." (Actuellement ".$idAcaUpdt.") ont �t� mis � jous.";
					header ('location:?gerer_aca&modifier_aca&sms_gerer='.$sms_gerer.'');
					}
				else
					{
					$jrD_a_modif=$jrDUpdt;
					$mmD_a_modif=$mmDUpdt;
					$aaaaD_a_modif=$aaaaDUpdt;
					$jrF_a_modif=$jrFUpdt;
					$mmF_a_modif=$mmFUpdt;
					$aaaaF_a_modif=$aaaaFUpdt;
					
					$sms_gerer = "Impossible de mettre � jour l'ann�e acad�mique ".$idAca_a_modif.". Contacter d'urigence l'Administrateur.";	
					}
				}
			else
				{
				$sms_gerer = "L'intervalle entre l'ann�e d'ouverture et de fermeture n'est pas valide.";
				
					$jrD_a_modif=$jrDUpdt;
					$mmD_a_modif=$mmDUpdt;
					$aaaaD_a_modif=$aaaaDUpdt;
					$jrF_a_modif=$jrFUpdt;
					$mmF_a_modif=$mmFUpdt;
					$aaaaF_a_modif=$aaaaFUpdt;
				}
			}
		else
			{
			$sms_gerer = "L'ann�e acad�mique que vous avez indiqu�e est inf�ri�re � l'ann�e de lancement officiel de l'UNIQUE.";
					
					$jrD_a_modif=$jrDUpdt;
					$mmD_a_modif=$mmDUpdt;
					$aaaaD_a_modif=$aaaaDUpdt;
					$jrF_a_modif=$jrFUpdt;
					$mmF_a_modif=$mmFUpdt;
					$aaaaF_a_modif=$aaaaFUpdt;
			}
		}
	else
		{
		$sms_gerer = "Veuillez remplir tous les champs. ";
		}
	}				



?>