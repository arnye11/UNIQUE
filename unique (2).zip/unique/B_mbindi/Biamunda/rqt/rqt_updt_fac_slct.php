<?php 
	if (isset($_GET['EditFacSec']) and isset($_GET['id']) and $_SESSION['idFonctAutoDec']=="admin" and isset($_POST['BtModifFacSec'])){
		
		$idEts = filter_input(INPUT_POST,'idEts', FILTER_SANITIZE_SPECIAL_CHARS);
		$idFac = filter_input(INPUT_POST,'idFac', FILTER_SANITIZE_SPECIAL_CHARS);
		$designFac = filter_input(INPUT_POST,'designFac', FILTER_SANITIZE_SPECIAL_CHARS);

		if ($designFac != ""){
			$rqt_updt_fac_modif = "UPDATE tb_faculte SET idFac = '".$idFac."', designFac = '".$designFac."' WHERE idFac = '".$idFac."'";
			if($exe_updt_slct_fac_modif = mysqli_query($con, $rqt_updt_fac_modif)){
				$sms_gerer = "Les inofrmations de la Filiere ont ete mis a jour.";
				header ('location:?accueil&sms='.$sms_gerer);
			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Echec de mise � jour</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Veuillez saisir la Fili&egrave;re</div>";
		}
	}

?>