<?php
	$sms_updt_id="";
	$champ = false;
	 
if(isset($_GET['gerer_admin']) and isset($_GET['aDmini5TratIF'])and (isset($_GET['id']) and $_GET['id']!=""))
	{
	if(isset($_POST['BtEnreg']) and (isset($_GET['id']) and $_GET['id']!="") and (isset($_GET['mod']) and $_GET['mod']==1))
		{
		$id=$_GET['id'];
		$nom = filter_input(INPUT_POST,'nom', FILTER_SANITIZE_SPECIAL_CHARS);
		$postnom = filter_input(INPUT_POST,'postnom', FILTER_SANITIZE_SPECIAL_CHARS);
		$prenom = filter_input(INPUT_POST,'prenom', FILTER_SANITIZE_SPECIAL_CHARS);
		$sexe = filter_input(INPUT_POST,'sexe', FILTER_SANITIZE_SPECIAL_CHARS);
		$tel = filter_input(INPUT_POST,'tel', FILTER_SANITIZE_SPECIAL_CHARS);
		if($nom=="" || $postnom=="" || $prenom=="" ||$sexe=="" )
			{
			$champ = false;
			$sms_updt_id = "<div class='echec' style='font-size:13px; font-style:italic';>Il parrait que vous avez oubli� de remplir un champ signal� par *. Veuillez recommancer.</div>";
			}
		else
			{
			$champ = true;
			$rqt_insrt_id = "UPDATE tb_auto_dec  SET nomAutoDec='".$nom."', postnomAutoDec='".$postnom."', prenomAutoDec='".$prenom."', sexeAutoDec='".$sexe."', telAutoDec='".$tel."' where idAutoDec='".$id."'";
			if($exe_rqt_insrt_id = $conDb->query($rqt_insrt_id))
				{
				$sms_updt_id = "<div style='color:#009900'>Identit�s mise � jour avec succ�s.</div>";
				$champ = true;
				}
			else
				{
				$sms_updt_id = "<div style='color:#FF0000'>Impossible d'effecuter cette op�ration. Veuillez reaisseyer.</div>";
				$champ = false;
				}
			}
		}
	if(isset($_POST['BtEnreg']) and (isset($_GET['id']) and $_GET['id']!="") and (isset($_GET['mod']) and $_GET['mod']==2))
		{
		$id=$_GET['id'];
		$log = filter_input(INPUT_POST,'log', FILTER_SANITIZE_SPECIAL_CHARS);
		$password = filter_input(INPUT_POST,'password', FILTER_SANITIZE_SPECIAL_CHARS);
		$NivAc = filter_input(INPUT_POST,'NivAc', FILTER_SANITIZE_SPECIAL_CHARS);
		if($log=="" || $password=="" || $NivAc=="" )
			{
			$champ = false;
			$sms_updt_id = "<div class='echec' style='font-size:13px; font-style:italic';>Il parrait que vous avez oubli� de remplir un champ signal� par *. Veuillez recommancer.</div>";
			}
		else
			{
			$rqt_slct_log="select * from tb_auto_dec where loginAutoDec = '".$log."' and idAutoDec!='".$id."'";
			if($exe_rqt_slct_log = $conDb->query($rqt_slct_log))
				{
				if($result_rqt_slct_log = $exe_rqt_slct_log->fetch_assoc())
					{
					$sms_updt_id = "<div style='color:#FF0000'>Ce login (".$log.") est d�j� utilis� par une autre personne.</div>";
					$champ = false;
					}
				else
					{
					$champ = true;
					$rqt_insrt_id = "UPDATE tb_auto_dec  SET loginAutoDec='".$log."', paswordAutoDec='".$password."', NivAc='".$NivAc."' where idAutoDec='".$id."'";
					if($exe_rqt_insrt_id = $conDb->query($rqt_insrt_id))
						{
						$sms_updt_id = "<div style='color:#009900'>Compte d'utilisateur mise � jour avec succ�s.</div>";
						$champ = true;
						}
					else
						{
						$sms_updt_id = "<div style='color:#FF0000'>Impossible d'effecuter cette op�ration. Veuillez reaisseyer.</div>";
						$champ = false;
						}
					}
				}
			else
				{
				$sms_updt_id = "<div style='color:#FF0000'>Impossible de v�rifier ce compte d'utilisateur. Veuillez reaisseyer.</div>";
				$champ = false;
				}
			}
		}
	}
?>