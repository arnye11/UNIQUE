<?php
if(isset($_GET['profil']) and isset($_GET['modification_profil']) and isset($_GET['mod']) and $_GET['mod']==1)
	{
	$sms_updt_id="";
	$champ = false;
	 
	if(isset($_POST['BtEnreg']) and (isset($_GET['id']) and $_GET['id']!=""))
		{
		$id=$_GET['id'];
		$nom = filter_input(INPUT_POST,'nom', FILTER_SANITIZE_SPECIAL_CHARS);
		$postnom = filter_input(INPUT_POST,'postnom', FILTER_SANITIZE_SPECIAL_CHARS);
		$prenom = filter_input(INPUT_POST,'prenom', FILTER_SANITIZE_SPECIAL_CHARS);
		$sexe = filter_input(INPUT_POST,'sexe', FILTER_SANITIZE_SPECIAL_CHARS);
		$jrNaiss = filter_input(INPUT_POST,'jrNaiss', FILTER_SANITIZE_SPECIAL_CHARS);
		$mNaiss = filter_input(INPUT_POST,'moiNaiss', FILTER_SANITIZE_SPECIAL_CHARS);
		$aNaiss = filter_input(INPUT_POST,'aNaiss', FILTER_SANITIZE_SPECIAL_CHARS);
		$lieuNaiss = filter_input(INPUT_POST,'lieuNaiss', FILTER_SANITIZE_SPECIAL_CHARS);
		$tel = filter_input(INPUT_POST,'tel', FILTER_SANITIZE_SPECIAL_CHARS);
		$email = filter_input(INPUT_POST,'email', FILTER_SANITIZE_SPECIAL_CHARS);
		$adressH = filter_input(INPUT_POST,'adressH', FILTER_SANITIZE_SPECIAL_CHARS);
		if($nom=="" || $postnom=="" || $prenom=="" ||$sexe=="" ||$jrNaiss=="" ||$mNaiss=="" ||$aNaiss=="" ||$lieuNaiss=="")
			{
			$champ = false;
			$sms_updt_id = "<div class='echec' style='font-size:13px; font-style:italic';>Il parrait que vous avez oubli� de remplir un champ signal� par *. Veuillez recommancer.</div>";
			}
		else
			{
			$champ = true;
			$dateNaiss = $aNaiss."-".$mNaiss."-".$jrNaiss;
			$rqt_insrt_id = "UPDATE tb_etudiant  SET nomEtud='".$nom."', postnomEtud='".$postnom."', prenomEtud='".$prenom."', sexeEtud='".$sexe."', datenaissEtud='".$dateNaiss."', lieunaisEtud='".$lieuNaiss."', telEtud='".$tel."', emailEtud='".$email."', adresseEtud='".$adressH."' where matricEtud='".$id."'";
			if($exe_rqt_insrt_id = mysql_query($rqt_insrt_id))
				{
				$sms_updt_id = "<div style='color:#009900'>Identit�s mise � jour avec succ�s.</div>";
				$champ = true;
				}
			else
				{
				$sms_updt_id = "<div style='color:#FF0000'>Impossible d'effecuter cette op�ration. Veuillez reaisseyer.</div>";
				$champ = false;
				}
			}
		}
	}
?>