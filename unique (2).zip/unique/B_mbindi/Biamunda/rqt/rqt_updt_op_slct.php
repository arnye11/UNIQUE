<?php 
	if (isset($_POST['BtUpdateOp'])){ 
		$idFac = filter_input(INPUT_POST,'idFac', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$designOp = filter_input(INPUT_POST,'designOp', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if (($idOp != "") and ($designOp !="")){
			$rqt_updt_Op_modif = "UPDATE tb_option  SET designOp = '".$designOp."' WHERE idOp = '".$idOp."'";
			if(mysqli_query($con, $rqt_updt_Op_modif)){
				$sms_gerer = "Modification effectu�e";
				//$sms_gerer=filter_input($sms_gerer,$sms_gerer, FILTER_SANITIZE_SPECIAL_CHARS);
				header ('location:?fAculTe&iDfaC='.$idFac.'&sms_gerer='.$sms_gerer.'#'.$idOp);
			}
			else{
				$sms_gerer = "Impossible de modifier cette option.";
			}
		}
		else{
			$sms_gerer = "Le champs est vide</a> ";
		}
	}

?>