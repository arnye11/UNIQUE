<?php 
if (isset($_GET['gerer_promotion']) and isset($_GET['modifier_pro']) and isset($_GET['pro']) and !isset($_POST['BtUpdatePro']))
	{ 
	$idpro = $_GET['pro'];
	if ($idpro != "")
		{
		$rqt_slct_pro_modif = "select * from  tb_promotion where idPromo = '".$idpro."'";
		if($exe_rqt_slct_pro_modif = $conDb->query($rqt_slct_pro_modif))
			{
			 if($result_rqt_slct_pro_modif = $exe_rqt_slct_pro_modif->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
				{
				$idpro=$result_rqt_slct_pro_modif['idPromo'];
				$designpro=$result_rqt_slct_pro_modif['designPromo'];
				$sms_gerer = "Promotion trouv�e.";		
				}
			else
				{
				$sms_gerer = "Aucune information trouv�e concernant la promotion indiqu�e.";
				}
			}
		else
			{
			$sms_gerer = "Impossible de trouver la promotion indiqu�e. ";
			}
		}
	else
		{
		$sms_gerer = "Vous n'avez pas indiqu� la promotion � modifier. &nbsp;<a href='?gerer_promotion&modifier_pro'>Reaisseyez</a> ";
		}
				

	}
///____________________________________________________________________________________________________________________________________________
if (isset($_GET['gerer_promotion']) and isset($_GET['modifier_pro']) and isset($_GET['pro']) and isset($_POST['BtUpdatePro']))
	{ 
	$idpro = $_GET['pro'];
	$codPro = $_POST['codPro'];
	$DesignProModf = $_POST['DesignProModf'];

	if (($codPro != "") and ($DesignProModf !=""))
		{
		$rqt_updt_pro_modif = "UPDATE tb_promotion  SET idPromo = '".$codPro."', designPromo = '".$DesignProModf."' where idPromo = '".$idpro."'";
		if($exe_updt_slct_pro_modif = $conDb->query($rqt_updt_pro_modif))
			{
			$sms_gerer = "Les inofrmations de la prmotion (".$codPro.") ont �t� mis � jous.";
			header ('location:?gerer_promotion&modifier_pro&sms_gerer='.$sms_gerer.'');
			}
		else
			{
			$sms_gerer = "Impossible de mettre � jour cette promotion.";
			}
		}
	else
		{
		$sms_gerer = "Veuillez remplir tous les champs ou <a href='?gerer_promotion&modifier_pro'>Reaisseyer</a> ";
		}
				

	}

?>