<?php
//dans pg_apres_conx
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])){
		$idPromoOrgV = $_GET['pRomotIon'];
		$idOpOrgV =$_GET['oPtiOn'];
		$idFacOpOrgV = $_GET['iDfaC'];
		$designFacOpOrgV ="";
		$designOpOrgV ="";
		$rqt_slct_promo = "SELECT * FROM  tb_promotion WHERE idPromo = '".$_GET['pRomotIon']."'"; 
		if($exe_rqt_slct_promo = $conDb->query($rqt_slct_promo)){
			if ($tb_promotion = $exe_rqt_slct_promo->fetch_assoc()) {
				$_SESSION['systPromo']=$idPromo = $tb_promotion["systPromo"];
				$_SESSION['idPromo']=$idPromo = $tb_promotion["idPromo"];
				$rqt_Verification = "SELECT  tb_option.*, tb_organisation_option.* FROM tb_organisation_option INNER JOIN tb_option ON tb_organisation_option.idOp = tb_option.idOp WHERE (((tb_organisation_option.idPromo)='".$idPromoOrgV."') AND ((tb_organisation_option.idOp)='".$_GET['oPtiOn']."') AND ((tb_organisation_option.idAnAca)='".$an_aca."')) ";
						//$rqt_VerificationA = "SELECT * FROM tb_organisation_option WHERE idPromo='".$idPromoOrgV."' AND idOp ='".$_GET['oPtiOn']."' AND idAnAca = '".$_SESSION['idAnAca']."'"; 
						
				if($exe_rqt_slct_opOrgV = mysqli_query($con, $rqt_Verification)){
					if(mysqli_num_rows($exe_rqt_slct_opOrgV)>0){ 
						if($tb_opOrgV = mysqli_fetch_assoc($exe_rqt_slct_opOrgV)) {
							$idOpOrgV =$tb_opOrgV['idOp'];
							$_SESSION["designOp"] = $designOpOrgV =$tb_opOrgV['designOp'];
							echo "<h3>".$idPromoOrgV."&ensp;".$designOpOrgV."</h3>";
							if(isset($_GET["fAculTe"])){
								include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/menuAMS.php");
							}
							
							include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/inscription.php");
							include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Cours/cours.php");
							include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/makuta/fr_rapport.php");
						}
					}
					else{
						echo "Cette promotion et option ne sont pas organis&eacute;es.";
					}
				}
				else{
					echo "Erreur lors de v&eacute;rification si cette promotion et cette option sont organis&eacute;es.";
				}
			}
			else{
				echo "Promotion introuvable";
			}
		}
		else{
			echo "Impossible d'identifier la promotion";
		}
	}


?>