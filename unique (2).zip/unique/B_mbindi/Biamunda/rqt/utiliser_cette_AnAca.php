<style type="text/css">
	.aca{
		width: 45%;
		margin: 20px;
		border: solid 1px #C3C3C3C3;
	}

	.x{
		display: inline-block;
		float: right;
		position: relative;
		width: 50px;
		height: 50px; 
		line-height: 50px;
		background:#003858; 
		color:#FFFFFF; 
		font-size:1.5em; 
		text-align: center;
		
	}
	.x:hover{
		background: #ff0000;
	}
	@media (max-width : 75em){
		.aca{
			width: 75%;
		}

	}
	@media (max-width : 65em){
		.aca{
			width: 80%;
		}

	}
	@media (max-width : 60em){
		.aca{
			width: 90%;
		}

	}
	
</style>
<div align="center" class="aca">
	<a href="?dc10=10f0000010"><div class="x">x</div></a>
	<div style="background:#003858; color:#FFFFFF; font-size:1.5em; text-align: center;height: 50px; line-height: 50px;overflow: hidden;">
		Pr&eacute;voir une Ann&eacute;e Acad&eacute;mique

	</div>
	
	<div style="width:90%; margin-bottom: 40px;">	
		<?php 
			include("B_mbindi/Biamunda/f_ajout_aca.php");							
		?>
	</div>
	<div style="margin-bottom: 40px;">
		<?php 
			$rqt_list_aca = "select * from  tb_an_aca ORDER BY idAnAca DESC";
			if($exe_rqt_list_aca = $conDb->query($rqt_list_aca)){
				if($exe_rqt_list_aca->num_rows>0){
					 ?>
					<div style="border-bottom:solid 1px #c3c3c3; margin-top:10px;margin-bottom:40px;">
						<div style="width:50px;position: relative; top:10px; background: #f2f2f2; border: solid 1px #f2f2f2;">Ou</div>
					</div>
					<div style="font-size:12px; top: -20px; position: relative; letter-spacing: 8px;">Provisoirement</div>
					<form action="" method="post">
						<select name="annee" style="height:30px;background: #ffffff; border-radius:5px 5px; width:50%;">
							<option value="">Selectionner une ann&eacute;e</option>
							<?php 
								while($result_rqt_list_aca = $exe_rqt_list_aca->fetch_assoc()){
									?>
									<option value="<?php echo $result_rqt_list_aca['idAnAca']; ?>">
										<?php echo $result_rqt_list_aca['idAnAca']; ?>
									</option>
						  			<?php 
								}
							?>
						</select>
						<input name="BtUtiliserCeteAnAca" type="submit" value="Utiliser cette ann&eacute;e acad&eacute;mique" style="height:30px;">
					</form>
				<?php
				}
			}
			else{
				echo  "<option value=''> <div style='color:FF0000'> Impossible d'atteindre les ann�e acad�miques. <br/>SVP, contacter urigement l'Administrateur pour l'assistance< /div>< /option>";
			}
		?>
	</div>    
		
</div>

