<?php
if(isset($_GET["aproposInternaut"]))
	{
	$form_publication = false;
	$idet = $_GET['id'];
	$rqt_rchrch_person = "SELECT * FROM personn WHERE  IdPerso ='".$idet."'";
	
	if($execut_rqt_rchrch_person = mysql_query($rqt_rchrch_person))//execution de la requete
		{ 
		if($result_rchrh = mysql_fetch_assoc($execut_rqt_rchrch_person))// Recuperation du resultat de la requet
			{
			$_SESSION['result_rchrh_idEtud']=$result_rchrh['IdPerso'];
			$_SESSION['result_rchrh_PrenomEtud'] = $result_rchrh['PrenomPerso'];
			$_SESSION['result_rchrh_NomEtud'] = $result_rchrh['NomPerso'];
			$_SESSION['result_rchrh_PostnomEtud'] = $result_rchrh['PostnomPerso'];
			$_SESSION['result_rchrh_SexeEtud'] = $result_rchrh['SexePerso'];
			$_SESSION['result_rchrh_AvatarEtud'] = $result_rchrh['AvatarPerso'];
			$_SESSION['result_rchrh_MatriculePerso'] = $result_rchrh['MatriculePerso'];
			$prenom_nom_postnom = $_SESSION['result_rchrh_PrenomEtud']."&nbsp;".$_SESSION['result_rchrh_NomEtud']."&nbsp;".$_SESSION['result_rchrh_PostnomEtud'];
			}
		}
	}	
?>