<div>
	<div style="width: 100%; font-size: 22px; font-weight: bold; text-align: center;">
		Ses collegues
	</div>

	<div style="width: 100%;">
		<div style="width:99%; height:auto; border:solid 1px #CCCCCC; margin-bottom: 12px;">
			<table cellpadding="0" cellspacing="0" style="width:100%;" >
					<tr>
						<td>
							
							<?php 
								$nbrToalInscrit = 0;
								$nbrToalInscritM = 0;
								$nbrToalInscritF = 0;
								
								if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}
								
								$rqt_slct_etud_inscri_promoOp = "SELECT * FROM tb_inscription WHERE idProm = '".$idPromo."' and idOp = '".$idOp."' and idAca = '".$an_aca."'";
								if($exe_rqt_slct_etud_inscri_promoOp = $conDb->query($rqt_slct_etud_inscri_promoOp)){
									if($exe_rqt_slct_etud_inscri_promoOp->num_rows>0){
										$nbrToalInscrit=$exe_rqt_slct_etud_inscri_promoOp->num_rows;
											while($result_exe_rqt_slct_etud_inscri_promoOp = $exe_rqt_slct_etud_inscri_promoOp->fetch_assoc()){
												$slct_etud_inscrit_promoOp = "SELECT * FROM tb_etudiant WHERE matricEtud = '".$result_exe_rqt_slct_etud_inscri_promoOp['matricEtud']."'";
												if($ex_slct_etud_inscrit_promoOp = $conDb->query($slct_etud_inscrit_promoOp)){
													if($ex_slct_etud_inscrit_promoOp->num_rows>0){
														$result_etud_inscrit_promoOp = $ex_slct_etud_inscrit_promoOp->fetch_assoc();
														if($result_etud_inscrit_promoOp['sexeEtud']=="M"){
															$nbrToalInscritM = $nbrToalInscritM+1;
														}
														else{
															$nbrToalInscritF = $nbrToalInscritF+1;
														}
													}
												}
												else{
													echo "Erreur lors de v&eacute;rification du sexe de l'&eacute;tudiant.";
												}
												
											}
											
									}
									else{
										echo "Aucun &eacute;tudiant inscrit";
									}	
								}
								else{
									echo "Erreur lors de v&eacute;rification des &eacute;tudiants inscrits";
								}
							?>

							<div>
								<?php echo  $idPromo."&nbsp;".$designOp;?>
							</div>
							<div >Statistiques d'inscription</div>
							<div align="center">
								<table width="100%" style="background:#CCCCCC; border:solid 1px #666666; text-align:center;" border="0">
									<tr style="background:#666666; color:#FFFFFF;">
										<td>M</td>
										<td>F</td>
										<td>Total</td>
									</tr>
									<tr>
										<td><?php echo $nbrToalInscritM; ?></td>
										<td><?php echo $nbrToalInscritF; ?></td>
										<td><?php echo $nbrToalInscrit; ?></td>
									</tr>
								</table>
							</div>
						</td>
					</tr>
			</table>
		</div>
		<div>
			<?php 			
				$rqt_list_etud_col = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$idPromo."') AND ((tb_inscription.idOp)='".$idOp."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";

				if($exe_rqt_list_etud_col = $conDb->query($rqt_list_etud_col)){
					if($exe_rqt_list_etud_col->num_rows>0){
						$numOrdre=0;
						$ligneForm = 1;
						while($tb_listEtud = $exe_rqt_list_etud_col->fetch_assoc()){ ?>
							<div align="left" style="margin-bottom: 7px;">
								<?php 
									echo "<a href='?profil&id=".$tb_listEtud['matricEtud']."' style='text-transform:uppercase'>";
									echo $numOrdre=$numOrdre+1;
									echo ".&nbsp;"; 
									echo $tb_listEtud["nomEtud"];
									echo "&nbsp;"; 
									echo $tb_listEtud["postnomEtud"];
									echo "&nbsp;"; 
									echo $tb_listEtud["prenomEtud"];
									echo "</a>";
								?>
							</div>
							<?php 
						}
					}
					else{
						echo "Aucun &eacute;tudiant inscrit.";
					}
				}
				else{
					echo "Erreur lors d'&eacute;tablissement de a liste";
				}
			?>
		</div>
	</div>
</div>
