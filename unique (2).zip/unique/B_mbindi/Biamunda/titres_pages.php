<?php 
	//LES TITRES DES PAGES 
	$titrePg=$_SESSION["sigle_tb_etablissement"]." - UNIQUE";
	
	if(isset($_GET['pV'])){
		$titrePg = "PV DE DELIBERATION ".$an_aca." - ".$_GET['pRomotIon']." ".$_SESSION['designOp'];
	}
	if(isset($_GET['ficheCS']) || isset($_GET['fIcHe'])||isset($_GET['fiche_cote'])){
		$titrePg = "FICHE DE COTATION ".$an_aca." - ".$_GET['pRomotIon']." ".$_SESSION['designOp'];
	}
	if(isset($_GET['gRillDelib'])){
		$titrePg = "GRILLE DE DELIBERATION ".$an_aca." - ".$_GET['pRomotIon']." ".$_SESSION['designOp'];
	}
	if(isset($_GET['palMaresFac'])){
		$titrePg = "PALMARES ".$an_aca." - ".$_SESSION['designFac'] ;
	}
	if(isset($_GET['palMares'])){
		$titrePg = "PALMARES ".$an_aca." - ".$_GET['pRomotIon']." ".$_SESSION['designOp'];
	}
	if(isset($_GET['atTrIbutIoNs'])){
		$titrePg = "CHARGE HORAIRE ".$an_aca." - ".$_SESSION['designFac'];
	}
	if(isset($_GET['oP_cPtablE82Zxs'])){
		$titrePg = "OPERATIONS COMPTABLES ".$an_aca ;
		$accueil=false;
	}
	if(isset($_GET['lisSteEtud'])){
		$titrePg = "LISTE D'ETUDIANTS INSCRITS ".$an_aca." - ".$_GET['pRomotIon']." ".$_SESSION['designOp'] ;
		$accueil=false;
	}
?>