<div class="zonTriRecherch">
<span class="Ptri_d_recherche">
Trier par  : &nbsp;
<a  class="<?php if($tri_tous==true){echo "tri_actif";}else{echo "tri_d_recherche";}?>" name="tous01" href="?tous01=true&contenu=<?php echo $contenu;?>" title="Afficher tous les types">Tous</a>
&nbsp;&bull;
<a class="<?php if($tri_cours==true){echo "tri_actif";}else{echo "tri_d_recherche";}?>" href="?cous01" title="Afficher uniquement les cours">Cours</a>
&nbsp;&bull;
<a class="<?php if($tri_lecons==true){echo "tri_actif";}else{echo "tri_d_recherche";}?>" href="?lecons01" title="Afficher uniquement les le�ons">Le�ons</a> 
&nbsp;&bull;
<a class="<?php if($tri_videos==true){echo "tri_actif";}else{echo "tri_d_recherche";}?>" href="?videos01" title="Afficher uniquement les videos">Videos</a>
&nbsp;&bull;
<a class="<?php if($tri_personnes==true){echo "tri_actif";}else{echo "tri_d_recherche";}?>" href="?personnes01" title="Afficher uniquement les personnes">Personnes</a>
&nbsp;&bull; </span>
</div>