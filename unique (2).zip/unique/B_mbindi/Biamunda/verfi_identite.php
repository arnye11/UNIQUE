<?php 

/******************   RECUPERATION DES PARAMETRES ET VERIFICATION  ********************/
if(isset($_POST['BtConnexion'])) //SI LE BOUTON "CONNEXION" EST CLIQUE
	{
	$emailetud = filter_input(INPUT_POST,'emailetud', FILTER_SANITIZE_SPECIAL_CHARS);
	$motdepasse2 = filter_input(INPUT_POST,'motdepasse2', FILTER_SANITIZE_SPECIAL_CHARS);
	
	//ctrl E-mail si valide
	if(filter_var($emailetud, FILTER_VALIDATE_EMAIL) !==false)
		{
		$adresse_email_valide = true;	
		}
			

	//VERIFICATION DU COMPTE ET DU MOT DE PASSE SI SONT SAISI
	if(($emailetud == "Adresse �lectronique" or $emailetud == "" or $adresse_email_valide == false) or ($motdepasse2 == ""))
		{
		//CTRL DES CHAMPS POUR PREPARER LES SMS
		if($emailetud == "Adresse �lectronique")
			{
			$sms_verification = "Veillez d'abord saisir votre  Adresse �lectronique";
			$inputEmail=false;
			}
		elseif($emailetud == "")
			{
			$sms_verification = "Le champ adresse �lectronique est vide. Entrez votre Adresse �lectronique!";
			$inputEmail=false;
			}
		elseif($adresse_email_valide == false)
			{
			$sms_verification = "Adresse E-mail incorrecte. l'E-mail correcte s'�crit comme ceci : exemple@gmail.com";
			$inputEmail=false;
			}
		elseif($motdepasse2 == "")
			{
			$sms_verification = "Vous n'avez pas saisi votre mot de passe!";
			$InputMotdePasse = false;
			}
		 
		}
	else //SI LES CHAMPS N'ONT PAS LES VALEURS PAR DEFAUT
		{	
		//requete de verification d'identit� de l'internaute
		include($_SERVER['DOCUMENT_ROOT']."istia-rdc-ens.cd/inclusion/rqt_verification_d_identite_pour_internaute.php");
		
		//MISE A JOUR DE TEMPS DE CONNXEION
		$periode_connexion = "UPDATE personn SET connecte = 1, date_connecte = NOW(), temps_connecte = NOW() WHERE IdPerso =".$_SESSION['idetud']."";
		if($exe_periode_connexion = mysql_query($periode_connexion))
			{
			// ????????????????????????????????
			}
		else
			{
			//sms � l'Adm : "Impossible de controler le temps de connexion de l'internaut"
			}


		
		}
	}
elseif(isset($_COOKIE['emailcooki']) and isset($_COOKIE['motdepassecooki']))
	{
	$emailetud = filter_var($_COOKIE['emailcooki'], FILTER_SANITIZE_SPECIAL_CHARS);
	$motdepasse2 = filter_var($_COOKIE['motdepassecooki'], FILTER_SANITIZE_SPECIAL_CHARS);
	
		//ctrl E-mail si valide
		if(filter_var($emailetud, FILTER_VALIDATE_EMAIL) !==false)
			{
			$adresse_email_valide = true;	
			}
	
	if(($emailetud != "Adresse �lectronique" or $emailetud != "") and ($motdepasse2 != "") and ($adresse_email_valide !=false))
		{
		//requete de verification d'identit� de l'internaute
		include($_SERVER['DOCUMENT_ROOT']."istia-rdc-ens.cd/inclusion/rqt_verification_d_identite_pour_internaute.php");
		}
	else //SI LES CHAMPS N'ONT PAS LES VALEURS PAR DEFAUT
		{
		//CTRL DES CHAMPS POUR PREPARER LES SMS
		if($emailetud == "Adresse �lectronique")
			{
			$sms_verification = "Veillez d'abord saisir votre  Adresse �lectronique";
			$inputEmail=false;
			}
		elseif($emailetud == "")
			{
			$sms_verification = "Le champ adresse �lectronique est vide. Entrez votre Adresse �lectronique!";
			$inputEmail=false;
			}
		elseif($adresse_email_valide == false)
			{
			$sms_verification = "Adresse E-mail incorrecte. l'E-mail correcte s'�crit comme ceci : exemple@gmail.com";
			$inputEmail=false;
			}
		elseif($motdepasse2 == "")
			{
			$sms_verification = "Vous n'avez pas saisi votre mot de passe!";
			$InputMotdePasse = false;
			}
			 		
		}
	}


?>