<?php 
//dans cours.php

	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['atTribuEr'])){
		$httot = 0;
		$hptot = 0;
		$htot = 0;
		$th = 0;
		
		/* ------------------------------------------------------
			Ancien Système 
			------------------------------------------------------ */
		if ($_SESSION['systPromo']=="A"){	
			$nonAttrib = 0;
			?>
			<div >
				<h3>Attributione des cours <br/> Promotion : <?php echo $idPromoOrgV."&ensp;".$designOpOrgV;?><br> Ann&eacute;e acad&eacute;mique : <?php echo $an_aca;?> </h3>
				<?php 
				if(isset($_POST['BtAttCours'])){ echo $sms_gerer; }
				if(isset($_POST['BtModifierCoursProgram'])){ echo $sms_gerer; }
				if(isset($_GET['sms_gerer'])){ echo "<span class='reussite'>".$_GET['sms_gerer']."</span>"; }
				
				?>
				<table width="100%" border="1" cellpadding="2" cellspacing="0" style="font-size:13px;">
					<tr style="background:#999999; text-align:center;  ">
						<td width="3%">N&deg;</td>
						<td width="50%">
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr" ?>">DESIGNATION COURS</a> 
						</td>
						<td width="3%">HT</td>
						<td width="3%">HP</td>
						<td width="4%">TOT.</td>
						<td width="26%">
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&triParEnse" ?>">ENSEIGNANT</a> 
							
						</td>
						<td width="10%">Action </td>
					</tr>
					<?php 
					if(isset($_GET['triParEnse'])){
						$rqt_slct_cours_Program = "SELECT  * FROM tb_attribution JOIN tb_program_cours ON tb_attribution.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_attribution.idEns";
						
						if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
							if($exe_rqt_slct_cours_Program->num_rows>0){
								$num=0;
								while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
									$num = $num+1;
									$idEns ="";
									
										?>
										<tr>
											<td><div align="right"><?php echo $num; ?> </div></td>
											<td>
												<?php 
												$rqt_slct_c = "SELECT * FROM tb_cours WHERE idCours ='".$tb_programme_cours['idCours']."'";
												if($exe_rqt_slct_c= $conDb->query($rqt_slct_c)){
													if($tb_c = $exe_rqt_slct_c->fetch_assoc()){
														echo $tb_c['designCours'];
													}
													else{
														echo "<div class='erreur'>Cours introuvble.</div>";
													}
												}
												else{
													echo "Erreur.";
												}
												?>
											</td>
											<td><div align="right"><?php echo $tb_programme_cours["ht"]; ?></div></td>
											<td><div align="right"><?php echo $tb_programme_cours["hp"]; ?></div></td>
											<td><div align="right"><?php echo $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; ?></div></td>
											<td>
												<?php 
												$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns = tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$tb_programme_cours['idCours']."') AND ((tb_attribution.idPromo)='".$idPromoOrgV."') AND ((tb_attribution.idOp)='".$idOpOrgV."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ORDER BY nomEns ASC";
												if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
													if($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
														$idEns = $tb_ens['idEns'];
														echo $tb_ens['idGrad']."&nbsp;".$tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns']."&nbsp;|&nbsp;".$tb_ens['domainEtudEns'];
													}
													else{
														echo "<div class='erreur'>Non attribu&eacute;.</div>";
														$nonAttrib = $nonAttrib + $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; 
													}
												}
												else{
													echo "Erreur.";
												}
												?>
											</td>
											<td>
											    <?php 
												if ($idEns ==""){ ?>
													<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&modIf&iDcOurs=".$tb_programme_cours["idCours"] ?>">
														<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/note14.ico" class="icon" align="left" alt="Attrib." title="Attribuer" style="margin-left:5px;"/>
													</a>
													<?php 
												}
												else{?>
													<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&sUpp&iDcOurs=".$tb_programme_cours["idCours"] ?>">
													<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/supp.gif" class="icon" align="right" alt="Sup." title="Retirer" style="margin-right:5px;"/></a>
													<?php 
												}
												?>
											</td>
										</tr>
										<?php 
									
								}

							}
							else{
								?>
								<tr align="left" style="">
									<td colspan="7" style="color:#FF99CC;">Aucun cours n'est encore programm&eacute;</td>
								</tr>
								<?php 
							} 
						}
						else{
							?>
							<tr align="left" style="">
								<td colspan="7" style="color:#FF0000;">Erreur lors de r&eacute;cuperation des cours programm&eacute;</td>
							</tr>
							<?php 
						} 
					}
					else{
						$rqt_slct_cours_Program = "SELECT * FROM tb_cours JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";//COURS 
						//$rqt_list_cours = "SELECT * FROM  tb_program_cours ORDER BY designCours ";//COURS 
						if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
							if($exe_rqt_slct_cours_Program->num_rows>0){
								$num=0;
								while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
									$num = $num+1;
									$idEns = "";
									$nomEns = "";
									$httot = $httot + $tb_programme_cours["ht"] ;
									$hptot = $hptot + $tb_programme_cours["hp"] ;
									
									$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns =tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$tb_programme_cours['idCours']."') AND ((tb_attribution.idPromo)='".$idPromoOrgV."') AND ((tb_attribution.idOp)='".$idOpOrgV."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ORDER BY nomEns ASC";
									if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
										if($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
												$idEns = $tb_ens['idEns'];
												$nomEns = $tb_ens['idGrad']."&nbsp;".$tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns']."&nbsp;|&nbsp;".$tb_ens['domainEtudEns'];
										}
										else{
											$nomEns ="<div class='erreur'>Non attribu&eacute;.</div>";
											$nonAttrib = $nonAttrib + $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; 
										}
									}
									else{
											$nomEns ="Erreur.";
									}
									if(isset($_GET['modIf']) and isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"] and !isset($_POST['BtAttCours'])){

										
										?>
										<tr>
											<td><div align="right"><?php echo $num; ?></div></td>
											<td><?php echo $tb_programme_cours["designCours"] ; ?></td>
											<td><div align="right"><?php echo $tb_programme_cours["ht"]; ?></div></td>
											<td><div align="right"><?php echo $tb_programme_cours["hp"]; ?></div></td>
											<td><div align="right"><?php echo $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; ?></div></td>
											<td colspan="2">
												<div align="right">
													<form action="" method="post" name="formProgramCours">
														<input name="idCours" type="hidden"  value="<?php echo $tb_programme_cours["idCours"]; ?>">
														<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
														<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
														<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
														<select name="idEns" style="width:60%;">
															<option value="<?php echo $idEns; ?>"><?php echo $nomEns; ?></option>
															<?php 
															$rqt_ens = "SELECT * FROM tb_enseignant ORDER BY nomEns ASC";
															if($exe_rqt_ens = $conDb->query($rqt_ens)){
																if($exe_rqt_ens->num_rows>0){
																	while($tb_ens = $exe_rqt_ens->fetch_assoc()){
																		echo "<option value='".$tb_ens['idEns']."'>".$tb_ens['idGrad']."&nbsp;".$tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns']."&nbsp;|&nbsp;".$tb_ens['domainEtudEns']."</option>";
																	}
																}
																else{
																	echo "<option value=''>Aucun enseignant enregistr&eacute;.</option>";
																}
															}
															else{
																	echo "<option value=''>Erreur.</option>";
																}
															?>
															
															
														</select>
														<input name="BtAttCours" type="submit" value="Attribuer" style="width:38%;"> <br>
														<a  href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr";?>">Annuler</a>								</form>
												</div>		
											</td>
										</tr>
									<?php
									}
									else{
										?>
										<tr>
											<td><div align="right"><?php echo $num; ?> </div></td>
											<td><?php echo $tb_programme_cours["designCours"]; ?></td>
											<td><div align="right"><?php echo $tb_programme_cours["ht"]; ?></div></td>
											<td><div align="right"><?php echo $tb_programme_cours["hp"]; ?></div></td>
											<td><div align="right"><?php echo $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; ?></div></td>
											<td><?php echo $nomEns; ?></td>
											<td>
											<?php 
												if ($idEns ==""){ ?>
													<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&modIf&iDcOurs=".$tb_programme_cours["idCours"] ?>">
														<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/note14.ico" class="icon" align="left" alt="Attrib." title="Attribuer" style="margin-left:5px;"/>
													</a>
													<?php 
												}
												else{?>
													<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&rEtireRetTrib&iDcOurs=".$tb_programme_cours["idCours"] ?>">
													<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/supp.gif" class="icon" align="right" alt="Sup." title="Retirer" style="margin-right:5px;"/></a>
													<?php  
												}
											?>
											</td>
										</tr>

										<?php 
									}
								}
								?>
								<tr align="left" style="background:#A0A0A4;">
									<td colspan="2"><div align="right">HEURE TOTALE :  </div></td>
									<td ><div align="right"><?php echo $httot; ?></div></td>
									<td ><div align="right"><?php echo $hptot; ?></div></td>
									<td ><div align="right"><?php  $htot=$httot+$hptot; echo $htot;?></div></td>
									<td >&nbsp;</td>
									<td >&nbsp;</td>
								</tr>

								<?php 
							}
							else{
								?>
								<tr align="left" style="">
									<td colspan="7" style="color:#FF99CC;">Aucun cours n'est encore programm&eacute;</td>
								</tr>
								<?php 
							} 
						}
						else{
							?>
							<tr align="left" style="">
								<td colspan="7" style="color:#FF0000;">Erreur lors de r&eacute;cuperation des cours programm&eacute;</td>
							</tr>
							<?php 
						} 
					}
					?>

				</table>
			</div>
			<div>
				<div align="center">
					<h3>
						BUDGET DE LA PROMOTION
					</h3>
				</div>
				<div align="center">
					<table cellpadding="2" cellspacing="0" border="1" >
						<tr>
							<td>GRADE</td>
							<td>HEURES ATTRIBUEES</td>
							<td>TAUX HORAIRE</td>
							<td>TOTAL</td>
						</tr>
						<?php
							$thAnnuel=0; 
							$rqt_grad = "SELECT  * FROM tb_grade ORDER BY idGrad DESC";
							if($exe_rqt_grad = $conDb->query($rqt_grad)){
								if($exe_rqt_grad->num_rows>0){
									$num=0;
									while($tb_grad = $exe_rqt_grad->fetch_assoc()){ ?>
										<tr>
											<td>
												<?php echo $tb_grad["idGrad"];?>
											</td>
											<td align="right">
												<?php 
													$htotAt =0;
													$rqt_tb_ProgramCours = "SELECT  * FROM tb_attribution JOIN tb_program_cours ON tb_attribution.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ";
						
													if($exe_rqt_tb_ProgramCours = $conDb->query($rqt_tb_ProgramCours)){
														if($exe_rqt_tb_ProgramCours->num_rows>0){
															while($tb_ProgramCours = $exe_rqt_tb_ProgramCours->fetch_assoc()){
																$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns = tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$tb_ProgramCours['idCours']."') AND ((tb_attribution.idPromo)='".$idPromoOrgV."') AND ((tb_attribution.idOp)='".$idOpOrgV."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ";

																if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
																	if($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
																		if($tb_grad["idGrad"] == $tb_ens['idGrad']){
																			$htotAt = $htotAt + $tb_ProgramCours["ht"] + $tb_ProgramCours["hd"] + $tb_ProgramCours["hp"];
																		}
																	}
																}
															}
															echo $htotAt;
														}
														else{
															echo "0";
														}
													}
													else{
														echo "Erreur.";
													}
														
												?>
											</td>
											<td align="right">
												<?php 
													$rqt_slct_th = "SELECT * FROM tb_taux_horaire WHERE idGrad ='".$tb_grad["idGrad"]."' AND idFac='".$idFac."' AND idAnAca = '".$an_aca."'";
													if ($exe_rqt_slct_th=$conDb->query($rqt_slct_th)) {
														if($tb_th = $exe_rqt_slct_th->fetch_assoc()) {
															echo $tb_th["montantTh"];
															$th = $htotAt * $tb_th["montantTh"];
															$thAnnuel += $th;
														}
													}
												?>
											</td>
											<td align="right">
												<?php echo $th;?>
											</td>
										</tr>
									<?php
									}
								}
								else{
									?>
									<tr>
										<td colspan="4">
											<?php echo "Pas des grades";?>
										</td>
									</tr>
								<?php
								}
							}
							else{
								?>
								<tr>
									<td colspan="4">
										<?php echo "Erreur de la rqt";?>
									</td>
								</tr>
								<?php
							}
						?>
						<tr style="background: #000000; color: #ffffff;">
							<td colspan="3" align="right">TOTAL GENERAL : &nbsp; </td>
							<td align="right">
								<?php echo $thAnnuel;?>
							</td>
						</tr>
						<tr >
							<td colspan="2" style="color:#ff0000;">HEURES NON ATTRIBUES</td>
							<td colspan="2" style="color:#ff0000;" align="center" >
								<?php echo $nonAttrib ;?>
							</td>
							
						</tr>
					</table>
				</div> 
			</div>
			<?php 

		}

		/* ------------------------------------------------------
			Nouveau Système 
			------------------------------------------------------ */
		if ($_SESSION['systPromo']=="N"){
			$hAttribS1 = 0;
			$hNonAttribS1 = 0;

			$hAttribS2 = 0;
			$hNonAttribS2 = 0;

			$hAttribTot = 0;
			$hNonAttribTot = 0;	
			?>
			<div >
				<h3 align="center">Attribution des cours  <?php echo $an_aca;?> </h3>
				<?php 
					$form=1;
					$rqt_slct_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem "; 
					if($exe_rqt_slct_Sem = $conDb->query($rqt_slct_Sem)){
						
						$htAnnuel=0;
						$hdAnnuel=0;
						$hpAnnuel=0;
						$htotAnnuel=0;
						$creditAnnuel=0;

						while($tb_semestre = $exe_rqt_slct_Sem->fetch_assoc()) {
							echo "<h2 id=".$tb_semestre["idSem"].">".$tb_semestre["designSem"]."</h2>";
							if((isset($_POST['BtProgramCours'])||isset($_POST['BtProgramEC'])) and $_POST['idSem']==$tb_semestre["idSem"]){ echo $sms_gerer; }
							?>						
							<div >
								<table width="95%" border="1" cellpadding="1" cellspacing="0">
									<tr style="background:#999999; text-align:center;font-weight: bold; ">
										<td width="3%">N&deg;</td>
										<td >
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr" ?>">DESIGNATION COURS</a> 
										</td>
										<td width="3%">HT</td>
										<td width="3%">HD</td>
										<td width="3%">HP</td>
										<td >TOT.</td>
										<td >C.</td>
										<td >
											<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&triParEnse" ?>">ENSEIGNANT</a> 
										</td>
										<td ></td>
									</tr>
									<?php 
			
										$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' ORDER BY designUE "; 
										if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
											if($exe_rqt_slct_ue->num_rows>0){
												$numUE=1;
												$htSem=0;
												$hdSem=0;
												$hpSem=0;
												$htotSem=0;
												$creditSem=0;

												$ue_ec = false;
												while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {

													
													$num=0;
													$htUE = 0;
													$hdUE = 0;
													$hpUE = 0;
													$htotUE = 0;
													$creditUE = 0;

													$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."') AND ((tb_cours.idUE)='".$tb_ue["idUE"]."')) ORDER BY tb_cours.designCours";
													if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
														if($exe_rqt_slct_cours_Program->num_rows>0){
															
															$ue_ec=true;
															?>
															<tr style="background:#999999; text-align:left; " >
																<td colspan="9"><?php echo $numUE++.". ".$tb_ue["designUE"]; ?></td>
															</tr>
															<?php 
															while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
																$idEns ="";

																$num  = $num+1;
																$htEC = $tb_programme_cours["ht"];
																$hdEC = $tb_programme_cours["hd"];
																$hpEC = $tb_programme_cours["hp"];
																$htotEC   = ($htEC + $hdEC + $hpEC);
																$creditEC = ($htotEC/15);
																
																$htUE = $htUE + $htEC ;
																$hdUE = $hdUE + $hdEC ;
																$hpUE = $hpUE + $hpEC ;
																$htotUE  = $htotUE + $htotEC ;
																$creditUE = $creditUE + $creditEC ;

																// VERIFICATION COTE
																$rqt_cote = "SELECT  * FROM tb_cote WHERE idCours='".$tb_programme_cours["idCours"]."' AND idPromo ='".$idPromoOrgV."' AND idOp='".$idOpOrgV."' AND idAca='".$an_aca."'";
	
																if($exe_rqt_cote = $conDb->query($rqt_cote)){
																	if($exe_rqt_cote->num_rows<=0){
																		$btRetirer = true;
																	}
																}
																else{echo "Erreur cote";}
																
																// VERIFICATION ATTRIBUTION
																$btRetirer = false;

																$rqt_tb_attribution = "SELECT  * FROM tb_attribution WHERE idCours='".$tb_programme_cours["idCours"]."' AND idPromo ='".$idPromoOrgV."' AND idOp='".$idOpOrgV."' AND idAnAca='".$an_aca."'";
	
																if($exe_rqt_tb_attribution = $conDb->query($rqt_tb_attribution)){
																	if($exe_rqt_tb_attribution->num_rows<=0){
																		$btRetirer = true;
																	}
																}
																else{echo "Erreur Attr";}

																if(isset($_GET['sms_gerer']) and (isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"])){  
																		?>
																		<tr  id="<?php echo $tb_programme_cours["idCours"]; ?>" align="right">
																			<td colspan="9">
																				<?php 
																					echo "<span class='reussite'>".$_GET['sms_gerer']."</span>"; 
																				?>
																			</td>
																		</tr>
																		<?php 
																	}

																?>
																<tr id="<?php echo $tb_programme_cours["idCours"]; ?>" >
																	<td><?php echo $num; ?> </td>
																	<td>
																		<?php echo $tb_programme_cours["designCours"]; ?>
																	</td>
																	<td>
																		<div align="right">
																			<?php echo $htEC; ?>
																		</div>
																	</td>
																	<td>
																		<div align="right">
																			<?php echo $hdEC; ?>
																		</div>
																	</td>
																	<td>
																		<div align="right">
																			<?php echo $hpEC; ?>
																		</div>
																	</td>
																	<td>
																		<div align="right">
																			<?php echo $htotEC;  ?>
																		</div>
																	</td>
																	<td>
																		<div align="right"><?php echo  round($creditEC, 0); ?></div>
																	</td>
																	<?php 
																		if(isset($_GET['modIf']) and isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"] and !isset($_POST['BtAttCours'])){
																	 
																			?>
																			<td colspan="2">
																				<div align="right">
																					<form action="" method="post" name="formProgramCours">
																						<input name="idCours" type="hidden"  value="<?php echo $tb_programme_cours["idCours"]; ?>">
																						<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
																						<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
																						<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
																						<select name="idEns" style="width:60%;">
																							<option value="<?php echo $idEns; ?>"><?php echo $nomEns; ?></option>
																							<?php 
																							$rqt_ens = "SELECT * FROM tb_enseignant ORDER BY nomEns ASC";
																							if($exe_rqt_ens = $conDb->query($rqt_ens)){
																								if($exe_rqt_ens->num_rows>0){
																									while($tb_ens = $exe_rqt_ens->fetch_assoc()){
																										echo "<option value='".$tb_ens['idEns']."'>".$tb_ens['idGrad']."&nbsp;".$tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns']."&nbsp;|&nbsp;".$tb_ens['domainEtudEns']."</option>";
																									}
																								}
																								else{
																									echo "<option value=''>Aucun enseignant enregistr&eacute;.</option>";
																								}
																							}
																							else{
																									echo "<option value=''>Erreur.</option>";
																								}
																							?>
																						</select>
																						<input name="BtAttCours" type="submit" value="Attribuer" style="width:38%;"> <br>
																						<a  href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr";?>">Annuler</a>
																					</form>
																				</div>		
																			</td>
																			<?php 
																		}
																		else{
																			?>
																			<td>
																				<?php 
																					$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns = tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$tb_programme_cours['idCours']."') AND ((tb_attribution.idPromo)='".$idPromoOrgV."') AND ((tb_attribution.idOp)='".$idOpOrgV."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ORDER BY nomEns ASC";
																					if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
																						if($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
																							$idEns = $tb_ens['idEns'];
																							echo $tb_ens['idGrad']."&nbsp;".$tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns']."&nbsp;|&nbsp;".$tb_ens['domainEtudEns'];
																							if ($tb_semestre["idSem"]=="SEM1") {
																								$hAttribS1 += $htotEC ; 
																							}
																							else{
																								$hAttribS2 += $htotEC ; 
																							}
																						}
																						else{
																							echo "<div class='erreur'>Non attribu&eacute;.</div>";
																							if ($tb_semestre["idSem"]=="SEM1") {
																								$hNonAttribS1 += $htotEC ;  
																							}
																							else{
																								$hNonAttribS2 += $htotEC ; 
																							}
																							
																						}
																					}
																					else{
																						echo "Erreur.";
																					}
																				?>
																			</td>
																			<td>
																			    <?php 
																					if ($idEns ==""){ ?>
																						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&modIf&iDcOurs=".$tb_programme_cours["idCours"] ?>">
																							<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/note14.ico" class="icon" align="left" alt="Attrib." title="Attribuer" style="margin-left:5px;"/>
																						</a>
																						<?php 
																					}
																					else{?>
																						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr&rEtireRetTrib&iDcOurs=".$tb_programme_cours["idCours"] ?>">
																							<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/supp.gif" class="icon" align="right" alt="Sup." title="Retirer" style="margin-right:5px;"/>
																						</a>
																						<?php 
																					}
																				?>
																			</td>
																			<?php 
																		}
																	?>
																</tr>
																<?php 
																
															}
															$htSem= $htSem + $htUE;
															$hdSem= $hdSem + $hdUE;
															$hpSem= $hpSem + $hpUE;
															$htotSem= $htotSem + $htotUE;
															$creditSem= $creditSem + $creditUE;

															
															?>
															<tr align="left" style="background:#A0A0A4;">
																<td colspan="2"><div align="right">TOTAL HEURE/CREDIT UE :  </div></td>
																<td ><div align="right"><?php echo $htUE; ?></div></td>
																<td ><div align="right"><?php echo $hdUE; ?></div></td>
																<td ><div align="right"><?php echo $hpUE; ?></div></td>
																<td ><div align="right"><?php echo $htotUE;?></div></td>
																<td ><div align="right"><?php echo  round($creditUE,0) ;?></div></td>
																<td >&nbsp;</td>
																<td >&nbsp;</td>
															</tr>
															<?php 
														}
														
													}
													else{
														?>
														<tr align="left" style="">
															<td colspan="9" style="color:#FF0000;">Erreur lors de r&eacute;cuperation des &eacute;l&eacute;ments programm&eacute;s cette ann&eacute;e </td>
														</tr>
														<?php 
													} 
												}
												
												$htAnnuel= $htAnnuel + $htSem;
												$hdAnnuel= $hdAnnuel + $hdSem;
												$hpAnnuel= $hpAnnuel + $hpSem;
												$htotAnnuel= $htotAnnuel + $htotSem;
												$creditAnnuel= $creditAnnuel + $creditSem;

												if ($ue_ec==false) {
													?>
													<tr align="left" style="">
														<td colspan="9" style="color:#FF99CC;">Aucun &eacute;l&eacute;ment n'est encore programm&eacute; cette ann&eacute;e. </td>
													</tr>
													<?php 
												} 
												
												?>
												<tr style="text-align:right;">
													<td colspan="2">TOTAL HEURE/CREDIT 1er SEMESTRE</td>
													<td><?php echo $htSem; ?></td>
													<td><?php echo $hdSem; ?></td>
													<td><?php echo $hpSem; ?></td>
													<td><?php echo $htotSem; ?></td>
													<td><?php echo round($creditSem,0); ?></td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
												</tr>
												<?php
												
											}
											else{
												echo "Aucune unit&eacute; d'enseignement trouvr&eacute;e";
											}
										}
										else{
											echo "Erreur lors de r&eacute;cup&eacute;ration des unit&eacute;s d'enseignement";
										}
									?>
								</table>
							</div>
							<?php 
							// CALCUL DES HEURES TOTALES ATTRIBUEES ET NON ATTRIBUEEES
							if ($tb_semestre["idSem"]=="SEM1") {
								$hAttribTot += $hAttribS1 ;
								$hNonAttribTot += $hNonAttribS1 ; 
							}
							else{
								$hAttribTot += $hAttribS2 ;
								$hNonAttribTot += $hNonAttribS2 ;
							}
						}
						?>
						<br>
						<table width="90%"  cellpadding="0" cellspacing="1">
							<tr >
								<td ></td>
								<td ></td>
								<td style="background:#999999;text-align:center;font-weight:bold;">HT</td>
								<td style="background:#999999;text-align:center;font-weight:bold;">HD</td>
								<td style="background:#999999;text-align:center;font-weight:bold;">HP</td>
								<td style="background:#999999;text-align:center;font-weight:bold;">TOT.</td>
								<td style="background:#999999;text-align:center;font-weight:bold;" title="Crédit">C.</td>
								
							</tr>
							<tr style="background:#999999;text-align:right;font-weight:bold; text-align: center;">
								<td colspan="2">TOTAL HEURE/CREDIT ANNUEL</td>
								<td><?php echo $htAnnuel; ?></td>
								<td><?php echo $hdAnnuel; ?></td>
								<td><?php echo $hpAnnuel; ?></td>
								<td><?php echo $htotAnnuel; ?></td>
								<td><?php echo round($creditAnnuel,0); ?></td>
								
							</tr>
						</table>
							<?php
					}
				?>
			</div>
			<?php 
			include("B_mbindi/Cours/budget_charge_horaire_promotion.php"); 
		}
	}
?>