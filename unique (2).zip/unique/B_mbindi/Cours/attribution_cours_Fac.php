	<?php 
		if(isset($_GET['atTrIbutIoNs'])){

			?>
			<style type="text/css">
				.ATTRIBUTIONS{
					/*background-image: linear-gradient(rgba(0, 0, 255, 0.5), rgba(255, 255, 0, 0.5));*/
				}
			</style>
			<div style="width:100%; height:115px; border-bottom:solid 5px #666666; padding: 3px;">
				<table style="width:100%;">	
					<tr >
						<td style="width:100px;height:110px;">	
							<div style="width:100%; height:100%; " >
								<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" style="max-width:100%; max-height:auto;"/>
							</div>
						</td>
						<td style=" " >
							<div align="center" style="font-size:1.1em; text-transform: uppercase; font-weight: bold;" >
								<?php echo $nom_etablissement ; ?><br />
								&laquo; <?php echo $sigle_tb_etablissement ; ?> &raquo;<br />
								SECRETARIAT GENERAL ACADEMIQUE<br />
								<?php 
									$rqt_fac = "select * from  tb_faculte WHERE idFac = '".$_GET['iDfaC']."'";
									if($exe_rqt_fac = $conDb->query($rqt_fac)){
										if($result_rqt_fac = $exe_rqt_fac->fetch_assoc()){
											if ($_SESSION['typEts']=="UN") 
												echo "FACULTE : ";
											else
												echo "SECTION : ";

											echo $result_rqt_fac['designFac'] ;
										}
										else{
											echo "FACULTE INTROUVABLE";
										}
									}
									else{
										echo "IMPOSSIBLE DE TROUVER LA FACULTE";
									}
									
								?>
							</div>
						</td>
						<td style="width:100px; height:110px; " align="right">
							<div style="width:100%; height:100%; ">
								<img src="B_mbindi/Biamunda/icon/unique.gif" style="max-width:100%; max-height:auto;" />
							</div>
						</td>
					</tr>
				</table>
			</div>
			<div align="center" style="height: auto; font-size:1.2em; font-weight:bold;margin-top:20px;margin-bottom:20px;">
				<div align="center" style="width:90%;border:solid 2px #000000; border-radius:16px 16px;" class="ATTRIBUTIONS">
					ATTRIBUTIONS DES COURS PAR ENSEIGNANT <br> <?php echo $an_aca; ?>
				</div>
			</div>
			
			<?php 
			$typensVL = "V";
			$thTotGen = 0;
			for($typens = 1; $typens<=2; $typens++){
				$thTotTyp = 0;
				if($typens == 1){ 
					echo "<h3>ENSEIGNANTS VISITEURS </h3>";
				}
				else{
					echo "<h3>ENSEIGNANTS LOCAUX</h3>"; 
					$typensVL = "L";
				}

				$rqt_slct_ens = "SELECT * FROM tb_enseignant JOIN tb_grade ON tb_enseignant.idGrad = tb_grade.idGrad WHERE (((tb_enseignant.typeEns)='".$typensVL ."')) ORDER BY nomEns ASC";
				if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
					if (mysqli_num_rows($exe_rqt_slct_ens)>0) {
						$num=1;
						?>
						<div style="width:95%;">
							
							<?php 
								while($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
									$rqt_slct_attrib = "SELECT  * FROM tb_attribution JOIN tb_option ON tb_attribution.idOp = tb_option.idOp WHERE (((tb_option.idFac)='".$_GET["iDfaC"]."') AND ((tb_attribution.idEns)='".$tb_ens["idEns"]."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ORDER BY tb_attribution.idPromo ASC";
									if($exe_rqt_slct_attrib = $conDb->query($rqt_slct_attrib)){
										if (mysqli_num_rows($exe_rqt_slct_attrib)>0) {
											?>
											<div style="margin-bottom:30px;">
												<div align='left' style="font-size: 1em; font-weight: bold;">
													<?php  
														echo $num++.". ".$tb_ens["nomEns"]." ".$tb_ens["postnomEns"]." ".$tb_ens["prenomEns"];
													?>
												</div>
												<div align='left' style="padding-left: 20px;font-style: italic; margin-bottom: 6px;">
													<?php  
														echo $tb_ens["designGrad"]." en ".$tb_ens["domainEtudEns"].". Téléphone : ".$tb_ens["telEns"];
													?>
												</div>
												<table style="width:100%;" border="1" cellpadding="0.1" cellspacing="0">
													<tr style="background:#E9E9E9;">
														<td align="center">N°</td>
														<td align="center" >PROMOTION</td>
														<td align="center" >COURS</td>
														<td align="center" >HT</td>
														<td align="center" >HD</td>
														<td align="center" >HP</td>
														<td align="center" >HTOT</td>
														<td align="center">TAUX HOR(FC)</td>
														<td align="center" >TAUX TOT (FC)</td>
														<td align="center" >OBS.</td>
													</tr>
													<?php 
														$numC = 1;
														$httot=0;
														$hdtot=0;
														$hptot=0;
														$htotEns = 0;

														$th = 0;
														$thTot = 0;
														$thTotEns = 0;
														
														while($tb_attribution = $exe_rqt_slct_attrib->fetch_assoc()){
															$ht =0;
															$hd = 0;
															$htp = 0;
															$htot = 0;

															$rqt_slct_cours_Program = "SELECT  * FROM tb_cours JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idCours)='".$tb_attribution["idCours"]."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_program_cours.idPromo ASC";
															if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
																if ($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()) {
																	$ht = $tb_programme_cours["ht"];
																	$hd = $tb_programme_cours["hd"];
																	$hp = $tb_programme_cours["hp"];
																	$htot = $ht+$hd+$hp;
																	
																	$httot +=$ht;
																	$hdtot += $hd;
																	$hptot += $hp;
																	$htotEns += $htot;
																	
																	?>
																	<tr>
																		<td><div align="right"><?php echo $numC++; ?>&nbsp;</div></td>
																		<td><?php echo $tb_programme_cours["idPromo"]." ".substr($tb_attribution["designOp"], 0, 4); ?>&nbsp;</td>
																		<td><?php echo $tb_programme_cours["designCours"]; ?>&nbsp;</td>
																		<td><div align="right"><?php echo $ht; ?>&nbsp;</div></td>
																		<td><div align="right"><?php echo $hd; ?>&nbsp;</div></td>
																		<td><div align="right"><?php echo $hp; ?>&nbsp;</div></td>
																		<td><div align="right"><?php echo $htot; ?>&nbsp;</div></td>
																		<td>
																			<div align="right">
																			<?php 
																				$rqt_slct_th = "SELECT * FROM tb_taux_horaire WHERE idGrad ='".$tb_ens["idGrad"]."' AND idFac='".$_GET['iDfaC']."' AND idAnAca = '".$an_aca."'";
																				if ($exe_rqt_slct_th=$conDb->query($rqt_slct_th)) {
																					if($tb_th = $exe_rqt_slct_th->fetch_assoc()) {
																						$th = $tb_th["montantTh"];
																						$thTot = $htot * $th;
																						echo number_format($th, 0, ',', ' ') ;
																					}
																					else{
																						echo $th;
																					}
																				}
																				else{
																					echo "Erreur";
																				}
																			?>&nbsp;
																			</div>
																		</td>
																		<td>
																			<div align="right">
																				<?php 
																					echo number_format($thTot, 0, ',', ' '); 
																					$thTotEns += $thTot; 
																				?> &nbsp;
																			</div>
																		</td>
																		<td>&nbsp;</td>
																	</tr>		
																	<?php
																}
															}
															else{
																echo "Echec de trouver les cours";
															}
														}
													?>	
													<tr style="background:#E9E9E9;">
														<td colspan="3" style="background:#ffffff;"><div align="right">TOTAL  : &nbsp;&nbsp;</div></td>
														<td><div align="right"><?php echo $httot ; ?>&nbsp;</div></td>
														<td><div align="right"><?php echo $hdtot ; ?>&nbsp;</div></td>
														<td><div align="right"><?php echo $hptot ; ?>&nbsp;</div></td>
														<td><div align="right"><?php echo number_format($htotEns, 0, ',', ' '); ?>&nbsp;</div></td>
														<td><div align="right"><?php echo number_format($th, 0, ',', ' '); ?>&nbsp;</div></td>
														<td>
															<div align="right">
																<?php 
																	echo number_format($thTotEns, 0, ',', ' '); 
																	//echo number_format($thTotEns); 
																	$thTotTyp += $thTotEns;
																?>&nbsp;
															</div>
														</td>
														<td>&nbsp;</td>
													</tr>
												</table>
											</div>
											<?php 
										}
									}
									else{
										echo "Echec de trouver les attributions";
									}
								}
							?>
							<div style="margin-bottom:60px;">
								Total à payer aux enseignants 
								<?php 
									if ($typens == 1)
										echo "Visiteurs : ";
									else 
										echo "locaux : " ;

									echo number_format($thTotTyp, 0, ',', ' ')." FC"; 
									$thTotGen += $thTotTyp;?>&nbsp;</div>
							</div>
						<?php  
					}
					else{
						echo "Aucun invité cette année.";
					}
				}
				else{
					echo "Echec de trouver l'enseignant";
				}
			}
			?>
			<div style="margin:40px;margin-bottom: 40px;" >
				Total général à payer tous les enseignants : <?php echo number_format($thTotGen, 0, ',', ' '); ?>
			</div>
			<div align="center" style="width:60%; float:right;">
				<div style="margin:40px;margin-bottom: 40px;" >
					Fait &agrave; <?php echo $_SESSION['villeEts']; ?>, le 
					<?php 
						 if($jour>=10){echo $jour;}else{echo  "0".$jour;}
						 echo "/";
						 if($moi>=10){echo $moi;}else{ echo "0".$moi;}
						 echo "/";
						 echo $annee_encours; 
					?>&nbsp;
				</div>
				<div  style="margin:40px;margin-bottom: 40px;" >
					<b>	
						<?php 
							if ($_SESSION['typEts']=="UN") 
								echo "FACULTE  ";
							else
								echo "SECTION  ";
						?>
					</b>
					<br>
					<i>(Nom, Sceau et signature de l'autorité)</i>
				</div>
			</div>
			
			<?php 	
				if (!isset($_GET['imPRessIoN'])) {
					?>	
					<div align="left" style="padding-left: 40px; margin-top: 90px; bottom:0px;">
						<?php 
						echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&imPRessIoN&atTrIbutIoNs&aca=".$an_aca."'><img src='B_mbindi/Biamunda/icon/print.ico' class='ico' >
								<br>Imprimer</a>";
						?>	
					</div> 
					<?php 	
				}
			?>
			
			<?php	
		}	
	?>
	

