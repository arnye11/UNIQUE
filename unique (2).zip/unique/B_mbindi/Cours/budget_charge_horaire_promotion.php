<div>
	<div align="center">
		<h3>
			BUDGET DE LA PROMOTION
		</h3>
	</div>
	<div>
		<table style="width: 100%;">
			<tr>
				<td>
					<?php 
						//HEURES ATTRIBUEES ET NON ATTRIBUE PAR SEMESTRE
						$rqt_slct_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem "; 
						if($exe_rqt_slct_Sem = $conDb->query($rqt_slct_Sem)){
							
							$htAnnuel=0;
							$hdAnnuel=0;
							$hpAnnuel=0;
							$htotAnnuel=0;
							$creditAnnuel=0;
							$thAnnuel=0;

							while($tb_semestre = $exe_rqt_slct_Sem->fetch_assoc()) {
								?>
								<div align="center" style="display: inline-block; float: left; margin: 20px;">
									<div>
										<?php 
											echo "<h2 id=".$tb_semestre["idSem"].">";
											echo $tb_semestre["designSem"]."</h2>";
								 		?>
									</div>
									<div style="color:#00841b;text-align: right;">
										
										<?php 
											if ($tb_semestre["idSem"]=="SEM1") {
												echo "HEURES ATTRIBUEES : ".$hAttribS1."<br>"; 
												echo "HEURES NON ATTRIBUEES : ".$hNonAttribS1."<br>"; 
											}
											else{
												echo "HEURES ATTRIBUEES : ".$hAttribS2."<br>"; 
												echo "HEURES NON ATTRIBUEES : ".$hNonAttribS2."<br>" ;
											}
										?>
									</div>
									<table cellpadding="2" cellspacing="0" border="1" >
										<tr>
											<td>GRADE</td>
											<td title="Heures attribuées">H. AT.</td>
											<td title="Taux horaire">T. HOR.</td>
											<td>TOTAL</td>
										</tr>
										<?php 
											$hNonAttrib = 0;
											$thSem=0;
											$rqt_grad = "SELECT  * FROM tb_grade ORDER BY idGrad DESC";
											if($exe_rqt_grad = $conDb->query($rqt_grad)){
												if($exe_rqt_grad->num_rows>0){
													$num=0;
													while($tb_grad = $exe_rqt_grad->fetch_assoc()){
														$hAttribGrd =0;
														$th = 0;
														?>
														<tr>
															<td>
																<?php echo $tb_grad["idGrad"];?>
															</td>
															<td align="right">
																<?php
																	$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' ORDER BY designUE "; 
																	if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
																		if($exe_rqt_slct_ue->num_rows>0){
																			$numUE=1;
																			$htSem=0;
																			$hdSem=0;
																			$hpSem=0;
																			$htotSem=0;
																			$creditSem=0;

																			$ue_ec = false;
																			while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {			
																				$num=0;
																				$htUE = 0;
																				$hdUE = 0;
																				$hpUE = 0;
																				$htotUE = 0;
																				$creditUE = 0;

																				$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."') AND ((tb_cours.idUE)='".$tb_ue["idUE"]."')) ORDER BY tb_cours.designCours";
																				if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
																					if($exe_rqt_slct_cours_Program->num_rows>0){
																						
																						$ue_ec=true;
																						while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
																								
																							$num  = $num+1;
																							$htEC = $tb_programme_cours["ht"];
																							$hdEC = $tb_programme_cours["hd"];
																							$hpEC = $tb_programme_cours["hp"];
																							$htotEC   = ($htEC + $hdEC + $hpEC);
																							$creditEC = ($htotEC/15);
																							
																							$htUE = $htUE + $htEC ;
																							$hdUE = $hdUE + $hdEC ;
																							$hpUE = $hpUE + $hpEC ;
																							$htotUE  = $htotUE + $htotEC ;
																							$creditUE = $creditUE + $creditEC ;

																							
																							$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns = tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$tb_programme_cours['idCours']."') AND ((tb_attribution.idPromo)='".$idPromoOrgV."') AND ((tb_attribution.idOp)='".$idOpOrgV."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ORDER BY nomEns ASC";
																							if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
																								if($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
																									//Heures attribuées
																									if($tb_ens['idGrad']==$tb_grad["idGrad"]){
																										$hAttribGrd += $htotEC;
																										
																									}
																								
																								}
																								/*else{
																									//Heures Non attribuées
																									//$hNonAttrib += $htotEC; 

																								}*/
																							}
																							else{
																								echo "Erreur h.a.";
																							}
																						}
																					}
																				}
																				else{
																					echo "<div title='Echec de recupération des EC programmés cette année'>Echec</div>";
																				} 
																			}
																			if ($ue_ec==false) {
																				echo "<div title='Pas des EC programmés cette année'>0x</div>";
																			} 
																			
																		}
																		/*else{
																			echo "Aucune unit&eacute; d'enseignement trouvr&eacute;e ";
																		}*/
																	}
																	else{
																		echo "Erreur lors de r&eacute;cup&eacute;ration des unit&eacute;s d'enseignement";
																	}
																	echo $hAttribGrd;
																?>
															</td>
															<td align="right">
																<?php 
																	$rqt_slct_th = "SELECT * FROM tb_taux_horaire WHERE idGrad ='".$tb_grad["idGrad"]."' AND idFac='".$idFac."' AND idAnAca = '".$an_aca."'";
																	if ($exe_rqt_slct_th=$conDb->query($rqt_slct_th)) {
																		if($tb_th = $exe_rqt_slct_th->fetch_assoc()) {
																			echo $tb_th["montantTh"];
																			$th = $hAttribGrd * $tb_th["montantTh"];
																			$thSem += $th;
																		}

																	}
																?>
															</td>
															<td align="right">
																<?php echo $th;?>
															</td>
														</tr>
													<?php
													}
												}
												else{
													?>
													<tr>
														<td colspan="4">
															<?php echo "Pas des grades";?>
														</td>
													</tr>
												<?php
												}
											}
											else{
												?>
												<tr>
													<td colspan="4">
														<?php echo "Erreur de la rqt";?>
													</td>
												</tr>
												<?php
											}
										?>
										<tr style="background: #000000; color: #ffffff;">
											<td colspan="3" align="right">TOTAL GENERAL (FC) : &nbsp; </td>
											<td align="right">
												<?php echo $thSem;?>
											</td>
										</tr>
										
									</table>
									
								</div>
								<?php 
							}
						}

						//TOTAL GENERAL DES HEURES ATTRIBUEES ET NON ATTRIBUE
						?>
						<div align="center" style="display: inline-block; float: left; margin: 20px;">
							<div>
								<?php 
									echo "<h2>TOTAL GENERAL</h2>";
						 		?>
							</div>
							<div style="color:#00841b;text-align: right;">
								
								<?php 
									echo "HEURES TOTALE ATTRIBUEES : ".$hAttribTot."<br>"; 
									echo "HEURES TOTAL NON ATTRIBUEES : ".$hNonAttribTot."<br>" ;
									
								?>
							</div>
							<table cellpadding="2" cellspacing="0" border="1" >
								<tr>
									<td>GRADE</td>
									<td title="Heures attribuées">H. AT.</td>
									<td title="Taux horaire">T. HOR.</td>
									<td>TOTAL</td>
								</tr>
								<?php 
									$th=0;
									
									$thAnnuel=0;
									$rqt_grad = "SELECT  * FROM tb_grade ORDER BY idGrad DESC";
									if($exe_rqt_grad = $conDb->query($rqt_grad)){
										if($exe_rqt_grad->num_rows>0){
											$num=0;
											while($tb_grad = $exe_rqt_grad->fetch_assoc()){
												?>
												<tr>
													<td>
														<?php echo $tb_grad["idGrad"];?>
													</td>
													<td align="right">
														<?php
															$rqt_slct_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem "; 
															if($exe_rqt_slct_Sem = $conDb->query($rqt_slct_Sem)){
																
																$htAnnuel=0;
																$hdAnnuel=0;
																$hpAnnuel=0;
																$htotAnnuel=0;
																$creditAnnuel=0;
																
																$hAttribGrdTot =0;
																$hNonAttrib = 0;
																$th=0;
																while($tb_semestre = $exe_rqt_slct_Sem->fetch_assoc()) {
																
																	$hAttribGrd =0;
																	$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' ORDER BY designUE "; 
																	if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
																		if($exe_rqt_slct_ue->num_rows>0){
																			$numUE=1;
																			$htSem=0;
																			$hdSem=0;
																			$hpSem=0;
																			$htotSem=0;
																			$creditSem=0;

																			$ue_ec = false;
																			while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {			
																				$num=0;
																				$htUE = 0;
																				$hdUE = 0;
																				$hpUE = 0;
																				$htotUE = 0;
																				$creditUE = 0;
																				$hAttribGrd =0;
																				$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.* FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."') AND ((tb_cours.idUE)='".$tb_ue["idUE"]."')) ORDER BY tb_cours.designCours";
																				if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
																					if($exe_rqt_slct_cours_Program->num_rows>0){
																						
																						$ue_ec=true;
																						while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
																								
																							$num  = $num+1;
																							$htEC = $tb_programme_cours["ht"];
																							$hdEC = $tb_programme_cours["hd"];
																							$hpEC = $tb_programme_cours["hp"];
																							$htotEC   = ($htEC + $hdEC + $hpEC);
																							$creditEC = ($htotEC/15);
																							
																							$htUE = $htUE + $htEC ;
																							$hdUE = $hdUE + $hdEC ;
																							$hpUE = $hpUE + $hpEC ;
																							$htotUE  = $htotUE + $htotEC ;
																							$creditUE = $creditUE + $creditEC ;

																							
																							$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns = tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$tb_programme_cours['idCours']."') AND ((tb_attribution.idPromo)='".$idPromoOrgV."') AND ((tb_attribution.idOp)='".$idOpOrgV."') AND ((tb_enseignant.idGrad)='".$tb_grad["idGrad"]."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ORDER BY nomEns ASC";
																							if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
																								if($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
																									//Heures attribuées
																									$hAttribGrd += $htotEC;
																										$hAttribGrdTot += $hAttribGrd;
																									
																								
																								}
																								/*else{
																									//Heures Non attribuées
																									//$hNonAttrib += $htotEC; 

																								}*/
																							}
																							else{
																								echo "Erreur h.a.";
																							}
																						}
																					}
																				}
																				else{
																					echo "<div title='Echec de recupération des EC programmés cette année'>Echec</div>";
																				} 
																			}
																			if ($ue_ec==false) {
																				echo "<div title='Pas des EC programmés cette année'>0x</div>";
																			} 
																			
																		}
																		/*else{
																			echo "Aucune unit&eacute; d'enseignement trouvr&eacute;e";
																		}*/
																	}
																	else{
																		echo "Erreur lors de r&eacute;cup&eacute;ration des unit&eacute;s d'enseignement";
																	}
																}
																echo $hAttribGrdTot ;
																
															}		
															
														?>
													</td>
													<td align="right">
														<?php 
															$rqt_slct_th = "SELECT * FROM tb_taux_horaire WHERE idGrad ='".$tb_grad["idGrad"]."' AND idFac='".$idFac."' AND idAnAca = '".$an_aca."'";
															if ($exe_rqt_slct_th=$conDb->query($rqt_slct_th)) {
																if($tb_th = $exe_rqt_slct_th->fetch_assoc()) {
																	echo $tb_th["montantTh"];
																	$th = $hAttribGrdTot * $tb_th["montantTh"];
																	$thAnnuel += $th;
																}
															}
														?>
													</td>
													<td align="right">
														<?php echo $th ;?>
													</td>
												</tr>
												<?php 
											}
										}
										else{
											?>
											<tr>
												<td colspan="4">
													<?php echo "Pas des grades";?>
												</td>
											</tr>
										<?php
										}
									}
									else{
										?>
										<tr>
											<td colspan="4">
												<?php echo "Erreur de la rqt";?>
											</td>
										</tr>
										<?php
									}
								?>
								<tr style="background: #000000; color: #ffffff;">
									<td colspan="3" align="right">TOTAL GENERAL : &nbsp; </td>
									<td align="right">
										<?php echo $thAnnuel;?>
									</td>
								</tr>
								
							</table>
						</div>
							
				</td>
			</tr>
		</table>
	</div>
</div>
