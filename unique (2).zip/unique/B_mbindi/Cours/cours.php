
<?php 
//dans rqt_verification_promo_op
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])){?>
		<style type="text/css">
			<!--
			.menuInscription{
				height:auto; display:inline; float:left; font-family:'Century Schoolbook'; text-align:left; margin-left:2%;margin-right:2%; text-align:center; 
			}
			#s_menuInscriptionSlct{
				padding:5px; box-shadow:0px 2px 2px 0px #333399;
			}
			
			-->
		</style>
		
		<table width="100%">
			<tr>
				<td>
					<div class="menuInscription" <?php if (isset($_GET['listCours'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours" ?>">Cours</a> 
					</div>
					<div class="menuInscription" <?php if (isset($_GET['pRograMe'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe" ?>">Programmer</a> 
					</div>
					<div class="menuInscription" <?php if (isset($_GET['atTribuEr'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&atTribuEr" ?>">Attribuer</a> 
					</div>
					<div class="menuInscription" <?php if (isset($_GET['aLigner'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&aLigner" ?>">Aligner</a> 
					</div>
					<div class="menuInscription" <?php if (isset($_GET['tAuxhOraIre'])){ echo "id='s_menuInscriptionSlct'"; }?> >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&tAuxhOraIre" ?>">Taux horaire</a> 
					</div>
				</td>
			</tr>
		</table>

		<table width="100%">
			<tr>
				<td>
					<div class="divFormInscript">
						<?php 
							include("B_mbindi/Cours/programme_cours.php"); 
							include("B_mbindi/Cours/attribution_cours.php"); 
							include("B_mbindi/Cours/f_ajouter_cours.php");
							if (isset($_GET['listCours'])) {
								include("B_mbindi/Cours/rqt_list_cours.php");
							}
							include("B_mbindi/Cours/taux_horaire.php");
							
						?>
					
					</div>
				
				</td>
			</tr>
		</table>

		 <?php 	
	}

?>