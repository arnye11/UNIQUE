<?php 
	if (isset($_GET['AjoutUE'])){
		if (isset($_POST['BtAjoutUE'])){echo $sms_gerer;}
		?>
		<div style="width:98%; text-align:right; padding-right: 5px;">
			<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours" ?>">X</a> 
		</div>
		<div id="fue">
			<form action="" method="post" name="f_ajout_Cours">	
				<input type="hidden" name="idPromo" value="<?php echo $_GET['pRomotIon']; ?>">
				<input type="hidden" name="idOp" value="<?php echo $_GET['oPtiOn']; ?>">
							
				<table>
					<tr>
						<td>Code UE</td>
						<td>
							<input type="text" name="idUE" >
						</td>
					</tr>
					<tr>
						<td>Désignation UE</td>
						<td>
							<input type="text" name="designUE" >
						</td>
					</tr>
					<tr>
						<td>Semestre</td>
						<td>
							<select name="idSem" style="width:100%;" >
								<option value="">Seléctionner un semestre</option>
								<?php 
									$rqt_sem = "select * from  tb_semestre ORDER BY idSem ";//COURS 
									if($exe_rqt_sem = $conDb->query($rqt_sem)){
										if($exe_rqt_sem->num_rows>0){
											while($tb_sem = $exe_rqt_sem->fetch_assoc()){
												echo "<option value='".$tb_sem["idSem"]."'>".$tb_sem["designSem"]."</option>";
											}
										}
										else{
											echo "<option value=''>Pas de semestre</option>";
										} 
									}
									else{
										echo "<option value=''>Erreur</option>";
									}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td></td>
						<td>
							<input type="submit" name="BtAjoutUE" value="Ajouter" >
						</td>
					</tr>
				</table>
			</form>
		</div>
		<?php 
	} 
?>