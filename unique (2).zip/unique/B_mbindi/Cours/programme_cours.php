<?php
//dans cours.php 
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['pRograMe'])){
		/* ------------------------------------------------------
			Ancien Système 
			------------------------------------------------------ */
		if ($_SESSION['systPromo']=="A"){		
			$httot = 0;
			$hptot = 0;
			$htot = 0;
			?>
			<script language="JavaScript" type="text/javascript">
				var ht = 0;
				var hp = 0;
				var htot = 0;
				function txtht(t){
					ht = parseInt(t); 
					//htot = ht + parseInt(hp);
					//document.formProgramCours.tot.value = htot;

					document.formProgramCours.tot.value = ht ;
					//document.formProgramCours.tot.value = parseInt(document.formProgramCours.ht.value) + parseInt(document.formProgramCours.hp.value);
				}
				function txthp(p){
					hp = parseInt(p);
					htot = ht + hp;
					document.formProgramCours.tot.value = htot;
					//document.formProgramCours.tot.value = hp + parseInt(document.formProgramCours.ht.value);
				}
			</script>
			<style type="text/css">
				<!--
				.ProgrammeCours, .ListeCours{
					height:auto; 
					display:inline; 
					float:left; 
					border:solid 1px #CCCCCC; 
					padding:5px; 
				}
				.ProgrammeCours{
					width:60%;   
				}
				.ListeCours{
					width:36%; 
				}
				-->
			</style>
			 
			<table width="100%">
				<tr>
					<td>
						<div class="ProgrammeCours">
							<div >
								<h3>Programme des cours de : <?php echo $idPromoOrgV."&ensp;".$designOpOrgV;?><br> Pour l'ann&eacute;e acad&eacute;mique : <?php echo $an_aca;?> </h3>
								<?php 
								if(isset($_POST['BtProgramCours'])){ echo $sms_gerer; }
								if(isset($_POST['BtModifierCoursProgram'])){ echo $sms_gerer; }
								if(isset($_GET['sms_gerer'])){ echo "<span class='reussite'>".$_GET['sms_gerer']."</span>"; }
								
								?>
								<table width="100%" border="1" cellpadding="2" cellspacing="0">
									<tr style="background:#999999; text-align:center; ">
										<td width="4%">N&deg;</td>
										<td width="63%">D&eacute;signation</td>
										<td width="5%">HT</td>
										<td width="5%">HP</td>
										<td width="7%">TOT.</td>
										<td width="15%">Action </td>
									</tr>
									<?php 
										$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";//COURS 
										//$rqt_list_cours = "SELECT * FROM  tb_program_cours ORDER BY designCours ";//COURS 
										if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
											if($exe_rqt_slct_cours_Program->num_rows>0){
												$num=0;
												while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
													$num = $num+1;
													$httot = $httot + $tb_programme_cours["ht"];
													$hptot = $hptot + $tb_programme_cours["hp"];
													if(isset($_GET['modIf']) and isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"]){ 
														if (isset($_POST['BtModifierCoursProgram'])) {
															?>
															<tr>
																<td colspan="6"> 
																	<?php echo $sms_gerer; ?>
																</td>
															</tr>
															<?php
														}
														?>
														<form action="" method="post" name="formProgramCours">
															<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
															<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
															<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
															<tr>
																<td> <?php echo $num; ?></td>
																<td>
																	<input name="idCours" type="hidden"  value="<?php echo $tb_programme_cours["idCours"]; ?>">
																		<?php echo $tb_programme_cours["designCours"] ; ?>
																</td>
																<td><input name="ht" type="text" size="2" value="<?php echo $tb_programme_cours["ht"]; ?>" onchange="txtht(this.value)"></td>
																<td>
																	<input name="hp" type="text" size="2" value="<?php echo $tb_programme_cours["hp"]; ?>" onchange="txthp(this.value)" >
																</td>
																<td colspan="2">
																	<div align="center">
																		<input name="BtModifierCoursProgram" type="submit" value="Modifier" style="width:48%;"> 
																		<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe";?>">Annuler</a>
																	</div>
																</td>
															</tr>
														</form> <?php
													}
													else{
														?>
														<tr>
															<td><?php echo $num; ?> </td>
															<td><?php echo $tb_programme_cours["designCours"]; ?></td>
															<td><div align="right"><?php echo $tb_programme_cours["ht"]; ?></div></td>
															<td><div align="right"><?php echo $tb_programme_cours["hp"]; ?></div></td>
															<td><div align="right"><?php echo $tb_programme_cours["ht"]+$tb_programme_cours["hp"]; ?></div></td>
															<td>
																<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe&modIf&iDcOurs=".$tb_programme_cours["idCours"] ?>">
																	<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" style="margin-left:10px;"/> 
																</a>
																<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/supp.gif" class="icon" align="right" alt="Sup." title="Retirer" style="margin-right:10px;"/> &nbsp;&nbsp;&nbsp;&nbsp;
															</td>
														</tr>
														<?php 
													}
												}
												?>
												<tr align="left" style="background:#A0A0A4;">
													<td colspan="2"><div align="right">HEURE TOTALE :  </div></td>
													<td ><div align="right"><?php echo $httot; ?></div></td>
													<td ><div align="right"><?php echo $hptot; ?></div></td>
													<td ><div align="right"><?php  $htot=$httot+$hptot; echo $htot;?></div></td>
													<td >&nbsp;</td>
												</tr>
												<?php 
											}
											else{
												?>
												<tr align="left" style="">
													<td colspan="6" style="color:#FF99CC;">Aucun cours n'est encore programm&eacute; cette ann&eacute;e. </td>
												</tr>
												<?php 
											} 
										}
										else{
											?>
											<tr align="left" style="">
												<td colspan="6" style="color:#FF0000;">Erreur lors de r&eacute;cuperation des cours programm&eacute;s cette ann&eacute;e </td>
											</tr>
											<?php 
										} 
									?>

									<tr>
										<td colspan="6" style="color:#666666; font-size:18px;" align="center">Ajouter un cours au programme de cette ann&eacute;e </td>
									</tr>
									<form action="" method="post" name="formProgramCours">
										<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
										<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
										<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
										<tr>
											<td colspan="2">
												<select name="idCours" style="width:100%;" >
													<option value="">Sel&eacute;ctionner le cours</option>
													<?php 
													$rqt_cours_a_prog = "select * from  tb_cours WHERE idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designCours ";//COURS 
													if($exe_rqt_cours_a_prog = $conDb->query($rqt_cours_a_prog)){
														if($exe_rqt_cours_a_prog->num_rows>0){
															while($result_rqt_cours_a_prog = $exe_rqt_cours_a_prog->fetch_assoc()){
																echo "<option value='".$result_rqt_cours_a_prog["idCours"]."'>".$result_rqt_cours_a_prog["designCours"]."</option>";
															}
														}
														else{
															echo "<option value=''>Aucun cours trouv&eacute;</option>";
														} 
													}
													else{
														echo "<option value=''>Erreur lors de sel&eacute;ction des cours</option>";
													}?>
												</select>
											</td>
											<td><input name="ht" type="text" size="2" onchange="txtht(this.value)"></td>
											<td><input name="hp" type="text" size="2" onchange="txthp(this.value)" ></td>
											<td><input name="tot" type="text" size="2" disabled="disabled" ></td>
											<td><input name="BtProgramCours" type="submit" value="Programmer" style="width:100%;"></td>
										</tr>
									</form>
								</table>
							</div>
						</div>
						<div class="ListeCours">
							<?php 
							include("B_mbindi/Cours/f_ajouter_cours.php"); 
							include("B_mbindi/Cours/rqt_list_cours.php");
							?>
						</div>
					</td>
				</tr>
			</table>
			<?php 
		}
		
		/* ------------------------------------------------------
			Nouveau Système LMD
			------------------------------------------------------ */
		if ($_SESSION['systPromo']=="N"){
			$heureCredit = 15;

			?>

			<script language="JavaScript" type="text/javascript">
				var ht = 0;
				var hd = 0;
				var hp = 0;
			
				function valht(t){
					ht = parseInt(t);
					document.formProgramEC.htot.value = ht + hd + hp ;
					document.formProgramEC.credit.value = ((ht + hd + hp)/15) ;

				}
				function valhd(d){
					hd = parseInt(d);
					document.formProgramEC.htot.value = (ht + hd + hp) ;
					document.formProgramEC.credit.value = ((ht + hd + hp)/15) ;
				}
				function valhp(p){
					hp = parseInt(p);
					document.formProgramEC.htot.value =  (ht + hd + hp);
					document.formProgramEC.credit.value = parseInt((ht + hd + hp)/15,0) ;
				}	
			</script>
			<style type="text/css">
				<!--
				.ProgrammeCours, .ListeCours{
					height:auto; 
					display:inline; 
					float:left; 
					border:solid 1px #CCCCCC; 
					padding:5px; 
				}
				.ProgrammeCours{
					width:60%;   
				}
				.ListeCours{
					width:36%; 
				}
				-->
			</style>

			<div style="background:#FFFFFF; border:solid 1px #000000; padding:1px;">
				<table width="100%">
					<tr>
						<td>
							<div class="ProgrammeCours">
								<div style="height:50px;border: solid 1px #cdcdcd; font-size:1.5em;">
									<div style="display: inline-block; float:left;">
										<b>Ann&eacute;e acad&eacute;mique : <?php echo $an_aca;?> </b>
									</div>
									<div style="display: inline-block; float:right;">
										<b> 1 Crédit = 15h </b>
									</div>
								</div>
									

								<?php 
									$form=1;
									$rqt_slct_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem "; 
									if($exe_rqt_slct_Sem = $conDb->query($rqt_slct_Sem)){
											
										$htAnnuel=0;
										$hdAnnuel=0;
										$hpAnnuel=0;
										$htotAnnuel=0;
										$creditAnnuel=0;

										while($tb_semestre = $exe_rqt_slct_Sem->fetch_assoc()) {
											echo "<h2 id=".$tb_semestre["idSem"].">".$tb_semestre["designSem"]."</h2>";
											if((isset($_POST['BtProgramCours'])||isset($_POST['BtProgramEC'])) and $_POST['idSem']==$tb_semestre["idSem"]){ echo $sms_gerer; }
											?>						
											<div >
												<table width="100%" border="1" cellpadding="1" cellspacing="0">
													<tr style="background:#999999; text-align:center;font-weight: bold; ">
														<td width="3%">N&deg;</td>
														<td >D&eacute;signation</td>
														<td width="3%">HT</td>
														<td width="3%">HD</td>
														<td width="3%">HP</td>
														<td >TOT.</td>
														<td >C.</td>
														<td ></td>
													</tr>
													<?php 
							
														$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' ORDER BY designUE "; 
														if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
															if($exe_rqt_slct_ue->num_rows>0){
																$numUE=1;
																$htSem=0;
																$hdSem=0;
																$hpSem=0;
																$htotSem=0;
																$creditSem=0;

																$ue_ec = false;
																while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {

																	
																	$num=0;
																	$htUE = 0;
																	$hdUE = 0;
																	$hpUE = 0;
																	$htotUE = 0;
																	$creditUE = 0;

																	$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromoOrgV."') AND ((tb_program_cours.idOp)='".$idOpOrgV."') AND ((tb_program_cours.idAnAca)='".$an_aca."') AND ((tb_cours.idUE)='".$tb_ue["idUE"]."')) ORDER BY tb_cours.designCours";
																	if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
																		if($exe_rqt_slct_cours_Program->num_rows>0){
																			
																			$ue_ec=true;
																			?>
																			<tr style="background:#999999; text-align:left; " >
																				<td colspan="8"><?php echo $numUE++.". ".$tb_ue["designUE"]; ?></td>
																			</tr>
																			<?php 
																			while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){
																				$num  = $num+1;
																				$htEC = $tb_programme_cours["ht"];
																				$hdEC = $tb_programme_cours["hd"];
																				$hpEC = $tb_programme_cours["hp"];
																				$htotEC   = ($htEC + $hdEC + $hpEC);
																				$creditEC = ($htotEC/$heureCredit);
																				
																				$htUE = $htUE + $htEC ;
																				$hdUE = $hdUE + $hdEC ;
																				$hpUE = $hpUE + $hpEC ;
																				$htotUE  = $htotUE + $htotEC ;
																				$creditUE = $creditUE + $creditEC ;

																				// VERIFICATION COTE
																				$rqt_cote = "SELECT  * FROM tb_cote WHERE idCours='".$tb_programme_cours["idCours"]."' AND idPromo ='".$idPromoOrgV."' AND idOp='".$idOpOrgV."' AND idAca='".$an_aca."'";
					
																				if($exe_rqt_cote = $conDb->query($rqt_cote)){
																					if($exe_rqt_cote->num_rows<=0){
																						$btRetirer = true;
																					}
																				}
																				else{echo "Erreur cote";}
																				
																				// VERIFICATION ATTRIBUTION
																				$btRetirer = false;

																				$rqt_tb_attribution = "SELECT  * FROM tb_attribution WHERE idCours='".$tb_programme_cours["idCours"]."' AND idPromo ='".$idPromoOrgV."' AND idOp='".$idOpOrgV."' AND idAnAca='".$an_aca."'";
					
																				if($exe_rqt_tb_attribution = $conDb->query($rqt_tb_attribution)){
																					if($exe_rqt_tb_attribution->num_rows<=0){
																						$btRetirer = true;
																					}
																				}
																				else{echo "Erreur Attr";}

																				if(isset($_GET['modIf'])||isset($_POST['BtModifierECProgram']) and isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"]){ ?>
																					<form action="" method="post" name="formProgramCours" >
																						<input name="idPromo" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
																						<input name="idOp" type="hidden"  value="<?php echo $idOpOrgV; ?>">
																						<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
																						<input name="idCours" type="hidden"  value="<?php echo $tb_programme_cours["idCours"]; ?>">
																						<?php 
																							if(isset($_POST['BtModifierECProgram'])){ 
																								?>
																								<tr  id="<?php echo $tb_programme_cours["idCours"]; ?>" align="right">
																									<td colspan="8">
																										<?php echo $sms_gerer; ?>
																									</td>
																								</tr>
																								<?php 
																							}
																						?>
																						<tr  id="<?php echo $tb_programme_cours["idCours"]; ?>">
																							<td> <?php echo $num; ?></td>
																							<td valign="top">
																								<?php echo $tb_programme_cours["designCours"] ; ?>
																							</td>
																							<td valign="top">
																								<input name="ht" type="text" style="width: 25px;" maxlength="3" value="<?php echo $htEC; ?>" onchange="txtht(this.value)">
																							</td>
																							<td valign="top">
																								<input name="hd" type="text" style="width: 25px;" maxlength="3" value="<?php echo $hdEC; ?>" onchange="txtht(this.value)">
																							</td>
																							<td valign="top">
																								<input name="hp" type="text" style="width: 25px;" maxlength="3" value="<?php echo $hpEC; ?>" onchange="txthp(this.value)" >
																							</td>
																							<td colspan="3" valign="top">
																								<div style="height: 25px; margin-bottom: 5px; ">
																									<input name="BtModifierECProgram" type="submit" value="OK" style="float: left;" >
																									<?php 
																										if ($btRetirer==true) {
																											?>
																											<input name="BtRetierECProgram" type="submit" value="Retirer" style="float: right; background: #ff0f3e; color:#ffffff; ">
																											<?php 
																										}
																									?>
																								</div>
																								<div style="text-align:left;">
																									<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe";?>">Annuler</a>
																									
																								</div>
																							</td>
																						</tr>
																					</form> <?php
																				}
																				else{
																					?>
																					<?php 
																						if(isset($_GET['sms_gerer']) and (isset($_GET['iDcOurs']) and $_GET['iDcOurs'] == $tb_programme_cours["idCours"])){  
																							?>
																							<tr  id="<?php echo $tb_programme_cours["idCours"]; ?>" align="right">
																								<td colspan="8">
																									<?php 
																										echo "<span class='reussite'>".$_GET['sms_gerer']."</span>"; 
																									?>
																								</td>
																							</tr>
																							<?php 
																						}

																					?>
																					<tr id="<?php echo $tb_programme_cours["idCours"]; ?>" >
																						<td><?php echo $num; ?> </td>
																						<td>
																							<?php echo $tb_programme_cours["designCours"]; ?>
																						</td>
																						<td>
																							<div align="right">
																								<?php echo $htEC; ?>
																							</div>
																						</td>
																						<td>
																							<div align="right">
																								<?php echo $hdEC; ?>
																							</div>
																						</td>
																						<td>
																							<div align="right">
																								<?php echo $hpEC; ?>
																							</div>
																						</td>
																						<td>
																							<div align="right">
																								<?php echo $htotEC;  ?>
																							</div>
																						</td>
																						<td>
																							<div align="right"><?php echo  round($creditEC, 0); ?></div>
																						</td>
																						<td>
																							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe&modIf&iDcOurs=".$tb_programme_cours["idCours"]."#".$tb_programme_cours["idCours"] ?>">
																								<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" style="margin-left:10px;"/> 
																							</a>
																							<?php 
																								if(($_SESSION['idAnAca'] != $an_aca) and ($ue_ec!=false)){
																									if (isset($_GET['reutilProgram']) and isset($_GET['pourProgram'])) {
																										
																										$rqt_ajout_cours_program = "INSERT INTO tb_program_cours VALUES (NULL, '".$tb_programme_cours["idCours"]."','".$_GET['pRomotIon']."','".$_GET['oPtiOn']."','".$htEC."','".$hdEC."','".$hpEC."','".$_SESSION['idAnAca']."', NOW())";
																										if($exe_rqt_ajout_cours_program = $conDb->query($rqt_ajout_cours_program)){
																											?>
																											<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/s_success.png" class="icon" align="left" alt="Modif." title="Modifier" style="margin-left:10px;"/>
																											<?php
																										}
																										else{
																											?>
																											<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/w95mbx03.ico" class="icon" align="left" alt="Modif." title="Modifier" style="margin-left:10px;"/>
																											<?php
																										}
																									}
																								}
																							?>
																						</td>
																					</tr>
																					<?php 
																				}
																			}
																			$htSem= $htSem + $htUE;
																			$hdSem= $hdSem + $hdUE;
																			$hpSem= $hpSem + $hpUE;
																			$htotSem= $htotSem + $htotUE;
																			$creditSem= $creditSem + $creditUE;
																			
																			?>
																			<tr align="left" style="background:#A0A0A4;">
																				<td colspan="2"><div align="right">TOTAL HEURE/CREDIT UE :  </div></td>
																				<td ><div align="right"><?php echo $htUE; ?></div></td>
																				<td ><div align="right"><?php echo $hdUE; ?></div></td>
																				<td ><div align="right"><?php echo $hpUE; ?></div></td>
																				<td ><div align="right"><?php echo $htotUE;?></div></td>
																				<td ><div align="right"><?php echo  round($creditUE,0) ;?></div></td>
																				<td >&nbsp;</td>
																			</tr>
																			<?php 
																		}
																	}
																	else{
																		?>
																		<tr align="left" style="">
																			<td colspan="8" style="color:#FF0000;">Erreur lors de r&eacute;cuperation des &eacute;l&eacute;ments programm&eacute;s cette ann&eacute;e </td>
																		</tr>
																		<?php 
																	} 
																}
																
																$htAnnuel= $htAnnuel + $htSem;
																$hdAnnuel= $hdAnnuel + $hdSem;
																$hpAnnuel= $hpAnnuel + $hpSem;
																$htotAnnuel= $htotAnnuel + $htotSem;
																$creditAnnuel= $creditAnnuel + $creditSem;

																if ($ue_ec==false) {
																	?>
																	<tr align="left" style="">
																		<td colspan="8" style="color:#FF99CC;">Aucun &eacute;l&eacute;ment n'est encore programm&eacute; cette ann&eacute;e. </td>
																	</tr>
																	<?php 
																} 
																
																?>
																<tr style="text-align:right;">
																	<td colspan="2">TOTAL HEURE/CREDIT 1er SEMESTRE</td>
																	<td><?php echo $htSem; ?></td>
																	<td><?php echo $hdSem; ?></td>
																	<td><?php echo $hpSem; ?></td>
																	<td><?php echo $htotSem; ?></td>
																	<td><?php echo round($creditSem,0); ?></td>
																	<td>&nbsp;</td>
																</tr>
																<?php
																if (isset($_GET["ajouterEC"]) and $tb_semestre["idSem"]==$_GET["sem"]) {
																	?>
																	<form action="" method="post" name="formProgramEC" >
																		<input name="idSem" type="hidden"  value="<?php echo $tb_semestre["idSem"]; ?>">
																		<input name="promoOrg" type="hidden"  value="<?php echo $idPromoOrgV; ?>">
																		<input name="opOrg" type="hidden"  value="<?php echo $idOpOrgV; ?>">
																		<input name="anAca" type="hidden"  value="<?php echo $an_aca; ?>">
																		<tr>
																			<td colspan="2">
																				<select name="idCours" style="width:100%;" >
																					<option value="">Sel&eacute;ctionner l'&eacute;l&eacute;ment</option>
																					<?php 
																						$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' ORDER BY designUE "; 
																						if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
																							if($exe_rqt_slct_ue->num_rows>0){
																								while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {
																									$rqt_cours_a_prog = "select * from  tb_cours WHERE idUE = '".$tb_ue["idUE"]."' and idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designCours ";//COURS 
																									if($exe_rqt_cours_a_prog = $conDb->query($rqt_cours_a_prog)){
																										if($exe_rqt_cours_a_prog->num_rows>0){
																											while($result_rqt_cours_a_prog = $exe_rqt_cours_a_prog->fetch_assoc()){
																												$rqt_tb_program_cours = "SELECT * FROM  tb_program_cours WHERE idCours = '".$result_rqt_cours_a_prog["idCours"]."' and idAnAca='".$an_aca."'";
																												if($tb_program_cours = $conDb->query($rqt_tb_program_cours)){
																													if($tb_program_cours->num_rows<=0){
																														echo "<option value='".$result_rqt_cours_a_prog["idCours"]."'>".$result_rqt_cours_a_prog["designCours"]."</option>";
																													}
																												}
																												else{
																													echo "<option value=''>Erreur de vérification EC</option>";
																												}
																											}
																										}
																										else{
																											//echo "<option value=''>Aucun cours trouv&eacute;</option>";
																										} 
																									}
																									else{
																										echo "<option value=''>Erreur lors de sel&eacute;ction des cours</option>";
																									}
																								}
																							}
																							else{
																								echo "<option value=''>Pas d'UE</option>";
																							}
																						}
																						else{
																							echo "<option value=''>Erreur lors de sel&eacute;ction des UE</option>";
																						}
																					?>
																				</select>
																			</td>
																			<td>
																				<input name="ht" type="text" size="2" onchange="valht(this.value)">
																			</td>
																			<td>
																				<input name="hd" type="text" size="2" onchange="valhd(this.value)">
																			</td>
																			<td>
																				<input name="hp" type="text" size="2" onchange="valhp(this.value)" >
																			</td>
																			<td>
																				<input name="htot" type="text" size="2" disabled="disabled" >
																			</td>
																			<td>
																				<input name="credit" type="text" size="2" disabled="disabled" >
																			</td>
																			<td>
																				<input name="BtProgramEC" type="submit" value="Programmer" style="width:100%;">
																			</td>
																		</tr>
																	</form>			
																	<?php
																}
																else{
																	?>
																	<tr>
																		<td colspan="8" style="color:#666666; font-size:18px;" align="center">
																			<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&pRograMe&ajouterEC&sem=".$tb_semestre["idSem"]."#".$tb_semestre["idSem"] ?>">Programmer un élément</a> 
																		</td>
																	</tr>
																	<?php
																}
															}
															else{
																echo "Aucune unit&eacute; d'enseignement trouvr&eacute;e";
															}
														}
														else{
															echo "Erreur lors de r&eacute;cup&eacute;ration des unit&eacute;s d'enseignement";
														}
													?>
												</table>
											</div>
											<?php 
										}
										?>
										<br>
										<table width="100%" border="1" cellpadding="1" cellspacing="0">
											<tr>
												<td colspan="5">
												 <div align="center">TOTAL HEURE ET CREDIT ANNUEL</div>
												</td>
											</tr>
											<tr style="text-align:center;font-weight:bold;">
												<td >HT</td>
												<td >HD</td>
												<td >HP</td>
												<td >TOT.</td>
												<td >CREDIT.</td>
											</tr>
											<tr style="text-align:center;font-weight:bold;">
												<td><?php echo $htAnnuel; ?></td>
												<td><?php echo $hdAnnuel; ?></td>
												<td><?php echo $hpAnnuel; ?></td>
												<td><?php echo $htotAnnuel; ?></td>
												<td><?php echo round($creditAnnuel,0); ?></td>
											</tr>
										</table>
										<?php 
											if(($_SESSION['idAnAca'] != $an_aca) and ($ue_ec!=false)){
												?>
												<a href="<?php echo $url_Act."&aca=".$an_aca."&reutilProgram=".$an_aca."&pourProgram=".$_SESSION['idAnAca']; ?>">
													<div style="float: right; background:#003858;color: #fff; margin: 30px; padding: 20px;border-radius: 12px;">
														Reutiliser pour <?php echo $_SESSION['idAnAca']; ?>
													</div>	
												</a>		
												<?php 
											} 
										?>
										
										
										<?php
									}
								?>

							</div>
							<div class="ListeCours">
								<?php 
								include("B_mbindi/Cours/f_ajouter_cours.php"); 
								include("B_mbindi/Cours/rqt_list_cours.php");
								?>
							</div>
						</td>
					</tr>
				</table>
				
			</div>				
			<?php 
		}
	}
?>