<?php 
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['pRograMe'])){
		
		/* ------------------------------------------------------
			Ancien Système 
			-------------------------------------------------- */		
		if (isset($_POST['BtProgramCours'])){

			$idPromoProgramV = filter_input(INPUT_POST,'promoOrg', FILTER_SANITIZE_SPECIAL_CHARS);
			$idOpProgramV = filter_input(INPUT_POST,'opOrg', FILTER_SANITIZE_SPECIAL_CHARS);
			$idAanAcaProgramV = filter_input(INPUT_POST,'anAca', FILTER_SANITIZE_SPECIAL_CHARS);
			$idCours = filter_input(INPUT_POST,'idCours', FILTER_SANITIZE_SPECIAL_CHARS);
			$ht = filter_input(INPUT_POST,'ht', FILTER_SANITIZE_SPECIAL_CHARS);
			$hp = filter_input(INPUT_POST,'hp', FILTER_SANITIZE_SPECIAL_CHARS);
			
			if($idPromoProgramV !="" and $idOpProgramV !="" and $idAanAcaProgramV !="" and $idCours !="" and $ht !="" and $hp !="" ){ 
				$rqt_slct_coursProgram = "select * from  tb_program_cours WHERE idCours = '".$idCours."'  AND idPromo ='".$idPromoProgramV."'  AND idOp ='".$idOpProgramV."' AND idAnAca ='".$idAanAcaProgramV."'";//COURS 
				if($exe_rqt_slct_coursProgram = $conDb->query($rqt_slct_coursProgram)){
					if($exe_rqt_slct_coursProgram->num_rows>0){
						$sms_gerer = "<div class='erreur'>Ce cours est d&eacute;j&agrave; programm&eacute;.</div>";
					}
					else{
						//$rqt_ajout_cours_program = "INSERT INTO tb_program_cours VALUES (NULL, '".$idCours."','".$idPromoProgramV."','".$idOpProgramV."','".$ht."','".$hd."','".$hp."','".$idAanAcaProgramV."', NOW())";
						$hd = 0;
						$rqt_ajout_cours_program = "INSERT INTO tb_program_cours VALUES (NULL, '".$idCours."','".$idPromoProgramV."','".$idOpProgramV."','".$ht."', '".$hd."','".$hp."','".$idAanAcaProgramV."', NOW())";
						if($exe_rqt_ajout_cours_program = $conDb->query($rqt_ajout_cours_program))
							{
							$sms_gerer = "<div style='color:#009900'> Cours programm&eacute; avec succ&egrave;s.</div>";
							}
						else
							{
							$sms_gerer = "<div class='erreur'>Impossible de programmer ce cours. veuillez reaisseyer.</div>";
							}
					
					}
				}
				else{
					$sms_gerer = "<div class='erreur'>Erreur lors de v&eacute;rification si ce cours est d&eacute;j&agrave; programm&eacute;.</div>";
				}
			}
			else{
				$sms_gerer = "<div class='erreur'>Les champs sont vide. Veuillez le remplire</div>";
			}
		}
		
		/* ------------------------------------------------------
			Nouveau Système LMD
			-------------------------------------------------- */		
		if (isset($_POST['BtProgramEC'])){
			$idPromoProgramV = filter_input(INPUT_POST,'promoOrg', FILTER_SANITIZE_SPECIAL_CHARS);
			$idOpProgramV = filter_input(INPUT_POST,'opOrg', FILTER_SANITIZE_SPECIAL_CHARS);
			$idAanAcaProgramV = filter_input(INPUT_POST,'anAca', FILTER_SANITIZE_SPECIAL_CHARS);
			$idCours = filter_input(INPUT_POST,'idCours', FILTER_SANITIZE_SPECIAL_CHARS);
			$ht = filter_input(INPUT_POST,'ht', FILTER_SANITIZE_SPECIAL_CHARS);
			$hd = filter_input(INPUT_POST,'hd', FILTER_SANITIZE_SPECIAL_CHARS);
			$hp = filter_input(INPUT_POST,'hp', FILTER_SANITIZE_SPECIAL_CHARS);
			
			if($idPromoProgramV !="" and $idOpProgramV !="" and $idAanAcaProgramV !="" and $idCours !="" and $ht !="" and $hd !="" and $hp !="" ){ 
				$rqt_slct_coursProgram = "select * from  tb_program_cours WHERE idCours = '".$idCours."'  AND idPromo ='".$idPromoProgramV."'  AND idOp ='".$idOpProgramV."' AND idAnAca ='".$idAanAcaProgramV."'";//COURS 
				if($exe_rqt_slct_coursProgram = $conDb->query($rqt_slct_coursProgram)){
					if($exe_rqt_slct_coursProgram->num_rows>0){
						$sms_gerer = "<div class='erreur'>Ce cours est d&eacute;j&agrave; programm&eacute;.</div>";
					}
					else{
						$rqt_ajout_cours_program = "INSERT INTO tb_program_cours VALUES (NULL, '".$idCours."','".$idPromoProgramV."','".$idOpProgramV."','".$ht."','".$hd."','".$hp."','".$idAanAcaProgramV."', NOW())";
						if($exe_rqt_ajout_cours_program = $conDb->query($rqt_ajout_cours_program))
							{
							$sms_gerer = "<div style='color:#009900'> Cours programm&eacute; avec succ&egrave;s.</div>";
							}
						else
							{
							$sms_gerer = "<div class='erreur'>Impossible de programmer ce cours. veuillez reaisseyer.</div>";
							}
					
					}
				}
				else{
					$sms_gerer = "<div class='erreur'>Erreur lors de v&eacute;rification si ce cours est d&eacute;j&agrave; programm&eacute;.</div>";
				}
			}
			else{
				$sms_gerer = "<div class='erreur'>Les champs sont vide. Veuillez le remplire</div>";
			}
		}
	}
?>