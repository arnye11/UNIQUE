<?php 
	if(isset($_POST['BtAjoutUE'])){
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$idUE = filter_input(INPUT_POST,'idUE', FILTER_SANITIZE_SPECIAL_CHARS);
		$designUE = filter_input(INPUT_POST,'designUE', FILTER_SANITIZE_SPECIAL_CHARS);
		$idSem = filter_input(INPUT_POST,'idSem', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if($idUE!="" and $designUE!="" and $idSem!=""){
			$rqt_insrt_ue = "insert into tb_ue values ('".$idUE."','".$designUE."','".$idSem."','".$idPromo."','".$idOp."')";
			if($exe_rqt_insrt_ue = $conDb->query($rqt_insrt_ue)){
				$sms_gerer = "<div style='color:#009900'>Cours ajout&eacute; avec succ&egrave;s.</div>";
			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	}
?>