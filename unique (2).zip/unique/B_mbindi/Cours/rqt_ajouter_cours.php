<?php 
	if(isset($_POST['BtsaveCours'])){
		$idPromoo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOpp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$codCours = filter_input(INPUT_POST,'codCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$designCours = filter_input(INPUT_POST,'designCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$ue = filter_input(INPUT_POST,'ue', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if($codCours!="" and $designCours!=""){
			$rqt_insrt_cours = "insert into tb_cours values ('".$codCours."','".$designCours."','".$ue."','".$idPromoo."','".$idOpp."')";
			if($exe_rqt_insrt_cours = $conDb->query($rqt_insrt_cours)){
				$sms_gerer = "<div style='color:#009900'>Cours ajout&eacute; avec succ&egrave;s.</div>";
			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	}

	
?>