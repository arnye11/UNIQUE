<?php 
//<- rqt
// -> attribution_cours

	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['atTribuEr']) and isset($_POST['BtAttCours'])){

		$idCours = filter_input(INPUT_POST,'idCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$promoOrg = filter_input(INPUT_POST,'promoOrg', FILTER_SANITIZE_SPECIAL_CHARS);
		$opOrg = filter_input(INPUT_POST,'opOrg', FILTER_SANITIZE_SPECIAL_CHARS);
		$anAca = filter_input(INPUT_POST,'anAca', FILTER_SANITIZE_SPECIAL_CHARS);
		$idEns = filter_input(INPUT_POST,'idEns', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if($idCours !="" and $promoOrg !="" and $opOrg !="" and $anAca !="" and $idEns !="" ){ 
			$rqt_slct_coursAttrib = "SELECT * FROM  tb_attribution WHERE idCours = '".$idCours."' AND idPromo ='".$promoOrg."'  AND idOp ='".$opOrg."' AND idAnAca ='".$anAca."'";//COURS 
			if($exe_rqt_slct_coursAttrib = $conDb->query($rqt_slct_coursAttrib)){
				if($exe_rqt_slct_coursAttrib->num_rows>0){
					$sms_gerer = "<div class='erreur'>Ce cours d&eacute;j&agrave; attribu&eacute; &agrave; un enseignant.</div>";
				}
				else{
					$rqt_ajout_cours_Attrib = "INSERT INTO tb_attribution VALUES (NULL, '".$idCours."','".$idEns."','".$promoOrg."','".$opOrg."','".$anAca."', NOW())";
					if($exe_rqt_ajout_cours_Attrib = $conDb->query($rqt_ajout_cours_Attrib)){
						$sms_gerer = "<div style='color:#009900'> Cours attribu&eacute; avec succ&egrave;s.</div>";
					}
					else{
						$sms_gerer = "<div class='erreur'>Impossible d'attribuer ce cours. veuillez reaisseyer.</div>";
					}
				}
			}
			else{
				$sms_gerer = "<div class='erreur'>Erreur lors de v&eacute;rification si ce cours est d&eacute;j&agrave; attribu&eacute;.</div>";
			}
		}
		else{
			$sms_gerer = "<div class='erreur'>Les champs sont vide. Veuillez le remplire</div>";
		}

	}
?>