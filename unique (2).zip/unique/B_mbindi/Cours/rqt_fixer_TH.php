<?php 
	if(isset($_POST['btFixerTH'])){
		$idGrad = filter_input(INPUT_POST,'idGrad', FILTER_SANITIZE_SPECIAL_CHARS);
		$idFac = filter_input(INPUT_POST,'idFac', FILTER_SANITIZE_SPECIAL_CHARS);
		$montantTh = filter_input(INPUT_POST,'montantTh', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if($idGrad!="" and $idFac!="" and $montantTh!=""){
			$rqt_slct_th = "SELECT * FROM tb_taux_horaire WHERE idGrad ='".$idGrad."' AND idFac='".$idFac."' AND idAnAca = '".$an_aca."'";
			if ($exe_rqt_slct_th=$conDb->query($rqt_slct_th)) {
				if($exe_rqt_slct_th->num_rows>0) {
					$rqt_updt_th = "UPDATE tb_taux_horaire SET montantTh = '".$montantTh."', dateTh = NOW() WHERE idGrad = '".$idGrad."' AND idAnAca = '".$an_aca."'";
					if($conDb->query($rqt_updt_th)){
						$sms_gerer = "Taux horaire mise à jour";
						header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&tAuxhOraIre&sms_gerer='.$sms_gerer.'');
					}
					else{
						$sms_gerer = "<div style='color:#FF0000'>Echec de mise à jour.</div>";
					}
				}
				else{
					$rqt_insrt_th = "insert into tb_taux_horaire values (NULL,'".$idGrad."','".$montantTh."','".$idFac."','".$an_aca."', NOW())";
					if($conDb->query($rqt_insrt_th)){
						$sms_gerer = "Taux horaire fixé";
						header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&tAuxhOraIre&sms_gerer='.$sms_gerer.'');
					}
					else{
						$sms_gerer = "<div style='color:#FF0000'>Echec.</div>";
					}
				}
			}
					

		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	}
?>