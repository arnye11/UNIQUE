<?php 
	if (isset($_GET['gerer_cours']) || isset($_GET['pRograMe']) xor isset($_GET['listCours'])){?>
		<div align="center" style="width:98%; margin:2px; border:solid 1px #000000;border-radius:12px 12px 0px 0px; ">
			<div align="center" style="background:#999999; border:solid 1px #000000;border-radius:12px 12px 0px 0px; padding:1px; ">
				<div align="center" style="font-size:25px;">Liste de tous les cours</div>
			</div>
			<?php	
				/* ------------------------------------------------------
					Ancient Syst�me GL
					------------------------------------------------------ */		
				if($_SESSION['systPromo']=="A"){
					?>
					<div style="background:#FFFFFF; border:solid 1px #000000; padding:1px;">
						<?php 
						$rqt_list_cours = "SELECT * FROM  tb_cours WHERE idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designCours ";//COURS 
						if($exe_rqt_list_cours = $conDb->query($rqt_list_cours)){?>
							<table width="100%" border="1" style="font-family:Bookman Old Style; font-size:13px; border-collapse: collapse;">
								<tr align="left">
									<td style="font-size:15px;">N&deg;</td>
									<td style="font-size:15px;" >Code</td>
									<td scope="col" style="font-size:15px;">D&eacute;signation</td>
								</tr>
								<?php
								 	if($exe_rqt_list_cours->num_rows>0){
									  $num=0;
										while($tb_cours = $exe_rqt_list_cours->fetch_assoc()){
											$num = $num+1;
											if (isset($_GET['modifCours']) and $_GET['modifCours']==$tb_cours['idCours']){ 
												if(isset($_POST['BtUpdtCours'])){ 
													?>
													<tr align="center" >
														<td colspan="4">
															<?php
																echo $sms_gerer ;
															?>
														</td>
													</tr>
													<?php
												}
												?>
												<tr align="left" style="">
													<td colspan="4" style="border-bottom:solid 1px">
														<div align="center" style="width:100%;">
															<form action="" method="post" name="f_ajout_Cours">	
																<input type="hidden" name="idPromo" value="<?php echo $_GET['pRomotIon']; ?>">
																<input type="hidden" name="idOp" value="<?php echo $_GET['oPtiOn']; ?>">
																<input type="hidden" name="codCours" style="width:12%;" value="<?php echo $tb_cours['idCours']; ?>" >
																<input type="text" style="width:15%;" value="<?php echo $tb_cours['idCours']; ?>" disabled >
																<input type="text" name="designCours" value="<?php echo $tb_cours['designCours']; ?>" style="width:65%;" >
																<input type="submit" name="BtUpdtCours" value="OK" style="width:9%;">
															</form>
														</div>
													</td>
												</tr>
												<?php 
											}
											else{
												?>
												<tr align="left" style="">
													<td scope="col" style="border-bottom:solid 1px">
														<?php echo $num; ?>
													</td>
													<td scope="col" style="border-bottom:solid 1px">
														<?php echo $tb_cours['idCours']; ?>
													</td>
													<td scope="col" style="border-bottom:solid 1px" >
														<?php echo $tb_cours['designCours']; ?>
													</td>
													<td scope="col" style="border-bottom:solid 1px" >
														<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours&modifCours=".$tb_cours["idCours"] ?>">
															<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" /> 
														</a>
													</td>
												</tr>
												<?php 
											}
										}
									}
									else{
										?>
										<tr align="left" style=" color:#CC6666;">
											<td colspan="3" style="border-bottom:solid 1px">
												<?php echo "Aucun cours n'est encore enregistr&eacute;."; ?>
											</td>
										</tr>
										<?php 
									} 
								?>
							</table>
							<div >
								<br/>Pr&eacute;voir un cours dans cette promotion
							</div >
							<div style="color:#003366; font-size:15px;">
								<?php if (isset($_POST['BtsaveCours'])){echo $sms_gerer;} ?>
							</div>
							<div align="center" style="width:100%;">
								<form action="" method="post" name="f_ajout_Cours">	
									<input type="hidden" name="idPromo" value="<?php echo $_GET['pRomotIon']; ?>">
									<input type="hidden" name="idOp" value="<?php echo $_GET['oPtiOn']; ?>">
									<input type="text" name="codCours" style="width:10%;">
									<input type="text" name="designCours" style="width:45%;" >
									<input type="submit" name="BtsaveCours" value="Ajouter" style="width:15%;">
								</form>
							</div>
							<?php 
						}
						else{
							echo  "Impossible d'atteindre les cours organis�s dans cette promotion. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
						}?>
					</div>
					<?php
				}

				/* ------------------------------------------------------
					Nouveau Syst�me LMD
					------------------------------------------------------ */		
				if($_SESSION['systPromo']=="N"){
					$rqt_slct_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem "; 
					if($exe_rqt_slct_Sem = $conDb->query($rqt_slct_Sem)){
						while($tb_semestre = $exe_rqt_slct_Sem->fetch_assoc()) {
							echo "<h2 align='left'>".$tb_semestre["designSem"]."</h2>";
							?>
							<div style="background:#FFFFFF; border:solid 1px #000000; padding:1px;">
								<?php 
									$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' AND idPromo = '".$_SESSION['idPromo']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designUE "; 
									if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
										if($exe_rqt_slct_ue->num_rows>0){
											$num=1;
											?>
											<table border="1" style="width:100%; font-family:Bookman Old Style; font-size:13px; border-collapse: collapse;">
												<tr align="left" style="background: #CCCCCC;text-transform: uppercase;">
													<td style="font-size:15px;">N&deg;</td>
													<td style="font-size:15px;" >Code</td>
													<td style="font-size:15px;" >Unit&eacute; d'enseignement</td>
													<td style="font-size:15px;">El&eacute;ment constitutif</td>
												</tr>
												<?php 
												while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {
													$idUE = $tb_ue['idUE'];
													?>
													<tr id="<?php echo $tb_ue['idUE']; ?>">
														<td ><?php echo $num; ?></td>
														<?php 
															//MODIFICATION UE
															if (isset($_GET['modifUE']) and $_GET['modifUE']==$tb_ue['idUE']){ 
																?>
																<td colspan="2">
																	<?php 
																		if(isset($_POST['BtUpdtUE'])){ 
																			 echo "<div>".$sms_gerer."</div>";
																		} 
																	?>
																	<div align="left" style="width:100%;" >
																		<form action="" method="post">	
																			<input type="hidden" name="idFacult" value="<?php echo $_GET['iDfaC']; ?>" >
																			<input type="hidden" name="idUE" value="<?php echo $tb_ue['idUE']; ?>" >
																			<input type="hidden" name="idPromo" value="<?php echo $_GET['pRomotIon']; ?>">
																			<input type="hidden" name="idOp" value="<?php echo $_GET['oPtiOn']; ?>">
																			<select name="idSem" style="width:25%;" >
																				<option value="<?php echo $tb_semestre['idSem']; ?>"><?php echo $tb_semestre['designSem']; ?></option>
																				<option value=""></option>
																				<?php
																					$rqt_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem ";  
																					if($exe_rqt_Sem = $conDb->query($rqt_Sem)){
																						if($exe_rqt_Sem->num_rows>0){
																							while($tbSem = $exe_rqt_Sem->fetch_assoc()){
																								echo "<option value='".$tbSem["idSem"]."'>";
																								echo $tbSem["designSem"];
																								echo "</option>";
																							}
																						}
																						else{
																							echo "<option value=''>Pas des semestres</option>";
																						} 
																					}
																					else{
																						echo "<option value=''>Erreur</option>";
																					}
																				?>
																			</select>
																			<input type="text" name="designUE" value="<?php echo $tb_ue['designUE']; ?>" style="width:55%;" >
																			<input type="submit" name="BtUpdtUE" value="OK" style="width:30px;">
																		</form>
																	</div>
																</td>
																<?php 
															}
															else{
																?>
																<td ><?php echo $tb_ue['idUE']; ?></td>
																<td >
																	<div style="display:inline-block;float: left;">
																		<?php echo $tb_ue["designUE"]; ?>
																	</div>	
																	<div style="display:inline-block;float: right;">
																		<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours&modifUE=".$tb_ue["idUE"]."#".$idUE; ?>">
																			<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" /> 
																		</a>
																	</div>
																</td>
																<?php 
															}
														?>
														<td>
															<?php 
															$rqt_list_cours = "SELECT * FROM  tb_cours WHERE idUE = '".$tb_ue["idUE"]."' AND idPromo = '".$tb_promotion["idPromo"]."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designCours ";
															if($exe_rqt_list_cours = $conDb->query($rqt_list_cours)){
																if($exe_rqt_list_cours->num_rows>0){
																	$ligne = $exe_rqt_list_cours->num_rows; 
																	while($tb_cours = $exe_rqt_list_cours->fetch_assoc()){
																		//$num = $num+1;

																		if (isset($_GET['modifCours']) and $_GET['modifCours']==$tb_cours['idCours']){ 
																			if(isset($_POST['BtUpdtCours'])){ 
																				 echo "<div>".$sms_gerer."</div>";
																			}
																			?>
																			<div align="center" style="width:100%;" >
																				<form action="" method="post" name="f_ajout_Cours">	
																					<input type="hidden" name="idPromo" value="<?php echo $_GET['pRomotIon']; ?>">
																					<input type="hidden" name="idOp" value="<?php echo $_GET['oPtiOn']; ?>">
																					<input type="hidden" name="codCours" style="width:12%;" value="<?php echo $tb_cours['idCours']; ?>" >
																					<?php
																						// VERIFICATION PROGRAMME_COURS
																						$rqt_program_cours = "SELECT  * FROM tb_program_cours WHERE idCours='".$tb_cours["idCours"]."' AND idPromo ='".$_GET['pRomotIon']."' AND idOp='".$_GET['oPtiOn']."'";
																						if($exe_rqt_program_cours = $conDb->query($rqt_program_cours)){
																							if($exe_rqt_program_cours->num_rows<=0){
																								?>
																								<input type="submit" name="BtSuppEC" value="Supprimer" style="background: #ff0f3e; color:#ffffff; float: left; ">
																								<?php 
																							}
																						}
																						else{echo "Echec";}
																					?>
																					<select name="ue" style="width:30%;" >
																						<option value="<?php echo $tb_ue['idUE']; ?>"><?php echo $tb_ue['designUE']; ?></option>
																						<?php 
																							$rqt_ue = "select * from  tb_ue WHERE idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designUE ";//COURS 
																							if($exe_rqt_ue = $conDb->query($rqt_ue)){
																								if($exe_rqt_ue->num_rows>0){
																									while($tb_ue = $exe_rqt_ue->fetch_assoc()){
																										echo "<option value='".$tb_ue["idUE"]."'>".$tb_ue["designUE"]."</option>";
																									}
																								}
																								else{
																									echo "<option value=''>Pas d'UE</option>";
																								} 
																							}
																							else{
																								echo "<option value=''>Erreur</option>";
																							}
																						?>
																					</select>
																					<input type="text" name="designCours" value="<?php echo $tb_cours['designCours']; ?>" style="width:35%;" >
																					<input type="submit" name="BtUpdtCours" value="OK" style="width:30px;">
																				</form>
																			</div>
																			<?php 
																		}
																		else{
																			?>
																			<table style="width: 100%;">
																				<tr >
																					<td style="border-bottom: solid 1px #000000;">
																						<div style="display:inline-block;float: left;" >
																							<?php echo $tb_cours['designCours']; ?>
																						</div>
																						<div style="display:inline-block;float: right;">
																							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours&modifCours=".$tb_cours["idCours"]."#".$idUE; ?>">
																								<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" /> 
																							</a>
																						</div>			
																					</td>
																				</tr>
																			</table>
																			
																			<?php 
																		}
																	}
																}
																else{
																	?>
																	<div align="left" style=" color:#CC6666;">
																		<?php
																			// VERIFICATION PROGRAMME_COURS
																			if(isset($_GET['modifUE']) and $_GET['modifUE']==$idUE){
																				?>
																				<form method="post">
																					<input type="hidden" name="idUE" value="<?php echo $idUE; ?>" >
																					<input type="submit" name="BtSuppUE" value="Supprimer" style="background: #ff0f3e; color:#ffffff; float: left;margin-right: 6px; ">
																				</form>
																				
																				<?php 
																			}
																			else{
																				echo "Aucun &eacute;l&eacute;ment constitutif n'est encore enregistr&eacute;."; 
																				?>
																				<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours&modifUE=".$idUE."#".$idUE; ?>" style="float: right;">
																					<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" /> 
																				</a>
																				<?php 
																			}
																		?>
																	</div>
																	<?php 
																}
															}
															else{
																echo  "Impossible de trouver les &eacute;l&eacute;ment organis�s dans cette promotion. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
															}
															?>
														</td>
													</tr>
													<?php
													$num = $num+1;
												} 
												?>
												
											</table>
											<?php
										}
										else{
											echo "Aucune unit&eacute; d'enseignement trouvr&eacute;e";
										}
									}
									else{
										echo "Erreur lors de r&eacute;cup&eacute;ration des unit&eacute;s d'enseignement";
									}
								?>
								
							</div>				
							<?php 
						}
					}
					?>
					<div >
						<br/>Pr&eacute;voir un &eacute;l&eacute;ment constitutif dans cette promotion
					</div >
					<div style="color:#003366; font-size:15px;">
						<?php if (isset($_POST['BtsaveCours'])){echo $sms_gerer;} ?>
					</div>
					<div align="center" style="width:100%;">
						<form action="" method="post" name="f_ajout_Cours">	
							<input type="hidden" name="idPromo" value="<?php echo $_GET['pRomotIon']; ?>">
							<input type="hidden" name="idOp" value="<?php echo $_GET['oPtiOn']; ?>">
							<input type="text" name="codCours" style="width:10%;">
							<input type="text" name="designCours" style="width:45%;" >
							<select name="ue" style="width:20%;" >
								<option value="">UE</option>
								<?php 
									$rqt_ue = "select * from  tb_ue WHERE idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designUE ";//COURS 
									if($exe_rqt_ue = $conDb->query($rqt_ue)){
										if($exe_rqt_ue->num_rows>0){
											while($tb_ue = $exe_rqt_ue->fetch_assoc()){
												echo "<option value='".$tb_ue["idUE"]."'>".$tb_ue["designUE"]."</option>";
											}
										}
										else{
											echo "<option value=''>Pas d'UE</option>";
										} 
									}
									else{
										echo "<option value=''>Erreur</option>";
									}
								?>
							</select>
							<input type="submit" name="BtsaveCours" value="Ajouter" style="width:15%;">
						</form>
					</div>
					<div align="center">
						<p>
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours&AjoutUE#fue" ?>">Aujouter une UE</a> 
						</p>
						<p>
						<?php include("B_mbindi/Cours/formAjoutUE.php"); ?>
						</p>
					</div>

					<!-- 
						---------------------------------------------------------
						ELEMENTS SANS UNITES D'ENSEINEMENT
						---------------------------------------------------------
					-->
					<div style="background:#FFFFFF; border:solid 1px #000000; padding:1px;">
						<?php 
						$rqt_list_cours = "SELECT * FROM  tb_cours WHERE idUE = '' AND idPromo = '".$tb_promotion["idPromo"]."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designCours ";//COURS 
						if($exe_rqt_list_cours = $conDb->query($rqt_list_cours)){?>
							<table width="100%" border="1" style="font-family:Bookman Old Style; font-size:13px; border-collapse: collapse;">
							  <tr align="left">
								<td style="font-size:15px; background: #000000; color:#FFFFFF; text-align: center; text-transform: uppercase;" colspan="4">
									El&eacute;ment sans Unit&eacute; d'enseignement
								</td>
							  </tr>
							  <tr align="left">
								<td style="font-size:15px;">N&deg;</td>
								<td style="font-size:15px;" >Unit&eacute; d'enseignement</td>
								<td scope="col" style="font-size:15px;">El&eacute;ment de l'UE</td>
								<td ></td>
							  </tr>
							  <?php
							  if($exe_rqt_list_cours->num_rows>0){
								  $num=0;
									while($tb_cours = $exe_rqt_list_cours->fetch_assoc()){
										$num = $num+1;
										if (isset($_GET['modifCours']) and $_GET['modifCours']==$tb_cours['idCours']){ 
											if(isset($_POST['BtUpdtCours'])){ 
												?>
												<tr align="center" >
													<td colspan="4">
														<?php
															echo $sms_gerer ;
														?>
													</td>
												</tr>
												<?php
												}
												?>
											<tr align="left" id="<?php echo $tb_cours["idCours"]; ?>">
												<td colspan="4" style="border-bottom:solid 1px">
													<div align="center" style="width:100%;">
														<form action="" method="post" name="f_ajout_Cours">	
															<input type="hidden" name="idPromo" value="<?php echo $_GET['pRomotIon']; ?>">
															<input type="hidden" name="idOp" value="<?php echo $_GET['oPtiOn']; ?>">
															<input type="hidden" name="codCours" style="width:12%;" value="<?php echo $tb_cours['idCours']; ?>" >
															<select name="ue" style="width:20%;" >
																<option value="">UE</option>
																<?php 
																	$rqt_ue = "select * from  tb_ue WHERE idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' ORDER BY designUE ";//COURS 
																	if($exe_rqt_ue = $conDb->query($rqt_ue)){
																		if($exe_rqt_ue->num_rows>0){
																			while($tb_ue = $exe_rqt_ue->fetch_assoc()){
																				echo "<option value='".$tb_ue["idUE"]."'>".$tb_ue["designUE"]."</option>";
																			}
																		}
																		else{
																			echo "<option value=''>Pas d'UE</option>";
																		} 
																	}
																	else{
																		echo "<option value=''>Erreur</option>";
																	}
																?>
															</select>
															<input type="text" name="designCours" value="<?php echo $tb_cours['designCours']; ?>" style="width:65%;" >
															<input type="submit" name="BtUpdtCours" value="OK" style="width:9%;">
														</form>
													</div>
												</td>
											</tr>
											<?php 
										}
										else{
											?>
											<tr align="left" style="" >
												<td scope="col" style="border-bottom:solid 1px">
													<?php echo $num; ?>
												</td>
												<td scope="col" style="border-bottom:solid 1px">
													<?php echo $tb_cours['idUE']; ?>
												</td>
												<td scope="col" style="border-bottom:solid 1px" >
													<?php echo $tb_cours['designCours']; ?>
												</td>
												<td scope="col" style="border-bottom:solid 1px" >
													<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&listCours&modifCours=".$tb_cours["idCours"]."#".$tb_cours["idCours"]; ?>">
														<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" /> 
													</a>
												</td>
											</tr>
											<?php 
										}
									}
								}
								else{
									?>
									<tr align="left" style=" color:#CC6666;">
										<td colspan="3" style="border-bottom:solid 1px"><?php echo "Aucun cours n'est encore enregistr&eacute;."; ?></td>
									</tr>
									<?php 
								} ?>
									
							</table>
							
							<?php 
						}
						else{
							echo  "Impossible d'atteindre les cours organis�s dans cette promotion. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
						}?>
					</div>				
					
					<?php 
				}	
			?>
		</div>
	<?php 
	}
?>
