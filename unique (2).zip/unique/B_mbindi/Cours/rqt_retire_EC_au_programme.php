<!-- 
dans rqt.php 

-->
<?php 
	if (isset($_POST['BtRetierECProgram'])){
		$idCours = filter_input(INPUT_POST,'idCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$anAca = filter_input(INPUT_POST,'anAca', FILTER_SANITIZE_SPECIAL_CHARS);
		$ht = filter_input(INPUT_POST,'ht', FILTER_SANITIZE_SPECIAL_CHARS);
		$hp = filter_input(INPUT_POST,'hp', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if ($_GET['iDcOurs'] != ""){
			$rqt_sup_cours_attrib = "DELETE FROM tb_program_cours WHERE idCours =  '".$idCours."' AND idPromo = '".$idPromo."' AND idOp = '".$idOp."' AND idAnAca = '".$an_aca."'";
			if($exe_rqt_sup_cours_attrib = $conDb->query($rqt_sup_cours_attrib)){
				$sms_gerer = "EC retiré avec succès.";
				header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&pRograMe&sms_gerer='.$sms_gerer.'');
			}
			else{
				$sms_gerer = "<span class='erreur'> Impossible de retirer ce cours.</span>";
			}
		}
		else{
			$sms_gerer = "<span class='erreur'>Cours indique inconnu.</span>";
		}

	}

?>