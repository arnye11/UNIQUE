<!-- 
dans rqt.php 

-->
<?php 
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['atTribuEr']) and isset($_GET['rEtireRetTrib']) and isset($_GET['iDcOurs'])){
	
		if ($_GET['iDcOurs'] != ""){
			$rqt_sup_cours_attrib = "DELETE FROM tb_attribution WHERE idCours =  '".$_GET['iDcOurs'] ."' AND idPromo = '".$_GET['pRomotIon']."' AND idOp = '".$_GET['oPtiOn']."' AND idAnAca = '".$an_aca."'";
			if($exe_rqt_sup_cours_attrib = $conDb->query($rqt_sup_cours_attrib)){
				$sms_gerer = "Le cours est retire.";
				header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&atTribuEr&sms_gerer='.$sms_gerer.'');
			}
			else{
				$sms_gerer = "<span class='erreur'> Impossible de retirer ce cours.</span>";
			}
		}
		else{
			$sms_gerer = "<span class='erreur'>Cours indique inconnu.</span>";
		}

	}

?>