<?php 
if ((isset($_GET['gerer_cours']) and isset($_GET['modifier_cours'])) and !isset($_GET['cours']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Modifier un Cours </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
						$rqt_list_cours = "select * from tb_cours ORDER BY designCours";//COURS 
						if($exe_rqt_list_cours = $conDb->query($rqt_list_cours))
							{
							 ?>
								<div align="center" style="width:98%; border:solid 1px #000000;border-radius:12px 12px 0px 0px; margin:1px;">
								<div align="center" style="background:#999999; border:solid 1px #000000;border-radius:12px 12px 0px 0px; padding:1px;">
									<div align="center" style="font-size:25px;">
									<?php
									echo "Liste des cours";
									//echo "Cours$result_rqt_list_cours['designCours'];
									?>
									</div>
								</div>			
								<div style="background:#FFFFFF; border:solid 1px #000000; padding:1px;">
								<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
								  
								  <tr align="left">
									<td scope="col" style="font-size:15px;">N&deg;</td>
									<td scope="col" style="font-size:15px;">Code</td>
									<td scope="col" style="font-size:15px;">D&eacute;signation</td>
									<td scope="col" style="font-size:15px;">Action</td>
								  </tr>
								  <?php 
									if($exe_rqt_list_cours->num_rows>0){
										$num=0;
										while($result_rqt_list_cours = $exe_rqt_list_cours->fetch_assoc()){
											$num+=1;?>
											<tr align="left" style="">
												<td scope="col" style="border-bottom:solid 1px"><?php echo $num; ?></td>
												<td scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_cours['idCours']; ?></td>
												<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_cours['designCours']; ?></th>
												<th scope="col" style="border-bottom:solid 1px">
												<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_cours&modifier_cours&cours=<?php echo $result_rqt_list_cours['idCours']; ?>">Modif.</a>
												</th>
											</tr>
											<?php 
										} 
									}
									else{
										?>
										<tr align="left" style="">
											<td colspan="4" style="border-bottom:solid 1px"><?php echo "Aucun cours n'est encore enregistr&eacute;."; ?></td>
										</tr>
										<?php 
									}?>
								</table>
								</div>
								</div><br/>
								<?php 
							}
						else
							{
							echo  "Impossible d'atteindre les cours organis�s dans cette promotion. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
							}

	}


?>