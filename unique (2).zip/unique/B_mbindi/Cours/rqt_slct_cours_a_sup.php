<?php 
if (isset($_GET['gerer_cours']) and isset($_GET['sup_cours']) || (isset($_GET['cours']) and !isset($_GET['modifier_cours'])))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Supprimer un Cours </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";

	$rqt_list_cours = "select * from  tb_cours ORDER BY designCours ";//COURS 
	if($exe_rqt_list_cours = $conDb->query($rqt_list_cours))
		{
		 ?>
			<div align="center" style="width:98%; margin:2px; border:solid 1px #000000;border-radius:12px 12px 0px 0px; ">
			<div align="center" style="background:#999999; border:solid 1px #000000;border-radius:12px 12px 0px 0px; padding:1px; ">
				<div align="center" style="font-size:25px;">Liste des cours</div>
			</div>			
			<div style="background:#FFFFFF; border:solid 1px #000000; padding:1px;">
			<table width="100%" border="0" style="font-family:Bookman Old Style; font-size:13px;">
			  
			  <tr align="left">
				<td scope="col" style="font-size:15px;">Code</th>
				<td scope="col" style="font-size:15px;">D&eacute;signation</th>
				<td scope="col" style="font-size:15px;">Action</th>
			  </tr>
			  <?php 
				if($exe_rqt_list_cours->num_rows>0){
					while($result_rqt_list_cours = $exe_rqt_list_cours->fetch_assoc()){?>
						<tr align="left" style="">
							<td scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_cours['idCours']; ?></td>
							<td scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_cours['designCours']; ?></td>
							<td scope="col" style="border-bottom:solid 1px">
							<?php 
							$rqt_slct_idcours_cote = "select * from tb_cote where idCours = '".$result_rqt_list_cours['idCours']."'";
							if($exe_rqt_slct_idcours_cote = $conDb->query($rqt_slct_idcours_cote))
								{
								if($result_exe_rqt_slct_idcours_cote = $exe_rqt_slct_idcours_cote->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
									{
									echo "!";
									}
								else
									{
											?>
									<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_cours&sup_cours&cours=<?php echo $result_rqt_list_cours['idCours']; ?>"><img src='B_mbidndi/Biamunda/icon/trash01.ico' class="icon" />Sup.</a>
									<?php 
									}
								}
							?>
							</td>
						</tr>
						<?php 
					} 
				}
				else{
					?>
					<tr align="left" style="">
						<td colspan="3" style="border-bottom:solid 1px"><?php echo "Aucun cours n'est encore enregistr&eacute;."; ?></td>
					</tr>
					<?php 
				} ?>
			</table>
			</div>
			</div>
			<br/>
			<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les cours organis�s dans cette promotion. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
							}
	}


?>