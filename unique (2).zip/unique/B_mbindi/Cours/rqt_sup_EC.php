<!-- 
dans rqt.php 

-->
<?php 
	if (isset($_POST['BtSuppEC'])){
		$idCours = filter_input(INPUT_POST,'codCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$ue = filter_input(INPUT_POST,'ue', FILTER_SANITIZE_SPECIAL_CHARS);
		
		$rqt_sup_cours_attrib = "DELETE FROM tb_cours WHERE idCours =  '".$idCours."' AND idPromo = '".$idPromo."' AND idOp = '".$idOp."' AND idUE = '".$ue."'";
		if($exe_rqt_sup_cours_attrib = $conDb->query($rqt_sup_cours_attrib)){
			$sms_gerer = "EC retiré avec succès.";
			header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&listCours&sms_gerer='.$sms_gerer.'');
		}
		else{
			$sms_gerer = "<span class='erreur'> Impossible de retirer ce cours.</span>";
		}
		

	}

?>