<!-- 
dans rqt.php
-->
<?php 
	if (isset($_POST['BtSuppUE'])){
		$idUE = filter_input(INPUT_POST,'idUE', FILTER_SANITIZE_SPECIAL_CHARS);
		if ($idUE!="") {
			$rqt_sup_ue = "DELETE FROM tb_ue WHERE idUE = '".$idUE."'";
			if($exe_rqt_sup_ue = $conDb->query($rqt_sup_ue)){
				$sms_gerer = "UE supprimée avec succès.";
				header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&listCours&sms_gerer='.$sms_gerer.'');
			}
			else{
				$sms_gerer = "<span class='erreur'> Impossible de retirer ce cours.</span>";
			}
		}
	}

?>