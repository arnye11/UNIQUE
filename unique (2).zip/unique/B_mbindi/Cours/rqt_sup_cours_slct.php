<?php 
if (isset($_GET['gerer_cours']) and isset($_GET['sup_cours']) and isset($_GET['cours']))
	{ 
	$cours = $_GET['cours'];
	if ($cours != "")
		{
		//verification si une option est enregistr�e avec son id
		$rqt_slct_idcours_cote = "select * from tb_cote where idCours = '".$cours."'";
		if($ex_rqt_slct_idcours_cote = $conDb->query($rqt_slct_idcours_cote))
			{
			 if($result_rqt_slct_idcours_cote = $ex_rqt_slct_idcours_cote->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
				{
				$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/w95mbx03.ico' />&nbsp;Vous n'avez pas les droits de supprimer ce cours. Nous vous recommandons de contacter l'Administrateur.</div>";
				}
			else
				{
				$rqt_sup_cours_slct = "DELETE FROM tb_cours WHERE idCours =  '".$cours."'";
				if($exe_rqt_sup_cours_slct = $conDb->query($rqt_sup_cours_slct))
					{
					$sms_gerer = "<div style='color:#009900'><img src='B_mbindi/Biamunda/icon/info.ico' />&nbsp;&nbsp;Le cours a �t� supprim� avec succ�s.</div>";
					}
				else
					{
					$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' /> Impossible de supprimer le cours indiqu�e. Contacter d'urigence l'Administrateur pour trouver solution � ce probl�me. </div>";
					}
				}
			}
		else
			{
			$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' />Impossible de supprimer cette facult� parce que nous avons eu du mal � v�rifier les options organis�e dans celle-ci. d'urigence, consultez l'Administrateur pour trouver solution � ce probl�me.</div>";
			}	
		}
	else
		{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' />Vous n'avez pas indiqu� la fault� � Supprimer</div>. &nbsp;<a href='?gerer_departement&sup_dep'>Reaisseyez</a> ";
		}
				

	}

?>