<?php 
	if(isset($_POST['BtUpdtCours'])){
		$idPromoo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOpp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$codCours = filter_input(INPUT_POST,'codCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$designCours = filter_input(INPUT_POST,'designCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$ue = filter_input(INPUT_POST,'ue', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if(($ue!="" or $codCours!="") and $designCours!=""){
			$rqt_updt_cours = "";
			if ($_SESSION['systPromo']=="A") {
				$rqt_updt_cours = "UPDATE tb_cours  SET designCours = '".$designCours."' WHERE idCours = '".$codCours."' AND idPromo = '".$idPromoo."' AND idOp = '".$idOpp."'";
			}
			if ($_SESSION['systPromo']=="N") {
				$rqt_updt_cours = "UPDATE tb_cours  SET designCours = '".$designCours."', idUE = '".$ue."' WHERE idCours = '".$codCours."' AND idPromo = '".$idPromoo."' AND idOp = '".$idOpp."'";
			}

			if($exe_rqt_updt_cours = $conDb->query($rqt_updt_cours)){
				$sms_gerer = "<div style='color:#009900'>Cours modifi&eacute; avec succ&egrave;s.</div>";
				header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&listCours');

			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	}
?>