<?php 
	///________UPDT UNITE D'ENSEIGNEMENT___________
	if (isset($_GET['modifUE']) and isset($_POST['BtUpdtUE'])){ 
		$idFacult = filter_input(INPUT_POST,'idFacult', FILTER_SANITIZE_SPECIAL_CHARS);
		$idUE = filter_input(INPUT_POST,'idUE', FILTER_SANITIZE_SPECIAL_CHARS);
		$designUE = filter_input(INPUT_POST,'designUE', FILTER_SANITIZE_SPECIAL_CHARS);
		$idSem = filter_input(INPUT_POST,'idSem', FILTER_SANITIZE_SPECIAL_CHARS);
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if ($idUE != "" and $designUE !=""){
			$rqt_updt_UE = "UPDATE tb_ue  SET designUE='".$designUE."', idSem = '".$idSem."' WHERE idUE='".$idUE."'";
			if($exe_rqt_updt_cours = $conDb->query($rqt_updt_UE)){
				$sms_gerer = "<div style='color:#009900'>Cours modifi&eacute; avec succ&egrave;s.</div>";
				header('location:?fAculTe&iDfaC='.$idFacult.'&pRomotIon='.$idPromo.'&oPtiOn='.$idOp.'&cOuRs&listCours');
			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
		else{
			$sms_gerer = "Veuillez remplir tous les champs ou <a href='?gerer_cours&modifier_cours'>Reaisseyer</a> ";
		}
	}
?>