<!-- 
dans rqt* 
pour form modifier cours du programme qui est dans programme_cours*
--> 

<?php 
	if(isset($_POST['BtModifierCoursProgram'])){ 
		if ($_SESSION['systPromo']=="A"){
			$idCours = filter_input(INPUT_POST,'idCours', FILTER_SANITIZE_SPECIAL_CHARS);
			$promoOrg = filter_input(INPUT_POST,'promoOrg', FILTER_SANITIZE_SPECIAL_CHARS);
			$opOrg = filter_input(INPUT_POST,'opOrg', FILTER_SANITIZE_SPECIAL_CHARS);
			$anAca = filter_input(INPUT_POST,'anAca', FILTER_SANITIZE_SPECIAL_CHARS);
			$ht = filter_input(INPUT_POST,'ht', FILTER_SANITIZE_SPECIAL_CHARS);
			$hp = filter_input(INPUT_POST,'hp', FILTER_SANITIZE_SPECIAL_CHARS);
		
			if (($ht != "") and ($hp !="")){
				$rqt_updt_cours_program = "UPDATE tb_program_cours  SET ht = '".$ht."', hp = '".$hp."' WHERE idCours = '".$idCours."' AND idPromo = '".$promoOrg."' AND idOp = '".$opOrg."' AND idAnAca = '".$anAca."'";
				if($exe_rqt_updt_cours_program = $conDb->query($rqt_updt_cours_program)){
					$sms_gerer = "Les informations du cours sont modifiees.";
					header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&pRograMe&sms_gerer='.$sms_gerer.'');
				}
				else{
					$sms_gerer = "<span class='erreur'> Impossible de mettre &agrave; jour ce cours.</span>";
				}
			}
			else{
				$sms_gerer = "<span class='erreur'>Veuillez remplir tous les champs.</span>";
			}
		}
	}
	
	if(isset($_POST['BtModifierECProgram'])){ 	
		if ($_SESSION['systPromo']=="N"){
			$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
			$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
			$anAca = filter_input(INPUT_POST,'anAca', FILTER_SANITIZE_SPECIAL_CHARS);
			$idCours = filter_input(INPUT_POST,'idCours', FILTER_SANITIZE_SPECIAL_CHARS);
			$ht = filter_input(INPUT_POST,'ht', FILTER_SANITIZE_SPECIAL_CHARS);
			$hd = filter_input(INPUT_POST,'hd', FILTER_SANITIZE_SPECIAL_CHARS);
			$hp = filter_input(INPUT_POST,'hp', FILTER_SANITIZE_SPECIAL_CHARS);
			
			if($ht !="" and $hd !="" and $hp !="" ){
				$rqt_updt_cours_program = "UPDATE tb_program_cours  SET ht = '".$ht."', hd = '".$hd."', hp = '".$hp."' WHERE idCours = '".$idCours."' AND idPromo = '".$idPromo."' AND idOp = '".$idOp."' AND idAnAca = '".$anAca."'";
				if($exe_rqt_updt_cours_program = $conDb->query($rqt_updt_cours_program)){
					$sms_gerer = "les heures de cet élément sont modifiees.";
					header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOuRs&pRograMe&iDcOurs='.$idCours.'&sms_gerer='.$sms_gerer.'');
				}
				else{
					$sms_gerer = "<span class='erreur'> Impossible de mettre &agrave; jour cet Elément.</span>";
				}
			}
			else{
				$sms_gerer = "<span class='erreur'>Veuillez à bien remplir tous les champs.</span>";
			} 
		}
	}

?>