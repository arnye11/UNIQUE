<?php 
//dans cours.php

	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['cOuRs'])and isset($_GET['tAuxhOraIre'])){
		?>
		<div >
			<div>
				<div align="center">
					<h3>
						TAUX HORAIRE : <?php echo $an_aca;?> 
					</h3>
					<?php 
						if(isset($_POST['btFixerTH'])){
							echo $sms_gerer;
						}
					?>
				</div>
				<div align="center">
					<table cellpadding="2" cellspacing="0" border="1" >
						<tr>
							<td>GRADE</td>
							<td>TAUX HORAIRE</td>
							<td>Fixer</td>
						</tr>
						<?php 
							$rqt_grad = "SELECT  * FROM tb_grade ORDER BY idGrad DESC";
							if($exe_rqt_grad = $conDb->query($rqt_grad)){
								if($exe_rqt_grad->num_rows>0){
									$num=0;
									while($tb_grad = $exe_rqt_grad->fetch_assoc()){ 
										?>
										<tr>
											<td>
												<?php echo $tb_grad["idGrad"];?>
											</td>
											<?php  
												$montantTh=0;
												$idTh = "";
												$rqt_th = "SELECT  * FROM tb_taux_horaire WHERE idGrad = '".$tb_grad["idGrad"]."' AND idFac = '".$_GET['iDfaC']."' AND idAnAca = '".$an_aca."'";
												if($exe_rqt_th = $conDb->query($rqt_th)){
													if($tb_th = $exe_rqt_th->fetch_assoc()){ 
														$montantTh=$tb_th["montantTh"];
														$idTh = $tb_th["idTh"];
													}
													
												}
												else{
													 $montantTh=0.0;
													 $idTh = "0";
												}
												 
												if (isset($_GET["modIfTh"]) and $_GET["modIfTh"]==$tb_grad["idGrad"]) {
													?>
													<td align="right" colspan="2">
														<form method="post">
															<input type="hidden" name="idGrad" value="<?php echo $tb_grad["idGrad"]; ?>">
															<input type="hidden" name="idFac" value="<?php echo $_GET['iDfaC']; ?>">
															<input type="text" name="montantTh" value="<?php echo $montantTh; ?>">
															<input type="submit" name="btFixerTH" value="Fixer">
														</form>
													</td>
													<?php 
												}
												else{												
													?>
													<td align="right"><?php echo $montantTh; ?></td>
													<td align="right">
														<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOuRs&tAuxhOraIre&modIfTh=".$tb_grad["idGrad"]; ?>">
															<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" style="margin-left:10px;"/> 
														</a>
													</td>
													<?php  
												}
											?>
										</tr>
									<?php
									}
								}
								else{
									?>
									<tr>
										<td colspan="3">
											<?php echo "Pas des grades";?>
										</td>
									</tr>
								<?php
								}
							}
							else{
								?>
								<tr>
									<td colspan="3">
										<?php echo "Erreur de la rqt";?>
									</td>
								</tr>
								<?php
							}
						?>
						
						
					</table>
				</div> 
			</div>
		</div>
		<?php 
	}
?>