<div style="width:100%; height:auto;">
	

<?php 
	if (isset($_GET["imPRessIoN"])){
		include("B_mbindi/Impression/recu.php");
		include("B_mbindi/Impression/liste_etudiantsParPromotion.php");
		include("B_mbindi/Impression/impression_liste_presence_etudiant.php");
		include("B_mbindi/profilEtudiant/carte_etudiant.php");
		include("B_mbindi/pue/grille/grille_de_deliberation.php"); 
		include("B_mbindi/pue/pv/pv.php");
		include("B_mbindi/pue/releve/releve_des_cotes.php");
		include("B_mbindi/pue/palmares/palmares.php");
		include("B_mbindi/pue/fiche_cote/fichiers_de_cotation.php");
		include("B_mbindi/Inscription/fiche_cotation_standard.php");
		include("B_mbindi/makuta/frais_situation_gene_promo.php");
		include("B_mbindi/Cours/attribution_cours_Fac.php");
		include("B_mbindi/pue/palmares/palmares_LMD_FAC.php"); 
		?>
		<div  align="center" style="width:90px;height:33px; border-radius:50px; position:fixed; top:auto; bottom:0%; left:auto; right:0%; font-size:20px; font-family:'Century Schoolbook'; border:solid 1px #A0A0A4; color:#A0A0A4; ">
			unique
		</div> 

		<?php					
		}

?>
</div>
