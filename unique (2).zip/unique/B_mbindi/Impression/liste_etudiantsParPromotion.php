<?php 
	if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and isset($_GET["lisSteEtud"])){
	
		$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ASC";
		//TRI DES DONNEES 
		if(isset($_GET['trierPrcTgAZ'])){
			$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.pourctgEtud DESC, tb_etudiant.nomEtud ASC ";
		}
		if(isset($_GET['trierPrcTgZA'])){
			$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.pourctgEtud ASC, tb_etudiant.nomEtud ASC ";
		}

		if(isset($_GET['trierNomAZ'])){
			$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ASC ";
		}
		if(isset($_GET['trierNomZA'])){
			$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud DESC ";
		}
	
	 	?>
		<div style="background:#FFFFFF;">
			<div align="center" style="width:100%; border-bottom:solid 2px #000000; text-transform:uppercase;">
				<table style="width:100%;">
					<tr>
						<td style="width:75px; height:auto;">
							<a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC'];?>&pRomotIon=<?php echo $_GET['pRomotIon'];?>&oPtiOn=<?php echo $_GET['oPtiOn'];?>&lisSte">
								<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" width="100%" height="100%"/>
							</a>
						</td>
						<td >
							<div align="center" style="font-size:22px;">
								<?php echo $nom_etablissement."<br/>&laquo; ".$sigle_tb_etablissement."&raquo;"; ?><br />
								secr&eacute;tariat G&eacute;n&eacute;ral Acad&eacute;mique
								<br />
								
							</div>				
						</td>
						<td style="width:105px; height:auto;">
							<div> <img src="B_mbindi/Biamunda/icon/unique.png" width="100%" height="100px" /></div>
						</td>
					</tr>
				</table>
			</div>
			<div style="text-transform:uppercase;" align="left">
				<?php 
															
					$rqt_fac = "select * from  tb_faculte WHERE idFac = '".$_GET['iDfaC']."'";
					if($exe_rqt_fac = $conDb->query($rqt_fac)){
						if($exe_rqt_fac->num_rows>0){
							if($tb_fac = $exe_rqt_fac->fetch_assoc()){
								echo "<h3><a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&lisSte'>";
								echo  "FACULTE : ".$tb_fac['designFac'];
								echo "</a></h3>";
							}
						}
					}
				?>
				
			</div>
			<div style="width: 98%; border: solid 2px #000000; margin-top: 15px; border-radius:8px 8px ; background: #e6e4e4;">
				<strong style="font-size: 25px;" align="center">
					<?php 
						if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N" || $_GET['pRomotIon']=="L1" || $_GET['pRomotIon']=="Ir1"){
							echo "LISTE DES ETUDIANTS INSCRITS";
						}
						else{
							echo "LISTE DES ETUDIANTS REINSCRITS";
						}
					?>
				</strong>
			</div>

			<div style="width:99%; height:auto; margin-bottom: 6px;">
				<table cellpadding="0" cellspacing="0" style="width:99%;" >
					<tr>
						<td>
							<?php 
								$rqt_op = "SELECT  * FROM tb_option WHERE idOp ='".$_GET['oPtiOn']."'";
								if($exe_rqt_slct_op = $conDb->query($rqt_op)){
									if($exe_rqt_slct_op->num_rows>0){ 
										if($tb_op = $exe_rqt_slct_op->fetch_assoc()) {
											$tb_op['designOp'];
											?>
											<table style="font-size: 18px; font-style:all; ">
												<tr>
													<td>Promotion </td>
													<td> : 
														<?php 
															echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&lisSte'>";
															echo $_GET['pRomotIon']."&nbsp;".$tb_op['designOp'];
															echo "</a>";
														?>
													</td>
												</tr>
												<tr>
													<td>Ann&eacute;e acad&eacute;mique </td>
													<td> : <?php echo $an_aca ; ?></td>
												</tr>
											</table>
											<?php
										}
									}
									else{
										echo "<div class='erreur'>Option introuvable</div>";
									}
								}
								else{
									echo "<div class='erreur'>Erreur lors de r&eacute;cup&eacute;ration de l'option</div>";
								}
							?>
						</td>
						<td>
							<?php 
								$nbrToalInscrit = 0;
								$nbrToalInscritM = 0;
								$nbrToalInscritF = 0;
								
								if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}
								
								$rqt_slct_etud_inscri_promoOp = "SELECT * FROM tb_inscription WHERE idProm = '".$_GET['pRomotIon']."' and idOp = '".$_GET['oPtiOn']."' and idAca = '".$an_aca."'";
								if($exe_rqt_slct_etud_inscri_promoOp = $conDb->query($rqt_slct_etud_inscri_promoOp)){
									if($exe_rqt_slct_etud_inscri_promoOp->num_rows>0){
										$nbrToalInscrit=$exe_rqt_slct_etud_inscri_promoOp->num_rows;
											while($result_exe_rqt_slct_etud_inscri_promoOp = $exe_rqt_slct_etud_inscri_promoOp->fetch_assoc()){
												$slct_etud_inscrit_promoOp = "SELECT * FROM tb_etudiant WHERE matricEtud = '".$result_exe_rqt_slct_etud_inscri_promoOp['matricEtud']."'";
												if($ex_slct_etud_inscrit_promoOp = $conDb->query($slct_etud_inscrit_promoOp)){
													if($ex_slct_etud_inscrit_promoOp->num_rows>0){
														$result_etud_inscrit_promoOp = $ex_slct_etud_inscrit_promoOp->fetch_assoc();
														if($result_etud_inscrit_promoOp['sexeEtud']=="M"){
															$nbrToalInscritM = $nbrToalInscritM+1;
														}
														else{
															$nbrToalInscritF = $nbrToalInscritF+1;
														}
													}
												}
												else{
													echo "Erreur lors de v&eacute;rification du sexe de l'&eacute;tudiant.";
												}
												
											}
											
									}
									else{
										echo "Aucun &eacute;tudiant inscrit";
									}	
								}
								else{
									echo "Erreur lors de v&eacute;rification des &eacute;tudiants inscrits.";
								}
							?>
							<div align="center" style="width:98%; height:auto; font-family:'Century Schoolbook'; font-size:16xp;">Statistiques d'inscription</div>
							<div align="center">
								<table width="100%" style="background:#FFFFFF; border:solid 2px #000000; text-align:center;" border="0" cellpadding="2" cellspacing="2" >
									<tr style="background:#666666; color:#FFFFFF;">
										<td>M</td>
										<td>F</td>
										<td>Total</td>
									</tr>
									<tr>
										<td><?php echo $nbrToalInscritM; ?></td>
										<td><?php echo $nbrToalInscritF; ?></td>
										<td><?php echo $nbrToalInscrit; ?></td>
									</tr>
								</table>
							</div>
						</td>
					</tr>
				</table>

			</div>
			
			<div>
				<?php 
					if($exe_rqt_list_etud_PromoOp = $conDb->query($rqt_list_etud_PromoOp)){
						if($exe_rqt_list_etud_PromoOp->num_rows>0){
							?>
							<table style="width:100%; border:solid 2px #000000; font-size:12px;" cellpadding="3" cellspacing="2" border="0" bordercolor="#000000"> 
							  <tr style="background:#D6D6D6; border:solid 1px #000000; text-transform:uppercase;">
								<td><div align="center">N&deg;</div></td>
								<td>
									<div align="center">
										<?php 	
											if(isset($_GET["trierNomAZ"])){
												echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&imPRessIoN&lisSteEtud&trierNomZA'> NOM 
													<img src='B_mbidndi/Biamunda/icon/az.png' class='icon' align='right' alt='AZ' title='Trier par ordre décroissant' />
													</a>";	
											}
											else{
												echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&imPRessIoN&lisSteEtud&trierNomAZ'> NOM 
													<img src='B_mbidndi/Biamunda/icon/za.png' class='icon' align='right' alt='AZ' title='Trier par ordre croissant' />
													</a>";	
											}
										?> 
									</div>
								</td>
								<td><div align="center">POSTNOM</div></td>
								<td><div align="center">PRENOM</div></td>
								<td><div align="center">SEXE</div></td>
								<td><div align="center">MATRICULE</div></td>
								<td><div align="center">LIEU NAISS. </div></td>
								<td><div align="center">DATE NAISS. </div></td>
								<!-- 
								<td><div align="center">TELEPHONE</div></td>
								<td><div align="center">ADRESSE</div></td>
								-->
								<?php 
									if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N"){
										?>
										<td><div align="center">Section</div></td>
										<td>
											<div align="center">
												<?php 
												if(isset($_GET["trierPrcTgZA"])){	
													echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&imPRessIoN&lisSteEtud&trierPrcTgAZ'> % 
													<img src='B_mbidndi/Biamunda/icon/az.png' class='icon' align='right' alt='AZ' title='Trier par ordre décroissant' />
													</a>";
												}
												else{
													echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&imPRessIoN&lisSteEtud&trierPrcTgZA'> % 
													<img src='B_mbidndi/Biamunda/icon/za.png' class='icon' align='right' alt='ZA.' title='Trier par ordre croissant' />
													</a>";
												}
												?> 
											</div>
										</td>
										<td><div align="center">PERE</div></td>
										<td><div align="center">MERE</div></td>
										<?php 
									}
								?>
							  </tr>
									<?php 
									$numOrdre=0;
									$ligneForm = 1;
									while($tb_listEtud = $exe_rqt_list_etud_PromoOp->fetch_assoc()){
									
									
									?>
									<tr style="text-transform:uppercase;<?php if ($ligneForm == 2){echo "background:#f2f0f0;"; $ligneForm =1;}else{$ligneForm =$ligneForm +1;} ?>">
										<td><div align="right"><?php echo $numOrdre=$numOrdre+1; ?></div>					    </td>
										<td><div align="left"><?php echo $tb_listEtud["nomEtud"];?></div></td>
										<td><div align="left"><?php echo $tb_listEtud["postnomEtud"];?></div></td>
										<td><div align="left"><?php echo $tb_listEtud["prenomEtud"];?></div></td>
										<td><div align="center"><?php echo $tb_listEtud["sexeEtud"];?></div></td>
										<td><div align="right"><?php echo $tb_listEtud["matricEtud"];?></div></td>
										<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["lieunaisEtud"];?></div></td>
										<td><div align="right"><?php echo $tb_listEtud["datenaissEtud"];?></div></td>
										<!-- 
										<td><div align="right"><?php //echo $tb_listEtud["telEtud"];?></div></td>
										<td><div align="left"><?php //echo $tb_listEtud["adresseEtud"];?></div></td>
										-->
										<?php 
											if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N"){
												?>
												<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["sectionSuiviEtud"];?></div></td>
												<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["pourctgEtud"];?></div></td>
												<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["nomPereEtud"];?></div></td>
												<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["nomMereEtud"];?></div></td>
												<?php 
											}
										?>
									</tr>
									<?php 
									}
									?>
							</table>
							<div style="width:500px; height:30px; float:right;" align="center">
								<p>Fait &agrave; <?php echo $_SESSION['villeEts']; ?>, le ......../........./2022.</p>
							<div>
							<div style="width:500px; height:50px; float:right;" align="center">
								<p>Nom et signature de l'autorit&eacute;</p>
							<div>
							<?php 
						}
						else{
							echo "Aucun &eacute;tudiant inscrit.";
						}
					}
					else{
						echo "Erreur lors d'&eacute;tablissement de la liste";
					}
				?>
			</div>
		</div>
	<?php	
	}
 ?>

