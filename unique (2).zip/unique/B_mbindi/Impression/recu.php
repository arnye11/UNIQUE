<?php 
	if(isset($_GET["recude"]) and isset($_GET["num"])){ ?>

<script type="text/javascript">
function imprimer(){
  window.print();
}
</script>

<style type="text/css">
	<!--
	.pgrecu{
		width:100%; height:210px; margin:0px; padding:0px; background:#FFFFFF 
	}
	.recu{
		width:100%; height:209px; border:solid 1px #CCCCCC; padding:2px; box-shadow:0px 2px 2px 0px #999999;
	}
	.soucherecu1, .soucherecu2{
		height:196px; border:solid 1px #CCCCCC; padding:1px; display:inline; 
	}
	.soucherecu1{
		width:30%; float:left; font-size:10px;  
	}
	.soucherecu2{
		width:68%; float:right; font-size:12px; 
	}
	.btPrinter{
		 position:fixed; top:3%; bottom:auto; left:auto; right:12%; box-shadow:5px #999999; 
	}
	-->
</style>





<?php 

$rqt_slct_fr_vers = "SELECT tb_versement.*, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_versement ON tb_etudiant.matricEtud = tb_versement.matEtud WHERE (((tb_versement.idVers)='".$_GET['num']."'))";

//$rqt_slct_fr_vers = "select * from tb_versement where idVers = '".$_GET['num']."'";
if($exe_rqt_slct_fr_vers =$conDb->query($rqt_slct_fr_vers)){
	if($exe_rqt_slct_fr_vers->num_rows>0){
		?>
		<div class="pgrecu">
			<div class="recu">
				<?php 	
				if($tb_Etud_vers = $exe_rqt_slct_fr_vers->fetch_assoc()){
					for($t = 1; $t<=2; $t++){
					?>
					<div class="soucherecu<?php echo $t; ?>">
						<div align="center" style="width:100%; border-bottom:solid 2px #000000; text-transform:uppercase;">
							<table style="width:100%;">
								<tr>
									<td style="width:55px; height:auto;">
										<div style="width:50px; height:50px;">
											<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" width="100%" height="100%"/>
										</div>
									</td>
									<td >
										<div align="center">
											<?php echo $_SESSION['nom_etablissement']."<br/>&laquo; ".$_SESSION['sigle_tb_etablissement']."&raquo;"; ?><br />
											FACULTE D'INFORMATIQUE<br />
											DECANAT<br />
										</div>
									</td>
								</tr>
							</table>
						</div>
						<div style="font-size:14px; background:#000000; color:#FFFFFF;">
							<strong>Re&ccedil;u N&deg; &nbsp;<?php echo $_GET["num"]."R".$_GET["recude"]; ?>,  de : </strong>
						</div>
						<div style="width:98%; border:solid 1px #999999;">
							<table style="width:100%;">
								<tr>
									<td style="width:55px; height:auto;">
									<div style="width:50px; height:50px;">
										<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/media/<?php echo $tb_Etud_vers['matricEtud']."/".$tb_Etud_vers['avantarEtud'];?>" alt="Pas de Photo" width="100%" height="100%" />
									</div>
									</td>
									<td >
									<div style="width:100%;">
										<strong style="text-transform:uppercase;"><?php echo $tb_Etud_vers["nomEtud"]."&emsp;".$tb_Etud_vers["postnomEtud"]."&emsp;"?></strong>
										<strong style="text-transform:capitalize;"><?php echo$tb_Etud_vers["prenomEtud"]; ?></strong>
									</div>
									Promotion : <?php echo $tb_Etud_vers["idPromo"]; ?><br/>
									Ann&eacute;e acad&eacute;mique : <?php echo $tb_Etud_vers["idAca"]; ?><br/>
									Montant vers&eacute; : 
									<?php 
										echo $tb_Etud_vers["montantVers"]."&emsp; FC. &nbsp;&nbsp;&nbsp;&nbsp;";
										echo "Motif : " ;
										$rqt_slct_fr = "SELECT * FROM tb_frais WHERE idFr='".$tb_Etud_vers['idFr']."'";
											if($exe_rqt_slct_fr =$conDb->query($rqt_slct_fr)){
												if($exe_rqt_slct_fr->num_rows>0){
													if($tb_fr = $exe_rqt_slct_fr->fetch_assoc()){
														echo $tb_fr['designFr'];
													}
												}
											}
									?>

									<br/>
									Date : <?php echo $tb_Etud_vers["dateVers"]; ?><br/>
									
									</td>
								</tr>
							</table>
						</div>
						<div align="right" style="">Nom et signature de l'autorit&eacute;</div>
					</div>
					<?php 
					}
				}
				?>
			</div>
		</div>
		<?php 
	}
	else{
		echo "Pas de versement";
	}
}
else{
	echo "Erreur";
}
?>
<script type="text/javascript">
  window.print();
</script>
<?php }?>