<?php 
	if(isset($_GET["cArteEtUdiant"])){ 
		if ($_SESSION['NivAc'] >= 0 and $_SESSION['NivAc'] <= 5){
			//include("barcode.php")
			//include("barcodeimage.php")
			?>

			<style type="text/css">
				<!--
				.pgrecu{
					width:700px; 
					height:255px; 
					margin:25px; 
					padding:0px; 
					background:#FFFFFF; 
				}
				.recu{
					width:100%; 
					height:243px; 
					border:solid 1px #CCCCCC; 
					padding:2px; 
					box-shadow:0px 2px 2px 0px #999999; 
				}
				.soucherecu1, .soucherecu2{
					width:49.5%;
					height:235px; 
					border:solid 1px #CCCCCC; 
					border-bottom:solid 3px #ff0000 ; 
					border-top: solid 3px #ff0000 ; 
					padding:1px; 
					display:inline; 
					font-size:12px; 
				}
				.soucherecu1{
					float:left;  
				}
				.soucherecu2{
					float:right; 
				}
				.btPrinter{
					position:fixed; 
					top:3%; 
					bottom:auto; 
					left:auto; 
					right:12%; 
					box-shadow:5px #999999; 
				}
				-->
			</style>

			<?php 

			//$rqt_slct_fr_vers = "SELECT tb_versement.*, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_versement ON tb_etudiant.matricEtud = tb_versement.matEtud WHERE (((tb_versement.idVers)='".$_GET['num']."'))";

			$rqt_list_etud_PromoOp = "SELECT tb_inscription.*, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";

			//$rqt_slct_fr_vers = "select * from tb_versement where idVers = '".$_GET['num']."'";
			if($exe_rqt_slct_fr_vers =$conDb->query($rqt_list_etud_PromoOp)){
				if($exe_rqt_slct_fr_vers->num_rows>0){
					while($tb_Etud_vers = $exe_rqt_slct_fr_vers->fetch_assoc()){
						?>
						<div class="pgrecu">
							<div class="recu">
								<div class="soucherecu1">
									<div align="center" style="width:100%; text-transform:uppercase;">
										<table style="width:100%;">
											<tr>
												<td >
													<div align="center" style="width:12%; display:inline; float: left; ">
														<img src="A_mutue/quepiEtud.ico" alt="logo Ets" width="90%" height="30"/>
													</div>
													<div align="center" style="width:74%; display:inline; float: left;">
														<?php echo $nom_univers ; ?><br />
														<strong style="text-transform:capitalize;">
															Secr&eacute;tariat G&eacute;n&eacute;ral Acad&eacute;mique<br />
														</strong>
													</div>
													<div align="center" style="width:12%; display:inline; float: left; ">
														<img src="A_mutue/<?php echo $logo; ?>" alt="logo Ets" width="90%" height="30"/>
													</div>
												</td>
											</tr>
										</table>
									</div>
									<div style="font-size:13px; background:#1616a4; color:#FFFFFF; padding: 1px;" align="center" >
										<strong>CARTE D'ETUDIANT  <?php echo $tb_Etud_vers["idAca"]; ?></strong>
									</div>
									<div style="width:98%; " align="center">
										<table style="width:100%;" border="0" align="center">
											<tr >
												<td style="width:65px; height:auto;" valign="top">
													<div style="width:100%; height:115px; " align="center" >
														<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbidndi/Biamunda/media/<?php echo $tb_Etud_vers['matricEtud']."/".$tb_Etud_vers['avantarEtud'];?>" alt="Pas de Photo" width="100%" height="100%" />
													</div>
													<div align="center" style="">
														<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?profil&id=<?php echo $tb_Etud_vers['matricEtud'] ?>&frais">
															NME
															<?php echo $tb_Etud_vers["matricEtud"];?>
														</a>
													</div>
													<div align="center">
														<strong style="color: #ff0000;">UNILO</strong>
													</div>
												</td>
												<td valign="top" >
													<div style="width:100%; border-bottom: solid 1px #000000; font-size:4">
														<div style="width: 100%; height: 13px;">
															<div style="width: 75%; display: inline; float: left;">
																Nom : 
																<strong style="text-transform:uppercase;">
																	<?php echo $tb_Etud_vers["nomEtud"];?><br>
																</strong>
															</div>
															<div style="width: 20%; display: inline; float: right;">
																Sexe :
																<strong style="text-transform:uppercase;">
																	<?php echo $tb_Etud_vers["sexeEtud"]; ?><br>
																</strong>
															</div>
														</div>
														Postnom : 
														<strong style="text-transform:uppercase;">
															<?php echo $tb_Etud_vers["postnomEtud"];?><br>
														</strong>
														Pr&eacutenom : 
														<strong style="text-transform:capitalize;">
															<?php echo $tb_Etud_vers["prenomEtud"]; ?><br>
														</strong>
														 
														Lieu/Date naiss. :
														<strong style="text-transform:uppercase;">
															<?php echo $tb_Etud_vers["lieunaisEtud"]."/".$tb_Etud_vers["datenaissEtud"]; ?><br>
														</strong> 
														Adresse :
														<strong >
															<?php echo $tb_Etud_vers["adresseEtud"] ; ?><br>
														</strong>
														Promotion : 
														<strong >
															<?php echo $tb_Etud_vers["idProm"]." ".$designOpOrgV; ?><br/>
														</strong>
													</div>
													<div>	
														Nom Père/Mère :
														<strong style="text-transform:uppercase;">
															<?php echo $tb_Etud_vers["nomPereEtud"]." / ".$tb_Etud_vers["nomMereEtud"]; ?><br>
														</strong> 
													</div>
													<div align="right">
														Fait à Kabinda, le <?php echo $jour."/".$moi."/".$annee_encours; ?>
													</div>
													<div style="font-size: 8;">
														<!--<img src="barcodeimage.php?code=CODE39EXTENDED&text=Hello%20World!&showtext=1&width=80&height=20">
														<img src="barcodeimage.php?codetype=code39&size=8">
														<img src="barcodeimage.php?code=CODE128&text=ActiveBarcode">
														<img src="barcodeimage.php?code=CODE39EXTENDED&text=Hello%20World!&showtext=1&rotate=90&
															  backcolor=002288&forecolor=12345&width=250&
															  height=430&borderwidth=50&borderheight=25">-->
														<?php
														$string = $_SESSION['sigle_tb_etablissement'].$tb_Etud_vers["idInscrit"] ; 
														echo "<img alt='testing' src='barcode.php?codetype=code39&size=16&text=".$string."&print=false'/>";
														//Barcode::gd($res, $color, 50, 80, 75, "codebar", $datas, $width=null, $height=null); 
														//Barcode::fpdf($res, $color, $x, $y, $angle, $type, $datas, $width=null, $height=null); 
														// créer un fichier
														//QRcode::png('code data text', 'filename.png');
														// Afficher directement le qr code (dans le navigateur)
														//QRcode::png('some othertext 1234');
														?>
													</div> 
													<div align="right" style="width:100%; background: #ffcc00;">
														Nom et signature de l'autorit&eacute;
													</div>
												</td>
											</tr>
										</table>
									</div>
									
								</div>
								<div class="soucherecu2">
									<div align="center" style="width:100%; border-bottom:solid 2px #000000; text-transform:uppercase;">
										<table style="width:100%;">
											<tr>											
												<td >
													<div align="center">
														Secr&eacute;tariat G&eacute;n&eacute;ral Acad&eacute;mique<br />
														Facult&eacute : <?php echo $designFac; ?>
													</div>
												</td>
											</tr>
										</table>
									</div>
									<div style="font-size:14px; background:#1616a4; color:#FFFFFF; padding: 5px;" align="center" >
										<strong>CARTE D'ETUDIANT N° <?php echo $tb_Etud_vers["idInscrit"] ;?> </strong>
									</div>
									<div style="width:98%; ">
										<table style="width:100%;">
											<tr style="height: 100px;" valign="top">
												<td style="width:24%; ">
													<div style="width:100%; height:auto;" align="center">
														
													</div>
												</td>
												<td style="width:50%px; ">
													<div style="width:100%; height:auto;" align="center">
														<img src="A_mutue/<?php echo $logo; ?>" alt="logo Ets" width="90%" height="120"/>
													</div>
												</td>
												<td style="width:24%; ">
													<div style="width:100%; height:auto;" align="center">
														
													</div>
												</td>
											</tr>
										</table>
									</div>
									<div align="center" style="">
										<i>
											Les Autorités tant Civiles, Policières que Militaires sont priées de venir en aide au porteur de la présente en cas de nécessité.
										</i>
									</div>
								</div>
								
							</div>
						</div>
						<?php 
					}
				}
				else{
					echo "Pas d'Etudiants inscrits";
				}
			}
			else{
				echo "Erreur";
			}
		}
		else{
				echo "Vous n'avez pas le droit d'acc&eacute;der à cette information";
			}
	} 
?>