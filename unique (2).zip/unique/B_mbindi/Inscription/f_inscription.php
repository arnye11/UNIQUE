<?php
if (isset($_GET['iNscrir'])){
	echo "<div style='border-bottom:groove;' id = 'i'><h3 align='center'>Formulaire d'Inscription</h3>";
	echo "</div>";
	echo $sms_inscription;
	if(isset($_POST['BtInscrir'])){echo "<div style='color:#009900'>".$sms_avatar."</div>";}else{ echo $sms_avatar;}
?>


<form action="" method="post" enctype="multipart/form-data" >
<table border="0" align="center"  style="width:100%; font-family:Bookman Old Style; font-size:13px; box-shadow:0px 2px 2px 2px #777777; background:#F0F0F0;">
 <tr>
    <td height="25"><div align="right">Promotion* : </div></td>
    <td  style="padding-top:5px;">
    <div align="left">
      <?php echo "<h3>".$idPromoOrgV."&ensp;".$designOpOrgV."</h3>"; ?>
      <input type="hidden" name="idPromo" value="<?php echo $idPromoOrgV; ?>" />
      <input type="hidden" name="idOp" value="<?php echo $idOpOrgV; ?>" />
    </div>  </td>
  </tr>
  <tr>
    <td width="161"><div align="right">Nom* : </div></td>
    <td width="304"  style="padding-top:5px;"><div align="left">
      <input type="text" name="nomEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $nomEtud;} ?>"/>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Postnom* : </div></td>
    <td><div align="left">
		<input type="text" name="postnomEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $postnomEtud;} ?>"/>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Pr&eacute;nom* : </div></td>
    <td><div align="left">
      <input type="text" name="prenomEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $prenomEtud;} ?>"/>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Sexe* : </div></td>
    <td><div align="left">
      <select name="sexeEtud">
        <option value="<?php if (isset($_POST['BtInscrir'])){ echo $sexeEtud;} ?>"><?php if (isset($_POST['BtInscrir'])){ echo $sexeEtud;} ?></option>
        <option value="M">M</option>
        <option value="F">F</option>
      </select>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Date de naissance* : </div></td>
    <td>
  		<div align="left">
        <input type="Date" name="dateNaissEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $dateNaissEtud;} ?>"/>
      </div>		
    </td>
  </tr>
  <tr>
    <td><div align="right">Lieu de naissance* : </div></td>
    <td style="border-bottom:solid 1px #220000; padding-bottom: 5px;"><div align="left">
      <input type="text" name="LieuNaiss" value="<?php if (isset($_POST['BtInscrir'])){ echo $LieuNaiss;} ?>"/>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Section suivie aux humanit&eacute;s </div></td>
    <td style="padding-top:5px;"><div align="left">
      <input type="text" name="sectionSuivEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $sectionSuivEtud;} ?>"/>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Pourcentage : </div></td>
    <td style="padding-top:5px;"><div align="left">
      <input type="text" name="PourctgEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $PourctgEtud;} ?>"/>
    </div></td>
  </tr>
  <tr>
    <td><div align="right">T&eacute;l. : </div></td>
    <td style="padding-top:5px;"><div align="left">
      <input type="text" name="TelEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $TelEtud;} ?>"/>
</div></td>
  </tr>
  <tr>
    <td><div align="right">E-mail : </div></td>
    <td>
        <div align="left">
          <input type="text" name="EmailEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $EmailEtud;} ?>"/>
        </div>
    </td>
  </tr>
  <tr>
    <td><div align="right">Adresse  : </div></td>
    <td>
      <div align="left">
        <textarea name="adresseEtud" style="width:260px; height:40px"><?php if (isset($_POST['BtInscrir'])){ echo $adresseEtud;} ?></textarea>
      </div>
    </td>
  </tr>
  <tr>
    <td><div align="right">Nom du p&egrave;re : </div></td>
    <td>
        <div align="left">
          <input type="text" name="nomPereEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $nomPereEtud;} ?>"/>
        </div>
    </td>
  </tr>
  <tr>
    <td><div align="right">Nom de la m&egrave;re : </div></td>
    <td>
        <div align="left">
          <input type="text" name="nomMereEtud" value="<?php if (isset($_POST['BtInscrir'])){ echo $nomMereEtud;} ?>"/>
        </div>
    </td>
  </tr>
 
  <tr>
    <td><div align="right">Photo : </div></td>
    <td  style="padding-bottom:5px; border-bottom:solid 1px #220000;">
		<!--Recuper� par  rqt_uplaod_avantar.php-->
		<input type="file" name="AvatarEtud" style="width:260px;" value="<?php if (isset($_POST['BtInscrir'])){ echo $AvatarEtud;} ?>"/>	</td>
  </tr>
  <tr>
    <td><div align="right">
      <input type="reset" name="BtAnnuler_Inscri" value="Annuler" />
    </div></td>
    <td>
      <div align="right">
        <input type="submit" name="BtInscrir" value="Inscrir" style="width:70%; font-size:14px; " />
        </div></td>
  </tr>
</table>

</form>
<?php 
	}
?>
