<div style="width:100%;" >
<?php 
//Rqt SELECTION DE LA PROMOTION DE L'ANNEE EN COURS

if(isset($_GET['reincription']) || isset($_GET['cursus']) || (isset($_GET['profil'])and ($reinscription == false))){ 
	$rqt_slct_etud_inscri = "select * from tb_inscription where matricEtud = '".$result_slct_etud['matricEtud']."'";
	if($exe_Tb_inscription = $conDb->query($rqt_slct_etud_inscri)){
		?>
		<h2 style="font-size:20px">Cursus de l'&eacute;tudiant</h2>
		<div>
			<?php  
				if (isset($_POST['BtSupReinscription']) and isset($_GET["modifInscrit"])){ 
					echo $sms_gerer;
				}
				if (isset($_POST['BtModifReinscrire'])){ 
					echo $sms_gerer;
				}
			?>
		</div>
		<table border="0" align="left" width="100%" style="margin-bottom:6PX;">
			<tr>
				<th scope="col" style="background:#FF6600; color:#FFFFFF;">Ann&eacute;e Acad&eacute;mique </th>
				<th scope="col" style="background:#FF6600; color:#FFFFFF;">Promotion</th>
				<th scope="col" style="background:#FF6600; color:#FFFFFF;">Option </th>
				<th scope="col" style="background:#FF6600; color:#FFFFFF;">% </th>
				<th scope="col" style="background:#FF6600; color:#FFFFFF;">MENTION </th>
				<th scope="col" style="background:#FF6600; color:#FFFFFF;">SESSION </th>
				<th scope="col" style="background:#FF6600; color:#FFFFFF;">Action </th>

			</tr>
			<?php 
			while($Tb_inscription = $exe_Tb_inscription->fetch_assoc()){
				$promotion = $Tb_inscription['idProm'];
				$slct_op = "select * from tb_option where idOp = '".$Tb_inscription['idOp']."'";//RQT SELECTION DE L'OPTION
				if($exe_slct_op = $conDb->query($slct_op)){
					if($Tb_Option = $exe_slct_op->fetch_assoc()){
						$IdOption = $Tb_Option['idOp'];
						$Option = $Tb_Option['designOp'];
						$slct_fac = "select * from tb_faculte where idFac = '".$Tb_Option['idFac']."'";//RQT SELECTION DEPARTEMENT
						if($exe_slct_fac = $conDb->query($slct_fac)){
							if($Tb_Fac = $exe_slct_fac->fetch_assoc()){
								$idFac = $Tb_Fac['idFac'];
								$annuler_inscription = 0;

								//VERIFICATION DE L'ETUDIANT
								$rqt_verif = "SELECT * FROM tb_versement WHERE matEtud = '".$_SESSION['matricEtud']."' and idAca='".$Tb_inscription['idAca']."'";
								if($ex_rqt_verif= $conDb->query($rqt_verif)){
									if(mysqli_num_rows($ex_rqt_verif)>0) {
										$annuler_inscription += 1;
									}
								}
								else{
									$annuler_inscription += 1;
								}
								$rqt_verif = "SELECT * FROM tb_cote WHERE matricEtud = '".$_SESSION['matricEtud']."' and idAca='".$Tb_inscription['idAca']."'";
								if($ex_rqt_verif = $conDb->query($rqt_verif)){
									if(mysqli_num_rows($ex_rqt_verif)>0) {
										$annuler_inscription += 1;
									}
								}
								else{
									$annuler_inscription += 1;
								}
								//----------------------------------

								if (isset($_GET["modifInscrit"]) and $_GET["modifInscrit"] == $Tb_inscription['idAca'] and $annuler_inscription == 0 ) {

									?>
									<form action="" method="post">
										<tr>
											<th scope="col" style="border-bottom:solid 1px #FF6600;">
												<div align="center">
													<?php
														if ($annuler_inscription == 0 ) {
															?>
															<input name="BtSupReinscription" type="submit" value="Supprimer"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
															<?php 
														}
													?>
													<?php echo $Tb_inscription['idAca']; ?>
													<input type="hidden" name="aca" value="<?php echo $Tb_inscription['idAca']; ?>">
												</div>							    
											</th> 
											<th scope="col" style="border-bottom:solid 1px #FF6600; ">
												<div align="left">
													<select name="idPromo" >
														<option style="color:#FF3333;" value="<?php echo $promotion; ?>">
															<?php echo $promotion; ?>
														</option>
														<?php 
															$rqt_list_promotion = "select * from  tb_promotion ORDER BY idPromo ASC";
															if($exe_rqt_list_promotion = $conDb->query($rqt_list_promotion)){
																echo "<option value=''></option>";
																while($result_exe_rqt_list_promotion = $exe_rqt_list_promotion->fetch_assoc()){
																	?>
																	<option value="<?php echo $result_exe_rqt_list_promotion['idPromo']; ?>">
																		<?php echo $result_exe_rqt_list_promotion['idPromo']; ?>
																	</option>
																	<?php 
																}
															}
															else{
																?>
																<option style="color:#FF3333;" value="" class="eche" >Erreur.</option>
																<?php 
															}
														?>
													</select>
												</div>
											</th>
											<th scope="col" style="border-bottom:solid 1px #FF6600;" title="Facult� : <?php echo $Tb_Fac['designFac']; ?>">
												<div align="left">
													<select name="idOp">
														<option value="<?php echo $IdOption; ?>"><?php echo $Option; ?></option>
						                          		<?php 
														$rqt_list_option = "select * from  tb_option WHERE idFac ='".$Tb_Fac['idFac']."' ";
															if($exe_rqt_list_option = $conDb->query($rqt_list_option)){
																echo "<option value=''>------------</option>";
																while($Tb_Option = $exe_rqt_list_option->fetch_assoc()){
																	?>
										                          	<option value="<?php echo $Tb_Option['idOp']; ?>"><?php echo $Tb_Option['designOp']; ?></option>
										                          	<?php 
																}
															}
															else{
																echo  "<option value=''>< /option>";
																echo  "<option class='echec' value=''>Erreur</option>";
															}
													  
														?>
						                        	</select>
												</div>
											</th>
											<th scope="col" style="border-bottom:solid 1px #FF6600;" title="Facult� : <?php echo $Tb_Fac['designFac']; ?>">
												<div align="left">
													<input name="BtModifReinscrire" type="submit" value="Modifier">
												</div>
											</th>
											<th scope="col" style="border-bottom:solid 1px #FF6600;" title="Facult� : <?php echo $Tb_Fac['designFac']; ?>">
												<div align="left">
													<a title="Modifier" href="<?php $_SERVER['HTTP_HOST'];?>?profil&id=<?php echo $result_slct_etud['matricEtud'];?>&cursus">Annuler </a>
												</div>
											</th>
											
										</tr>	
									</form>
									
									<?php
								}
								else{
									?>
									<tr>
										<th scope="col" style="border-bottom:solid 1px #FF6600;">
											<div align="center">
												<?php echo $Tb_inscription['idAca']; ?>
											</div>							    
										</th>
										<th scope="col" style="border-bottom:solid 1px #FF6600; ">
											<div align="left"><?php echo $promotion; ?></div>
										</th>
										<th scope="col" style="border-bottom:solid 1px #FF6600;" title="Facult� : <?php echo $Tb_Fac['designFac']; ?>">
											<div align="left"><?php echo $Option; ?></div>
										</th>
										<?php 
											for ($i=1; $i <= 2; $i++) { 
												if ($i==1) 
													$session = "s2";
												else
													$session="s1";
												
												$rqt_slct_d = "select * from tb_deliberation where  matricEtud ='".$result_slct_etud['matricEtud']."' and idPromo = '".$promotion."' and idOp = '".$IdOption."' and idAnAca = '".$Tb_inscription['idAca']."' and session = '".$session."'";
												if($exe_rqt_slct_d = $conDb->query($rqt_slct_d)){
													if($tb_delib = $exe_rqt_slct_d->fetch_assoc()){
														echo "<td style='border-bottom:solid 1px #FF6600;'>";
															echo "<div align='right'>";
																echo $tb_delib["prctg"];
															echo "<div>";
														echo "</td>";
														echo "<td style='border-bottom:solid 1px #FF6600;'>";
															
															if( $tb_delib["mention"]=="AA"){
																echo "Assumul� aux ajourn�s";
															}
															if( $tb_delib["mention"]=="A"){
																echo "Ajourn�";
															}
															if( $tb_delib["mention"]=="S"){
																echo "Satisfaction";
															}
															if( $tb_delib["mention"]=="D"){
																echo "Distinction";
															}
															if( $tb_delib["mention"]=="GD"){
																echo "Grande distinction";
															}
															if( $tb_delib["mention"]=="PGD"){
																echo "Plus grande distinction";
															}
														echo "</td>";
														echo "<td style='border-bottom:solid 1px #FF6600;'>";
															echo $session;
														echo "</td>";
														$i=3;
													}
													else{
														if ($i==2) {
															echo "<td style='border-bottom:solid 1px #FF6600;'>&mdash;</td>";
															echo "<td style='border-bottom:solid 1px #FF6600;'>&mdash;</td>";
															echo "<td style='border-bottom:solid 1px #FF6600;'>&mdash;</td>";
														}
														
													}

												}
												else{
													echo "Erreur";
												}
											}
										?>
										<th scope="col" style="border-bottom:solid 1px #FF6600;" title="Facult� : <?php echo $Tb_Fac['designFac']; ?>">
											<div align="left">
												<?php 
													if ($annuler_inscription == 0 ) { ?>
														<a title="Modifier" href="<?php $_SERVER['HTTP_HOST'];?>?profil&id=<?php echo $result_slct_etud['matricEtud'];?>&cursus&modifInscrit=<?php echo $Tb_inscription['idAca']; ?>#etudiant">
															<img class="icon" src="B_mbindi/Biamunda/icon/edit.gif" />
														</a>
														<?php 
													}
												?>
											</div>
										</th>
									</tr>
									<?php	
								}								
							}
						}
					}
				}
			}
	 		?>
		</table>
<p></p>


		<?php
		if($reinscription == false){
			?>
			<div align="center">
				<div style="font-size:20px;" align="center">REINSCRIPTION</div>
				<?php if(isset($_POST['BtReinscrire'])){echo $sms_inscription ;} ?>
			 
				<form action="" method="post">
					<input type="hidden" name="Mat"  value="<?php echo $result_slct_etud['matricEtud']; ?>" >
				  	<table border="0" bgcolor="#BBBBBB">
						<tr>
							<td><div>Ann&eacute;e acad&eacute;mique </div></td>
							<td><div><?php echo $an_aca; ?></div></td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td><div>Promotion </div></td>
							<td>
								<input name="matricEtud" type="hidden" value="<?php echo $result_slct_etud["matricEtud"];?>"/>
								<select name="idPromo" >
									<option style="color:#FF3333;" value="<?php echo $promotion; ?>">
										<?php echo $promotion; ?>
									</option>
									<?php 
										$rqt_list_promotion = "select * from  tb_promotion ORDER BY idPromo ASC";
										if($exe_rqt_list_promotion = $conDb->query($rqt_list_promotion)){
											echo "<option value=''></option>";
											while($result_exe_rqt_list_promotion = $exe_rqt_list_promotion->fetch_assoc()){
												?>
												<option value="<?php echo $result_exe_rqt_list_promotion['idPromo']; ?>">
													<?php echo $result_exe_rqt_list_promotion['idPromo']; ?>
												</option>
												<?php 
											}
										}
										else{
											?>
											<option style="color:#FF3333;" value="" class="eche" >Erreur.</option>
											<?php 
										}
									?>
								</select>
							</td>
							<td>&nbsp;</td>
					  	</tr>
					  	<tr>
					    	<td>Option</td>
						    <td>
						    	<select name="idOp">
									<option value="<?php echo $IdOption; ?>"><?php echo $Option; ?></option>
	                          		<?php 
									$rqt_list_option = "select * from  tb_option WHERE idFac ='".$Tb_Fac['idFac']."' ";
										if($exe_rqt_list_option = $conDb->query($rqt_list_option)){
											echo "<option value=''>------------</option>";
											while($Tb_Option = $exe_rqt_list_option->fetch_assoc()){
												?>
					                          	<option value="<?php echo $Tb_Option['idOp']; ?>"><?php echo $Tb_Option['designOp']; ?></option>
					                          	<?php 
											}
										}
										else{
											echo  "<option value=''>< /option>";
											echo  "<option class='echec' value=''>Erreur</option>";
										}
								  
									?>
	                        	</select>
	                    	</td>
					    	<td>&nbsp;</td>
				      	</tr>
					  	<tr>
						    <td>Frais</td>
						    <td><input type="text" name="Fr"  style="width:20px;" ></td>
						    <td>
						    	<div align="right">
						      		<input name="BtReinscrire" type="submit" value="R&eacute;inscrire">
					        	</div>
					    	</td>
				    	</tr>
			    	</table>		
			  	</form>
			</div>
			<?php
		}
	}
	else{
		echo "<p class='eche'>Impossible de retrouver le cursus de cet &eacute;tudiant.</p>";
	}
}
?>
</p>