<?php 
	if(isset($_GET["ficheCS"])){
		$cours = "cours";
		
		if (!isset($_GET['imPRessIoN'])) {
			?>
			<div align="right" style="width: 99%; border: solid 1px #d9d9d9; margin-bottom:20px;">
				<a href='?fAculTe&iDfaC=<?php echo $_GET['iDfaC'];?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn'] ?>&inScriPtion&ficheCS&cours'>Cours</a> &emsp;|&emsp;
				<a href='?fAculTe&iDfaC=<?php echo $_GET['iDfaC'];?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn'] ?>&inScriPtion&ficheCS&stage'>Stage</a> &emsp;|&emsp;
				<a href='?fAculTe&iDfaC=<?php echo $_GET['iDfaC'];?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn'] ?>&inScriPtion&ficheCS&tfc_memoire'>TFC/Mémoire</a>
				
			</div>
			<?php	
		}			
		$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";
		 ?>
		<div>
			<div style="width:100%; height:115px; border-bottom:ridge 5px #666666;">
				<table style="width:100%;">	
					<tr >
						<td style="width:100px;height:110px;">	
							<div style="width:100%; height:100%; " >
								<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" style="max-width:100%; max-height:auto;"/>
							</div>
						</td>
						<td style=" " >
							<div align="center" style="font-size:1.1em; text-transform: uppercase; font-weight: bold;" >
								ENSEIGNEMENT SUPERIEUR ET UNIVERSITAIRE
								<br/>
								<?php echo $nom_etablissement ; ?><br />
								&laquo; <?php echo $sigle_tb_etablissement ; ?> &raquo;<br />
								SECRETARIAT GENERAL ACADEMIQUE<br />
								<?php 
									$rqt_fac = "select * from  tb_faculte WHERE idFac = '".$_GET['iDfaC']."'";
									if($exe_rqt_fac = $conDb->query($rqt_fac)){
										if($result_rqt_fac = $exe_rqt_fac->fetch_assoc()){
											if ($_SESSION['typEts']=="UN") 
												echo "FACULTE : ";
											else
												echo "SECTION : ";

											echo $result_rqt_fac['designFac'] ;
										}
										else{
											echo "FACULTE INTROUVABLE";
										}
									}
									else{
										echo "IMPOSSIBLE DE TROUVER LA FACULTE";
									}
									
								?>
							</div>
						</td>
						<td style="width:100px; height:110px; " align="right">
							<div style="width:100%; height:100%; ">
								<img src="B_mbindi/Biamunda/icon/unique.gif" style="max-width:100%; max-height:auto;" />
							</div>
						</td>
					</tr>
				</table>
			</div>

			
			<div align="center" style="width:100%; height: auto; font-size:1.2em; font-weight:bold;">
				<div align="center" style="width:90%; height: auto;  border:solid 2px #000000; border-radius:16px 16px; margin-top: 10px; margin-bottom:10px; padding:5px;">
					FICHE DE COTATION
				</div>
			</div>
			
			<div style="width:99%; height:auto; border:solid 1px #CCCCCC;">
				<table cellpadding="0" cellspacing="0" style="width:99%;" >
					<tr>
						<td>
							<table width="100%">
								<tr>
									<td>Promo./Option</td>
									<td>: <?php echo $_GET['pRomotIon']." ".$_SESSION["designOp"]; ?>  </td>
								</tr>
								<tr>
									<td>Cours</td>
									<td>: ................................................................... </td>
								</tr>
								<tr>
									<td>Volume horaire</td>
									<td>: ht .......hp .......ht .......</td>
								</tr>
								<tr>
									<td>Ponderation</td>
									<td>: ................................................................... </td>
								</tr>
								<tr>
									<td>Enseignant</td>
									<td>: ................................................................... </td>
								</tr>
								<tr>
									<td>Grade</td>
									<td>: ................................................................... </td>
								</tr>
							</table>
						</td>
						<td>
							
							<?php 
								echo "<div align='center'>";
								echo "Année académique : ".$an_aca;
								echo "</div>";
								$nbrToalInscrit = 0;
								$nbrToalInscritM = 0;
								$nbrToalInscritF = 0;
								
								if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}
								
								$rqt_slct_etud_inscri_promoOp = "SELECT * FROM tb_inscription WHERE idProm = '".$_GET["pRomotIon"]."' and idOp = '".$_GET["oPtiOn"]."' and idAca = '".$an_aca."'";
								if($exe_rqt_slct_etud_inscri_promoOp = $conDb->query($rqt_slct_etud_inscri_promoOp)){
									if($exe_rqt_slct_etud_inscri_promoOp->num_rows>0){
										$nbrToalInscrit=$exe_rqt_slct_etud_inscri_promoOp->num_rows;
											while($result_exe_rqt_slct_etud_inscri_promoOp = $exe_rqt_slct_etud_inscri_promoOp->fetch_assoc()){
												$slct_etud_inscrit_promoOp = "SELECT * FROM tb_etudiant WHERE matricEtud = '".$result_exe_rqt_slct_etud_inscri_promoOp['matricEtud']."'";
												if($ex_slct_etud_inscrit_promoOp = $conDb->query($slct_etud_inscrit_promoOp)){
													if($ex_slct_etud_inscrit_promoOp->num_rows>0){
														$result_etud_inscrit_promoOp = $ex_slct_etud_inscrit_promoOp->fetch_assoc();
														if($result_etud_inscrit_promoOp['sexeEtud']=="M"){
															$nbrToalInscritM = $nbrToalInscritM+1;
														}
														else{
															$nbrToalInscritF = $nbrToalInscritF+1;
														}
													}
												}
												else{
													echo "Erreur lors de v&eacute;rification du sexe de l'&eacute;tudiant.";
												}
												
											}
											
									}
									else{
										echo "Aucun &eacute;tudiant inscrit";
									}	
								}
								else{
									echo "Erreur lors de v&eacute;rification des &eacute;tudiants inscrits recemment.";
								}
							?>
							<div align="center" style="width:98%; height:auto; font-family:'Century Schoolbook'; font-size:16xp;">Statistiques d'inscription</div>
							<div align="center">
								<table width="100%" style="background:#CCCCCC; border:solid 1px #666666; text-align:center;" border="0">
									<tr style="background:#666666; color:#FFFFFF;">
										<td>M</td>
										<td>F</td>
										<td>Total</td>
									</tr>
									<tr>
										<td><?php echo $nbrToalInscritM; ?></td>
										<td><?php echo $nbrToalInscritF; ?></td>
										<td><?php echo $nbrToalInscrit; ?></td>
									</tr>
								</table>
							</div>
						</td>
					</tr>
				</table>

			</div>
			
			<div>
				<?php 
					if($exe_rqt_list_etud_PromoOp = $conDb->query($rqt_list_etud_PromoOp)){
						if($exe_rqt_list_etud_PromoOp->num_rows>0){
							?>
							<table style="width:100%; border:solid 1px #FFFFFF; font-size:12px;">
							  <tr style="background:#D6D6D6; border:solid 1px ; text-transform:uppercase;">
								<td rowspan="2"><div align="center">N&deg;</div></td>
								<td rowspan="2"><div align="center">NOM</div></td>
								<td rowspan="2"><div align="center">POSTNOM</div></td>
								<td rowspan="2"><div align="center">PRENOM</div></td>
								<td rowspan="2"><div align="center">SEXE</div></td>
								<?php 
									if (isset($_GET["stage"])) {
										$cours = "stage";
									 	?>
										<td ><div align="center">1er L</div></td>
										<td ><div align="center">2em L</div></td>
										<td ><div align="center">Ets</div></td>
									 	<td ><div align="center">TOT</div></td>
									 	<?php 
									}
									elseif(isset($_GET["tfc_memoire"])){
										$cours = "tfc_memoire";
										?>
										<td ><div align="center">1er L</div></td>
										<td ><div align="center">2em L</div></td>
										<td ><div align="center">Directeur</div></td>
									 	<td ><div align="center">TOT</div></td>
									 	<?php 
									}
									else{
									 	?>
										<td colspan="3"><div align="center">MOYENNE</div></td>
										<td rowspan="2"><div align="center">EXA. S1 <br>10</div></td>
										<td rowspan="2"><div align="center">TOT. S1 <br>20</div></td>
										<td rowspan="2"><div align="center">EXA. S2</div><br>10</td>
										<td rowspan="2"><div align="center">TOT.S2</div><br>20</td>
									<?php 
									}
								?>
							  </tr>
							  <tr style="background:#D6D6D6; border:solid 1px ; text-transform:uppercase;">
							  	<?php 
									if (isset($_GET["stage"])||isset($_GET["tfc_memoire"])) {
									 	?>
										<td><div align="center">5</div></td>
										<td><div align="center">5</div></td>
										<td><div align="center">10</div></td>
										<td><div align="center">20</div></td>
										<?php 
									}
									else{
									 	?>
										<td><div align="center">TP /5</div></td>
										<td><div align="center">INT /5</div></td>
										<td><div align="center">TOT /10</div></td>
										<?php 
									}
								?>
								
							  </tr>
								<?php 
									$numOrdre=0;
									$ligneForm = 1;
									while($tb_listEtud = $exe_rqt_list_etud_PromoOp->fetch_assoc()){
										?>
										<tr style="text-transform:uppercase;<?php if ($ligneForm == 2){echo "background:#D6D6D6;"; $ligneForm =1;}else{$ligneForm =$ligneForm +1;} ?>">
											<td id="<?php echo $tb_listEtud["matricEtud"]; ?>">
												<div align="right"><?php echo $numOrdre=$numOrdre+1; ?></div>
											</td>
											<td><div align="left"><?php echo $tb_listEtud["nomEtud"];?></div></td>
											<td><div align="left"><?php echo $tb_listEtud["postnomEtud"];?></div></td>
											<td><div align="left"><?php echo $tb_listEtud["prenomEtud"];?></div></td>
											<td><div align="center"><?php echo $tb_listEtud["sexeEtud"];?></div></td>
											<?php 
												if (isset($_GET["stage"])||isset($_GET["tfc_memoire"])) {
												 	?>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<?php 
												}
												else{
												 	?>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
													<?php 
												}
											?>
											
											
										</tr>
										<?php 
									}
								?>
							</table>
							<div align="right">Fait à .......................,  le ....../....../...... </div>
							<div style="height:120px; line-height: 120px;" >
								<table style="width:100%">
									<tr>
										<td><div align="center">Doyen</div> </td>
										<td><div align="center">Eneginant</div></td>
									</tr>
								</table>
							</div>
							<?php 
						}
						else{
							echo "Aucun &eacute;tudiant inscrit.";
						}
					}
					else{
						echo "Erreur lors d'&eacute;tablissement de a liste";
					}
				?>
			</div>
		</div>
		<div align="right">
			<?php 	
				if (!isset($_GET['imPRessIoN'])) {
					echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&imPRessIoN&ficheCS&".$cours."&aca=".$an_aca."'><img src='B_mbindi/Biamunda/icon/print.ico' class='ico' >
							<br>Imprimer</a>";
				}
			?>
		</div> 
		<?php	

	}
 ?>
