
<?php 
//dans rqt_verification_promo_op

	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['inScriPtion'])||isset($_GET["iNscrir"])||isset($_GET["lisSte"])){?>
		<style type="text/css">
		<!--
			.menuInscription{
				width:98%; height:auto; font-family:'Century Schoolbook'; text-align:left; margin:10px;  
			}
			<?php 
				if(isset($_GET['iNscrir'])){?>
					.divFormInscript, .divInfoInscript{
						height:auto; display:inline; float:left; border:solid 1px #CCCCCC; padding:5px; 
					}
					.divFormInscript{
						width:60%;   
					}
					.divInfoInscript{
						width:36%; 
					}
					<?php 
				} 
				else{
					?>
					.divFormInscript{
						width:99%;   height:auto; border:solid 1px #CCCCCC; padding:5px; background: #ffffff;
					}
					<?php
				}
			?>				
		-->
		</style>
		 
		<div class="menuInscription" id="inscrir">
			<?php 
				
				echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&inScriPtion&iNscrir#i'>Inscrire</a> &emsp;|&emsp;";
				echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&inScriPtion&rEiNscrir#i'>Réinscrire</a> &emsp;|&emsp;";
				echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&inScriPtion&lisSte'>Liste d'étudiants inscrits</a> &emsp;|&emsp;";
				echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&inScriPtion&liStprEsence'>Liste de présence</a> &emsp;|&emsp;";
				//echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&inScriPtion&ce'>Carte d'&eacute;tudiant</a> &emsp;|&emsp;";
				echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&inScriPtion&ficheCS'>Fiche de cotation standard</a>";
			
			 ?>
		</div>
		<div id="listAca">
			<?php include("B_mbindi/Biamunda/list_aca.php"); ?>
		</div>
		<div align="left">
			<table width="87%" bgcolor="#ffffff">
				<tr>
					<td>
						<div class="divFormInscript">
							<?php 
								include("B_mbindi/Inscription/reinscription.php");
								include("B_mbindi/Inscription/liste_etudiant_PromoOp.php");
								include("B_mbindi/Inscription/f_inscription.php"); 
								include("B_mbindi/Inscription/liste_presence.php");
								include("B_mbindi/Inscription/cartes_etudiants.php");
								include("B_mbindi/Inscription/fiche_cotation_standard.php");

							?>
						</div>
						<?php if(isset($_GET['iNscrir'])){?>
							<div class="divInfoInscript">
								<?php 
									include("B_mbindi/Inscription/rqt_statistique_inscrits_promoOp.php");
									
									include("B_mbindi/Inscription/rqt_inscrits_recement.php");
								?>
							</div>
						<?php }?>
					
					</td>
				</tr>
			</table>
		</div>
		 <?php 	
	}

?>