<?php 
	if(isset($_GET["rEiNscrir"]) and ($_SESSION['idAnAca'] != $an_aca)){
	
		$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";
		 ?>
		<div>
			<div>
				<h2 align="center">LISTE DES ANCIENS ETUDIANTS A REINSCRIRE</h2>
			</div>

			<div style="width:99%; height:auto; border:solid 1px #CCCCCC;">
				<table cellpadding="0" cellspacing="0" style="width:99%;" >
					<tr>
						<td>
							<h2>
								Promotion :&nbsp; <?php echo  $_GET['pRomotIon']."&nbsp;".$designOpOrgV;?><br/>
								Ann&eacute;e acad&eacute;mique : <?php echo  $an_aca;?> 
							</h2>
						</td>
						<td>
							<?php 
								$nbrToalInscrit = 0;
								$nbrToalInscritM = 0;
								$nbrToalInscritF = 0;
								
								if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}
								
								$rqt_slct_etud_inscri_promoOp = "SELECT * FROM tb_inscription WHERE idProm = '".$idPromoOrgV."' and idOp = '".$idOpOrgV."' and idAca = '".$an_aca."'";
								if($exe_rqt_slct_etud_inscri_promoOp = $conDb->query($rqt_slct_etud_inscri_promoOp)){
									if($exe_rqt_slct_etud_inscri_promoOp->num_rows>0){
										$nbrToalInscrit=$exe_rqt_slct_etud_inscri_promoOp->num_rows;
										while($result_exe_rqt_slct_etud_inscri_promoOp = $exe_rqt_slct_etud_inscri_promoOp->fetch_assoc()){
											$slct_etud_inscrit_promoOp = "SELECT * FROM tb_etudiant WHERE matricEtud = '".$result_exe_rqt_slct_etud_inscri_promoOp['matricEtud']."'";
											if($ex_slct_etud_inscrit_promoOp = $conDb->query($slct_etud_inscrit_promoOp)){
												if($ex_slct_etud_inscrit_promoOp->num_rows>0){
													$result_etud_inscrit_promoOp = $ex_slct_etud_inscrit_promoOp->fetch_assoc();
													if($result_etud_inscrit_promoOp['sexeEtud']=="M"){
														$nbrToalInscritM = $nbrToalInscritM+1;
													}
													else{
														$nbrToalInscritF = $nbrToalInscritF+1;
													}
												}
											}
											else{
												echo "Erreur lors de v&eacute;rification du sexe de l'&eacute;tudiant.";
											}
											
										}
											
									}
									else{
										echo "Aucun &eacute;tudiant inscrit";
									}	
								}
								else{
									echo "Erreur lors de v&eacute;rification des &eacute;tudiants inscrits recemment.";
								}
							?>
							<div align="center" style="width:98%; height:auto; font-family:'Century Schoolbook'; font-size:16xp;">Statistiques d'inscription</div>
							<div align="center">
								<table width="100%" style="background:#CCCCCC; border:solid 1px #666666; text-align:center;" border="0">
									<tr style="background:#666666; color:#FFFFFF;">
										<td>M</td>
										<td>F</td>
										<td>Total</td>
									</tr>
									<tr>
										<td><?php echo $nbrToalInscritM; ?></td>
										<td><?php echo $nbrToalInscritF; ?></td>
										<td><?php echo $nbrToalInscrit; ?></td>
									</tr>
								</table>
							</div>
						</td>
					</tr>
				</table>

			</div>
			
			<div>
				<?php 
					if($exe_rqt_list_etud_PromoOp = $conDb->query($rqt_list_etud_PromoOp)){
						if($exe_rqt_list_etud_PromoOp->num_rows>0){
							?>
							<table style="width:100%; border:solid 1px #FFFFFF; font-size:12px;">
							  <tr style="background:#D6D6D6; border:solid 1px ; text-transform:uppercase;">

								<td><div align="center">N&deg;</div></td>
								<td><div align="center">NOM</div></td>
								<td><div align="center">POSTNOM</div></td>
								<td><div align="center">PRENOM</div></td>
								<td><div align="center">SEX</div></td>
								<td><div align="center">MATRICULE</div></td>
								<td><div align="center">%</div></td>
								<td><div align="center">MENTION</div></td>
								<td><div align="center">SESSION</div></td>
							  </tr>
									<?php 
									$numOrdre=0;
									$ligneForm = 1;
									while($tb_listEtud = $exe_rqt_list_etud_PromoOp->fetch_assoc()){
										?>
										<tr style="text-transform:uppercase;<?php if ($ligneForm == 2){echo "background:#D6D6D6;"; $ligneForm =1;}else{$ligneForm =$ligneForm +1;} ?>">
											<td id="<?php echo $tb_listEtud["matricEtud"]; ?>">
												<div align="right"><?php echo $numOrdre=$numOrdre+1; ?></div>
											</td>
											<td>
												<div align="left">
														<?php echo $tb_listEtud["nomEtud"];?>
												</div>
											</td>
											<td><div align="left"><?php echo $tb_listEtud["postnomEtud"];?></div></td>
											<td><div align="left"><?php echo $tb_listEtud["prenomEtud"];?></div></td>
											<td><div align="center"><?php echo $tb_listEtud["sexeEtud"];?></div></td>
											<td>
												<a href="?profil&id=<?php echo $tb_listEtud['matricEtud'] ?>">
													
													<div align="right"><?php echo $tb_listEtud["matricEtud"];?>
													</div>
												</a>
											</td>
											<?php 
												for ($i=1; $i <= 2; $i++) { 
													if ($i==1) 
														$session = "s2";
													else
														$session="s1";

													
													$rqt_slct_d = "select * from tb_deliberation where  matricEtud ='".$tb_listEtud['matricEtud']."' and idPromo = '".$_GET['pRomotIon']."' and idOp = '".$idOpOrgV."' and idAnAca = '".$an_aca."' and session = '".$session."'";
													if($exe_rqt_slct_d = $conDb->query($rqt_slct_d)){
														if($tb_delib = $exe_rqt_slct_d->fetch_assoc()){
															echo "<td>";
																echo "<div align='right'>";
																	echo $tb_delib["prctg"];
																echo "<div>";
															echo "</td>";
															echo "<td>";
																
																if( $tb_delib["mention"]=="AA"){
																	echo "Assumulé aux ajournés";
																}
																if( $tb_delib["mention"]=="A"){
																	echo "Ajourné";
																}
																if( $tb_delib["mention"]=="S"){
																	echo "Satisfaction";
																}
																if( $tb_delib["mention"]=="D"){
																	echo "Distinction";
																}
																if( $tb_delib["mention"]=="GD"){
																	echo "Grande distinction";
																}
																if( $tb_delib["mention"]=="PGD"){
																	echo "Plus grande distinction";
																}
															echo "</td>";
															echo "<td>";
																echo $session;
															echo "</td>";
															$i=3;
														}
														else{
															if ($i==2) {
																echo "<td>";
																echo "</td>";
																echo "<td>";
																	echo "Pas de mention";
																echo "</td>";
																echo "<td>";
																echo "</td>";
															}
															
														}

													}
													else{
														echo "Erreur";
													}
												}
											?>
											
										</tr>
										<?php 
										
									}
									?>
							
							</table>
							<?php 
						}
						else{
							echo "Aucun &eacute;tudiant inscrit.";
						}
					}
					else{
						echo "Erreur lors d'&eacute;tablissement de a liste";
					}
				?>
			</div>
		</div>
		<p>
			<?php 	echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&imPRessIoN&lisSteEtud'>Imprimer</a>";	?>
		</p>
		<?php
	}
 ?>
