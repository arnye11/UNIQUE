<?php 
if (isset($_POST['BtSupReinscription']) and isset($_GET["modifInscrit"])){ 
	$aca = filter_input(INPUT_POST,'aca', FILTER_SANITIZE_SPECIAL_CHARS);
	$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
	$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
	$matricEtud = $_SESSION['matricEtud'];
	
	if($matricEtud!="" and $idPromo!="" and $idOp!="" and $aca!=""){
		$rqt = "SELECT * FROM tb_inscription WHERE matricEtud='".$matricEtud."' and idAca='".$aca."'";
		if($exe_rqt = mysqli_query($con, $rqt)){ 
			if(mysqli_num_rows($exe_rqt)>0){

				$annuler_inscription = 0;

				$rqt_verif = "SELECT * FROM tb_versement WHERE matEtud = '".$matricEtud."' and idAca='".$aca."'";
				if($ex_rqt_verif= $conDb->query($rqt_verif)){
					if(mysqli_num_rows($ex_rqt_verif)>0) {
						$annuler_inscription += 1;
					}
				}
				else{
					$annuler_inscription += 1;
				}
				$rqt_verif = "SELECT * FROM tb_cote WHERE matricEtud = '".$matricEtud."' and idAca='".$aca."'";
				if($ex_rqt_verif = $conDb->query($rqt_verif)){
					if(mysqli_num_rows($ex_rqt_verif)>0) {
						$annuler_inscription += 1;
					}
				}
				else{
					$annuler_inscription += 1;
				}

				if ($annuler_inscription == 0 ) {
					$rqt_supEtudInsc = "DELETE FROM tb_inscription WHERE matricEtud =  '".$matricEtud."' and idAca='".$aca."'";
					if($exe_rqt_supEtudInsc = $conDb->query($rqt_supEtudInsc)){
						header ('location:?profil&id='.$matricEtud."&cursus&ms=Inscription annulée");
					}
					else{
						$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' class='icon' /> Impossible d'annuler l'inscription de cet &eacute;tudiant.</div>";
					}
				}
				else{
					$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' class='icon' /> Vous n'avez pas le droit de faire cette opr&eacute;ration.</div>";
				}	
			}
			else{
				$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' class='icon' /> L'&eacute;tudiant n'existe pas</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' class='icon' /> Echec de v&eacute;rification</a> ";
		}
	}
	else{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbindi/Biamunda/icon/info.ico' class='icon' /> Les champs sont vide</a> ";
	}

}
				
?>