<?php 
	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['inScriPtion'])and isset($_POST['BtInscrir'])){
		$nomEtud = filter_input(INPUT_POST,'nomEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$postnomEtud = filter_input(INPUT_POST,'postnomEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$prenomEtud = filter_input(INPUT_POST,'prenomEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$sexeEtud = filter_input(INPUT_POST,'sexeEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$dateNaissEtud = filter_input(INPUT_POST,'dateNaissEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		/*
		$jrNaissEtud = filter_input(INPUT_POST,'jrNaissEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$moiNaissEtud = filter_input(INPUT_POST,'moiNaissEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$AnNaissEtud = filter_input(INPUT_POST,'AnNaissEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		
		$dateNaissEtud = $AnNaissEtud."-".$moiNaissEtud."-".$jrNaissEtud;
		*/
		
		$LieuNaiss = filter_input(INPUT_POST,'LieuNaiss', FILTER_SANITIZE_SPECIAL_CHARS);
		$sectionSuivEtud = filter_input(INPUT_POST,'sectionSuivEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$PourctgEtud = filter_input(INPUT_POST,'PourctgEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$TelEtud = filter_input(INPUT_POST,'TelEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$EmailEtud = filter_input(INPUT_POST,'EmailEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$adresseEtud = filter_input(INPUT_POST,'adresseEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$AvatarEtud = filter_input(INPUT_POST,'AvatarEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$nomPereEtud = filter_input(INPUT_POST,'nomPereEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$nomMereEtud = filter_input(INPUT_POST,'nomMereEtud', FILTER_SANITIZE_SPECIAL_CHARS);

		if($nomEtud!="" and $postnomEtud!="" and $prenomEtud!="" and $sexeEtud!="" and $dateNaissEtud!="" and $LieuNaiss!="" and $idPromo!="" and $idOp!=""){
			//CREATION DU MATRICULE DE L'ETUDIANT
			$matriculEtud = time()."U";
			$matriculManuel = $matriculEtud ;
			//ENREGISTRMENT DE L'ETUDIANT
			$rqt_insrt_etud = "INSERT INTO tb_etudiant VALUES('".$matriculEtud."','".$matriculManuel."','".$nomEtud."','".$postnomEtud."','".$prenomEtud."','".$sexeEtud."','".$dateNaissEtud."','".$LieuNaiss."','".$sectionSuivEtud."','".$PourctgEtud."','".$TelEtud."','".$EmailEtud."','".$adresseEtud."','".$AvatarEtud."', NOW(), '".$nomPereEtud."','".$nomMereEtud."')";
			if($exe_rqt_insrt_etud = mysqli_query($con, $rqt_insrt_etud)){
				//INSCRIPTION ETUDIANT
				$rqt_inscription = "INSERT INTO tb_inscription VALUES(NULL,'".$matriculEtud."','".$idOp."','".$idPromo."','".$_SESSION['idAnAca']."','".$_SESSION['idAutoDec']."',NOW())";
				if($exe_rqt_inscription = mysqli_query($con, $rqt_inscription)){
					$inscription_etud = true;
					include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Inscription/rqt_upload_avatar_etud.php");
					$sms_inscription = "<div class='reussite'>L'&eacute;tudiant ".$nomEtud."&nbsp;".$postnomEtud."&nbsp;".$prenomEtud." a &eacute;t&eacute; inscrit avec succ&egrave;s.<br>Matricule : ".$matriculEtud."</div>";
					$nomEtud = ""; 
					$postnomEtud = "";
					$prenomEtud = "";
					$sexeEtud = "";
					$jrNaissEtud = "";
					$moiNaissEtud = "";
					$AnNaissEtud = "";
					
					$dateNaissEtud = "";
					
					$LieuNaiss = "";
					$sectionSuivEtud = "";
					$PourctgEtud = "";
					$TelEtud = "";
					$EmailEtud = "";
					$adresseEtud = "";
					$nomPereEtud = "";
					$nomMereEtud = "";
				}
				else{
					$sms_inscription = "<div class='erreur'>Erreur lors d'inscription de l'étudiant : ".$matriculEtud." dans la promotion de ".$idPromo.", option ".$idOp.". Mais ses identités sont sauvegardées. Contacter d'urigence l'Administrateur pour ce cas.</div>";
				}
			}
			else{
				$sms_inscription = "<div style='color:#FF0000'>Impossible de sauvegarder les identités de : ".$prenomEtud." &nbsp; ".$nomEtud." &nbsp; ".$postnomEtud.". Contacter d'urigence l'Administrateur pour ce cas.</div>";
			}
		}
		else{
			$sms_inscription = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	}
?>

