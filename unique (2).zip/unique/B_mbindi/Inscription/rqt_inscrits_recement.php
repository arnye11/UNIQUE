<?php 
if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['inScriPtion'])){
	?>
	<style>
		<--
			
			
		-->
	</style>		
	<?php 
	$nbrEtudInscriRec;
	if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}

	$rqt_slct_etud_recem_inscri = "select * from tb_inscription where idProm = '".$idPromoOrgV."' and idOp = '".$idOpOrgV."' and idAca = '".$an_aca."' and dateInscrit BETWEEN '".$date_moins_3."' and NOW() ORDER BY dateInscrit DESC";
	if($exe_rqt_slct_etud_recem_inscri = $conDb->query($rqt_slct_etud_recem_inscri)){
		if($exe_rqt_slct_etud_recem_inscri->num_rows>0){
			$nbrEtudInscriRec=$exe_rqt_slct_etud_recem_inscri->num_rows;
			echo "<h3>Inscrits R&eacute;cemment(".$nbrEtudInscriRec.")</h3>";
			?>
			<div align="center" id="">
				<div style="width:98%;height:400px; <?php if ($nbrEtudInscriRec>3){?> overflow:scroll;<?php } ?> padding-right:3px;	background:#FFFFFF;	border:solid 1px #FFCC33;color:#333333; margin-top:30px;margin-bottom:10px; box-shadow:2px 2px 2px 2px #666666;" align="center">
					<?php
						while($result_exe_rqt_slct_etud_recem_inscri = $exe_rqt_slct_etud_recem_inscri->fetch_assoc()){
							$slct_etud = "select *, DAY(datenaissEtud) AS jrNais, MONTH(datenaissEtud) AS mmNais, YEAR(datenaissEtud) AS aaaaNais from tb_etudiant where matricEtud = '".$result_exe_rqt_slct_etud_recem_inscri['matricEtud']."'";
							if($ex_slct_etud = $conDb->query($slct_etud)){
								if($result_slct_etud = $ex_slct_etud->fetch_assoc()){
									?>
									<p>
										<table class = "profilInscriRec">
											<tr>
												<td>												
													<div class="profilInscriRec11" align="center">
														<img src="B_mbidndi/Biamunda/media/<?php echo $result_slct_etud['matricEtud']."/".$result_slct_etud['avantarEtud'];?>" alt="Pas de Photo" width="100%" height="100%" />
													</div>
													<div class="profilInscriRec12" align="left">
														<?php 
																echo "<a href='?profil&id=".$result_slct_etud['matricEtud']."' style='text-transform:uppercase'>";
																echo $result_slct_etud['nomEtud']."&nbsp;".$result_slct_etud['postnomEtud']."&nbsp;".$result_slct_etud['prenomEtud']."&nbsp;<br/> Matr. : ".$result_slct_etud['matricEtud']."<br/>";

																if ($result_slct_etud['sexeEtud']=="M"){ 
																	echo "N&eacute; &agrave; ";
																}
																else { 
																	echo "N&eacute;e &agrave; ";
																} 
																echo $result_slct_etud['lieunaisEtud'].", le ";
																if($result_slct_etud['jrNais']<10){
																	echo "0".$result_slct_etud['jrNais'];
																}
																else{
																	echo $result_slct_etud['jrNais'];
																}
																echo "/ ";
																if($result_slct_etud['mmNais']<10){
																	echo "0".$result_slct_etud['mmNais'];
																}
																else{
																	echo $result_slct_etud['mmNais'];
																}
																echo "/";
																echo $result_slct_etud['aaaaNais']."."; 
																echo "</a><br>";
																/*****************************************/
																$slct_op = "select * from tb_option where idOp = '".$result_exe_rqt_slct_etud_recem_inscri['idOp']."'";
																if($exe_slct_op = $conDb->query($slct_op)){
																	if($result_slct_op = $exe_slct_op->fetch_assoc()){
																		$slct_fac = "select * from tb_faculte where idFac = '".$result_slct_op['idFac']."'";
																		if($exe_slct_fac = $conDb->query($slct_fac)){
																			if($result_slct_fac = $exe_slct_fac->fetch_assoc()){
																				echo "Enscrit en :<br/>";
																				echo "<a href=''>".$result_exe_rqt_slct_etud_recem_inscri['idProm']."&ensp;".$result_slct_op['designOp']."</a><br>".$result_exe_rqt_slct_etud_recem_inscri['dateInscrit']."<br/>";
																			}
																		}
																	}
																}
														?>
													</div>
													
												</td>
											</tr>
										</table>
									</p>
										<?php
									}
								else
									{
									echo "Aucune information trouv�e.";
									}
								}
							else
								{
								echo "Erreur lors de r&eacute;cup&eacute;ration des identit&eacute;s de l'&eacute;tudiant.";
								}
							
						}
					?>
				</div>
			</div>
			<?php
			}
		else
			{
			echo "Aucun inscrit ce dernier temps";
			}	
		}
	else{
	echo "Erreur lors de v&eacute;rification des &eacute;tudiants inscrits recemment.";
	}
}
?>