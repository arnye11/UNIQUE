<?php 
	if(isset($_GET["lisSte"])){
	
	$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";
	 ?>
<div>
	<div>
		<h2 align="center">
			<?php 
				if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N" || $_GET['pRomotIon']=="L1" || $_GET['pRomotIon']=="Ir1"){
					echo "LISTE DES ETUDIANTS INSCRITS";
				}
				else{
					echo "LISTE DES ETUDIANTS REINSCRITS";
				}
			?>
		</h2>
	</div>

	<div style="width:99%; height:auto; border:solid 1px #CCCCCC;">
		<table cellpadding="0" cellspacing="0" style="width:99%;" >
			<tr>
				<td>
					<h2>
						Promotion :&nbsp; <?php echo  $_GET['pRomotIon']."&nbsp;".$designOpOrgV;?><br/>
						Ann&eacute;e acad&eacute;mique : <?php echo  $an_aca;?> 
					</h2>
				</td>
				<td>
					<?php 
						$nbrToalInscrit = 0;
						$nbrToalInscritM = 0;
						$nbrToalInscritF = 0;
						
						if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}
						
						$rqt_slct_etud_inscri_promoOp = "SELECT * FROM tb_inscription WHERE idProm = '".$idPromoOrgV."' and idOp = '".$idOpOrgV."' and idAca = '".$an_aca."'";
						if($exe_rqt_slct_etud_inscri_promoOp = $conDb->query($rqt_slct_etud_inscri_promoOp)){
							if($exe_rqt_slct_etud_inscri_promoOp->num_rows>0){
								$nbrToalInscrit=$exe_rqt_slct_etud_inscri_promoOp->num_rows;
									while($result_exe_rqt_slct_etud_inscri_promoOp = $exe_rqt_slct_etud_inscri_promoOp->fetch_assoc()){
										$slct_etud_inscrit_promoOp = "SELECT * FROM tb_etudiant WHERE matricEtud = '".$result_exe_rqt_slct_etud_inscri_promoOp['matricEtud']."'";
										if($ex_slct_etud_inscrit_promoOp = $conDb->query($slct_etud_inscrit_promoOp)){
											if($ex_slct_etud_inscrit_promoOp->num_rows>0){
												$result_etud_inscrit_promoOp = $ex_slct_etud_inscrit_promoOp->fetch_assoc();
												if($result_etud_inscrit_promoOp['sexeEtud']=="M"){
													$nbrToalInscritM = $nbrToalInscritM+1;
												}
												else{
													$nbrToalInscritF = $nbrToalInscritF+1;
												}
											}
										}
										else{
											echo "Erreur lors de v&eacute;rification du sexe de l'&eacute;tudiant.";
										}
										
									}
									
							}
							else{
								echo "Aucun &eacute;tudiant inscrit";
							}	
						}
						else{
							echo "Erreur lors de v&eacute;rification des &eacute;tudiants inscrits recemment.";
						}
					?>
					<div align="center" style="width:98%; height:auto; font-family:'Century Schoolbook'; font-size:16xp;">Statistiques d'inscription</div>
					<div align="center">
						<table width="100%" style="background:#CCCCCC; border:solid 1px #666666; text-align:center;" border="0">
							<tr style="background:#666666; color:#FFFFFF;">
								<td>M</td>
								<td>F</td>
								<td>Total</td>
							</tr>
							<tr>
								<td><?php echo $nbrToalInscritM; ?></td>
								<td><?php echo $nbrToalInscritF; ?></td>
								<td><?php echo $nbrToalInscrit; ?></td>
							</tr>
						</table>
					</div>
				</td>
			</tr>
		</table>

	</div>
	
	<div>
		<?php 
			if($exe_rqt_list_etud_PromoOp = $conDb->query($rqt_list_etud_PromoOp)){
				if($exe_rqt_list_etud_PromoOp->num_rows>0){
					?>
					<table style="width:100%; border:solid 1px #FFFFFF; font-size:12px;">
					  <tr style="background:#D6D6D6; border:solid 1px ; text-transform:uppercase;">
						<td><div align="center">N&deg;</div></td>
						<td><div align="center">NOM</div></td>
						<td><div align="center">POSTNOM</div></td>
						<td><div align="center">PRENOM</div></td>
						<td><div align="center">SEX</div></td>
						<td><div align="center">MATRICULE</div></td>
						<td><div align="center">LIEU NAISS. </div></td>
						<td><div align="center">DAT. NAIS. </div></td>
						<td><div align="center">TELEPHO</div></td>
						<td><div align="center">ADRESSE</div></td>
						<?php 
							if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N"){
								?>
								<td><div align="center">Section</div></td>
								<td><div align="center">%</div></td>
								<td><div align="center">PERE</div></td>
								<td><div align="center">MERE</div></td>
								<?php 
							}
						?>
						<td><div align="center">...</div></td>
					  </tr>
							<?php 
							$numOrdre=0;
							$ligneForm = 1;
							while($tb_listEtud = $exe_rqt_list_etud_PromoOp->fetch_assoc()){
								if(isset($_GET["modifEtud"]) and $_GET["modifEtud"] == $tb_listEtud["matricEtud"]){
									if(isset($_POST['BtUpdtIdEtud'])||isset($_GET["sup"])){
										$nbcol = 0;
										if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N"){ $nbcol =15;}else{$nbcol=11;}
										?>
										<tr id="<?php echo $tb_listEtud["matricEtud"]; ?>" style="background:#ffefef; color: #d80f26; font-size: 19px;">
											<td colspan="<?php echo $nbcol; ?>">
												<?php echo $sms_gerer; ?>
											</td>
										</tr>
										<?php
									}
								?>
								<form action="" method="post" >
									<tr style="text-transform:uppercase;background:#41b33b; <?php if ($ligneForm == 2){$ligneForm =1;}else{$ligneForm =$ligneForm +1;} ?>">
										<td id="<?php echo $tb_listEtud["matricEtud"]; ?>">
											<div align="right" style="">
												<?php
													if(isset($_GET["modifEtud"])){
														echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&lisSte&modifEtud=".$tb_listEtud["matricEtud"]."&sup#".$tb_listEtud["matricEtud"]."'><img src='B_mbidndi/Biamunda/icon/supp.gif' class='icon' align='left' alt='Supp.' title='Supprimer cet étudiant'/> </a>";
														$numOrdre=$numOrdre+1;
													}
													else{
														 echo $numOrdre=$numOrdre+1; 
													}
												?>
											</div>					    
										</td>
										<td>
											<div align="left">
												<input name="nomEtud" type="text"  value="<?php echo $tb_listEtud["nomEtud"];?>" style="width:88%; height:20px;font-size:9px; text-transform:capitalize;" />
											</div>
										</td>
										<td>
											<div align="left">
												<input name="postnomEtud" type="text" value="<?php echo $tb_listEtud["postnomEtud"];?>"  style="width: 88%; height:20px;font-size:11px; text-transform:capitalize;" />
											</div>
										</td>
										<td>
											<div align="left"><input name="prenomEtud" type="text" value="<?php echo $tb_listEtud["prenomEtud"];?>"  style="width: 88%;  height:20px;font-size:11px;"  />
											</div>
										</td>
										<td>
											<div align="center">
												<input maxlength="1" name="sexeEtud" type="text" value="<?php echo $tb_listEtud["sexeEtud"];?>" style="width: 70%; text-transform:capitalize; height:20px;font-size:11px; " />
											</div>
										</td>
										<td>
											<div align="right">
												<?php echo $tb_listEtud["matricEtud"];?>
												<input name="matricEtud" type="hidden" value="<?php echo $tb_listEtud["matricEtud"];?>"/>
											</div>
										</td>
										<td>
											<div align="left">
												<input name="lieunaisEtud" type="text" value="<?php echo $tb_listEtud["lieunaisEtud"];?>" style="width: 88%; height:20px;font-size:9px; height:20px;font-size:11px;"  />
											</div>
										</td>
										<td>
											<div align="right">
												<input name="datenaissEtud" type="text" value="<?php echo $tb_listEtud["datenaissEtud"];?>"  style="width: 65px; height:20px;font-size:11px;" maxlength="10" />
											</div>
										</td>
										<td>
											<div align="right">
												<input name="telEtud" type="text" value="<?php echo $tb_listEtud["telEtud"];?>"  style="width: 88%; height:20px;font-size:11px;" />
											</div>
										</td>
										<td>
											<div align="left">
												<input name="adresseEtud" type="text" value="<?php echo $tb_listEtud["adresseEtud"];?>"  style="width: 88%; height:20px;font-size:11px;" />
											</div>
										</td>
										<?php 
											if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N"){
												?>
												<td>
													<div align="left">
														<input name="sectionSuiviEtud" type="text" value="<?php echo $tb_listEtud["sectionSuiviEtud"];?>"  style="width: 88%; height:20px;font-size:11px;" />
													</div>
												</td>
												<td>
													<div align="left">
														<input name="pourctgEtud" type="text" value="<?php echo $tb_listEtud["pourctgEtud"];?>" style="width: 15px; height:20px;font-size:11px;" maxlength="4" />
													</div>
												</td>
												<td>
													<div align="left">
														<input name="nomPereEtud" type="text"  value="<?php echo $tb_listEtud["nomPereEtud"];?>" style="width: 88%; height:20px;font-size:11px;" />
													</div>
												</td>
												<td>
													<div align="left">
														<input name="nomMereEtud" type="text" value="<?php echo $tb_listEtud["nomMereEtud"];?>" style="width: 88%; height:20px;font-size:11px;"  />
													</div>
												</td>
												<?php 
											}
										?>
										<td>
											<div align="left">
												<input name="BtUpdtIdEtud" type="submit" value="OK" style="width: 88%; height:20px;"/>
											</div>
										</td>
									</tr>
								</form>
								<?php 
								}
								else{
							?>
							<tr style="text-transform:uppercase;<?php if ($ligneForm == 2){echo "background:#D6D6D6;"; $ligneForm =1;}else{$ligneForm =$ligneForm +1;} ?>">
								<td id="<?php echo $tb_listEtud["matricEtud"]; ?>">
									<div align="right"><?php echo $numOrdre=$numOrdre+1; ?></div>
								</td>
								<td><div align="left"><?php echo $tb_listEtud["nomEtud"];?></div></td>
								<td><div align="left"><?php echo $tb_listEtud["postnomEtud"];?></div></td>
								<td><div align="left"><?php echo $tb_listEtud["prenomEtud"];?></div></td>
								<td><div align="center"><?php echo $tb_listEtud["sexeEtud"];?></div></td>
								<td><div align="right"><?php echo $tb_listEtud["matricEtud"];?></div></td>
								<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["lieunaisEtud"];?></div></td>
								<td><div align="right"><?php echo $tb_listEtud["datenaissEtud"];?></div></td>
								<td><div align="right"><?php echo $tb_listEtud["telEtud"];?></div></td>
								<td><div align="left"><?php echo $tb_listEtud["adresseEtud"];?></div></td>
								<?php 
									if($_GET['pRomotIon'] == "G1" || $_GET['pRomotIon']=="L1N"){
										?>
										<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["sectionSuiviEtud"];?></div></td>
										<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["pourctgEtud"];?></div></td>
										<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["nomPereEtud"];?></div></td>
										<td><div align="left">&nbsp;&nbsp;<?php echo $tb_listEtud["nomMereEtud"];?></div></td>
										<?php 
									}
								?>
								<td>
									<div align="center">
									<?php 
										echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&lisSte&modifEtud=".$tb_listEtud["matricEtud"]."#".$tb_listEtud["matricEtud"]."'><img src='B_mbidndi/Biamunda/icon/edit.gif' class='icon' alt='Modif.' title='Modifier' /> </a>";
									?>
									</div>
								</td>
							</tr>
							<?php 
								}
							}
							?>
					
					</table>
					<?php 
				}
				else{
					echo "Aucun &eacute;tudiant inscrit.";
				}
			}
			else{
				echo "Erreur lors d'&eacute;tablissement de a liste";
			}
		?>
	</div>
</div>
<p>
	<?php 	echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&imPRessIoN&lisSteEtud'>Imprimer</a>";	?>
</p>
<?php	

	}
 ?>
