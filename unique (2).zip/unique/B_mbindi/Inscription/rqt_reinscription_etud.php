<?php 
	if (isset($_POST['BtReinscrire'])){
		$aca = filter_input(INPUT_POST,'aca', FILTER_SANITIZE_SPECIAL_CHARS);
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$matricEtud = $_SESSION['matricEtud'];
		 
		if($matricEtud!="" and $idPromo!="" and $idOp!=""){
			$rqtVerifInscrit = "SELECT * FROM tb_inscription WHERE matricEtud ='".$matricEtud."' and idAca = '".$_SESSION['idAnAca']."'";
				if($exe_rqtVerifInscrit = mysqli_query($con, $rqtVerifInscrit)){
					if(mysqli_num_rows($exe_rqtVerifInscrit)>0){
						$sms_inscription = "<div class='erreur'>Cet �tudiant est d�j� inscrit cette ann�e</div>";
					}
					else{
						$rqt_inscription = "INSERT INTO tb_inscription VALUES(NULL,'".$matricEtud."','".$idOp."','".$idPromo."','".$_SESSION['idAnAca']."','".$_SESSION['idAutoDec']."',NOW())";
						if($exe_rqt_inscription = mysqli_query($con, $rqt_inscription)){
							$sms_inscription = "<div class='reussite'>R�inscrit</div>";
						}
						else{
							$sms_inscription = "<div class='erreur'>Erreur</div>";
						}
					}
				}
				else{
					$sms_inscription = "<div class='erreur'>Erreur</div>";
				}
		}
		else{
			$sms_inscription = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	}

	
?>

