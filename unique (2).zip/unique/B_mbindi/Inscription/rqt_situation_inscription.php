<?php 
if ((isset($_GET['inscrition_inscrition']) or isset($_GET['inscrition']) or isset($_GET['inscrition_reinscription']) or isset($_GET['inscrition_situation'])))
	{ 
	if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}	
	?>
<div style="background:#FFFFCC; padding-left:5px; padding-right:5px; padding-bottom:5px; margin-bottom:5px; border-bottom:solid 5px #BBBBBB; ">
		<h3>SITUATION INSCRIPTION</h3>
		<?php echo "Ann�e acad�mique ".$an_aca; ?>
        <table width="230" border="0" style="font-size:14px;">
          <tr>
            <td width="110"><div align="center"></div></td>
            <td colspan="5" bgcolor="#EEEEEE"><div align="center">Promotions</div></td>
          </tr>
          <tr bgcolor="#EEEEEE">
            <td >
			<?php if (isset($_GET['inscrition_situation']) or isset($_GET['inscrition_inscrition']) or isset($_GET['inscrition'])){?>
				<div align="center"><!--LIEN + DE DETAILLS/-DE DETAILLE -->
					<a href="<?php if (isset($_GET['inscrition'])){echo "?inscrition_situation";}else{ echo "?inscrition";}?>">
						<?php if (isset($_GET['inscrition_inscrition']) or isset($_GET['inscrition'])){echo "+ de d�taille"; ?><img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>B_mbidndi/Biamunda/icon/arw09rt.ico"/><?php }else{?><img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>B_mbidndi/Biamunda/icon/note16.ico"/> <?php echo "Inscrir un nouveau";}?> </a>				
				</div>	
			<?php }?>
			</td>
            <td width="19"><div align="center">G1</div></td>
            <td width="19"><div align="center">G2</div></td> 
            <td width="19"><div align="center">G3</div></td>
            <td width="20"><div align="center">L1</div></td>
            <td width="17"><div align="center">L2</div></td>
          </tr>
		   <?php 
		  		if (isset($_GET['detaille']) or isset($_GET['inscrition_situation']))
		  			{ 
					$rqt_list_fac = "select * from  tb_faculte order by designFac";
					if($exe_rqt_list_fac = $conDb->query($rqt_list_fac))
						{
						while($result_rqt_list_fac = $exe_rqt_list_fac->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
							{
							  ?>
							  <tr bgcolor="#444444" >
								<td  style="color:#EEEEEE; border-bottom:solid 2px #222222;border-top:solid 2px #222222;"><?php echo $result_rqt_list_fac['designFac']; ?></td>
								<td  style="color:#EEEEEE; border-bottom:solid 2px #222222;">&nbsp;</td>
								<td  style="color:#EEEEEE; border-bottom:solid 2px #222222;">&nbsp;</td>
								<td  style="color:#EEEEEE; border-bottom:solid 2px #222222;">&nbsp;</td>
								<td  style="color:#EEEEEE; border-bottom:solid 2px #222222;">&nbsp;</td>
								<td  style="color:#EEEEEE; border-bottom:solid 2px #222222;">&nbsp;</td>
							  </tr>
							  <?php 
						
							$rqt_list_op = "select * from  tb_option where idFac = '".$result_rqt_list_fac['idFac']."' ORDER BY idOp";
							if($exe_rqt_list_op = $conDb->query($rqt_list_op))
								{
								while($result_rqt_list_op = $exe_rqt_list_op->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
									{
									  ?>
									  <tr bgcolor="#EEEEEE">
										<td >
											<div align="left" style="margin-left:8px; border-bottom:solid 1px #555555;">
											<?php echo  $result_rqt_list_op['designOp'];?></div>										</td>
											
										<td><div align="center">
										  <?php 
											$rqt_nbr_etud_inscrit_g1 = "select count(*) as nbrg1 from tb_inscription where idProm = 'G1' and idAca = '".$an_aca."' and idOp = '".$result_rqt_list_op['idOp']."'";
											if($exe_rqt_nbr_etud_inscrit_g1 = $conDb->query($rqt_nbr_etud_inscrit_g1))
												{
												if($result_rqt_nbr_etud_inscrit_g1 = $exe_rqt_nbr_etud_inscrit_g1->fetch_assoc())
													{
													echo  "<a href = '?inscrition_situation&situation&promotion=G1&Option=".$result_rqt_list_op['idOp']."&fac=".$result_rqt_list_fac['idFac']."'>".$result_rqt_nbr_etud_inscrit_g1['nbrg1']."</a>";
													}
												else
													{
													echo 0;
													}
												}
											else
												{
												echo "X";
												}
										?>
									    </div></td>
										<td><div align="center">
										  <?php 
											$rqt_nbr_etud_inscrit_g2 = "select count(*) as nbrg2 from tb_inscription where idProm = 'G2' and idAca = '".$an_aca."' and idOp = '".$result_rqt_list_op['idOp']."'";
											if($exe_rqt_nbr_etud_inscrit_g2 = $conDb->query($rqt_nbr_etud_inscrit_g2))
												{
												if($result_rqt_nbr_etud_inscrit_g2 = $exe_rqt_nbr_etud_inscrit_g2->fetch_assoc())
													{
													echo  "<a href = '?inscrition_situation&situation&promotion=G2&Option=".$result_rqt_list_op['idOp']."&fac=".$result_rqt_list_fac['idFac']."'>".$result_rqt_nbr_etud_inscrit_g2['nbrg2']."</a>";
													}
												else
													{
													echo 0;
													}
												}
											else
												{
												echo "X";
												}
										?>
									    </div></td>
										<td>
										  <div align="center">
										    <?php 
											$rqt_nbr_etud_inscrit_g3 = "select count(*) as nbrg3 from tb_inscription where idProm = 'G3' and idAca = '".$an_aca."' and idOp = '".$result_rqt_list_op['idOp']."'";
											if($exe_rqt_nbr_etud_inscrit_g3 = $conDb->query($rqt_nbr_etud_inscrit_g3))
												{
												if($result_rqt_nbr_etud_inscrit_g3 = $exe_rqt_nbr_etud_inscrit_g3->fetch_assoc())
													{
													echo  "<a href = '?inscrition_situation&situation&promotion=G3&Option=".$result_rqt_list_op['idOp']."&fac=".$result_rqt_list_fac['idFac']."'>".$result_rqt_nbr_etud_inscrit_g3['nbrg3']."</a>";
													}
												else
													{
													echo 0;
													}
												}
											else
												{
												echo "X";
												}
										?>										
								        </div></td>
										<td>
										  <div align="center">
										    <?php 
											$rqt_nbr_etud_inscrit_l1 = "select count(*) as nbrl1 from tb_inscription where idProm = 'L1' and idAca = '".$an_aca."' and idOp = '".$result_rqt_list_op['idOp']."'";
											if($exe_rqt_nbr_etud_inscrit_l1 = $conDb->query($rqt_nbr_etud_inscrit_l1))
												{
												if($result_rqt_nbr_etud_inscrit_l1 = $exe_rqt_nbr_etud_inscrit_l1->fetch_assoc())
													{
													echo  "<a href = '?inscrition_situation&situation&promotion=L1&Option=".$result_rqt_list_op['idOp']."&fac=".$result_rqt_list_fac['idFac']."'>".$result_rqt_nbr_etud_inscrit_l1['nbrl1']."</a>";
													}
												else
													{
													echo 0;
													}
												}
											else
												{
												echo "X";
												}
										?>										
								        </div></td>
										<td>
										  <div align="center">
										    <?php 
											$rqt_nbr_etud_inscrit_l2 = "select count(*) as nbrl2 from tb_inscription where idProm = 'L2' and idAca = '".$an_aca."' and idOp = '".$result_rqt_list_op['idOp']."'";
											if($exe_rqt_nbr_etud_inscrit_l2 = $conDb->query($rqt_nbr_etud_inscrit_l2))
												{
												if($result_rqt_nbr_etud_inscrit_l2 = $exe_rqt_nbr_etud_inscrit_l2->fetch_assoc())
													{
													echo  "<a href = '?inscrition_situation&situation&promotion=L2&Option=".$result_rqt_list_op['idOp']."&fac=".$result_rqt_list_fac['idFac']."'>".$result_rqt_nbr_etud_inscrit_l2['nbrl2']."</a>";
													}
												else
													{
													echo 0;
													}
												}
											else
												{
												echo "X";
												}
										?>										
								        </div></td>
									  </tr>
								<?php }
								}
							}
						}
					}				
			?>
          <tr bgcolor="#EEEEEE">
            <td><div align="right"><em><strong>Total : &nbsp; </strong></em></div></td>
            <td> 
				<div align="center">
				  <?php 
					$rqt_nbr_tot_etud_inscrit_g1 = "select count(*) as nbrg1 from tb_inscription where idProm = 'G1' and idAca = '".$an_aca."'";
					if($exe_rqt_nbr_tot_etud_inscrit_g1 = $conDb->query($rqt_nbr_tot_etud_inscrit_g1))
						{
						if($result_rqt_nbr_tot_etud_inscrit_g1 = $exe_rqt_nbr_tot_etud_inscrit_g1->fetch_assoc())
							{
							echo  "<a href = '?inscrition_situation&situation&promotion = G1'>".$result_rqt_nbr_tot_etud_inscrit_g1['nbrg1']."</a>";
							}
						else
							{
							echo 0;
							}
						}
					else
						{
						echo "X";
						}
				?>			
			  </div></td>
            <td>
				<div align="center">
				  <?php 
					$rqt_nbr_tot_etud_inscrit_g2 = "select count(*) as nbrg2 from tb_inscription where idProm = 'G2' and idAca = '".$an_aca."'";
					if($exe_rqt_nbr_tot_etud_inscrit_g2 = $conDb->query($rqt_nbr_tot_etud_inscrit_g2))
						{
						if($result_rqt_nbr_tot_etud_inscrit_g2 = $exe_rqt_nbr_tot_etud_inscrit_g2->fetch_assoc())
							{
							echo  "<a href = '?inscrition_situation&situation&promotion = G2'>".$result_rqt_nbr_tot_etud_inscrit_g2['nbrg2']."</a>";
							}
						else
							{
							echo 0;
							}
						}
					else
						{
						echo "X";
						}
				?>			
			  </div></td>
            <td>
				<div align="center">
				  <?php 
					$rqt_nbr_tot_etud_inscrit_g3 = "select count(*) as nbrg3 from tb_inscription where idProm = 'G3' and idAca = '".$an_aca."'";
					if($exe_rqt_nbr_tot_etud_inscrit_g3 = $conDb->query($rqt_nbr_tot_etud_inscrit_g3))
						{
						if($result_rqt_nbr_tot_etud_inscrit_g3 = $exe_rqt_nbr_tot_etud_inscrit_g3->fetch_assoc())
							{
							echo  "<a href = '?inscrition_situation&situation&promotion = G3'>".$result_rqt_nbr_tot_etud_inscrit_g3['nbrg3']."</a>";
							}
						else
							{
							echo 0;
							}
						}
					else
						{
						echo "X";
						}
				?>			
			  </div></td>
            <td>
				<div align="center">
				  <?php 
					$rqt_nbr_tot_etud_inscrit_l1 = "select count(*) as nbrl1 from tb_inscription where idProm = 'L1' and idAca = '".$an_aca."'";
					if($exe_rqt_nbr_tot_etud_inscrit_l1 = $conDb->query($rqt_nbr_tot_etud_inscrit_l1))
						{
						if($result_rqt_nbr_tot_etud_inscrit_l1 = $exe_rqt_nbr_tot_etud_inscrit_l1->fetch_assoc())
							{
							echo  "<a href = '?inscrition_situation&situation&promotion = L1'>".$result_rqt_nbr_tot_etud_inscrit_l1['nbrl1']."</a>";
							}
						else
							{
							echo 0;
							}
						}
					else
						{
						echo "X";
						}
				?>			
			  </div></td>
            <td>
				<div align="center">
				  <?php 
					$rqt_nbr_tot_etud_inscrit_l2 = "select count(*) as nbrl2 from tb_inscription where idProm = 'L2' and idAca = '".$an_aca."'";
					if($exe_rqt_nbr_tot_etud_inscrit_l2 = $conDb->query($rqt_nbr_tot_etud_inscrit_l2))
						{
						if($result_rqt_nbr_tot_etud_inscrit_l2 = $exe_rqt_nbr_tot_etud_inscrit_l2->fetch_assoc())
							{
							echo  "<a href = '?inscrition_situation&situation&promotion = L2'>".$result_rqt_nbr_tot_etud_inscrit_l2['nbrl2']."</a>";
							}
						else
							{
							echo 0;
							}
						}
					else
						{
						echo "X";
						}
				?>		  
			  </div></td>
          </tr>
          <tr bgcolor="#EEEEEE">
            <td colspan="6">
			<?php if (!isset($_GET['inscrition_situation'])){?>
				<div align="center">
					<a href="<?php if (isset($_GET['detaille'])){echo "?inscrition";}else{ echo "?inscrition&detaille";}?>">
						<?php if (isset($_GET['detaille'])){echo "&ndash;&nbsp;";}else{ echo "+&nbsp;";}?> de d&eacute;tailles <img src="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>B_mbidndi/Biamunda/icon/<?php if (isset($_GET['detaille'])){echo "arw09up.ico";}else{ echo "arw09dn.ico";}?>" />					</a>				</div>				
		  <?php }?>
		  </td>
          </tr>
        </table>
</div>
	<?php 
	}

?>