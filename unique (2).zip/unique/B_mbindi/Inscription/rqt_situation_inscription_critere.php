<?php 
if (isset($_GET['inscrition_situation']))
	{ 
	if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}	
	?>
<script type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>


<div style="background:#FFFFCC; padding-left:5px; padding-right:5px; padding-bottom:5px; margin-bottom:5px; border-bottom:solid 5px #BBBBBB;">
	<h3 style="margin-bottom:5px; padding-bottom:5px; border-bottom:solid 1px #004400; ">SITUATION INSCRIPTION
		<br/>
		<form action="?inscrition_situation&aca=<?php echo $_SESSION['idAnAca']; ?>" method="get">
			<select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
				<option value="?inscrition_situation&aca=<?php echo $an_aca; ?>"><?php echo $an_aca; ?></option>
				  <?php 
					$rqt_list_aca = "select * from  an_aca ORDER BY idAnAca DESC";
					if($exe_rqt_list_aca = mysql_query($rqt_list_aca))
						{
						while($result_rqt_list_aca = mysql_fetch_assoc($exe_rqt_list_aca)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
							{?>
							<option value="?inscrition_situation&aca=<?php echo $result_rqt_list_aca['idAnAca']; ?>"><?php echo $result_rqt_list_aca['idAnAca']; ?></option>
				  <?php 
							}
						}
					else
						{
						echo  "<option value=''> <div style='color:FF0000'> Impossible d'atteindre les ann�e acad�miques. <br/>SVP, contacter urigement l'Administrateur pour l'assistance< /div>< /option>";
						}
		  
		  ?>
            </select>
		  
		</form>
	</h3>
<div>
<?php 
	include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/Biamunda/rqt/rqt_situation_inscription_critere_all.php");
	include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/Biamunda/rqt/rqt_situation_inscription_critere_promo_fac_op.php");
}
?>
