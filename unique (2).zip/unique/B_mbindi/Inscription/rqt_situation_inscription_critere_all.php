<?php 
	if (!isset($_GET['promotion']) and !isset($_GET['Option']) and !isset($_GET['fac']))
		{
		$rqt_promo = "select * from promotion order by idPromo";
		$rqt_fac = "select * from faculte order by designFac";
		
		$slct_etud_incrit_prom = $rqt_promo;
			if($exe_slct_etud_incrit_pro = mysql_query($slct_etud_incrit_prom))
				{
				while($result_slct_etud_incrit_pro = mysql_fetch_assoc($exe_slct_etud_incrit_pro))//SI EXECUTION, ON RECUPERE SES INFORMATION 
					{
					$slct_etud_incrit_fac = $rqt_fac;
					if($exe_slct_etud_incrit_fac = mysql_query($slct_etud_incrit_fac))
						{
						while($result_slct_etud_incrit_fac = mysql_fetch_assoc($exe_slct_etud_incrit_fac)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
							{
							$slct_etud_incrit_op = "select * from optionn where idFac = '".$result_slct_etud_incrit_fac['idFac']."'";
							if($exe_slct_etud_incrit_op = mysql_query($slct_etud_incrit_op))
								{
								while($result_slct_etud_incrit_op = mysql_fetch_assoc($exe_slct_etud_incrit_op)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
									{
									  ?>
									<h3 align="left">
									Ann�e acad�mique :  <?php echo $an_aca; ?><br/>
									Promotion :  <?php echo $result_slct_etud_incrit_pro['idPromo']; ?><br/>
									Option :  <?php echo $result_slct_etud_incrit_op['designOp']; ?><br/>
									Facult� : <?php echo $result_slct_etud_incrit_fac['designFac']; ?>
									</h3>
									<div style="border:outset 2px #004400;">
										<strong style="font-size:20px;" >Liste des �tudiants inscrits</strong>
									</div>		
									<div style="background:#EEEEEE; border:solid 1px #33FFFF; padding-bottom:15px; width:auto; height:auto;" align="left" >
										<?php 
										//RQT ETUDIANTS INSCRIT -- CRITERE : DANS PROMOTION, OPTION, DEPARTEMENT, ANNEE ACADEMIQUE selection
										$slct_etud_incrit_pro_op_aca = "select * from inscription where idProm = '".$result_slct_etud_incrit_pro['idPromo']."' and  idOp = '".$result_slct_etud_incrit_op['idOp']."' and  idAca = '".$an_aca."' ORDER BY matricEtud ASC";
										if($exe_slct_etud_incrit_pro_op_aca = mysql_query($slct_etud_incrit_pro_op_aca))
											{
											$nbr = 0;
											while($result_slct_etud_incrit_pro_op_aca = mysql_fetch_assoc($exe_slct_etud_incrit_pro_op_aca)) 
												{
												
												$slct_etud = "select * from etudiant where matricEtud = '".$result_slct_etud_incrit_pro_op_aca['matricEtud']."'";
												if($exe_slct_etud = mysql_query($slct_etud))
													{
													
													while($result_slct_etud = mysql_fetch_assoc($exe_slct_etud)) 
														{
														 ?>
														<table border="0" width="100%">
														  <tr>
															<td>

															<div class="profil_apercu_inscrit11" align="center">
																<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/istia-kabinda/B_mbidndi/Biamunda/media/<?php echo $result_slct_etud['avantarEtud'];?>" alt="Pas de Photo" width="100%" height="100%" /></div>
															<div class="profil_apercu_inscrit22" align="left">
																<?php echo $result_slct_etud['nomEtud']."&nbsp;".$result_slct_etud['postnomEtud']."&nbsp;".$result_slct_etud['prenomEtud']."&nbsp;<br/> Matr. : ".$result_slct_etud['matricEtud'].".<br/>"; 
																if ($result_slct_etud['sexeEtud']=="M"){ echo "N� � ";}else { echo "N�e � ";} echo $result_slct_etud['lieunaisEtud'].", le ".$result_slct_etud['datenaissEtud']."."; ?>
															</div>
															<div class="profil_apercu_inscrit33" align="left" >
																<a href="">Profil</a>
															</div>		  
															</td>
														  </tr>
														</table>
														<?php
														 
														 }
													
													}
												else
													{
													echo "Impossible de retrouver l'�tudiant.";
													}
												$nbr = $nbr + 1;													
												}
											echo $nbr."&nbsp; insctis ";
											}
										else
											{
											echo "Impossible de retrouver les �tudiants inscrits ici.";
											}																									
										?>
									</div>
									<?php 
									}
								}
							else
								{
								echo "Impossible de retrouver l'option.";
								}
							}
						}
					else
						{
						echo "Impossible de retrouver la facult�.";
						}
					}
				}
			else
				{
				echo "Impossible de retrouver la promotion.";
				}
		}
?>
