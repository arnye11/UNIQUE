<?php 
if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn'])and isset($_GET['inScriPtion'])){
	
	$nbrToalInscrit = 0;
	$nbrToalInscritM = 0;
	$nbrToalInscritF = 0;
	
	if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}

	$rqt_slct_etud_inscri_promoOp = "SELECT tb_inscription.*, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$idPromoOrgV."') AND ((tb_inscription.idOp)='".$idOpOrgV."') AND ((tb_inscription.idAca)='".$an_aca."')) ";

	//$rqt_slct_etud_inscri_promoOp = "SELECT * FROM tb_inscription WHERE idProm = '".$idPromoOrgV."' and idOp = '".$idOpOrgV."' and idAca = '".$an_aca."'";

	if($exe_rqt_slct_etud_inscri_promoOp = mysqli_query($con, $rqt_slct_etud_inscri_promoOp)){
		while($tb_etud_inscri = mysqli_fetch_assoc($exe_rqt_slct_etud_inscri_promoOp)){
			$nbrToalInscrit=$nbrToalInscrit+1;
			if($tb_etud_inscri['sexeEtud']=="M"){
				$nbrToalInscritM = $nbrToalInscritM+1;
			}
			else{
				$nbrToalInscritF = $nbrToalInscritF+1;
			}					
		}
	}
	else{
		echo "Erreur lors de v&eacute;rification des &eacute;tudiants inscrits recemment.";
	}
	 ?>
	<div align="center" style="width:98%; height:auto; font-family:'Century Schoolbook'; font-size:16xp;">Statistiques d'inscription</div>
	<div align="center">
		<table width="100%" style="background:#CCCCCC; border:solid 1px #666666; text-align:center;" border="0">
			<tr style="background:#666666; color:#FFFFFF;">
				<td>M</td>
				<td>F</td>
				<td>Total</td>
			</tr>
			<tr>
				<td><?php echo $nbrToalInscritM; ?></td>
				<td><?php echo $nbrToalInscritF; ?></td>
				<td><?php echo $nbrToalInscrit; ?></td>
			</tr>
		</table>
	</div>
	
	 <?php
}
?>