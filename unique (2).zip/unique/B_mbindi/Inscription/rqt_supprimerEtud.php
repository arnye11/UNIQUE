<?php 
//SANNULATION DE L'INSCRIPTIION DE L'ETUDIANT
if (isset($_GET['modifEtud']) and isset($_GET['sup'])){ 
	$matricEtud = $_GET['modifEtud'];
	if ($matricEtud != ""){ 
		
		//VERIFICATION DE L'ETUDIANT
		$annuler_inscription = 0; 
		$rqt_verif = "SELECT * FROM tb_versement WHERE matEtud = '".$matricEtud."' and idAca='".$an_aca."'";
		if($ex_rqt_verif= $conDb->query($rqt_verif)){
			if(mysqli_num_rows($ex_rqt_verif)>0) {
				$annuler_inscription += 1;
			}
		}
		else{
			$annuler_inscription += 1;
		}
		
		//VERIFICATION DE L'ETUDIANT
		$rqt_verif = "SELECT * FROM tb_cote WHERE matricEtud = '".$matricEtud."' and idAca='".$an_aca."'";
		if($ex_rqt_verif = $conDb->query($rqt_verif)){
			if(mysqli_num_rows($ex_rqt_verif)>0) {
				$annuler_inscription += 1;
			}
		}
		else{
			$annuler_inscription += 1;
		}

		//----------------------------------
		//ANNULATION DE L'INSCRIPTION
		if ($annuler_inscription == 0 ) {
			$rqt_supEtudInsc = "DELETE FROM tb_inscription WHERE matricEtud =  '".$matricEtud."'";
			if($exe_rqt_supEtudInsc = $conDb->query($rqt_supEtudInsc)){
				header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&inScriPtion&lisSte#'.$matricEtud);
			}
			else{
				$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/info.ico' /> Impossible d'annuler l'inscription de cet &eacute;tudiant. Contacter d&acute;urigence l&acute;Administrateur pour trouver solution &agrave; ce probl&egrave;me. </div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/w95mbx03.ico' width='20' height='20' />&nbsp;  Vous n'avez pas les droits necessaires pour supprimer cet &eacute;tudiant. Nous vous recommandons de contacter l'Administrateur.</div>";
		}	
	}
	else{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/info.ico' class='icone' />Vous n&acute;avez pas indiqu&eacute; l'&eacute;tudiant &agrave; Supprimer</div>. &nbsp;<a href='?gerer_option&sup_op'>Reaisseyez</a> ";
	}				
}
				
?>