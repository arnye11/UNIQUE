<?php

if(isset($_POST["BtTelAv"])){
	
	$matriculEtud = filter_input(INPUT_POST,'matriculEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		

	/************************************************************
	* Definition des constantes / tableaux et variables
	*************************************************************/
	// Constantes
	define('Dossier', '/B_mbindi/Biamunda/media/'.$matriculEtud.'/'); // Repertoire cible
	define('MAX_SIZE', 1099511627776); // Taille max en octets du fichier
	define('WIDTH_MAX', 80000); // Largeur max de l'image en pixels
	define('HEIGHT_MAX', 80000); // Hauteur max de l'image en pixels
	// Tableaux de donnees
	$tabExt = array('jpg','gif','png','jpeg'); // Extensions autorisees
	$infosImg = array();
	// Variables
	$sms_modif ="";
	$photo = "";
	$extension = '';
	$message = '';
	$nomImage = '';
	/************************************************************
	* Creation du repertoire cible si inexistant
	*************************************************************/
	if( !is_dir( $_SERVER['DOCUMENT_ROOT'].Dossier) ){
		if( !mkdir( $_SERVER['DOCUMENT_ROOT'].Dossier, 0755) ) {
			exit('Erreur : le r�pertoire cible ne peut-�tre cr�� ! V�rifiez que vous diposiez des droits suffisants pour le faire ou cr�ez le manuellement !');
		}
	}
	/************************************************************
	* Script d'upload
	*************************************************************/
	if ($_FILES['avatr']['error']) {
		switch ($_FILES['avatr']['error']){
			case 1: // UPLOAD_ERR_INI_SIZE (la taillle est definie dans le fichier php.ini)
				$sms_avatar = "<div style='color:#FF0000;'>La photo d&eacute;passe la limite autoris&eacute;e par le serveur  !</div>";
				break;
			case 2: // UPLOAD_ERR_FORM_SIZE
				$sms_avatar = "<div style='color:#FF0000;'>La photo d&eacute;passe la limite autoris&eacute;e (2Mo)</div>";
				break;
			case 3: // UPLOAD_ERR_PARTIAL
				$sms_avatar = "<div style='color:#FF0000;'>L'envoi de la photo a �t� interrompu pendant le transfert !</div>";
				break;
			case 4: // UPLOAD_ERR_NO_FILE
				$sms_avatar = "<div style='color:#FF0000;'>La photo que vous avez envoy� a une taille nulle !</div>";
				break;
		}
	}
	else{
		$extension = pathinfo($_FILES['avatr']['name'], PATHINFO_EXTENSION);
		$nouveauNom = $matriculEtud."_".date("d_m_Y-H_i_s").".".$extension;
		$nom = $_FILES['avatr']['tmp_name'];
		move_uploaded_file($nom, $_SERVER['DOCUMENT_ROOT'].Dossier.$nouveauNom);
		$AvatarEtud = $nouveauNom; 
		
		$rqt_updt_avatr = "UPDATE tb_etudiant SET avantarEtud = '".$AvatarEtud."' WHERE matricEtud = '".$matriculEtud."'";
		$rqt_updt_avatr = "UPDATE tb_etudiant SET avantarEtud = '".$AvatarEtud."' WHERE matricEtud = '".$matriculEtud."'";
		if($exe_rqt_updt_avatr = $conDb->query($rqt_updt_avatr)){
			$sms_avatar = "La photo a &eacute;t&eacute; mise &agrave; jour.";	
		}
		else{
			$sms_avatar = "Echec de mise &agrave; jour de la photo du profil.";
			unlink($_SERVER['DOCUMENT_ROOT'].Dossier.$nouveauNom);
		}
	}
	/************************************************************
	* Script d'upload
	*************************************************************/
	// On verifie si le champ est rempli
	/*
	if(!empty($_FILES['avatr']['name'])){
		$sms_avatar = "xxxx";
		// Recuperation de l'extension du fichier
		$extension = pathinfo($_FILES['avatr']['name'], PATHINFO_EXTENSION);
		// On verifie l'extension du fichier
		if(in_array(strtolower($extension),$tabExt)){
			// On recupere les dimensions du fichier
			$infosImg = getimagesize($_FILES['avatr']['tmp_name']);
			// On verifie le type de l'image
			if($infosImg[2] >= 0 && $infosImg[2] <= 1000){
				// On verifie les dimensions et taille de l'image
				if(($infosImg[0] <= WIDTH_MAX) && ($infosImg[1] <= HEIGHT_MAX) && (filesize($_FILES['avatr']['tmp_name']) <= MAX_SIZE)){
					// Parcours du tableau d'erreurs
					if(isset($_FILES['avatr']['error']) && UPLOAD_ERR_OK === $_FILES['avatr']['error']){
						// On renomme le fichier
						$nomImage = $matriculEtud.md5(uniqid()) .'.'. $extension;
						//$nomImage = $matriculEtud.'.'. $extension;
						$AvatarEtud = $nomImage; 
						$rqt_updt_avatr = "UPDATE tb_etudiant SET avantarEtud = '".$AvatarEtud."' WHERE matricEtud = '".$matriculEtud."'";
						if($exe_rqt_updt_avatr = $conDb->query($rqt_updt_avatr)){
							//si le t�l�chargement s'est bien pass�, l'envoi de l'avatar dans le r�pertoire : 'unique/B_mbidndi/Biamunda/media/'
							if(move_uploaded_file($_FILES['avatr']['tmp_name'],$_SERVER['DOCUMENT_ROOT'].Dossier.$nomImage)){
									
								$sms_avatar = "La photo est a &eacute;t&eacute; mise &agrave; jour.";	
							}
							else{
								$sms_avatar = "erreur de t&eacute;l&eacute;chargement de l'avatar";
							}
						}
						else{
							$sms_avatar = "Impossible de mettre &agrave; jour la photo du profil.";
						}
					}
					else{
						$sms_avatar = "D�sol�! le fichier que vous avez indiqu� n'est pas une photo";
					}
				}
				else{
					$sms_avatar = "La taille de votre photo est tr�s Exorbitante! S.V.P. chercher une autre.";
				}
			}
			else{
				// Sinon erreur sur les dimensions et taille de l'image
				$sms_avatar = "le fichier que vous voulez t�l�charg� n'a pas une bonne dimensio!";
			}
		}
		else{
			// Sinon erreur sur le type de l'image
			$sms_avatar = "Le fichier � t�l�charger n'est pas une image !";
		}
	}
	else{
		// Sinon on affiche une erreur pour l'extension
		$AvatarEtud = "";
		$sms_avatar = "Vous n'avez pas indiqu� sa photo!";
	}
	*/
}

?>



