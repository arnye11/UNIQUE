<?php 
if (isset($_POST['BtUpdtIdEtud']) and isset($_GET['modifEtud'])){ 
	$matEtudiant = $_GET['modifEtud'];
	if ($matEtudiant != ""){ 
		$matricEtud = filter_input(INPUT_POST,'matricEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$nomEtud = filter_input(INPUT_POST,'nomEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$postnomEtud = filter_input(INPUT_POST,'postnomEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$prenomEtud = filter_input(INPUT_POST,'prenomEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$sexeEtud = filter_input(INPUT_POST,'sexeEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$lieunaisEtud = filter_input(INPUT_POST,'lieunaisEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$datenaissEtud = filter_input(INPUT_POST,'datenaissEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$telEtud = filter_input(INPUT_POST,'telEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$adresseEtud = filter_input(INPUT_POST,'adresseEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$sectionSuiviEtud = filter_input(INPUT_POST,'sectionSuiviEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$pourctgEtud = filter_input(INPUT_POST,'pourctgEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$nomPereEtud = filter_input(INPUT_POST,'nomPereEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$nomMereEtud = filter_input(INPUT_POST,'nomMereEtud', FILTER_SANITIZE_SPECIAL_CHARS);

		if (($matricEtud != "") and ($nomEtud !="")and ($postnomEtud !="")and ($prenomEtud !="")and ($sexeEtud !="")and ($lieunaisEtud !="")and ($datenaissEtud !="")){
			$rqt_updt_fac_modif = "UPDATE tb_etudiant SET nomEtud = '".$nomEtud."', postnomEtud = '".$postnomEtud."', prenomEtud = '".$prenomEtud."', sexeEtud = '".$sexeEtud."', lieunaisEtud = '".$lieunaisEtud."', datenaissEtud = '".$datenaissEtud."', telEtud = '".$telEtud."', adresseEtud = '".$adresseEtud."', sectionSuiviEtud = '".$sectionSuiviEtud."', pourctgEtud = '".$pourctgEtud."', nomPereEtud = '".$nomPereEtud."', nomMereEtud = '".$nomMereEtud."' where matricEtud = '".$matricEtud."'";
			if($exe_updt_slct_fac_modif = $conDb->query($rqt_updt_fac_modif)){
				$sms_gerer = "Les inofrmations de la faculte ont ete mis a jour.";
				header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&inScriPtion&lisSte#'.$matricEtud);
			}
			else{
				$sms_gerer = "Impossible de mettre &agrave; jour les identités de cette étudiant.";
			}
		}
		else{
			$sms_gerer = "Veuillez remplir tous les champs ou Reaisseyer";
		}
	}
				
}

?>