<?php 
	if (isset($_POST['BtModifReinscrire'])){
		$matricEtud = $_SESSION['matricEtud'] ;
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$aca = filter_input(INPUT_POST,'aca', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if($matricEtud!="" and $idPromo!="" and $idOp!="" and $aca !=""){
			$rqt_updt_inscrit = "UPDATE tb_inscription SET idProm = '".$idPromo."', idOp = '".$idOp."' WHERE matricEtud = '".$matricEtud."' AND idAca = '".$aca."'";
			if($exe_rqt_updt_inscrit = mysqli_query($con, $rqt_updt_inscrit)){
				$sms_gerer = "<div class='reussite'>Inscrit mofidi&eacute;e</div>";
			}
			else{
				$sms_gerer = "<div class='erreur'>Erreur</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	}
?>