<?php 
	if(isset($_GET["gerer_admin"]) and isset($_GET["aDmini5TratIF"]) and isset($_GET["aJ"]) and $_SESSION['NivInter'] >2 ){
		
		?>
		<div> 
			<div>
			  <h2>Ajouter un utilisateur</h2>
		  	</div>
			<div>
				<?php
					if(isset($_POST['BtAjUtil'])){ echo $sms_gerer; }
				?>
		  	</div>
			<div>
				<form action="" method="post">
					<table>
					  <tr>
					    <td colspan="2" align="center" bgcolor="#CCCCCC">Identit&eacute;s</td>
				      </tr>
					  <tr>
						<td>CID</td>
						<td><input name="idAutoDec" type="text" value="<?php echo $idAutoDec; ?>"></td>
					  </tr>
					  <tr>
						<td>Nom </td>
						<td><input name="nomAutoDec" type="text" value="<?php echo $nomAutoDec; ?>"></td>
					  </tr>
					  <tr>
						<td>Postnom </td>
						<td><input name="postnomAutoDec" type="text" value="<?php echo $postnomAutoDec; ?>"></td>
					  </tr>
					  <tr>
					    <td>Prenom</td>
					    <td><input name="prenomAutoDec" type="text" value="<?php echo $prenomAutoDec; ?>"></td>
				      </tr>
					  <tr>
					    <td>Sexe</td>
					    <td>
					      	<select name="sexeAutoDec">
								<option value="<?php echo $sexeAutoDec; ?>"><?php echo $sexeAutoDec; ?></option>
								<option value="M">M</option>
								<option value="F">F</option>
				        	</select>					    </td>
				      </tr>
					  <tr>
					    <td>T&eacute;l&eacute;phone</td>
					    <td><input name="telAutoDec" type="text" value="<?php echo $telAutoDec; ?>"></td>
				      </tr>
					  <tr>
					    <td colspan="2" align="center" bgcolor="#CCCCCC">Coordonn&eacute;s d'authentification </td>
				      </tr>
					  <tr>
					    <td>Login</td>
					    <td><input name="logAutoDec" type="text" value="<?php echo $logAutoDec; ?>"></td>
				      </tr>
					  <tr>
					    <td>Mot de passe </td>
					    <td><input name="pwAutoDec" type="text" value="<?php echo $pwAutoDec; ?>"></td>
				      </tr>
					  <tr>
					    <td>Fonction</td>
					    <td>
							<select name="idFonctAutoDec">
								<?php 
								$rqt_list_fonct = "select * from  tb_fonction order by designFonc";
								if($exe_rqt_list_fonct = $conDb->query($rqt_list_fonct))
									{
									echo "<option value=".$idFonctAutoDec.">".$idFonctAutoDec."</option>";
									while($tb_fonction = $exe_rqt_list_fonct->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
										{?>
								<option value="<?php echo $tb_fonction['idFonct']; ?>"><?php echo $tb_fonction['designFonc']; ?></option>
								<?php 
										}
									}
								else
									{
									echo  "<option value=''> <div style='color:FF0000'> Impossible d&acute;atteindre les d&eacute;partement organis&eacute;s . <br/>SVP, contacter urigement l&acute;Administrateur pour l&acute;assistance.</div> < /option>";
									}
							  
							  ?>
							</select>					    </td>
				      </tr>
					  <tr>
					    <td>Niveau d'acc&egrave;s </td>
					    <td><select name="NivAcces">
                          <option value="<?php echo $NivAcces; ?>"><?php echo $NivAcces; ?></option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                        </select></td>
				      </tr>
				      <tr>
					    <td>Niveau d'intervation </td>
					    <td>
					    	<select name="NivInter">
                          		<option value="<?php echo $NivInter; ?>"><?php echo $NivInter; ?></option>
                          		<option value="1">1</option>
                          		<option value="2">2</option>
                          		<option value="3">3</option>
                          		<option value="4">4</option>
                        	</select>
                        </td>
				      </tr>
				      <tr>
					    <td>Faculté d'attache</td>
					    <td>
					    	<select name="FacAt">
                          		<option value="<?php echo $FacAt; ?>">
                          			<?php echo $FacAt; ?>
                          		</option>
                          		<?php 
									$rqt_faculte = "select * from  tb_faculte order by designFac";
									if($exe_rqt_faculte = $conDb->query($rqt_faculte)){
										while($tb_faculte = $exe_rqt_faculte->fetch_assoc()) {?>
											<option value="<?php echo $tb_faculte['idFac']; ?>">
												<?php echo $tb_faculte['designFac']; ?>
											</option>
										<?php 
										}
									}
									else{
										echo "<option value=''>Erreur</option>";
									}
								?>
								<option value="TOUTES">TOUTES</option>
                        	</select>
                    	</td>
				      </tr>
					  <tr>
					    <td>&nbsp;</td>
					    <td align="right"><input type="submit" name="BtAjUtil" value="Ajouter" /></td>
				      </tr>
					</table>				
				</form>
		  	</div>
		</div>

	<?php 
	}
?>