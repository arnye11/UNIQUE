<?php
if(isset($_GET['gerer_admin']) and isset($_GET['aDmini5TratIF']) and (isset($_GET['id']) and $_GET['id']!="")){
	if(($_SESSION['loginSession'] == "admin" and $_SESSION['NivAc']>1) || $_GET['id']==$_SESSION['idAutoDec']){

		 $rqt_slct_autodec="select * from tb_auto_dec  where idAutoDec = '".$_GET['id']."'";
		if($exe_rqt_slct_autodec = $conDb->query($rqt_slct_autodec))
			{
			if($result_rqt_slct_autodec = $exe_rqt_slct_autodec->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
				{
				?>
				<style type="text/css">
					.zone_photo_profil_mod{
						width: 100%;
						height: auto;
					}
					.photoProfilAdmi{
						width: 170px;
						height: 170px;
					}
					#imgPhotoProfilAdmin{
						max-width: 100%;
						max-height: 100%;
					}
				</style>
				<h2 align="left" style="margin-left:20px; " id="user">CID : &nbsp;&nbsp; <?php echo $result_rqt_slct_autodec["idAutoDec"];?> </h2>
				<div class="profil_modification_photo"><!--debut div modification photo profil-->
					<div class="profil_modification_photo1" align="center"><!--debut div titre-photo-lien modifier la photo-->
						<div class="zone_titre_photo_profil" align="center"><!--div avec le nom de l'�tudiant-->
							<?php echo $result_rqt_slct_autodec['prenomAutoDec'];?>
						</div>
						<div  class="zone_photo_profil_mod" align="center"><!--div de la photo de l'�tudiant-->
							<div class="photoProfilAdmi">
								<img id="imgPhotoProfilAdmin" src="B_mbidndi/Biamunda/media/<?php echo $result_rqt_slct_autodec['avantarAutoDec'];?>" alt="Pas de Photo"/>
							</div>
							
						</div>
						<div class="zone_lien_modifier_photo_profil" align="center"><!--div lien modifier la photo-->
							 <a class="lien_modifier_photo_profil" href="?gerer_admin&aDmini5TratIF&id=<?php echo $result_rqt_slct_autodec["idAutoDec"]; ?>&photo"><div style="width:100%;">Modifier la photo</div></a>
						</div>
					</div><!--fin div titre-photo-lien modifier le photo-->
					<div class="profil_modification_photo2" align="center"><!--div formulaire selct photo du profil-->
					<?php if (isset($_GET['aDmini5TratIF']) and isset($_GET['photo'])){ ?>
						<p>
						<?php if (isset($_POST['Bt_Tel_Av'])){ echo $sms_avatar;} else { echo "Veuillez s&eacute;lectionner une photo.";} ?>
						</p>
						<form action="" method="post" enctype="multipart/form-data" >
							<input class="ClassAvatarEtud" type="file" name="avatr" style="width:260px;"/>
							<input class="ClassBtTelecharger" type="submit" name="Bt_Tel_Av" value="T&eacute;l&eacute;charger la photo" style="width:260px;"/>
						</form>
						<?php }?>
					</div><!--fin div form selct photo du profil-->
				</div><!--fin div modification photo profil-->
				
				<div align="left" style="background:#DDDDDD; padding:2px;"><!--debut div id admin-->
					<?php 
					//FORMULAIRE DE MODIFICATION D'IDENTITES 
					if((isset($_GET['mod']) and $_GET['mod']==1) and $champ == false)
						{?>
						<div align="center" style=" width:99%; background:#DDDDDD; border:solid 1px #000088;">
						<div align="center" style="border-bottom:solid 1px #000088; font-size:20px;">Modification d'identit&eacute;s<br/>
							<?php if($champ == false and isset($_POST['BtEnreg'])){echo $sms_updt_id;} ?>
						</div>
						<form method="post">
							<table border="0">
							  
							  <tr>
								<td><div align="right">Nom<sup class="echec">*</sup> : </div></td>
								<td>
									<div align="left">
									  <input type="text" name="nom" value="<?php echo $result_rqt_slct_autodec['nomAutoDec'];?>" />
									</div></td>
							  </tr>
							  <tr>
								<td><div align="right">Postnom<sup class="echec">*</sup> : </div></td>
								<td>
									<div align="left">
									  <input type="text" name="postnom" value="<?php echo $result_rqt_slct_autodec['postnomAutoDec'];?>"/>
									</div></td>
							  </tr>
							  <tr>
								<td><div align="right">Pr&eacute;nom<sup class="echec">*</sup> : </div></td>
								<td>
									<div align="left">
									  <input type="text" name="prenom" value="<?php echo $result_rqt_slct_autodec['prenomAutoDec'];?>"/>
									</div></td>
							  </tr>
							  <tr>
								<td><div align="right">Sexe<sup class="echec">*</sup> : </div></td>
								<td>
									<div align="left">
									  <select name="sexe">
										<option value="<?php echo $result_rqt_slct_autodec['sexeAutoDec'];?>"><?php echo $result_rqt_slct_autodec['sexeAutoDec'];?></option>
										<option value="M">M</option>
										<option value="F">F</option>
									  </select>
									</div></td>
							  </tr>
							  <tr>
								<td><div align="right">Num&eacute;ro de t&eacute;l&eacute;phone : </div></td>
								<td>
									<div align="left">
									  <input type="text" name="tel" value="<?php echo $result_rqt_slct_autodec['telAutoDec'];?>"/>
									</div></td>
							  </tr>
							  <tr>
								<td colspan="2"><div align="center"><span style="font-size:12px; font-family:'Times New Roman'; font-style:italic; color:#FF6600">Tout champ signal&eacute; par <sup class="echec">*</sup> est obligatoire. </span></div></td>
							  </tr>
							  <tr>
								<td><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_admin&aDmini5TratIF&id=<?php echo $result_rqt_slct_autodec["idAutoDec"]; ?>&#user "> <div align="center" style="width:100%; height:22px; color:#EEEEEE; background:#000077; border-radius:10px;">Annuler</div></a></td>
								<td>
									<input type="submit" name="BtEnreg" value="Enregistrer les modifications" style="width:100%; height:25px; color:#EEEEEE; background:#000077; border-radius:10px;"/>			</td>
							  </tr>
							</table>
						</form>
						</div>
						<?php
						}
					else
						{
						if($champ == true and isset($_POST['BtEnreg']))
							{
							echo "<div align='center' style='border:solid 1px #FF9900;background:#FFFF99;'>".$sms_updt_id."</div>";
							} 
						?>
						<div align="left"><h3>IDENTITES</h3></div>
						<table border="0">
						  <tr>
							<td>Nom  </td>
							<td>: 
								<?php echo $result_rqt_slct_autodec['nomAutoDec'];?>
							</td>
						  </tr>
						  <tr>
							<td>Postnom </td>
							<td>: 
								<?php echo $result_rqt_slct_autodec['postnomAutoDec'];?>&nbsp;&nbsp; 
							</td>
						  </tr>
						  <tr>
							<td>Pr&eacute;nom  </td>
							<td>: 
								<?php echo $result_rqt_slct_autodec['prenomAutoDec'];?>&nbsp;&nbsp; 
							</td>
						  </tr>
						  <tr>
							<td>Sexe  </td>
							<td>:
								 <?php if ($result_rqt_slct_autodec['sexeAutoDec']=="M"){ echo "Homme";}else { echo "Femme";}?>&nbsp;&nbsp; 
							</td>
						  </tr>
						  <tr>
							<td><div align="left">Num&eacute;ro de t&eacute;l&eacute;phone  </div></td>
							<td>
								<div align="left">: <?php echo $result_rqt_slct_autodec['telAutoDec'];?></div>
							</td>
						  </tr>
						</table>
						<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_admin&aDmini5TratIF&id=<?php echo $result_rqt_slct_autodec["idAutoDec"]; ?>&mod=1&#user">
							<div align="center" style="width:100%; height:22px; color:#EEEEEE; background:#000077; border-radius:10px;">Modifier son identit&eacute;</div>
						</a>
						<?php 
						}
					?>
				</div>
				
				<div align="left" style="background:#DDDDDD; padding:2px;"><!--debut div id �tud-->
				<?php 
					if((isset($_GET['mod']) and $_GET['mod']==2) and $champ == false)
						{?>
						<div align="center" style=" width:99%; background:#DDDDDD; border:solid 1px #000088;">
							<div align="center" style="border-bottom:solid 1px #000088; font-size:20px;">Modification du compte d'utilisateur<br/>
								<?php if($champ == false and isset($_POST['BtEnreg'])){echo $sms_updt_id;} ?>
							</div>
							<form method="post">
								<table>
									<tr>
										<td><div align="left">Login<sup class="echec">*</sup>  </div></td>
										<td><div align="left">: <input name="log" type="text" value="<?php echo $result_rqt_slct_autodec['loginAutoDec']; ?>"></div></td>
									</tr>
									<tr>
										<td><div align="left">Mot de passe<sup class="echec">*</sup>  </div></td>
										<td><div align="left">: <input name="password" type="text" value="<?php  echo $result_rqt_slct_autodec['paswordAutoDec']; ?>"></div></td>
									</tr>
									<tr>
										<td><div align="left">Niveau d'acc&egrave;s<sup class="echec">*</sup>  </div></td>
										<td><div align="left">:
											<select name="NivAc">
												<option value="<?php echo $result_rqt_slct_autodec['NivAc']; ?>"><?php echo $result_rqt_slct_autodec['NivAc']; ?></option>
												<?php 
												$niv=0;
												for($niv=0; $niv<6;$niv++)
													{?>
													<option value="<?php echo $niv; ?>"><?php echo $niv; ?></option>
													<?php
													}
												?>
											</select>
											</div>
											</td>
									</tr>
									<tr>
										<td>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_admin&aDmini5TratIF&id=<?php echo $result_rqt_slct_autodec["idAutoDec"]; ?>&#user" > <div align="center" style="width:100%; height:22px; color:#EEEEEE; background:#000077; border-radius:10px;">Annuler</div></a>
										</td>
										<td>
											<input type="submit" name="BtEnreg" value="Enregistrer les modifications" style="width:100%; height:25px; color:#EEEEEE; background:#000077; border-radius:10px;"/>			
										</td>
									</tr>
								</table>
							</form>
						</div>
						<?php 
						}
					else
						{
						?>
						<div align="left"><h3>Compte d'utilisateur </h3></div>
						<table>
							<tr>
								<td><div align="left">Login </div></td>
								<td><div align="left">: <?php echo $result_rqt_slct_autodec['loginAutoDec']; ?></div></td>
							</tr>
							<tr>
								<td><div align="left">Mot de passe </div></td>
								<td><div align="left">: <?php echo  $result_rqt_slct_autodec['paswordAutoDec']; ?></div></td>
							</tr>
							<tr>
								<td><div align="left">Niveau d'acc&egrave;s</div></td>
								<td><div align="left">: <?php echo  $result_rqt_slct_autodec['NivAc']; ?></div></td>
							</tr>
						</table>
						<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_admin&aDmini5TratIF&id=<?php echo $result_rqt_slct_autodec["idAutoDec"]; ?>&mod=2&#user">
							<div align="center" style="width:100%; height:22px; color:#EEEEEE; background:#000077; border-radius:10px;">Modifier le compte d'utilisateur</div>
						</a>
						<?php 
						}
						?>
				</div>
				<?php
				}
			else
				{
				echo "erreur2";
				}
			}
		else{
			echo "erreur1";
		}
	}
	else{
		echo "Vous n'avez pas le droit � cette information.";
	}
 }
 ?>