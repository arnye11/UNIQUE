<?php 
	$idAutoDec = "";
	$nomAutoDec = "";
	$postnomAutoDec = "";
	$prenomAutoDec = "";
	$sexeAutoDec = "";
	$telAutoDec = "";
	$logAutoDec = "";
	$pwAutoDec = "";
	$idFonctAutoDec = "";
	$NivAcces = "";
	$NivInter = "1";
	$avantar = "";
	$FacAt= "";
	

if(isset($_POST['BtAjUtil'])){
	$idAutoDec = filter_input(INPUT_POST,'idAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$nomAutoDec = filter_input(INPUT_POST,'nomAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$postnomAutoDec = filter_input(INPUT_POST,'postnomAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$prenomAutoDec = filter_input(INPUT_POST,'prenomAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$sexeAutoDec = filter_input(INPUT_POST,'sexeAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$telAutoDec = filter_input(INPUT_POST,'telAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$logAutoDec = filter_input(INPUT_POST,'logAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$pwAutoDec = filter_input(INPUT_POST,'pwAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$idFonctAutoDec = filter_input(INPUT_POST,'idFonctAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
	$NivAcces = filter_input(INPUT_POST,'NivAcces', FILTER_SANITIZE_SPECIAL_CHARS);
	$NivInter = filter_input(INPUT_POST,'NivInter', FILTER_SANITIZE_SPECIAL_CHARS);
	$FacAt = filter_input(INPUT_POST,'FacAt', FILTER_SANITIZE_SPECIAL_CHARS);
	$avantar = "";

	if($idAutoDec!="" and $nomAutoDec!="" and $postnomAutoDec!="" and $prenomAutoDec!="" and $sexeAutoDec!="" and $telAutoDec!="" and $logAutoDec!="" and $pwAutoDec!="" and $idFonctAutoDec!="" and $NivAcces!="" and $NivInter!="" and $FacAt!="" )
		{				
		$rqt_insrt_autoDec = "INSERT INTO tb_auto_dec VALUES('".$idAutoDec."','".$nomAutoDec."','".$postnomAutoDec."','".$prenomAutoDec."','".$sexeAutoDec."','".$telAutoDec."','".$avantar."','".$logAutoDec."','".$pwAutoDec."','".$idFonctAutoDec."','".$NivAcces."','".$NivInter."','".$FacAt."')";
		if($exe_rqt_insrt_autoDec = $conDb->query($rqt_insrt_autoDec))
			{
			$sms_gerer = "<div style='color:#009900'> Utilisateur ajout&eacute; avec succ&egrave;s.</div>";
			}
		else
			{
			$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
	else
		{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}

}
?>