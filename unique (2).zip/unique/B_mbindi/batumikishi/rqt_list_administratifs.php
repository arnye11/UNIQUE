<?php 
if(isset($_GET['gerer_admin']))
	{?>
<div>
  <div><h3>G&eacute;rer les Administratifs</h3></div>
  <?php 
		if($_SESSION['NivInter'] >2){ ?>
		  <div>
		  	<h3>
		  		<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_admin&aDmini5TratIF&aJ">Ajouter</a>
		  	</h3>
		  </div>
		  <?php 
		}
	?>
  <div>
  	<?php 

		$rqt_slct_autodec="select * from tb_auto_dec  order by NivAc desc";
		if($exe_rqt_slct_autodec = $conDb->query($rqt_slct_autodec))
			{
			while($result_rqt_slct_autodec = $exe_rqt_slct_autodec->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
				{
				?>
				<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_admin&aDmini5TratIF&id=<?php echo $result_rqt_slct_autodec["idAutoDec"]; ?>">
					<div align="justify" style="background:#DDDDDD; margin-bottom:5px; padding-left:5px;">
						<?php
						echo $result_rqt_slct_autodec["prenomAutoDec"]." ".$result_rqt_slct_autodec["nomAutoDec"]." ".$result_rqt_slct_autodec["postnomAutoDec"];
						echo "";
						?>
					</div>
				</a>
				<?php 
				}
			}
		else
			{
			echo "erreur";
			}
	?>
  </div>
</div>
<?php }?>