<?php 
	if(isset($_POST['BtConx'])){
		$login = filter_input(INPUT_POST,'login', FILTER_SANITIZE_SPECIAL_CHARS);
		$password = filter_input(INPUT_POST,'motdepasse', FILTER_SANITIZE_SPECIAL_CHARS);
		if ( empty($login)){
			$sms_authatification = "Veuillez saisir votre compte";
		}
		else {
			include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/batumikishi/rqt_verification_log_sous.php");
		}
		
	}
	else{
		if(isset($_COOKIE['LoginCookies']) and isset($_COOKIE['PasswordCookies'])){
			$login = filter_var($_COOKIE['LoginCookies'], FILTER_SANITIZE_SPECIAL_CHARS);
			$password = filter_var($_COOKIE['PasswordCookies'], FILTER_SANITIZE_SPECIAL_CHARS);
			
			include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/batumikishi/rqt_verification_log_sous.php");
		}
	}		
?>