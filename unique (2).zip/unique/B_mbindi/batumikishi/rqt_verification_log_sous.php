<?php 
	$rqt_Vrf_Id = "select * from tb_auto_dec where loginAutoDec = '".$login."' and paswordAutoDec = '".$password."'";
	if($exe_rqt_Vrf_Id = mysqli_query($con, $rqt_Vrf_Id)){
		if(mysqli_num_rows($exe_rqt_Vrf_Id)>0){
			if($result_rqt_Vrf_Id = mysqli_fetch_assoc($exe_rqt_Vrf_Id)) {
				$_SESSION['idAutoDec'] = $result_rqt_Vrf_Id['idAutoDec'];
				$_SESSION['PronomNomAutoDec'] = $result_rqt_Vrf_Id['prenomAutoDec']."&nbsp;".$result_rqt_Vrf_Id['nomAutoDec'] ;
				$_SESSION['loginSession'] = $result_rqt_Vrf_Id['loginAutoDec'];
				$_SESSION['PasswordSession'] = $result_rqt_Vrf_Id['paswordAutoDec'];
				$_SESSION['idFonctAutoDec'] = $result_rqt_Vrf_Id['idFonctAutoDec'];
				$_SESSION['prenom'] = $result_rqt_Vrf_Id['prenomAutoDec'];
				$_SESSION['NivAc'] = $result_rqt_Vrf_Id['NivAc'];
				$_SESSION['NivInter']= $result_rqt_Vrf_Id["NivInter"];
				$_SESSION['FacAttach'] = $result_rqt_Vrf_Id['idFac'];
				//envoi de cookies
				setcookie("LoginCookies", $_SESSION['loginSession'], time()+(60*60*2), "/", "", false, true);
				setcookie("PasswordCookies", $_SESSION['PasswordSession'], time()+(60*60), "/", "", false, true); 
				$conx = true; 
				$_SESSION['conx'] = $conx;
				
				if($_SESSION['FacAttach']!="TOUTES"){
					//header ('location:?fAculTe&iDfaC='.$_SESSION['FacAttach']);
					//header ('location:?fAculTe&iDfaC='.$result_rqt_Vrf_Id['idFac']);
					//exit();			
				}
			}
		}
		else{
			$sms_authatification = "Login et  mot de passe incorrectes.";
		}
	}
	else{
		$sms_authatification = "Impossible de v�rifier vos identit�s. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
	}

?>