<?php 
if (isset($_GET['ctrl']) and (isset($_GET['misession'])))
	{ 
	$idExam = $_GET['misession'];
	
	if (isset($_GET['aca'])){$an_aca = $_GET['aca'];}	
	?>
<div style="background:#FFFFCC; padding-left:5px; padding-right:5px; padding-bottom:5px; margin-bottom:5px; border-bottom:solid 5px #BBBBBB;">
        <div>
			<?php 
			$slct_etud_incrit_prom = "select * from promotion ORDER BY idPromo ASC";
			if($exe_slct_etud_incrit_pro = mysql_query($slct_etud_incrit_prom))
				{
				while($result_slct_etud_incrit_pro = mysql_fetch_assoc($exe_slct_etud_incrit_pro)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{
					$slct_etud_incrit_dep = "select * from faculte";
					if($exe_slct_etud_incrit_dep = mysql_query($slct_etud_incrit_dep))
						{
						while($result_slct_etud_incrit_dep = mysql_fetch_assoc($exe_slct_etud_incrit_dep)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
							{
							$slct_etud_incrit_op = "select * from optionn where idFac = '".$result_slct_etud_incrit_dep['idFac']."'";
							if($exe_slct_etud_incrit_op = mysql_query($slct_etud_incrit_op))
								{
								while($result_slct_etud_incrit_op = mysql_fetch_assoc($exe_slct_etud_incrit_op)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
									{
									  ?>
									<div align="left">
									<br/>
									Ann�e acad�mique :  <?php echo $an_aca; ?><br/>
									Promotion :  <?php echo $result_slct_etud_incrit_pro['idPromo']; ?><br/>
									Option :  <?php echo $result_slct_etud_incrit_op['designOp']; ?><br/>
									D�partement : <?php echo $result_slct_etud_incrit_dep['designFac']; ?>
									</div>
									
									<div align="right">
										<?php if (isset($_GET['misession'])){echo "<i>Pour la Mi-Session</i>";}?>
									</div>
									<div style="border:outset 2px #004400;">
										<strong style="font-size:20px;" >Etudiants en ordre avec les finances</strong>
									</div>		
									<div style="background:#EEEEEE; border:solid 1px #33FFFF; padding-bottom:15px; width:auto; height:auto;" align="left" >
										<?php 
										//RQT ETUDIANTS INSCRIT -- CRITERE : DANS PROMOTION, OPTION, DEPARTEMENT, ANNEE ACADEMIQUE selection
										$slct_etud_incrit_pro_op_aca = "select * from inscription where idProm = '".$result_slct_etud_incrit_pro['idPromo']."' and  idOp = '".$result_slct_etud_incrit_op['idOp']."' and  idAca = '".$an_aca."' ORDER BY matricEtud ASC";
										if($exe_slct_etud_incrit_pro_op_aca = mysql_query($slct_etud_incrit_pro_op_aca))
											{
											
											$nbrInscrit = 0;
											$nbr_en_ordre = 0;
											while($result_slct_etud_incrit_pro_op_aca = mysql_fetch_assoc($exe_slct_etud_incrit_pro_op_aca)) 
												{
												
												$slct_etud = "select * from etudiant where matricEtud = '".$result_slct_etud_incrit_pro_op_aca['matricEtud']."'";
												if($exe_slct_etud = mysql_query($slct_etud))
													{
													
													while($result_slct_etud = mysql_fetch_assoc($exe_slct_etud)) 
														{
														//---------------------------------------------------------------------------------------------------------
														$Nbr_Fr_exige = 0;
														$ordre = false;
														
														$slct_fr_exige_examen = "select * from  frais_fixe_pour_exam where idExam = '".$idExam."' and idAca = '".$an_aca."'";
														if($exe_slct_fr_exige_examen = mysql_query($slct_fr_exige_examen))
															{
															while($result_exe_slct_fr_exige_examen = mysql_fetch_assoc($exe_slct_fr_exige_examen)) 
																{
																
																$slct_fr_exige_exam = "select * from  frais where idFr = '".$result_exe_slct_fr_exige_examen['idFr']."'";
																if($exe_slct_fr_exige_exam = mysql_query($slct_fr_exige_exam))
																	{
																	while($result_exe_slct_fr_exige_exam = mysql_fetch_assoc($exe_slct_fr_exige_exam)) 
																		{
																		//echo $result_exe_slct_fr_exige_exam['designFr'];
																																
																		//TABLEAU : FRAIS EXIGES POUR LA MI-SESSION
																		//$fr_fix = array('F004', 'F001', 'F006', 'F007');
																		//foreach($fr_fix as $fr_fixe) //Parcours du tebleau des frais exig� pour la mi-session
																		//	{
																			//selection du montant fixe pour le fr dans la promotion o� inscrit l'etudiant
																			$rqt_montant_fr_fix = "select montantFix from fixation_prix where idFr = '".$result_exe_slct_fr_exige_exam['idFr']."' and idPromo = '".$result_slct_etud_incrit_pro['idPromo']."' and idAca = '".$an_aca."'";
																			if($exe_rqt_montant_fr_fix = mysql_query($rqt_montant_fr_fix))
																				{
																				if($result_rqt_montant_fr_fix = mysql_fetch_assoc($exe_rqt_montant_fr_fix))
																					{
																					//selection du montant vers� pour le fr dans la promotion o� inscrit l'etudiant
																					$rqt_montant_fr_vers = "select sum(montantVers) as montant_vers from versement where idFr = '".$result_exe_slct_fr_exige_exam['idFr']."' and matEtud = '".$result_slct_etud_incrit_pro_op_aca['matricEtud']."' and idAca = '".$an_aca."'";
																					if($exe_rqt_montant_fr_vers = mysql_query($rqt_montant_fr_vers))
																						{
																						if($result_rqt_montant_fr_vers = mysql_fetch_assoc($exe_rqt_montant_fr_vers))
																							{
																							if($result_rqt_montant_fr_vers['montant_vers'] == $result_rqt_montant_fr_fix['montantFix'])
																								{
																								$ordre = true;
																								$Nbr_Fr_exige = $Nbr_Fr_exige + 1;
																								//echo $Nbr_Fr_exige." Bon --->". $result_rqt_montant_fr_vers['montant_vers'] ."/". $result_rqt_montant_fr_fix['montantFix']."<br/>";
																								}
																							else
																								{
																								$ordre = false;
																								$Nbr_Fr_exige = $Nbr_Fr_exige ;
																								//echo $Nbr_Fr_exige." Mauvais --->". $result_rqt_montant_fr_vers['montant_vers'] ."/". $result_rqt_montant_fr_fix['montantFix']."<br/>";
																								}
																							
																							}
																						else
																							{
																							echo "impossible de retrouver le montant vers�/ ".$Nbr_Fr_exige = $Nbr_Fr_exige + 1;
																							}
																						}
																					else
																						{
																						echo "impossible d'executer la rqt du montant vers�/ ".$Nbr_Fr_exige = $Nbr_Fr_exige + 1;
																						}
																					}
																				else
																					{
																					echo "impossible de retrouver le montant fix�/ ".$Nbr_Fr_exige = $Nbr_Fr_exige + 1;
																					}
																				}
																			else
																				{
																				echo "impossible d'execut� la rqt de retrouver le montant fix�/ ".$Nbr_Fr_exige = $Nbr_Fr_exige + 1;
																				}
																			}
																	}
																}
															}
																		//echo 	"<br/>";
														if($ordre == true and $Nbr_Fr_exige == $nbrfr_exige)
															{																																										
															 ?>
															<table border="0" width="100%">
															  <tr>
																<td>
	
																<div class="profil_apercu_inscrit11" align="center">
																	<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/istia-kabinda/B_mbidndi/Biamunda/media/<?php echo $result_slct_etud['avantarEtud'];?>" alt="Pas de Photo" width="100%" height="100%" /></div>
																<div class="profil_apercu_inscrit22" align="left">
																	<?php echo $result_slct_etud['nomEtud']."&nbsp;".$result_slct_etud['postnomEtud']."&nbsp;".$result_slct_etud['prenomEtud']."&nbsp;<br/> Matr. : ".$result_slct_etud['matricEtud'].".<br/>"; 
																	if ($result_slct_etud['sexeEtud']=="M"){ echo "N� � ";}else { echo "N�e � ";} echo $result_slct_etud['lieunaisEtud'].", le ".$result_slct_etud['datenaissEtud']."."; ?>
																</div>
																<div class="profil_apercu_inscrit33" align="left" >
																	<a href="">Profil</a>
																</div>		  
																</td>
															  </tr>
															</table>
																										 
															<?php
															$nbr_en_ordre = $nbr_en_ordre+1;
														 	}
														 }
													
													}
												else
													{
													echo "Impossible de retrouver l'�tudiant.";
													}
												$nbrInscrit = $nbrInscrit + 1;													
												}
											echo $nbr_en_ordre." en ordre sur ".$nbrInscrit."&nbsp; insctis ";
											
											}
										else
											{
											echo "Impossible de retrouver les �tudiants inscrits ici.";
											}																									
										?>
									</div>
									<?php 
									echo "......................................................................................................................";
									echo "<br/>";
									}
								}
							else
								{
								echo "Impossible de retrouver l'option.";
								}
							}
						}
					else
						{
						echo "Impossible de retrouver le d�partement.";
						}
					}
				}
			else
				{
				echo "Impossible de retrouver la promotion.";
				}
			?>
		</div>
</div>
<?php }?>