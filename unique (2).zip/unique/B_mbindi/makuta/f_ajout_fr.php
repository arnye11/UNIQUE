<?php 
if ((isset($_GET['gerer_frais'])) and (isset($_GET['ajouter_fr']))){
?>

<h3 >Ajouter un Frais</h3>
<div >
	<?php if (isset($_POST['BtsaveFr'])){echo $sms_gerer;} ?>
</div>
<form action="" method="post" name="f_ajout_fr">

<table border="0">
  <tr>
    <td ><div align="right"><span>Code du Frais : </span></div></td>
    <td><div align="left">
      <input type="text" name="codFr">
    </div></td>
  </tr>
  <tr>
    <td><div align="right">D&eacute;sigmation : </div></td>
    <td><div align="left">
      <input type="text" name="designFr">
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Type Frais : </div></td>
    <td>
	  <div align="left">
	    <select name="idTypFr" >
	      <?php 
			$rqt_list_typ_fr = "select * from  tb_type_frais";
			if($exe_rqt_list_typ_fr = $conDb->query($rqt_list_typ_fr))
				{
			  	echo "<option value=''> </option>";
				while($result_rqt_list_typ_fr = $exe_rqt_list_typ_fr->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{?>
					  <option value="<?php echo $result_rqt_list_typ_fr['idTypFr']; ?>"><?php echo $result_rqt_list_typ_fr['designTypFr']; ?></option>
					  <?php 
					}
				}
			else
				{
				echo  "<option value=''> <div style='color:FF0000'> Impossible d'atteindre le type de frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.</div> < /option>";
				}
		  
		  ?>
	        </select>
        </div>	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>
		<div align="left">
		  <input type="submit" name="BtsaveFr" value="Enregistrer" />
		</div>	</td>
  </tr>
</table>

</form>
<?php 
}
?>
