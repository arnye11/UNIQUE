<?php 
if (isset($_GET['gerer_frais']) and isset($_GET['modifier_fr']) and isset($_GET['fr']))
	{
?>

<h3 >Modification du Frais</h3>
<div >
	<?php if (isset($_POST['BtsUpdtFr'])){echo $sms_gerer;} ?>
</div>
<form action="" method="post" name="f_update_fr">

<table border="0">
  <tr>
    <th scope="col"><div align="right"><span>Code frais : </span></div></th>
    <th scope="col"><div align="left">
    	<?php if($idFr_modif == true){?>
			<input disabled="disabled" type="text" name="codFr" value="<?php echo $idFr_a_modif; ?>">
			<input type="hidden" name="codFr" value="<?php echo $idFr_a_modif; ?>">
   		<?php }else{?> 
			<input type="text" name="codFr" value="<?php echo $idFr_a_modif; ?>">
		<?php }?>
   </div></th>
  </tr>
  <tr>
    <td><div align="right">D&eacute;sigmation : </div></td>
    <td><div align="left">
      <input type="text" name="designFr" value="<?php echo $designFr_a_modif; ?>">
    </div></td>
  </tr>
  <tr>
    <td><div align="right">Type Frais : </div></td>
    <td>
	  <div align="left">
	    <select name="idTypFr" >
	      <?php 
			$rqt_list_typ_fr = "select * from  tb_type_frais";
			if($exe_rqt_list_typ_fr = $conDb->query($rqt_list_typ_fr))
				{
			  	echo "<option value='".$idTypFr_a_modif."'>".$design_TypFr_a_modif."</option>";
				while($result_rqt_list_typ_fr = $exe_rqt_list_typ_fr->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{?>
	      <option value="<?php echo $result_rqt_list_typ_fr['idTypFr']; ?>"><?php echo $result_rqt_list_typ_fr['designTypFr']; ?></option>
	      <?php 
					}
				}
			else
				{
				echo  "<option value=''> <div style='color:FF0000'> Impossible d'atteindre le type de frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.</div> < /option>";
				}
		  
		  ?>
	        </select>
        </div>	</td>
  </tr>
  <tr>
    <td><div align="right"><a href="?gerer_frais&modifier_fr">ANNULER</a></div></td>
    <td>
      <div align="right">
        <input type="submit" name="BtsUpdtFr" value="Mettre &agrave; jour" />
        </div></td></tr>
</table>

</form>
<?php 
}
?>
