<?php 
	if (isset($_GET['fAculTe']) and isset($_GET['fIxefR']) and (isset($_GET['promo']) and !empty($_GET['promo']))){
	?>
		<script type="text/JavaScript">
		<!--
		function MM_jumpMenu(targ,selObj,restore){ //v3.0
		  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
		  if (restore) selObj.selectedIndex=0;
		}
		
		function btfixfr(){
			<?php 
			//include("B_mbidndi/makuta/rqt slct_fr_pr_fix_pri.php");
			?>
		}
		function btSupfixfr(){
			var conf = confirm( "Voulez-vous vraiment supprimer ce frais?" );
			if ( conf ) {
				<?php 
				include("B_mbidndi/makuta/rqt_sup_fr_slct.php");
				?>
			} 
			else {
					// Code � �x�cuter si l'utilisateur clique sur "Annuler" 
			}
		}
		function nume(inputtxt){
			var numbers = /^[-+]?[0-9]+$/;
			if(inputtxt.value.match(numbers)){
				//alert('Correct...Try another');
				document.frm_fx_fr.montantFr.focus(); 
				return true;
				}
			else{
				//alert('Please input correct format');
				document.frm_fx_fr.montantFr.focus();
				return false;
				}
			}
		//-->
		</script>
<?php 
	//LES VAR
	$montant_fixe =0;
	$sous_tot_montant_fixe =0;
	$tot_gene_montant_fixe =0;
	$idPromo=$_GET['promo'];
	
	echo "<div id='fr'><h3>FIXATION DES FRAIS EN ".$idPromo." </h3>";
	if(isset($_POST['BtFixerFr'])){ echo "<div style='color:#009900'>".$sms_gerer."</div>";}
	if(isset($_POST['BtSupCeFrFix'])){ echo "<div style='color:#FF0000'>".$sms_gerer."</div>";}
	echo "</div>";
	?>
	<div>
		<div>Sel&eacute;ctionner et fixer</div>
		<div>
			<form action="" method="post" name="frm_fx_fr">
			<table style="width:100%; font-family:Bookman Old Style; font-size:13px;">
				<tr align="left">
					<td bgcolor="#DEDEDE" style="font-size:15px;" scope="col">
						<div align="center">
						<input name="idPromo" type="hidden" value="<?php echo $_GET['promo']; ?>" />
						<input name="idFac" type="hidden" value="<?php echo $idFac; ?>" />
						<input name="idAca" type="hidden" value="<?php echo $_SESSION['idAnAca']; ?>" />
				
						<select name="idFr" style="width:100%;">
							<option value=""></option>
							<?php 		
							$rqt_list_fr = "select * from  tb_frais ORDER BY designFr ASC";
							if($exe_rqt_list_fr= $conDb->query($rqt_list_fr)){
								if($exe_rqt_list_fr->num_rows>0){
									while($tb_list_fr = $exe_rqt_list_fr->fetch_assoc()){
										$rqt_fr_fx = "SELECT * FROM tb_fixation_prix  where idPromo = '".$_GET['promo']."' AND idFac ='".$idFac."' AND  idAca = '".$_SESSION['idAnAca']."' AND  idFr = '".$tb_list_fr["idFr"]."' ";
										if($exe_rqt_fr_fx= $conDb->query($rqt_fr_fx)){
											if($exe_rqt_fr_fx->num_rows<1){
												echo "<option value='".$tb_list_fr['idFr']."'>".$tb_list_fr['designFr']."</option>";
											}
										}
									}
								}
								else{
									echo "<option value=''>Pas des frais</option>";
								}
							}
							else{
								echo "<option value=''>Erreur</option>";
							}
							?>
						</select>
						</div>
					</td>
					<td bgcolor="#DEDEDE" style="font-size:15px;" scope="col">
						<div align="center"><input name="montantFr" type="text" style="width:50px;" maxlength="6" onchange="nume(document.frm_fx_fr.montantFr)" /></div>
					</td>
					<td bgcolor="#DEDEDE" style="font-size:15px;" scope="col">
						<div align="center"><input name="BtFixerFr" type="submit" value="Fixer" /></div>
					</td>
				</tr>
			</table>
			</form>
		</div>
	</div>

	<div>Frais Fix&eacute;s</div>
	<?php
	$rqt_list_type_fr_a_fix = "select * from  tb_type_frais";
	if($exe_rqt_list_type_fr_a_fix = $conDb->query($rqt_list_type_fr_a_fix))
		{
		?>
		<table border="1" cellspacing="0" cellpadding="1" style="width:100%; font-family:Bookman Old Style; font-size:13px;">
			<tr align="left">
				<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">D&eacute;signation</div></th>
				<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">Montant</div></th>
				<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">&nbsp;</div></th>
			</tr>
			<?php 
				while($result_rqt_list_type_fr_a_fix = $exe_rqt_list_type_fr_a_fix->fetch_assoc()){ 
					$sous_tot_montant_fixe =0;
					?>
					<tr style="background:#5B5B5B; color:#FFFFFF;">
						<td colspan="3"><div align="left"><?php echo "&emsp;".$result_rqt_list_type_fr_a_fix['designTypFr']; ?></div></td>
					</tr>
					<?php 
					$rqt_fr = "SELECT tb_fixation_prix.*, tb_frais.* FROM tb_frais INNER JOIN tb_fixation_prix ON tb_frais.idFr = tb_fixation_prix.idFr WHERE (((tb_frais.idTypFr)='".$result_rqt_list_type_fr_a_fix['idTypFr']."') AND((tb_fixation_prix.idPromo)='".$_GET['promo']."') AND ((tb_fixation_prix.idFac)='".$idFac."') AND ((tb_fixation_prix.idAca)='".$an_aca."')) ";
					
					//$rqt_fr = "select * from  tb_frais where idTypFr ='".$result_rqt_list_type_fr_a_fix['idTypFr']."'";
					if($exe_rqt_fr = $conDb->query($rqt_fr)){
						if($exe_rqt_fr->num_rows>0){
							while($tb_fr = $exe_rqt_fr->fetch_assoc()){
								$montant_fixe=0; 
								?>
								<tr >
									<td ><div align="left"><?php echo $tb_fr['designFr']; ?></div></td>
									<?php 
										if (isset($_GET["fixer"]) and (isset($_GET["fIxefR"]) and $_GET["fIxefR"]==$tb_fr['idFr'])){ ?>
										
												<td colspan="2" >
													<div align="right">
														<form method="post" >			
														<?php
														$montant_fixe = $tb_fr['montantFix'];
														$sous_tot_montant_fixe = $sous_tot_montant_fixe+$montant_fixe;
														?>
														
														<input name="BtSupCeFrFix" type="submit" value="Supprimer" onclick="btSupfixfr()" />&emsp;
														<input name="idFixPrix" type="hidden" value="<?php echo $tb_fr['idFixPrix']; ?>" />
														
														<input name="idPromo" type="hidden" value="<?php echo $_GET['promo']; ?>" />
														<input name="idFac" type="hidden" value="<?php echo $idFac; ?>" />
														<input name="idAca" type="hidden" value="<?php echo $_SESSION['idAnAca']; ?>" />
														<input name="idFr" type="hidden" value="<?php echo $tb_fr["idFr"]; ?>" />
														<input name="montantFr" type="number"  value="<?php echo $montant_fixe; ?>" style="width:70px;" maxlength="6" autofocus />
														<input name="BtFixerFr" type="submit" value="Fixer" />
														
													</form>
													<a href="?fAculTe&iDfaC=<?php echo $idFac;?>&fIxefR&promo=<?php echo $_GET['promo'];?>">Annuler</a>
													</div>
												</td>
											
										 <?php
									}
									else{?>
										<td >
											<div align="right">
												<?php 
												$montant_fixe = $tb_fr['montantFix'];
												$sous_tot_montant_fixe = $sous_tot_montant_fixe+$montant_fixe;
														
												echo $montant_fixe;
												?>
												&nbsp;
											</div>
										</td>
										<td  >
											<div align="center">
												<a href='?fAculTe&iDfaC=<?php echo $idFac;?>&promo=<?php echo $_GET['promo'];?>&fIxefR=<?php echo $tb_fr["idFr"];?>&fixer#fr'>
													<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="right" alt="Modif." title="Modifier"/>
												</a>
											</div>
										</td>
									<?php 
									} ?>
								</tr>
							 	<?php 
							 }
							 ?>
							<tr bgcolor="#DEDEDE">
								<td ><div align="right"><em>SOUS-TOTAL  &nbsp;</em></div></td>
								<td  >
									<div align="right">
										<?php 
										$tot_gene_montant_fixe=$tot_gene_montant_fixe+$sous_tot_montant_fixe ; 
										echo $sous_tot_montant_fixe; 
										?>
										&nbsp;
									</div>
								</td>
								<td ><div align="center">&nbsp;</div></td>
							</tr>
							<?php 
						}
						else{
							?>
							<tr>
								<td  colspan="3"><div align="left">Aucun frais fix&eacute; ici</div></td>
							</tr>
							<?php 
						}
					}
					else{
						?>
						<tr align="left">
							<td colspan="3"><div align="left">Impossible de trouver les frais</div></td>
						</tr>
						<?php 
					}
				}
			?>
			<tr style="background:#5B5B5B; color:#FFFFFF;">
				<td><div align="right"><em>TOTAL GENERAL &nbsp; </em></div></td>
				<td>
					<div align="right">
						<?php echo $tot_gene_montant_fixe; ?>&nbsp;
					</div>							  
				</td>
				<td scope="col" >&nbsp;</td>
			</tr>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}
else{
	echo "<h3>Veuillez sel&eacute;ctionner une promotion</h3>";
}


?>
