<?php 
	if (isset($_GET['fAculTe']) and isset($_GET['fIxefR'])){?>

	<style type="text/css">
		<!--
		.divOrgOp{
			width:98%;margin:2px; color: 
		} 
		.divOrgOp, .divOrgOpContenu1{
			border:solid 1px #9A9A9A; margin:0px; padding:0px; 
		} 
		.divOrgOpCorps, .divOrgOpContenu1, .divOrgOpContenu2, .divOrgOpContenu3, #divOrgOpTitre{
			width:99%; height:auto;
		}
		.divOrgOpContenu2{
			height:20px;  margin-top:5px;
		}
		#divOrgOpTitre{
			height:auto; background:#D6D6D6; 
		}
		.Fac, .Op{
			width:60%; 
		}
		.Fac{
			text-transform:uppercase;
		}
		#enteteOrgOp{
			width:100%;border:solid 0px; background:#003333; color:#FFFFFF;margin-bottom:10px; padding:0px,
		}
		#Fac{
			background:#EBEBEB;
		}
		.Op{
			text-transform:lowercase;
		}
		.Promo{
			width:35%; text-align:center; font-size:12px;
		}
		.cellulePromo{
			width:20px; border:solid 1px #FF0000; margin-left:2px; margin-right:2;
		}
	
		-->
	</style>
	
	 <div class="divOrgOpCorps" id="divOrgOpTitre">
		<h2 align="center">Fixation des montant des frais</h2>
	</div>
		<?php 
			if(isset($_GET['gerer_option']) and isset($_GET['OrgOp']) and isset($_GET['iDproMo']) and isset($_GET['iDop']) ){
			echo $sms_gerer;
			}
		?>
	 <div class="divOrgOp">
		<div class="divOrgOpCorps"  id="enteteOrgOp">
				<table class="divOrgOpContenu2">
					<tr>
						<td class="Fac">Frais</td>
						<td class="Promo">
							<div class="divOrgOpContenu3">Promotions</div>
							<table class="divOrgOpContenu3">
								<tr>
									<?php 
									$rqt_promo = "SELECT idPromo FROM tb_promotion  ORDER BY idPromo ASC";
									$nbL = 0;
									if($exe_rqt_promo = $conDb->query($rqt_promo)){
										$nbL =$exe_rqt_promo->num_rows;
										//echo "<td>".$nbL."</td>";
										while($tb_promotion = $exe_rqt_promo->fetch_assoc()){
											echo "<td class='cellulePromo'>".$tb_promotion["idPromo"]."</td>";
										}
										
									}
									else{
										echo "<td>Erreur.</td>";
									}
									?>
								</tr>
							</table>
						</td>
					</tr>
				</table>
		</div>
		<?php 
			$rqt_TypFr = "SELECT * FROM tb_type_frais";
			if($exe_rqt_TypFr = $conDb->query($rqt_TypFr)){
				//$nbL =$exe_rqt_promo->num_rows;
				while($tb_TypFr = $exe_rqt_TypFr->fetch_assoc()){
					echo "<div class='divOrgOpCorps'>";
					echo "<div class='divOrgOpContenu1' id='Fac'>".$tb_TypFr["designTypFr"]."</div>";
					$rqt_fr = "SELECT * FROM tb_frais WHERE idTypFr = '".$tb_TypFr["idTypFr"]."' ORDER BY designFr ASC";
					if($exe_rqt_fr = $conDb->query($rqt_fr)){
						//$nbL =$exe_rqt_promo->num_rows;
						?>
						<table class="divOrgOpContenu2">
						<?php 
						while($tb_fr = $exe_rqt_fr->fetch_assoc()){
							?>
							
								<tr>
									<td class="Op"><?php echo $tb_fr["designFr"]; ?></td>
									<td class="Promo">
										<table class="divOrgOpContenu3">
											<tr>
												<?php 
												$rqt_promo = "SELECT idPromo FROM tb_promotion ORDER BY idPromo ASC";
												//$nbL = 0;
												if($exe_rqt_promo = $conDb->query($rqt_promo)){
													$nbL =$exe_rqt_promo->num_rows;
													while($tb_promo = $exe_rqt_promo->fetch_assoc()){
														echo "<td class='cellulePromo' title='en ".$tb_promo["idPromo"]."'>";
														$rqt_v_fxfr = "SELECT * FROM tb_fixation_prix  where idPromo = '".$tb_promo["idPromo"]."' AND idFac ='".$idFac."' AND  idAca = '".$_SESSION['idAnAca']."' AND  idFr = '".$tb_fr["idFr"]."' ";
														if($exe_rqt_v_fxfr = $conDb->query($rqt_v_fxfr)){
															if($tb_fxfr = $exe_rqt_v_fxfr->fetch_assoc()){
																echo "<a href='?fAculTe&iDfaC=".$idFac."&fRaIs=".$tb_promo["idPromo"]."&idAca=".$_SESSION['idAnAca']."&moins'>".$tb_fxfr['montantFix']."</a>";
															}
															else{
																echo "<a href='?fAculTe&iDfaC=".$idFac."&fRaIs=".$tb_promo["idPromo"]."&idAca=".$_SESSION['idAnAca']."&moins'>0</a>";
															}
														}
														else{
															echo "Error";
														}
														echo "</td>";
													}
													
												}
												else{
													echo "<td>Erreur lors de sel&eacute;ction des promotions.</td>";
												}
												?>
											</tr>
										</table>
									</td>
								</tr>
							
							<?php 
						}
						?>
							<tr>
								<td class="Op">Sous-Total</td>
								<td class="Op">xx</td>
							</tr>
						</table>
						<?php 
					
					}
					else {
						echo "<div class='divOrgOpContenu1'>Erreur lors de sel&eacute;ction des frais;.</div>";
					}
					echo "</div>";					
				}
			}
			else {
				echo "<div class='divOrgOpContenu2'>Erreur lors de sel&eacute;ction des types des frais.</div>";
			} ?>
	 </div>
	<?php 
	}
?>