<?php 
	if (isset($_GET['jr'])){
		?>
		<div align="right" style="width:98%; margin-bottom:5px; border:solid 1px #000066;">
			<table >
				<tr>
					<td> Sel&eacute;ctionnr une date :</td>
					<td> 
						<form action="" method="post">Jour
						  <select name="jr" style="width:50px;">
							<option value="<?php if (isset($_POST['BtJr'])){ echo $_POST["jr"];} ?>"><?php if (isset($_POST['BtJr'])){ echo $_POST["jr"];} ?></option>
							<?php jours_select_option();?>
						  </select>
						  &mdash;Mois
						  <select name="mois" style="width:100px;">
							<option value="<?php if (isset($_POST['BtJr'])){ echo $_POST["mois"];} ?>"><?php if (isset($_POST['BtJr'])){ echo $_POST["mois"];} ?></option>
							<?php mois_selct_option(); ?>
						  </select>
						  &mdash;Ann&eacute;e
						  <select name="an" style="width:55px;">
								<option value="<?php if (isset($_POST['BtJr'])){ echo $_POST["an"];}else{echo $annee_encours; } ?>">
									<?php if (isset($_POST['BtJr'])){ echo $_POST["an"];}else{echo $annee_encours; } ?>
								</option>

								<?php
								$aNaiss=0;
								for($aNaiss = 1970; $aNaiss<=$annee_encours; $aNaiss++)
									{
									echo "<option value='".$aNaiss."'>".$aNaiss."</option>";
									}
								?>
					      </select>
						   &emsp;
						   <input type="submit" name="BtJr" value="OK" style="width: 60px;" />
						</form>
				  </td>
			  </tr>
			</table>
		</div>
		<?php 
		$date_jrn = $date_ojrd8;
		if(isset($_POST["BtJr"])){
			if($_POST["an"] != "" and $_POST["mois"]!="" and $_POST["jr"] !=""){
				$_SESSION['date_jrn']=$date_jrn = $_POST["an"]."-".$_POST["mois"]."-".$_POST["jr"];
				$date_jrn2 = $_POST["jr"]."-".$_POST["mois"]."-".$_POST["an"];
			
				$rqt_slct_fr_vers = "select * from tb_versement where idPromo = '".$_GET['pRomotIon']."' and idOp = '".$_GET['oPtiOn']."' and idAca = '".$an_aca."' and dateVers BETWEEN  '".$_SESSION['date_jrn']." 00:00:00' and '".$_SESSION['date_jrn']." 23:59:59' ORDER BY dateVers  DESC";
				if($exe_rqt_slct_fr_vers =$conDb->query($rqt_slct_fr_vers)){
				if($exe_rqt_slct_fr_vers->num_rows>0){
					?>
					<table width="99%" border="0" bgcolor="#FFFFFF">
					  <tr style="background:#CCCCCC; color:#000000;">
						<td colspan="6">
							<h3 align="center">
							<?php 
								if(!isset($_POST["BtJr"])){
									echo "Versements d'aujourd'hui (".$date_ojrd8.")";
								}
								else{
									echo "Versements de la date du : ".$date_jrn2.".";
								}
							?>				
							</h6>
						</td>
					  </tr>
					  <tr style="background:#5B5B5B; color:#FFFFFF;">
						<td scope="col">Date de versement </td>
						<td scope="col">Montant (FC)</td>
						<td scope="col">Frais</td>
						<td scope="col">Etudiant</td>
						<td scope="col">Matricule</td>
						<td scope="col">Afficher</td>
					  </tr>
					  <?php
					  $montantverse_jr = 0;
					  while($rsult_exe_rqt_slct_fr_vers = $exe_rqt_slct_fr_vers->fetch_assoc())
						{?>
						  <tr>
							<td scope="col" style="border-bottom:solid 1px"><div align="left"><?php echo $rsult_exe_rqt_slct_fr_vers['dateVers'] ;?>
						    </div></td>
							<td scope="col" style="border-bottom:solid 1px; ">
								<div align="right">
						    	<?php 
									$montantverse_jr = $montantverse_jr + $rsult_exe_rqt_slct_fr_vers['montantVers'] ;
									echo $rsult_exe_rqt_slct_fr_vers['montantVers'] ;
								?>&nbsp;						</div>					</td>
							<td scope="col" style="border-bottom:solid 1px">
								<div align="left">&nbsp;
								  <?php 
								$rqt_slct_fr = "select * from tb_frais where idFr = '".$rsult_exe_rqt_slct_fr_vers['idFr']."'";
								if($exe_rqt_slct_fr = $conDb->query($rqt_slct_fr))
									{
									if($exe_rqt_slct_fr = $exe_rqt_slct_fr->fetch_assoc())
										{
										echo $exe_rqt_slct_fr['designFr'] ;
										}
									}
								?>
						        </div></td>
							<td scope="col" style="border-bottom:solid 1px; text-transform:uppercase;"><div align="justify">
								<?php 
								$rqt_slct_fr = "select * from tb_etudiant where matricEtud = '".$rsult_exe_rqt_slct_fr_vers['matEtud']."'";
								if($exe_rqt_slct_fr = $conDb->query($rqt_slct_fr))
									{
									if($exe_rqt_slct_fr = $exe_rqt_slct_fr->fetch_assoc())
										{
										echo $exe_rqt_slct_fr['nomEtud']."&nbsp;".$exe_rqt_slct_fr['postnomEtud']."&nbsp;<span style='text-transform:none;'>".$exe_rqt_slct_fr['prenomEtud']."</span>" ;
										}
									}
								?>

							</div></td>
							<td scope="col" style="border-bottom:solid 1px"><div align="justify"><?php echo $rsult_exe_rqt_slct_fr_vers['matEtud']; ?></div></td>
							<td scope="col" style="border-bottom:solid 1px">
								<div align="justify">
									<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&rAppoRtfrais&jr&imPRessIoN&recude=".$rsult_exe_rqt_slct_fr_vers['matEtud']."&num=". $rsult_exe_rqt_slct_fr_vers['idVers']?>">Re&ccedil;u</a>						</div>					
							</td>
						  </tr>
						  <?php 
						}
						 ?>
					    <tr bgcolor="#CCCCCC">
					        <td style="border-bottom:solid 1px" scope="col"><div align="right">Total vers&eacute; aujourd'hui : </div></td>
					        <td style="border-bottom:solid 1px; " scope="col"><div align="right"><?php echo $montantverse_jr; ?>&nbsp;</div></td>
					        <td style="border-bottom:solid 1px" scope="col"><div align="right"></div></td>
					        <td style="border-bottom:solid 1px; text-transform:uppercase;" scope="col"><div align="right"></div></td>
					        <td style="border-bottom:solid 1px" scope="col"><div align="right"></div></td>
					        <td style="border-bottom:solid 1px" scope="col"><div align="right"></div></td>
						</tr>
		            </table>
					<?php 
					if (isset($_GET["imPRessIoN"])) {
						?>
						<div style="width:90%;" align="right">
							<p>
								Fait à ......................................, le ......./......./.......
							</p>
							<p></p>
							<p>Nom, signature et sceau de l'autorité</p>
						</div>
						<?php 
					}	
					if (!isset($_GET["imPRessIoN"])) {
						?>
						 
						 <a href="?imPRessIoN&doc&fr&rAppoRtfrais&jr&pRomotIon=<?php echo $_GET['pRomotIon'];?>&oPtiOn=<?php echo $_GET['oPtiOn'];?>&aca=<?php echo $an_aca; ?>">
							<div style="width:60px; padding: 50px; float: right;">
								<img src="B_mbindi/Biamunda/icon/print.ico" class="ico"><br>
								Imprimer
							</div>
						</a> 
						<?php
					} 
					}
					else{
						//$o=new DateTime($date_ojrd8);
						echo "Pas des versements aujourd'hui (".$date_ojrd8.")";
					}
				}	
			}
			else{
				echo "Les champs sont vide. Veuillez sel&eacute;ctionner le jour et le mois.";
			}
		}
	}
?>