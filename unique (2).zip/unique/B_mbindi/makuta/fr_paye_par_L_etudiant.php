
<?php
 
	if (isset($_GET['profil']) and isset($_GET['frais']))
		{
		 $idfac = "";
		 
		if (isset($_GET['aca'])){$an_aca=$_GET['aca'];} 
		if ($_SESSION['loginSession'] == "Comptable" ||$_SESSION['loginSession'] == "DG" || $_SESSION['loginSession'] == "admin"){
		echo "<div style='border-bottom:groove; padding: 5px' id='frais'><h3>Situation des frais pour l'ann&eacute; acad&eacute;mique ".$_SESSION['idAnAca']."</h3>";
		if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
		echo "</div>";
	//______________Ses ann�es acad�miques _____________________________________________
	 	?>
		<div align='left' style="margin-bottom: 20px;">
			<table style="width: 100%;">
				<tr>
					<td>
	 					<?php 
							$rqt_slct_etud_inscri = "select * from tb_inscription where matricEtud = '".$result_slct_etud['matricEtud']."'";
							if($exe_Tb_inscription = $conDb->query($rqt_slct_etud_inscri)){
								  while($Tb_inscription = $exe_Tb_inscription->fetch_assoc()){
									$promotion = $Tb_inscription['idProm'];
									$slct_op = "select * from tb_option where idOp = '".$Tb_inscription['idOp']."'";//RQT SELECTION DE L'OPTION
									if($exe_slct_op = $conDb->query($slct_op)){
										if($Tb_Option = $exe_slct_op->fetch_assoc()){
											$slct_fac = "select * from tb_faculte where idFac = '".$Tb_Option['idFac']."'";//RQT SELECTION DEPARTEMENT
											if($exe_slct_fac = $conDb->query($slct_fac)){
												if($Tb_Fac = $exe_slct_fac->fetch_assoc()){
													$idfac = $Tb_Fac['idFac'];
													?>
													<div align="center" style="border-bottom:solid 3px #0000FF; display:inline-block; float:left; margin-right:20px;">
														<a title="" href="<?php $_SERVER['DOCUMENT_ROOT']."/".$url_site;?>?profil&id=<?php echo $result_slct_etud['matricEtud'];?>&frais&aca=<?php echo $Tb_inscription['idAca'];?>"><?php echo $Tb_inscription['idAca']."<br/>".$promotion."&nbsp;".$Tb_Option['designOp'] ;?></a>
													</div>
													<?php 
												}
											}
										}
									}
								}
							} 
						?>		
					</td>
				</tr>
			</table>
		</div>
							<?php 
//_________________________Fr pay� par l'�tudiat__________________________________________________
	$rqt_list_type_fr = "select * from  tb_type_frais";
	if($exe_rqt_list_type_fr = $conDb->query($rqt_list_type_fr))
		{
		if(isset($_POST['BtVerser'])){echo $sms;}
		?>
		<div style="width:99%;" class="<?php if($_SESSION['idAnAca'] != $an_aca){echo "aca_pas";}?>">
		<table border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF" style="width:100%;font-size:13px; box-shadow:0px 2px 2px 2px #003300;">
		  <tr align="left">
		    <td bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">FRAIS <?php if (isset($_GET['aca'])){echo "(".$an_aca.")";} ?></div></td>
		    <td colspan="3" bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center"> MONTANT </div></td>
          </tr>
		  <tr align="left">
		    <td bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">D&eacute;signation</div></td>
			<td bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">Fix&eacute; (FC)</div></td>
			
			<td bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">Vers&eacute; (FC)</div></td>
			<td bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">Actions</div></td>
		  </tr>
		  		<?php 
		  		
				while($result_rqt_list_type_fr = $exe_rqt_list_type_fr->fetch_assoc()){ 
					$montant_vers=0;
					$sous_tot_montant_vers = 0 ;
					$sous_tot_montant_fixe = 0 ;
					?>
					
					<tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
						<td scope="col" style="border-bottom:solid 1px"><div align="center"><?php echo $result_rqt_list_type_fr['designTypFr']; ?></div></td>
						<td scope="col" style="border-bottom:solid 1px"> </td>
						
						<td scope="col" style="border-bottom:solid 1px"> </div></td>
						<td scope="col" style="border-bottom:solid 1px">&nbsp;</td>
					</tr>
					<?php 
					$rqt_list_fr = "SELECT tb_fixation_prix.*, tb_frais.* FROM tb_frais INNER JOIN tb_fixation_prix ON tb_frais.idFr = tb_fixation_prix.idFr WHERE (((tb_frais.idTypFr)='".$result_rqt_list_type_fr['idTypFr']."') AND((tb_fixation_prix.idPromo)='".$result_slct_etud_inscrit['idProm']."') AND((tb_fixation_prix.iDfaC)='".$idfac."') AND ((tb_fixation_prix.idAca)='".$an_aca."')) ";
					
					//$rqt_list_fr = "select * from  tb_frais where idTypFr ='".$result_rqt_list_type_fr['idTypFr']."'";
					if($exe_rqt_list_fr = $conDb->query($rqt_list_fr))
						{
						while($result_rqt_list_fr = $exe_rqt_list_fr->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION de tous les frais 
							{
							$montant_fixe = 0 ;
							
							//verification si le fr est fix� dans la promo o� est inscrit l'etudiant 
							?>
							<tr align="left" style="">
							  <!--Designation frais-->
							  <td scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_fr['designFr']; ?></td>
							  <!--Montant fix�-->	
							  <td scope="col" style="background:#AAAAAA; color:#FFFFFF;border-bottom:solid 1px">
								<div align="right">
									  <?php 
										$montant_fixe = $result_rqt_list_fr['montantFix'];
										$sous_tot_montant_fixe = $sous_tot_montant_fixe + $montant_fixe ;
										echo $montant_fixe;
										?>
								</div>		
							  </td>
							  <!--Montant vers�-->
							  <td scope="col" style="border-bottom:solid 1px">
								<div align="right">
								  <?php 
									$rqt_slct_fr_vers = "SELECT SUM(montantVers) AS montantVerse FROM tb_versement WHERE idFr = '".$result_rqt_list_fr['idFr']."' and matEtud = '".$result_slct_etud['matricEtud']."' and idAca = '".$an_aca."'";
									if($exe_rqt_slct_fr_vers = $conDb->query($rqt_slct_fr_vers)){
										$montant_vers =0;
										if($rsult_exe_rqt_slct_fr_vers = $exe_rqt_slct_fr_vers->fetch_assoc()){
											$montant_vers = $montant_vers+$rsult_exe_rqt_slct_fr_vers['montantVerse'];
											$sous_tot_montant_vers = $sous_tot_montant_vers + $montant_vers ;
											echo $montant_vers;
										}
										else{
											echo "<i class='echec'>Echec</i>";
										}
									}
									else{
										echo "<i class='echec'>Erreur</i>";
									}
								  ?>
								</div>
							  </td>
							  <!--Lien Moditier-->
							  <td scope="col" style="border-bottom:solid 1px">
								  <?php 
								  if($montant_vers < $montant_fixe)
								  { 
									  if (isset($_GET['ajouter']) and ($_GET['frais'] == $result_rqt_list_fr['idFr']))
										{ ?>
										  <form action="" method="post" >
											  <input  name="idPromo" type="hidden" value="<?php echo $idPromo; ?>" />
											  <input  name="idOp" type="hidden" value="<?php echo $idOp; ?>" />

											  <input  id="<?php echo $result_rqt_list_fr['idFr']; ?>"  name="montVerser" type="text" style="width:55px;" maxlength="6" value="<?php echo $montantvers; ?>" autofocus/>
											  <input  name="montV" type="hidden" value="<?php echo $montant_vers; ?>" />
											  <input  name="montFx" type="hidden" value="<?php echo $montant_fixe; ?>" />
											  <input style="width:60px;" name="BtVerser" type="submit" value="Verser" />
										  </form>											  
										  <?php 
										}
									 else
										{
										?>
										<a id = "<?php echo $result_rqt_list_fr['idFr']; ?>" href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&frais=<?php echo $result_rqt_list_fr['idFr']; ?>&ajouter#<?php echo $result_rqt_list_fr['idFr']; ?>">
										<img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="right" alt="Modif." title="Modifier"/>
										</a>
										<?php 
										}
									}
								
									?>
								</td>
							</tr>
							<?php 
							}
							
							// FIN de la boucle liste fr ?>
						    <tr align="left" style="">
							  <td bgcolor="#DEDEDE" style="border-bottom:solid 1px" scope="col"><div align="right"><em>TOTAL  &nbsp;</em></div></td>
							  <td scope="col" style="background:#AAAAAA; color:#FFFFFF;border-bottom:solid 1px">
								  <div align="right">
								 	<?php 
										echo $sous_tot_montant_fixe; 
										$tot_montant_fixe = $tot_montant_fixe + $sous_tot_montant_fixe ;
									?>
								  </div>							  
							  </td>
							  
							  <td scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php 
										echo $sous_tot_montant_vers  ;
										$tot_montant_vers = $tot_montant_vers+$sous_tot_montant_vers;							
									?>
								  </div>							  
							  </td>
						  	  <td scope="col" style="border-bottom:solid 1px">
							  	<div align="center">
							  	  <?php
								  if($sous_tot_montant_vers == $sous_tot_montant_fixe and $sous_tot_montant_fixe !=0 )
									{ ?>
							  	  	<img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/s_success.png" alt="Pas de Photo" width="20%" height="auto" />
							  	  	<?php
									}  
									?>
					  	        </div></td>
		  				   </tr>
		  
							<?php 
							
						}
						
					}
					
					 ?>
							 <tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
							   <td style="border-bottom:solid 1px" scope="col"><div align="right"><em>TOTAL GENERAL &nbsp; </em></div></td>
							   <td scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php echo $tot_montant_fixe; ?>								  
								  </div>							   
							   </td>
							  
							   <td scope="col" style="border-bottom:solid 1px">
							      <div align="right">
								 	<?php echo $tot_montant_vers; ?>								  
								  </div>							   
							   </td>
							   <td scope="col" style="border-bottom:solid 1px">
							   	<div align="center">
							  	  <?php
								  if($tot_montant_vers == $tot_montant_fixe)
									{ ?>
							  	  	<img class="icon" src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/icon/s_success.png" alt="Pas de Photo" width="20%" height="auto" />
							  	  	<?php
									}  
									?>
					  	        </div>
							  </td>
	      </tr>
		</table>
		</div>
		<br />
		<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&Historiquevers&aca=<?php echo $an_aca;?>">Historique de versement</a>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
		}
	else
		{
		echo "Vous n'avez pas le droit d'acc�der � cette information";
		}
			

	}


?>