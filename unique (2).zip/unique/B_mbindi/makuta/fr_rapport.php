<?php 
	if (isset($_GET['fAculTe'])  and isset($_GET['iDfaC'])and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and isset($_GET['rAppoRtfrais'])){
		?>
		<style type="text/css">
			<!--
			.menuRapportfr{
				width:20%; height:auto; font-family:'Century Schoolbook'; text-align:center; margin:10px; display:inline; float:left; 
			}
			#menuRapportfrActif{
				height:auto;  border:solid 1px #CCCCCC; padding:5px; 
			}
			-->
		</style>

		<div align="left" style="width:100%;">
			<table style="width:100%;">
				<tr>
					<td>
						<div class="menuRapportfr" id="<?php  if (isset($_GET['gene'])){echo "menuRapportfrActif";} ?>" >
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&rAppoRtfrais&gene" ?>">Situation g&eacute;n&eacute;rale</a>
						</div>
						<div class="menuRapportfr" id="<?php  if (isset($_GET['jr'])){echo "menuRapportfrActif";} ?>" >
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&rAppoRtfrais&jr" ?>">Situation journali&egrave;re</a>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<div align="left" style="width:100%;">
			<table style="width:100%;">
				<tr>
					<td>
						<div>
							<?php
							include("B_mbindi/makuta/frais_situation_gene_promo.php");
							include("B_mbindi/makuta/fr_journal.php");
							?>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<?php 
	}
?>