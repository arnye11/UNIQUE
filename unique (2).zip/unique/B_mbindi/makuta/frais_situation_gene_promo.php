 
<?php 
	if (isset($_GET['gene']) || (isset($_GET["imPRessIoN"]) and isset($_GET['doc']) and isset($_GET['fr']) and isset($_GET['gene']) )){
		$fixe = 0;
		$percu = 0;
		$restant = 0;
		$totfixe=0;
		$totpercu=0;
		$totrestant=0;
		
		?>
			<style type="text/css">
				.situationFr{
					padding: 10px; 
										
				}
				.situationGeneFr{
					margin-bottom: 20px;
					
					<?php
						if (isset($_GET["imPRessIoN"]) ){
							?>
							width:90%; 
							text-align: center;
							<?php
						}
						else{
							?>
							width:80%; 
							text-align: left;
							<?php
						}					
					?>
				}
			</style>

		<div class="situationFr"  >
			<?php 
				if (isset($_GET["imPRessIoN"])) {
					?>
					<div class="situationGeneFr" align="center" style=" border-bottom: solid 3px #000000;">
						<table style="width:100%;">	
							<tr >
								<td style="width:100px;height:110px;">	
									<div style="width:100%; height:100%; " >
										<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" style="max-width:100%; max-height:auto;"/>
									</div>
								</td>
								<td style=" " >
									<div align="center" style="font-size:1.1em; text-transform: uppercase; font-weight: bold;" >
										ENSEIGNEMENT SUPERIEUR ET UNIVERSITAIRE
										<br/>
										<?php
											$_SESSION['nom_etablissement']."<br/>";
											echo "&laquo; ".$_SESSION['sigle_tb_etablissement']."&raquo;<br />";
										?> 
										SECRETARIAT GENERAL ADMINISTRATIF ET FINANCES<br />
										
									</div>
								</td>
								<td style="width:100px; height:110px; " align="right">
									<div style="width:100%; height:100%; ">
										<img src="B_mbindi/Biamunda/icon/unique.gif" style="max-width:100%; max-height:auto;" />
									</div>
								</td>
							</tr>
						</table>
					</div>
					<div  class="situationGeneFr" style="margin-bottom: 20px; margin-top: -20px; text-align: left; text-transform: uppercase; font-style: italic;">
						<?php 
							$rqt_fac = "select * from  tb_faculte WHERE idFac = '".$_SESSION['idFac']."'";
							if($exe_rqt_fac = $conDb->query($rqt_fac)){
								if($result_rqt_fac = $exe_rqt_fac->fetch_assoc()){
									echo "FACULTE : ".$result_rqt_fac['designFac'] ;
								}
								else{
									echo "FACULTE INTROUVABLE";
								}
							}
							else{
								echo "IMPOSSIBLE DE TROUVER LA FACULTE";
							}
							
						?>
					</div>
					<div class="situationGeneFr" style="border:solid 2px #000000; border-radius:12px; text-align: center;font-size: 1.5em; font-weight:bold;">
						Situation générale des frais<br>
						<?php echo $an_aca; ?>
					</div>
					<div class="situationGeneFr" style="border: 0px; text-align: left;">
						Pomotion : 
						<?php 
							echo $_SESSION['idPromo']."&nbsp;&nbsp; ".$_SESSION["designOp"] ; 
						?>
					</div>
					<?php 
				}
				else{
					echo "<h3 align='left'>Situation g&eacute;n&eacute;rale de frais</h3>";
					echo "<div id='listAca'>";
						 include("B_mbindi/Biamunda/list_aca.php"); 
					echo "</div>";
					
				}
				
				 ?>
				<div class="situationGeneFr" style="border:solid 1px #A0A0A4;">
					<?php 
						$rqt_list_etud_PromoOp = "SELECT tb_inscription.matricEtud, tb_etudiant.nomEtud, tb_etudiant.postnomEtud, tb_etudiant.prenomEtud, tb_etudiant.sexeEtud, tb_etudiant.datenaissEtud, tb_etudiant.lieunaisEtud FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";
						if($exe_rqt_list_etud_PromoOp = $conDb->query($rqt_list_etud_PromoOp)){
							if($exe_rqt_list_etud_PromoOp->num_rows>0){
								?>
								<table style="width:100%; border:solid 1px #FFFFFF; font-size:12px;">
									<tr style="background:#D6D6D6; border:solid 1px ; text-transform:uppercase;">
										<td rowspan="2"><div align="center">N&deg;</div></td>
										<td rowspan="2"><div align="center">NOM</div></td>
										<td rowspan="2"><div align="center">POSTNOM</div></td>
										<td rowspan="2"><div align="center">PRENOM</div></td>
										<td rowspan="2"><div align="center">SEXE</div></td>
										<td rowspan="2"><div align="center">MATRICULE</div></td>
										<td colspan="3"><div align="center">MONTANT</div></td>
									</tr>
									<tr style="background:#D6D6D6; border:solid 1px ; text-transform:uppercase;">
										<td><div align="center">Fix&eacute;</div></td>
										<td><div align="center">Per&ccedil;u</div></td>
										<td colspan="3"><div align="center">Restant</div></td>
									</tr>
										<?php 
										$numOrdre=0;
										$ligneForm = 1;
										while($tb_listEtud = $exe_rqt_list_etud_PromoOp->fetch_assoc()){
											$fixe = 0;
											$percu = 0;
											$restant = 0;
										
										?>
										<tr style="text-transform:uppercase;<?php if ($ligneForm == 2){echo "background:#D6D6D6;"; $ligneForm =1;}else{$ligneForm =$ligneForm +1;} ?>">
											<td><div align="right"><?php echo $numOrdre=$numOrdre+1; ?></div>					    </td>
											<td><div align="left">&nbsp;<?php echo $tb_listEtud["nomEtud"];?></div></td>
											<td><div align="left">&nbsp;<?php echo $tb_listEtud["postnomEtud"];?></div></td>
											<td><div align="left">&nbsp;<?php echo $tb_listEtud["prenomEtud"];?></div></td>
											<td><div align="center"><?php echo $tb_listEtud["sexeEtud"];?></div></td>
											<td><div align="right">
												<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?profil&id=<?php echo $tb_listEtud['matricEtud'] ?>&frais">
													<?php echo $tb_listEtud["matricEtud"];?>&nbsp;
												</a></div></td>
											
											<td><div align="right">
												<?php 
													//MONTANT FIXE
													$rqt_list_fr = "SELECT SUM(tb_fixation_prix.montantFix) AS montantfixe FROM tb_fixation_prix INNER JOIN tb_frais ON tb_frais.idFr = tb_fixation_prix.idFr WHERE (((tb_fixation_prix.idPromo)='".$_GET['pRomotIon']."') AND((tb_fixation_prix.iDfaC)='".$_SESSION["idFac"]."') AND ((tb_fixation_prix.idAca)='".$an_aca."')) ";
										
													//$rqt_list_fr = "select * from  tb_frais where idTypFr ='".$result_rqt_list_type_fr['idTypFr']."'";
													if($exe_rqt_list_fr = $conDb->query($rqt_list_fr)){
														if($result_rqt_list_fr = $exe_rqt_list_fr->fetch_assoc()){
															if($result_rqt_list_fr['montantfixe']>0){
																$fixe = $result_rqt_list_fr['montantfixe'];
																$totfixe = $totfixe + $fixe;
																echo $fixe;
															}
															else{
															echo $fixe;
															}
														}
														else{
															echo $fixe;
														}
													}
													else{
														echo "Erreur";
													}

												?>
											</div></td>
											<td><div align="right">
												<?php 
													//MONTANT VERSE
													$rqt_fr_vers = "SELECT SUM(montantVers) AS montantVerse FROM tb_versement WHERE matEtud = '".$tb_listEtud["matricEtud"]."' and idAca = '".$an_aca."'";
													if($exe_rqt_fr_vers = $conDb->query($rqt_fr_vers)){
														if($montant_vers = $exe_rqt_fr_vers->fetch_assoc()){
															if($montant_vers['montantVerse']>0){
																$percu = $montant_vers['montantVerse'];
																$totpercu = $totpercu + $percu;
																echo $percu;
															}
															else{
																echo $percu;
															}
														}
														else{
															echo $percu;
														}
													}
													else{
														echo "Erreur";
													}

												
												?>
											</div></td>
											<td><div align="right">
												<?php 
												$restant = $fixe - $percu; 
												echo $restant;
												?>
											</div></td>
										</tr>
										<?php 
										}
										?>
									<tr style="background:#D6D6D6; border:solid 1px ; text-transform:uppercase;">
										<td colspan="6"><div align="right">TOTAL GENERAL</div></td>
										<td><div align="right"><?php echo $totfixe; ?></div></td>
										<td><div align="right"><?php echo $totpercu; ?></div></td>
										<td colspan="3"><div align="right"><?php $totrestant = $totfixe-$totpercu; echo $totrestant; ?></div></td>
									</tr>
								</table>
								<?php
								if (isset($_GET["imPRessIoN"])) {
									?>
									<div style="width:90%;" align="right">
										<p>
											Fait &agrave; <?php echo $_SESSION['villeEts']; ?>, le <?php echo $jour."/".$moi."/".$annee_encours; ?>
										</p>
										<p></p>
										<p>Nom, signature et sceau de l'autorité</p>
									</div>
									<?php 
								}	
								if (!isset($_GET["imPRessIoN"])) {
									?>
									 
									 <a href="?imPRessIoN&doc&fr&gene&pRomotIon=<?php echo $_GET['pRomotIon'];?>&oPtiOn=<?php echo $_GET['oPtiOn'];?>&aca=<?php echo $an_aca; ?>">
										<div style="width:60px; padding: 50px; float: right;">
											<img src="B_mbindi/Biamunda/icon/print.ico" class="ico"><br>
											Imprimer
										</div>
									</a> 
									<?php
								} 
							}
							else{
								echo "Aucun &eacute;tudiant inscrit.";
							}
						}
						else{
							echo "Erreur lors d'&eacute;tablissement de a liste";
						}
					?>
				</div>
				
		</div>
		<?php	
	}
?>