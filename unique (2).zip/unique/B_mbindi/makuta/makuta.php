
<?php 
//-------------------------------------------------------
//----------------------MDL makuta-----------------------
//------------------dans pg_apres_conx-------------------
//-------------------------------------------------------

	if (isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and (isset($_GET['fIxefR']))){
		if (($_SESSION['NivAc'] >= 0 and $_SESSION['NivAc'] <= 5) and ($_SESSION['idFonctAutoDec'] == "admin")){
			$idPromo = "";
			$idOp = "";
			$iDfaC = $_GET['iDfaC'];
			
			if (isset($_GET['promo'])){ $idPromo = $_GET['promo']; }	
			?>
			<style type="text/css">
				<!--
				.menufr{
					width:60px; height:auto; display:inline; float:left; font-family:'Century Schoolbook'; text-align:left; margin:5px; text-align:center; 
				}
				#menufrAct{
					padding:5px; box-shadow:0px 2px 2px 0px #333399;
				}
				.divFr1, .divFr2{
					height:auto; display:inline; float:left; border:solid 1px #CCCCCC; padding:5px; 
				}
				.divFr1{
					width:60%;   
				}
				.divFr2{
					width:36%; 
				}
				-->
			</style>

			<table width="100%">
				<tr>
					<td>
						<?php 
						//Liens promotions
						$rqt_promo = "SELECT idPromo FROM tb_promotion  ORDER BY idPromo ASC";
						if($exe_rqt_promo =mysqli_query($con, $rqt_promo)){
							if(mysqli_num_rows($exe_rqt_promo)>0){
								$list_promo = false;
								while($tb_promotion = mysqli_fetch_assoc($exe_rqt_promo)){
									$idPromo = $tb_promotion["idPromo"];
									$promoOrganise = false;
									$rqt_list_op2 = "select * from  tb_option where idFac = '".$iDfaC."' ORDER BY designOp ASC";
									if($exe_rqt_list_op2 = mysqli_query($con, $rqt_list_op2)){
										if(mysqli_num_rows($exe_rqt_list_op2)>0){
											while($tb_option = mysqli_fetch_assoc($exe_rqt_list_op2)){
												$idOp = $tb_option["idOp"];
												$rqt_verificationProm = "SELECT * FROM tb_organisation_option  where idPromo ='".$idPromo."' AND idOp ='".$idOp."' AND  idAnAca = '".$an_aca."'";
												if($exe_rqt_verificationProm = mysqli_query($con, $rqt_verificationProm)){
													if(mysqli_num_rows($exe_rqt_verificationProm)>0){ 
														while($VerificationPromo =mysqli_fetch_assoc($exe_rqt_verificationProm)) {
															if($VerificationPromo['idPromo'] == $idPromo){
																$promoOrganise = true;
															}
														}
													}
												}
											}
										}
									}
									if($promoOrganise ==true){
										?>
										<div class="menufr" <?php if (isset($_GET['promo']) and $_GET['promo']==$tb_promotion["idPromo"]){ echo "id='menufrAct'"; }?> >
											<a href="?fAculTe&iDfaC=<?php echo $idFac;?>&fIxefR&promo=<?php echo $idPromo;?>"><?php echo $idPromo; ?></a>
										</div>
										<?php
										$list_promo = true;
									}
								}
								if($list_promo == false){echo "<h3 class='erreur'>Aucune promotion organis&eacute;e.</h3>";}
							}
							else{
								echo "<div class='menufr'>Aucune promotion trouv&eacute;e.</div>";
							}
							
						}
						else{
							echo "<div class='menufr'>Aucune promotion trouv&eacute;e.</div>";
						}
						?>
					</td>
				</tr>
			</table>

			<table width="100%">
				<tr>
					<td>
						<div class="divFr1">
							<?php 
								//include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/makuta/rqt_list_fr_a_modifier.php");
								include("B_mbindi/makuta/fixation_fr.php");
								//include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/makuta/fixation_montant_fr.php");
								include("B_mbindi/makuta/rqt_Historique_Vers_fr.php");
								include("B_mbindi/makuta/rqt_ctrl_etudiant_en_ordre.php");
								include("B_mbindi/makuta/rqt_rapport_fr.php");
								include("B_mbindi/makuta/f_ajout_fr.php");
								include("B_mbindi/makuta/f_modifier_fr.php");
							?>
						</div>
						<div class="divFr2">
							<?php 
								include("B_mbindi/makuta/rqt_fr_exige_pour_exames.php");
								//include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/makuta/f_fixation_de_frais.php");
								include("B_mbindi/makuta/rql_list_fr.php");
							?>
						</div>
					
					</td>
				</tr>
			</table>

			 <?php 	
		}
		else{
				echo "Vous n'avez pas le droit d'acc&eacute;der � cette information";
			}
	}

?>