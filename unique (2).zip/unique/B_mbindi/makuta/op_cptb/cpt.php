<?php  
	if (isset($_GET['compte'])) {
		?>
		<style type="text/css">
			.cpt{
				padding: 20px;
				border: solid 1px #000000;
			}
			.operation{
				display:inline; 
				float:left; 
				padding:7px; 
				background:#005f7e; 
				color: #ffffff;
				border-radius: 8px;
				margin: 5px;

			}
			.operation:hover{
				background: #005f7e; 
				box-shadow: 1px 1px 1px 4px #a7fffd;
				padding:8px; 
			}
			.t{
				color:#bdbdbd;
			}
		</style>
		<div>
			<h1>Op&eacute;rations du compte</h1>
		</div>
		<?php  
		if (isset($_GET["compte"])) {
			$compte=$_GET["compte"];
			if ($compte != "") {
				$rqt_cpt = "SELECT * FROM tb_compte WHERE idCpt ='".$compte."'";
				if($exe_rqt_cpt = mysqli_query($con, $rqt_cpt)){
					if($tb_compte = mysqli_fetch_assoc($exe_rqt_cpt)){
						?>
						<div class="cpt">
							<table style="width:100%;">
								<tr>
									<td>
										<div style="width:50%; display:inline; float:left;">
												<table style="width:100%;">
													<tr>
														<td><div align="right">Nom&eacute;ro compt : </div></td>
														<td>
															<div align="left">
																<?php echo $tb_compte["idCpt"] ;?>
															</div>
														</td>
													</tr>
													<tr>
														<td><div align="right">Intitul&eacute; du compte : </div></td>
														<td>
															<div align="left">
																<?php echo $tb_compte["designCpt"] ;?>
															</div>
														</td>
													</tr>
													<tr>
														<td><div align="right"></div></td>
														<td>
															<div align="left" style="">
																<a href="?oP_cPtablE82Zxs&compte=<?php echo $_GET['compte']; ?>&0peratI0n#<?php echo $_GET['compte']; ?>">
																	<div class="operation">Faire une op&eacute;ration</div>
																</a>
															</div>
														</td>
													</tr>
												</table>
												<div>
													
												</div>
										</div>
										<div style="width:45%; display:inline; float:right; border: solid 1px #cdcdcd;">
											<div style="background:#cecece; text-align:center;">Solde</div>
											<table style="width:100%;">
												<tr style="background:#cecece">
													<td><div align="center">CDF</div></td>
													<td><div align="center">USD</div></td>
												</tr>
												<tr>
													<td>
														<div align="right" style="margin-right:5px;">
															<?php 
																//SOLDE CDF
																$entrees = 0 ;
																$sorties = 0 ; 
																$solde = 0 ;

																//ENTREES CDF
																$rqt_Entr = "SELECT SUM(montantOper) AS montantTotE1 FROM tb_operation WHERE idCpt = '".$compte."' AND deviseOper = 'CDF' AND idTypOper = 'Entr1'";
																if($exe_rqt_Entr = mysqli_query($con, $rqt_Entr)){
																	if($tb_operationE = mysqli_fetch_assoc($exe_rqt_Entr)){
																		$entrees = $tb_operationE["montantTotE1"];
																		//echo $entrees;
																	}
																}
																else{
																	echo "<div class='erreur'>Erreur 1 </div>";
																}
																
																//SORTIES CDF
																$rqt_Sort = "SELECT SUM(montantOper) AS montantTotS1 FROM tb_operation WHERE idCpt = '".$compte."' AND deviseOper = 'CDF' AND idTypOper = 'Sort2'";
																if($exe_rqt_Sort = mysqli_query($con, $rqt_Sort)){
																	if($tb_operationS = mysqli_fetch_assoc($exe_rqt_Sort)){
																		$sorties = $tb_operationS["montantTotS1"];
																		//echo $sorties;
																	}
																}
																else{
																	echo "<div class='erreur'>Erreur 2 </div>";
																}
																//CALCUL SOLDE CDF
																$solde = $entrees - $sorties ;
																echo number_format($solde, 0, ',', ' ') ;
															?>
														</div>
													</td>
													<td>
														<div align="right" style="margin-right:5px;">
															<?php 
																//SOLDE USD
																$entrees = 0 ;
																$sorties = 0 ; 
																$solde = 0 ;

																//ENTREES USD
																$rqt_Entr = "SELECT SUM(montantOper) AS montantTotE1 FROM tb_operation WHERE idCpt = '".$compte."' AND deviseOper = 'USD' AND idTypOper = 'Entr1'";
																if($exe_rqt_Entr = mysqli_query($con, $rqt_Entr)){
																	if($tb_operationE = mysqli_fetch_assoc($exe_rqt_Entr)){
																		$entrees = $tb_operationE["montantTotE1"];
																		//echo $entrees;
																	}
																}
																else{
																	echo "<div class='erreur'>Erreur 1 </div>";
																}
																
																//SORTIES USD
																$rqt_Sort = "SELECT SUM(montantOper) AS montantTotS1 FROM tb_operation WHERE idCpt = '".$compte."' AND deviseOper = 'USD' AND idTypOper = 'Sort2'";
																if($exe_rqt_Sort = mysqli_query($con, $rqt_Sort)){
																	if($tb_operationS = mysqli_fetch_assoc($exe_rqt_Sort)){
																		$sorties = $tb_operationS["montantTotS1"];
																		//echo $sorties;
																	}
																}
																else{
																	echo "<div class='erreur'>Erreur 2 </div>";
																}
																//CALCUL SOLDE USD
																$solde = $entrees - $sorties ;
																echo number_format($solde, 0, ',', ' ') ;
															?>
														</div>
													</td>
												</tr>
											</table>
										</div>
									</td>
								</tr>
							</table>						
						</div>
						<?php 
							if (isset($_GET["0peratI0n"])) {												
								?>
								<div style="margin:20px; box-shadow: 2px 2px 2px 2px #cdcdcd; border: solid 1px #cdcdcd; ">
									<div style="width:100%;">
										<a href="?oP_cPtablE82Zxs&compte=<?php echo $_GET['compte']; ?>#<?php echo $_GET['compte']; ?>">
											<div style="width:40px; height:40px; line-height:40px; background:#FF0000; display: inline-block; position: relative; float:right; text-align:center; color: #FFFFFF;">X</div>
										</a>
									</div>
									<div style="height:40px; line-height:40px; background:#003758; text-align:center; color: #FFFFFF;font-size: 1.5em;">Effectuer une op&eacute;ration</div>
									<div style="margin:20px;">
										<?php 
											echo "<div style='color:#00b702;'>";
												echo $sms_gerer;
											echo "</div>";
										?>
										<form method="post">
											<input type="hidden" name="idCpt" value="<?php echo $_GET['compte']; ?> ">
											<input type="hidden" name="idAutoDec" value="<?php echo $_SESSION['idAutoDec']; ?> ">
											<div style="width:30%; margin:10px;">
												<select name="idTypOper" style="width:85%; height:40px; font-size:1em;">
													<?php 
														$rqtTypOper = "select * from tb_type_operation order by designTypOper";
														if($exe_rqtTypOper = mysqli_query($con, $rqtTypOper)){
															if ($exe_rqtTypOper->num_rows > 0) {
																echo "<option value=''>Type d'op&eacute;ration</option>";
																while($tb_type_operation = mysqli_fetch_assoc($exe_rqtTypOper)){
																	?>
																	<option value="<?php echo $tb_type_operation["idTypOper"] ?>"><?php echo $tb_type_operation["designTypOper"] ?></option>
																	
																	<?php
																}
															}
															else{
																echo  "<option value=''>Pas de type d'opération</option>";
															}
														}
														else{
															echo  "<option value=''>Erreur</option>";
														}
													?>
												</select>
											</div>
											<div style="width:30%; margin:10px;">
												<input type="text" name="montantOper" placeholder="Montant" value="<?php if (isset($_POST["btOperer"])) echo $_POST['montantOper'] ; ?>" style="width:55%; height:40px; font-size:1em;">
												<select name="deviseOper" style="width:30%; height:40px; font-size:1em;">
													<option value="<?php if (isset($_POST["btOperer"])) echo $_POST['deviseOper'] ; ?>"><?php if (isset($_POST["btOperer"])) echo $_POST['deviseOper'] ; else echo "Dévise"; ?></option>
													<option value="CDF">CDF</option>
													<option value="USD">USD</option>
												</select>
											</div>
											<div style="width:50%; margin:10px;">
												<textarea name="motifOper" placeholder="Motif de l'opération" rows="2" style="width:85%; height:40px; font-size:1.5em;"><?php if (isset($_POST["btOperer"])) echo $_POST['motifOper'] ; ?></textarea>
											</div>
											<!--
											<div style="width:30%; margin:10px;">
												<input type="date" name="dateOper" value="<?php echo $dateOper ; ?>" style="width:85%; height:40px; font-size:1.5em;">
											</div>
											-->
											<i>Tous les champs sont obligatoire </i>
											<div style="width:30%; margin:10px; margin-left: 300px;">
												<input type="submit" name="btOperer" value="Op&eacute;rer" style="width:85%; height:40px; font-size:1em;">
											</div>
										</form>	
									</div>
									  
								</div>
								<?php
							} 
						?>
						<div>
							<div style="font-size:1.5em;">Detaille du compte il y a un mois</div>
							<div align="center">
								<?php 
									$num = 1;
									$rqt_oper = "SELECT * FROM tb_operation RIGHT JOIN tb_type_operation ON tb_operation.idTypOper = tb_type_operation.idTypOper WHERE tb_operation.idCpt = '".$_GET['compte']."' order by dateOper  DESC";
									if($exe_rqt_oper = mysqli_query($con, $rqt_oper)){
										if ($exe_rqt_oper->num_rows>0) {
											?>
											<table style="width:90%;" cellspacing="0" cellpadding="1" border="1">
												<tr style="background:#cecece;">
													<td>N°</td>
													<td>Op&eacute;ration</td>
													<td>Date</td>
													<td>Montant</td>
													<td>Devise</td>
													<td>Motif</td>
													<td>Agent</td>
													<td>Obs.</td>
												</tr>
												<?php
												while ($tb_operation = mysqli_fetch_assoc($exe_rqt_oper)) {
													?>
													<tr>
														<td><?php echo $num++; ?></td>
														<td><?php echo $tb_operation["designTypOper"]; ?></td>
														<td><?php echo $tb_operation["dateOper"]; ?></td>
														<td><?php echo $tb_operation["montantOper"]; ?></td>
														<td><?php echo $tb_operation["deviseOper"]; ?></td>
														<td><?php echo $tb_operation["motifOper"]; ?></td>
														<td><?php echo $_SESSION['PronomNomAutoDec'] ; ?></td>
														<td></td>
													</tr>
													<?php
												}
												?>
											</table>
											<?php
										}
										else{
											echo "Aucune op&eacute;ration ce dernier temps";
										}
									} 
								?>
								
							</div>
						</div>
						<?php 
					}
					else{
						echo "<h1>Ce Compte n'existe pas</h1>";
					}
				}
				else{
					echo "<h1 class='erreur'>Echec d'affichage du compte</h1>";
				}
			}
			else{
				echo "<h1 class='erreur'>Prière de sel&eacute;ctionner un compte</h1>";
			}
		}
	}
?>
