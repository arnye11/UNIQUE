<?php 
	if (isset($_GET['oP_cPtablE82Zxs'])) {
 		if ($_SESSION['idFonctAutoDec']=="CPTBL" || $_SESSION['idFonctAutoDec']=="CAIS" || $_SESSION['idAutoDec']=="admin1") {
 			?>
	 		<style type="text/css">
	 			.cpts{
	 				width: 95%;
	 				height: 40px;
	 				padding: 5px;
	 				line-height: 40px;
	 				font-size: 1.2em;
	 				box-shadow: 0px 0px 4px 0px #cdcdcd;
	 				text-align: left;
	 			}
	 			.cpts:hover{
	 				background: #003758;
	 				color: #ffffff;
	 			}

	 		</style>
	 		<table style="width:100%;">
	 			<tr>
	 				<td>
	 					<div style="width:25%; border: solid 1px #cdcdcd; display:inline; float:left;" align="center">
	 						<h1>Comptes</h1>
	 						<?php
	 							if ($_SESSION['idFonctAutoDec']=="CPTBL" || $_SESSION['idAutoDec']=="admin1") {
		 							if (!isset($_GET["aJ0uterCpt"])) {
			 							echo "<div>";
				 						echo "<a href='?oP_cPtablE82Zxs&aJ0uterCpt'>Cr&eacute;er</a>";
				 						echo "</div>";
				 					}

		 							if (isset($_GET["aJ0uterCpt"])) {
		 							 	echo "<div style='color:#31c900;'>";
	 							 		echo $sms_gerer;
	 							 		echo "</div>";
		 							 	
		 							 	?>
	 							 		<form method="post">
	 							 			<div style="padding: 10px;">
	 							 				<input type="text" name="idCpt" placeholder="Num&eacute;ro compte" style="width:85%; height:40px; font-size:1em;">
	 							 			</div>
	 							 			<div style="padding: 10px;">
	 							 				<input type="text" name="designCpt"placeholder="Intitul&eacute; du compte" style="width:85%; height:40px; font-size:1em;">
	 							 			</div>
	 							 			<div style="padding: 10px;">
	 							 				<input type="submit" name="btCreerCpt" value="Cr&eacute;er" style="width:85%; height:40px; font-size:1em;">
	 							 			</div>
	 							 		</form>
	 							 		<div style="width:85%; height:40px; font-size:1em;">
			 								<a href='?oP_cPtablE82Zxs'>Annuler</a>
			 						 	</div>
		 							 	<?php 
		 							} 
		 						}
		 						?>
								<div style="padding: 10px;" align="center">
									<?php
		 							$rqt_list_cpt = "SELECT * FROM  tb_compte ORDER BY designCpt";
									if($exe_rqt_list_cpt = mysqli_query($con, $rqt_list_cpt)){
										if($exe_rqt_list_cpt->num_rows>0){
											while($tb_compte = mysqli_fetch_assoc($exe_rqt_list_cpt)) {
												?>
												<div style="" align="center">
													<a href='?oP_cPtablE82Zxs&compte=<?php echo $tb_compte["idCpt"]; ?>' >
														<div class="cpts" id="<?php echo $tb_compte["idCpt"]; ?>">
															<?php echo $tb_compte["designCpt"]; ?>
														</div>
													</a>
												</div>
												<?php
											}
										}
										else{
											echo "<div style='font-size: 1em;margin:20px;'>Pas des comptes</div>";
										}
									}
									else{
										echo  "Echec de trouver les comptes";
									}
									?>
								</div>
								<?php
	 						?>  
	 					</div>
	 					<div style="width:70%; border: solid 1px #cdcdcd; display:inline; float:left;padding: 20px;">
	 						<?php 
	 							if (!isset($_GET['compte'])) {
	 								echo "<h1>Sel&eacute;ctionner un compte</h1>";
	 							}
	 						 
								include("B_mbindi/makuta/op_cptb/cpt.php");
							?>
	 					</div>
	 				</td>
	 			</tr>
	 		</table> 
			
			<?php  
		}
		else{
			echo "<h1>Désolé!<br> Vous n'avez pas droit à cette information.</h1>";
		}
	}
?>