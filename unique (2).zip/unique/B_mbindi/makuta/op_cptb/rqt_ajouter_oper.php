<?php 
	if (isset($_GET["0peratI0n"])) {
		$dateOper = date('Y-m-d');	 
		if (isset($_POST["btOperer"])) {
			$idCpt = filter_input(INPUT_POST,'idCpt', FILTER_SANITIZE_SPECIAL_CHARS);
			$idTypOper = filter_input(INPUT_POST,'idTypOper', FILTER_SANITIZE_SPECIAL_CHARS);
			$montantOper = filter_input(INPUT_POST,'montantOper', FILTER_SANITIZE_SPECIAL_CHARS);
			$deviseOper = filter_input(INPUT_POST,'deviseOper', FILTER_SANITIZE_SPECIAL_CHARS);
			$idAutoDec = filter_input(INPUT_POST,'idAutoDec', FILTER_SANITIZE_SPECIAL_CHARS);
			$motifOper = filter_input(INPUT_POST,'motifOper', FILTER_SANITIZE_SPECIAL_CHARS);
			//$dateOper = filter_input(INPUT_POST,'dateOper', FILTER_SANITIZE_SPECIAL_CHARS);
			//$dateOper .= date(' H:m:s');

			if($idCpt!="" and $idTypOper!="" and $montantOper!="" and $deviseOper!="" and $motifOper!="" ){
				$rqt_insrt_oper = "INSERT INTO tb_operation VALUES (NULL, '".$idCpt."','".$idTypOper."','".$montantOper."','".$deviseOper."','".$_SESSION["idAutoDec"]."','".$motifOper."',NOW())";
				if($exe_rqt_insrt_oper = mysqli_query($con, $rqt_insrt_oper)){
					$sms_gerer = "Opération effectuée";
					header ('location:?oP_cPtablE82Zxs&compte='.$_GET['compte'].'&0peratI0n&sms='.$sms_gerer.'#'.$_GET['compte']);
				}
				else{
					$sms_gerer = "<div style='color:#FF0000;'>Echec de de l'op&eacute;ration</div>";
				}
			}
			else{
				$sms_gerer = "<div style='color:#FF0000;'>Veuillez remplir tous les champs</div>";
			}
		}
		if (isset($_GET["sms"]))
			$sms_gerer = $_GET["sms"];	
	}
?>