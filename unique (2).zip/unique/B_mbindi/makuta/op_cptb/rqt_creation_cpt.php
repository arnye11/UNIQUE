<?php 
	if (isset($_POST["btCreerCpt"])) {
		$idCpt = filter_input(INPUT_POST,'idCpt', FILTER_SANITIZE_SPECIAL_CHARS);
		$designCpt = filter_input(INPUT_POST,'designCpt', FILTER_SANITIZE_SPECIAL_CHARS);
		
		if($idCpt!="" and $designCpt!="" ){
			$rqt_insrt_cpt = "INSERT INTO tb_compte VALUES ('".$idCpt."','".$designCpt."','".$_SESSION["idAutoDec"]."', NOW())";
			if($exe_rqt_insrt_cpt = mysqli_query($con, $rqt_insrt_cpt)){
				$sms_gerer = "Le compte a été crée";
				header ('location:?oP_cPtablE82Zxs&aJ0uterCpt&sms='.$sms_gerer);
			}
			else{
				$sms_gerer = "<div style='color:#FF0000'>Echec de cr&eacute;ation du compte</div>";
			}
		}
		else{
			$sms_gerer = "<div style='color:#FF0000'>Veuillez remplir tous les champs</div>";
		}
	}
	if (isset($_GET["sms"]))
		$sms_gerer = $_GET["sms"];	
?>