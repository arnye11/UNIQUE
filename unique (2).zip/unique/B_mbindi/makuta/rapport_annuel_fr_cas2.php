<?php

$MF=0;
$TI=0;
$TO=0;
$MV=0;
$MA=0;
$TMF = 0;
$TMV = 0;
$TMA = 0;
$TGMF = 0;
$TGMV = 0;
$TGMA = 0;

$TGI_G1L2 = 0;
$TGMF_G1L2 = 0;
$TGMA_G1L2 = 0;
$TGMV_G1L2 = 0;


 	$rqt_list_promotion = "select * from promotion";
	if($exe_rqt_list_promotion = mysql_query($rqt_list_promotion))
		{
		while($result_rqt_list_promotion = mysql_fetch_assoc($exe_rqt_list_promotion)) //SI EXECUTION, ON RECUPERE SES INFORMATION de tous les type_frais 
			{
			$TGMV =0;
			
			$rqt_list_type_fr = "select * from  type_frais";
			if($exe_rqt_list_type_fr = mysql_query($rqt_list_type_fr))
				{
				echo "<h1>".$result_rqt_list_promotion['idPromo']."</h1>";
				?>
				
				<table border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF" style="font-family:Bookman Old Style; font-size:13px; box-shadow:0px 2px 2px 2px #003300;">
				  <tr align="left">
					<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">FRAIS</div></th>
					<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center" title="Montant Fix�">M.F</div></th>
					<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center" title="Total Inscrit">T.I</div></th>
					<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center" title="Total en Ordre">T.O</div></th>
					<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center" title="Montant Vers�">M.V</div></th>
					<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center" title="Montant Attendu">M.A</div></th>
				  </tr>
				  
						<?php 
						
						while($result_rqt_list_type_fr = mysql_fetch_assoc($exe_rqt_list_type_fr)) //SI EXECUTION, ON RECUPERE SES INFORMATION de tous les type_frais 
							{ 
							$MV = 0;
							$TMV = 0 ;
							$TMF = 0 ;
							$TMA = 0;
							
							?>
							
							<tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
								<th scope="col" style="border-bottom:solid 1px"><div align="center"><?php echo $result_rqt_list_type_fr['designTypFr']; ?></div></th>
								<th scope="col" style="border-bottom:solid 1px"><div align="center">$</div></th>
								
								<th scope="col" style="border-bottom:solid 1px"><div align="center"></div></th>
								<th scope="col" style="border-bottom:solid 1px">&nbsp;</th>
								<th scope="col" style="border-bottom:solid 1px">&nbsp;</th>
								<th scope="col" style="border-bottom:solid 1px">&nbsp;</th>
							</tr>
							<?php 
							$rqt_list_fr = "select * from  frais where idTypFr ='".$result_rqt_list_type_fr['idTypFr']."'";
							if($exe_rqt_list_fr = mysql_query($rqt_list_fr))
								{
								while($result_rqt_list_fr = mysql_fetch_assoc($exe_rqt_list_fr)) //SI EXECUTION, ON RECUPERE SES INFORMATION de tous les frais 
									{
									$MF = 0 ;
									//$TGMV =0;
									//$TMA = 0;
									
									//verification si le fr est fix� dans la promo o� est inscrit l'etudiant 
									$rqt_slct_fr_fix = "select * from fixation_prix where idFr = '".$result_rqt_list_fr['idFr']."' and idPromo = '".$result_rqt_list_promotion['idPromo']."' and idAca = '".$_SESSION['idAnAca']."'";
									if($exe_rqt_slct_fr_fix = mysql_query($rqt_slct_fr_fix))//si la rqt est exe, on recupere le resultat
										{
										if($rsult_exe_rqt_slct_fr_fix = mysql_fetch_assoc($exe_rqt_slct_fr_fix))//si le result est recup, on prepare l'affichage
											{
											?>
											<tr align="left" style="">
											  <!--Designation frais-->
											  <th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_fr['designFr']; ?></th>
											  <!--Montant fix�-->	
											  <th scope="col" style="background:#AAAAAA; color:#FFFFFF;border-bottom:solid 1px">
												<div align="right">
													  <?php 
														$MF = $rsult_exe_rqt_slct_fr_fix['montantFix'];
														$TMF = $TMF + $MF ;
																										
														echo "<i title='".$MF." $ montant fix�'>".$MF."</i>";
														?>
												</div>									  </th>
											  <!--Montant vers�-->
											  <th scope="col" style="border-bottom:solid 1px">
												<div align="right" >
												  <?php 
											  //RQT ETUDIANTS INSCRIT -- CRITERE : DANS PROMOTION, OPTION, DEPARTEMENT, ANNEE ACADEMIQUE selection
												$slct_etud_incrit_pro_aca = "select * from inscription where idProm = '".$result_rqt_list_promotion['idPromo']."' and  idAca = '".$an_aca."' ";
												if($exe_slct_etud_incrit_pro_aca = mysql_query($slct_etud_incrit_pro_aca))
													{
													$TI = 0;
													$TO = 0;
													//$TMA = 0;
													
													while($result_slct_etud_incrit_pro_aca = mysql_fetch_assoc($exe_slct_etud_incrit_pro_aca)) 
														{
														$montant_vers =  "select sum(montantVers) as montant_vers from versement where idFr = '".$result_rqt_list_fr['idFr']."' and matEtud = '".$result_slct_etud_incrit_pro_aca['matricEtud']."' and idAca = '".$an_aca."'";
														if($exe_montant_vers = mysql_query($montant_vers))
															{
															//$TO = 0;
															if($result_exe_montant_vers = mysql_fetch_assoc($exe_montant_vers)) 
																{
																if($result_exe_montant_vers['montant_vers'] == $MF)
																	{
																	$TO = $TO +1;
																	$TMV = $TMV+$result_exe_montant_vers['montant_vers'];
																	}
																}
															}
														else
															{
															echo "<i class='echec'>Erreur</i>";
															}
														$TI = $TI + 1;
														}
													echo "<i title='".$TI." Inscrits'>".$TI."</i>";
													}
																 
											  ?>									  
											  </div></th>
											  <!--Lien Moditier-->
											  <th scope="col" style="border-bottom:solid 1px ; background:#C0DCC0">
												<div align="right"><?php echo "<i title='".$TO." en ordre'>".$TO."</i>"; ?>									  </div></th>
											  <th scope="col" style="border-bottom:solid 1px;  background:#339999;"><div align="right">
												<?php 
													$MV = $MF*$TO;
													echo "<i title='".$MV." $ vers�s'>".$MV."</i>";
													
												  ?>
											  </div></th>
											  <th scope="col" style="border-bottom:solid 1px">
											   <div align="right">
												  <?php 
													$MA = $MF*$TI;
													echo "<i title='".$MA." $ attendus'>".$MA."</i>";
													$TMA = $TMA+$MA;
												   ?>
											   </div>
											  </th>
											</tr>
											<?php 
											}
										}
									}
									
									// FIN de la boucle liste fr ?>
									<tr align="left" style="">
									  <th bgcolor="#DEDEDE" style="border-bottom:solid 1px" scope="col"><div align="right"><em>TOTAL &nbsp;</em></div></th>
									  <th scope="col" style="background:#AAAAAA; color:#FFFFFF;border-bottom:solid 1px">
										  <div align="right">
											<?php 
												echo $TMF; 
												$TGMF = $TGMF + $TMF ;
											?>
										  </div>							  </th>
									  
									  <th bgcolor="#DEDEDE" scope="col" style="border-bottom:solid 1px"><div align="right"><?php echo "<i title='".$TI." Inscrits'>".$TI."</i>"; ?></div></th>
									  <th bgcolor="#DEDEDE" scope="col" style="border-bottom:solid 1px">&nbsp;</th>
									  <th scope="col" style="border-bottom:solid 1px; background:#009999;"><div align="right">
										<?php 
												echo "<i title='".$TMV." $ Total montant vers�'>".$TMV."</i>";$TMV  ;
												$TGMV = $TGMV+$TMV;							
											?>
									  </div></th>
									  <th bgcolor="#DEDEDE" scope="col" style="border-bottom:solid 1px">
										<div align="right">
											<?php 
												
												echo "<i title='".$TMA." $ Total montant attendu'>".$TMA."</i>";
												$TGMA = $TI*$TMF;
												//$ 
											?>
										</div>
										
									  </th>
								   </tr>
				  
									<?php 
									
								}
								
							}
							
							 ?>
									 <tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
									   <th style="border-bottom:solid 1px" scope="col"><div align="right"><em>TOTAL GENERAL  &nbsp;&nbsp;</em></div></th>
									   <th scope="col" style="border-bottom:solid 1px">
									   		<?php 
												echo "<i title='".$TGMF." $ Total g�n�eral montant fix�'>".$TGMF."</i>"; 
												$TGMF_G1L2 = $TGMF_G1L2 + $TGMF ;
											?> 
									   </th>
									   <th scope="col" style="border-bottom:solid 1px">
									   		<?php 
												$TGI_G1L2 = $TGI_G1L2 + $TI ;
												echo "<i title='".$TI." inscrits'>".$TI."</i>"; 
											?>
									   </th>
									   <th style="border-bottom:solid 1px" scope="col"><div align="center"><br/>
									       <br/>
									   </div></th>
									   <th style="border-bottom:solid 1px" scope="col">
									   		<?php 
												echo "<i title='".$TGMV." $ Total g�n�eral montant vers�'>".$TGMV."</i>";
												$TGMV_G1L2 = $TGMV_G1L2 + $TGMV ;
											?>
									   </th>
									   <th scope="col" style="border-bottom:solid 1px">
										<?php 
											$TGMA = $TGMF*$TI; 
											echo "<i title='".$TGMA." $ Total g�n�eral montant attendu'>".$TGMA."</i>";
											$TGMA_G1L2 = $TGMA_G1L2 + $TGMA ;
										?>
										
									   </th>
				  </tr>
				</table>
				<br />
				
				<?php 
				}
			else
				{
				echo  "Impossible d'atteindre les frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
				}
			}
		 ?>
		 <!--SITUATION SYNTHETIQUE DES FRAIS -->
		 <h1>Situation synth�tiques</h1>
         <div >		
           <table border="0">
             <tr>
               <td><div align="right">Total G&eacute;n&eacute;ral Inscrits de G1 - L2 : </div></td>
			  <td><div align="right"><?php echo $TGI_G1L2; ?></div>		       </td>
			  <td><div align="left">inscrits</div></td>
		    </tr>
             <tr>
               <td><div align="right">Total G&eacute;n&eacute;ral Montant Fix&eacute; de G1 - L2  : </div></td>
			  <td><div align="right"><?php echo $TGMF_G1L2; ?></div>		       </td>
			  <td><div align="left">$</div></td>
		    </tr>
             <tr>
               <td><div align="right">Total G&eacute;n&eacute;ral Montant Attendu de G1 - L2  : </div></td>
			  <td><div align="right"><?php echo $TGMA_G1L2; ?></div></td>
			  <td><div align="left">$</div></td>
		    </tr>
             <tr>
               <td><div align="right">Total G&eacute;n&eacute;ral Montant Vers&eacute;  de G1 - L2 : </div></td>
			  <td><div align="right"><?php echo $TGMV_G1L2; ?></div></td>
			  <td><div align="left">$</div></td>
		    </tr>
              </table>
         </div>
         <?php	
		}
	


?>