<?php 
if (isset($_GET['gerer_frais']) and !isset($_GET['fix_pr']))
	{ 
	echo "<div style='border-bottom:groove'>LISTE DES FRAIS</div>";
	$rqt_list_type_fr = "select * from  tb_type_frais";
	if($exe_rqt_list_type_fr = $conDb->query($rqt_list_type_fr))
		{
		while($result_rqt_list_type_fr = $exe_rqt_list_type_fr->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
			{
			echo "<div align='left' title='code : ".$result_rqt_list_type_fr['idTypFr']."' style='margin-bottom:5px; background:#F0F0F0; text-transform:lowercase;'>";
			echo "<div align='left' style='background:#5B5B5B; color:#FFFFFF; padding-left:5px;'>".$result_rqt_list_type_fr['designTypFr']."</div>";
			
			$rqt_list_fr = "select * from  tb_frais where idTypFr ='".$result_rqt_list_type_fr['idTypFr']."'";
			if($exe_rqt_list_fr = $conDb->query($rqt_list_fr))
				{
				while($result_rqt_list_fr = $exe_rqt_list_fr->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{
					echo "<div align='left' title='code : ".$result_rqt_list_fr['idFr']."' style='margin-bottom:5px;margin-left:20px; border-bottom:solid 2px #FFFFFF; background:#F0F0F0;'>".$result_rqt_list_fr['designFr']."</div>";
					}
				}
			else
				{			
				echo  "Impossible d'atteindre les frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
				}
			echo "</div>";
			}
		}
	else
		{
		echo  "Impossible d'atteindre les types des frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}


?>