<?php 
if (isset($_GET['gerer_frais']) and isset($_GET['fix_pr']))
	{
	//LES VAR
	//pour G1 
	$montant_fixeG1=0;
	$tot_montant_fixe_fr_G1=0;
	$tot_gene_montant_fixe_fr_G1=0;
	//pour G2
	$montant_fixeG2 =0;
	$tot_montant_fixe_fr_G2 = 0;
	$tot_gene_montant_fixe_fr_G2 = 0;
	//pour G3
	$montant_fixeG3 =0;
	$tot_montant_fixe_fr_G3 = 0;
	$tot_gene_montant_fixe_fr_G3 = 0;
	//pour L1
	$montant_fixeL1 =0;
	$tot_montant_fixe_fr_L1 = 0;
	$tot_gene_montant_fixe_fr_L1 = 0;
	//pour L2
	$montant_fixeL2 =0;
	$tot_montant_fixe_fr_L2 = 0;
	$tot_gene_montant_fixe_fr_L2 = 0;
	
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Fixation des frais </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
	$rqt_list_type_fr_a_fix = "select * from  tb_type_frais";
	if($exe_rqt_list_type_fr_a_fix = $conDb->query($rqt_list_type_fr_a_fix))
		{
		?>
		<table border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF" style="font-family:Bookman Old Style; font-size:13px; box-shadow:0px 2px 2px 2px #003300;">
		  <tr align="left">
		    <th colspan="2" bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">FRAIS</div></th>
		    <th colspan="5" bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">PRIX PAR PROMOTION </div></th>
	      </tr>
		  <tr align="left">
		    <th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">Code</div></th>
			<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">D&eacute;signation</div></th>
			<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">G1</div></th>
			<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">G2</div></th>
			<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">G3</div></th>
			<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">L1</div></th>
			<th bgcolor="#DEDEDE" style="font-size:15px;" scope="col"><div align="center">L2</div></th>
		  </tr>
		  <?php 
				while($result_rqt_list_type_fr_a_fix = $exe_rqt_list_type_fr_a_fix->fetch_assoc()) //SI EXECUTION, ON RECUPERE les type de frais
					{ 
					$tot_montant_fixe_fr_G1=0;
					$tot_montant_fixe_fr_G2=0;
					$tot_montant_fixe_fr_G3=0;
					$tot_montant_fixe_fr_L1=0;
					$tot_montant_fixe_fr_L2=0;
					?>
					<tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
						<th scope="col" style="border-bottom:solid 1px">
						  <div align="center"><?php echo $result_rqt_list_type_fr_a_fix['idTypFr']; ?>						</div></th>
						<th scope="col" style="border-bottom:solid 1px"><div align="center"><?php echo $result_rqt_list_type_fr_a_fix['designTypFr']; ?></div></th>
						<th scope="col" style="border-bottom:solid 1px"><div align="center">$</div></th>
						<th scope="col" style="border-bottom:solid 1px"><div align="center">$</div></th>
						<th scope="col" style="border-bottom:solid 1px"><div align="center">$</div></th>
						<th scope="col" style="border-bottom:solid 1px"><div align="center">$</div></th>
						<th scope="col" style="border-bottom:solid 1px"><div align="center">$</div></th>
					</tr>
					<?php 
					$rqt_list_fr_a_fix = "select * from  tb_frais where idTypFr ='".$result_rqt_list_type_fr_a_fix['idTypFr']."'";
					if($exe_rqt_list_fr_a_fix = $conDb->query($rqt_list_fr_a_fix))
						{
						while($result_rqt_list_fr_a_fix = $exe_rqt_list_fr_a_fix->fetch_assoc()) //SI EXECUTION, ON RECUPERE les frais 
							{
							$montant_fixeG1=0; 
							$montant_fixeG2=0; 
							$montant_fixeG3=0; 
							$montant_fixeL1=0; 
							$montant_fixeL2=0; 
							?>
							
							<tr align="left" style="">
                              <th scope="col" style="border-bottom:solid 1px"> <?php echo $result_rqt_list_fr_a_fix['idFr']; ?> </th>
							  <th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_fr_a_fix['designFr']; ?></th>
							  <th scope="col" style="border-bottom:solid 1px">
								<div align="right">
								  <?php 
								  //POUR G1
								  	$rqt_slct_fr_fixG1 = "select * from tb_fixation_prix where idFr = '".$result_rqt_list_fr_a_fix['idFr']."' and idPromo = 'G1' and idAca = '".$_SESSION['idAnAca']."'";
									if($exe_rqt_slct_fr_fixG1 = $conDb->query($rqt_slct_fr_fixG1))
										{
										if($rsult_exe_rqt_slct_fr_fixG1 = $exe_rqt_slct_fr_fixG1->fetch_assoc())
											{
											$montant_fixeG1 = $rsult_exe_rqt_slct_fr_fixG1['montantFix'];
											$tot_montant_fixe_fr_G1 = $tot_montant_fixe_fr_G1 + $montant_fixeG1;
											
											?>
											<!--SI LE MONTANT ETE DEJA FIXE, ON AFFICHE LE MONTANT-->
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=G1&motant=<?php echo $montant_fixeG1; ?>"><?php echo $montant_fixeG1; ?></a>
											<?php
											}
										else
											{
											$montant_fixeG1 = 0;
											$tot_montant_fixe_fr_G1 = $tot_montant_fixe_fr_G1 + $montant_fixeG1;
											
											?>
											<!--SI LE MONTANT N'A PAS ETE FIXE, ON AFFICHE 0-->
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=G1&motant=<?php echo  $montant_fixeG1; ?>"><?php echo $montant_fixeG1; ?></a>
											<?php 
											}
										}
									else
										{
										echo "<samp class='echec'>Erreur<samp/>";
										}
								  ?>
							    </div>							  </th>
							  <th scope="col" style="border-bottom:solid 1px">
						  	  <div align="right">
								  <?php 
								  //POUR G2 
								  	$rqt_slct_fr_fixG2 = "select * from tb_fixation_prix where idFr = '".$result_rqt_list_fr_a_fix['idFr']."' and idPromo = 'G2' and idAca = '".$_SESSION['idAnAca']."'";
									if($exe_rqt_slct_fr_fixG2 = $conDb->query($rqt_slct_fr_fixG2))
										{
										if($rsult_exe_rqt_slct_fr_fixG2 = $exe_rqt_slct_fr_fixG2->fetch_assoc())
											{
											$montant_fixeG2 = $rsult_exe_rqt_slct_fr_fixG2['montantFix'];
											$tot_montant_fixe_fr_G2=$tot_montant_fixe_fr_G2+$montant_fixeG2;
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=G2&motant=<?php echo  $montant_fixeG2; ?>"><?php echo $montant_fixeG2;?></a>
											<?php 
											}
										else
											{
											$montant_fixeG2 = 0;
											$tot_montant_fixe_fr_G2=$tot_montant_fixe_fr_G2+$montant_fixeG2;
											
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=G2&motant=<?php echo  $montant_fixeG2; ?>"><?php echo $montant_fixeG2;?></a>
											
											<?php 
											}
										}
									else
										{
										echo "<samp class='echec'>Erreur<samp/>";
										}
								  ?>
							  </div></th>
							  <th scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								  <?php 
								  //POUR G3
								  	$rqt_slct_fr_fixG3 = "select * from tb_fixation_prix where idFr = '".$result_rqt_list_fr_a_fix['idFr']."' and idPromo = 'G3' and idAca = '".$_SESSION['idAnAca']."'";
									if($exe_rqt_slct_fr_fixG3 = $conDb->query($rqt_slct_fr_fixG3))
										{
										if($rsult_exe_rqt_slct_fr_fixG3 = $exe_rqt_slct_fr_fixG3->fetch_assoc())
											{
											$montant_fixeG3 = $rsult_exe_rqt_slct_fr_fixG3['montantFix'];
											$tot_montant_fixe_fr_G3=$tot_montant_fixe_fr_G3+$montant_fixeG3;
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=G3&motant=<?php echo  $montant_fixeG3; ?>"><?php echo $montant_fixeG3;?></a>
											<?php
											}
										else
											{
											$montant_fixeG3 = 0;
											$tot_montant_fixe_fr_G3=$tot_montant_fixe_fr_G3+$montant_fixeG3;
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=G3&motant=<?php echo  $montant_fixeG3; ?>"><?php echo $montant_fixeG3;?></a>
											<?php
											}
										}
									else
										{
										echo "<samp class='echec'>Erreur<samp/>";
										}
								  ?>
								  </div>							  </th>
							  <th scope="col" style="border-bottom:solid 1px">
						  	  <div align="right">
							  <?php 
							  //POUR L1
								  	$rqt_slct_fr_fixL1 = "select * from tb_fixation_prix where idFr = '".$result_rqt_list_fr_a_fix['idFr']."' and idPromo = 'L1' and idAca = '".$_SESSION['idAnAca']."'";
									if($exe_rqt_slct_fr_fixL1 = $conDb->query($rqt_slct_fr_fixL1))
										{
										if($rsult_exe_rqt_slct_fr_fixL1 = $exe_rqt_slct_fr_fixL1->fetch_assoc())
											{
											$montant_fixeL1 = $rsult_exe_rqt_slct_fr_fixL1['montantFix'];
											$tot_montant_fixe_fr_L1=$tot_montant_fixe_fr_L1+$montant_fixeL1;
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=L1&motant=<?php echo  $montant_fixeL1; ?>"><?php echo $montant_fixeL1;?></a>
											<?php
											}
										else
											{
											$montant_fixeL1 = 0;
											$tot_montant_fixe_fr_L1=$tot_montant_fixe_fr_L1+$montant_fixeL1;
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=L1&motant=<?php echo  $montant_fixeL1; ?>"><?php echo $montant_fixeL1;?></a>
											<?php
											}
										}
									else
										{
										echo "<samp class='echec'>Erreur<samp/>";
										}
								  ?>
							  </div></th>
							  <th scope="col" style="border-bottom:solid 1px">
						      	<div align="right">
									<?php 
									//POUR L2
								  	$rqt_slct_fr_fixL2 = "select * from tb_fixation_prix where idFr = '".$result_rqt_list_fr_a_fix['idFr']."' and idPromo = 'L2' and idAca = '".$_SESSION['idAnAca']."'";
									if($exe_rqt_slct_fr_fixL2 = $conDb->query($rqt_slct_fr_fixL2))
										{
										if($rsult_exe_rqt_slct_fr_fixL2 = $exe_rqt_slct_fr_fixL2->fetch_assoc())
											{
											$montant_fixeL2 = $rsult_exe_rqt_slct_fr_fixL2['montantFix'];
											$tot_montant_fixe_fr_L2=$tot_montant_fixe_fr_L2+$montant_fixeL2;
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=L2&motant=<?php echo  $montant_fixeL2; ?>"><?php echo $montant_fixeL2;?></a>
											<?php
											}
										else
											{
											$montant_fixeL2 = 0;
											$tot_montant_fixe_fr_L2=$tot_montant_fixe_fr_L2+$montant_fixeL2;
											?>
											<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&fix_pr&modifier=<?php echo $result_rqt_list_fr_a_fix['idFr']; ?>&designation=<?php echo $result_rqt_list_fr_a_fix['designFr']; ?>&promotion=L2&motant=<?php echo  $montant_fixeL2; ?>"><?php echo $montant_fixeL2;?></a>
											<?php
											}
										}
									else
										{
										echo "<samp class='echec'>Erreur<samp/>";
										}
								  	?>							  
								  </div>
								</th>
		 					</tr>
							 <?php }?>
						    <tr align="left" style="">
							  <th colspan="2" bgcolor="#DEDEDE" style="border-bottom:solid 1px" scope="col"><div align="right"><em>TOTAL  &nbsp;</em></div></th>
							  <th scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php 
									echo $tot_montant_fixe_fr_G1; 
									$tot_gene_montant_fixe_fr_G1=$tot_gene_montant_fixe_fr_G1+$tot_montant_fixe_fr_G1; 
									?>
								  </div>							  </th>
							  <th scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php  
									echo $tot_montant_fixe_fr_G2; 
									$tot_gene_montant_fixe_fr_G2=$tot_gene_montant_fixe_fr_G2+$tot_montant_fixe_fr_G2;
									?>
								  </div>							  </th>
							  <th scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php  
									echo $tot_montant_fixe_fr_G3; 
									$tot_gene_montant_fixe_fr_G3=$tot_gene_montant_fixe_fr_G3+$tot_montant_fixe_fr_G3;
									?>
								  </div>							  </th>
							  <th scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php  
									echo $tot_montant_fixe_fr_L1; 
									$tot_gene_montant_fixe_fr_L1=$tot_gene_montant_fixe_fr_L1+$tot_montant_fixe_fr_L1;
									?>
								  </div>							  </th>
							  <th scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php  
									echo $tot_montant_fixe_fr_L2; 
									$tot_gene_montant_fixe_fr_L2=$tot_gene_montant_fixe_fr_L2+$tot_montant_fixe_fr_L2;
									?>
								  </div>							  </th>
		  </tr>
							<?php 
							
						}
					}
			 ?>
							 <tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
							   <th colspan="2" style="border-bottom:solid 1px" scope="col"><div align="right"><em>TOTAL GENERAL &nbsp; </em></div></th>
							   <th scope="col" style="border-bottom:solid 1px">
								  <div align="right">
								 	<?php echo $tot_gene_montant_fixe_fr_G1; ?>
								  </div>							  
							   </th>
							   <th scope="col" style="border-bottom:solid 1px">
							      <div align="right">
								 	<?php echo $tot_gene_montant_fixe_fr_G2; ?>
								  </div>
							   </th>
							   <th scope="col" style="border-bottom:solid 1px">
							     <div align="right">
								 	<?php echo $tot_gene_montant_fixe_fr_G3; ?>
							     </div>
							   </th>
							   <th scope="col" style="border-bottom:solid 1px">
							     <div align="right">
								 	<?php echo $tot_gene_montant_fixe_fr_L1; ?>
							     </div>
							   </th>
							   <th scope="col" style="border-bottom:solid 1px">
							     <div align="right">
								 	<?php echo $tot_gene_montant_fixe_fr_L2; ?>
							     </div>
							   </th>
	      </tr>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}


?>