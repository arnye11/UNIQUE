<?php 
if (isset($_GET['profil']) and isset($_GET['Historiquevers']))
	{ 
	echo "<div class='"; if($_SESSION['idAnAca'] != $an_aca){echo "aca_pas";} echo "'>";
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Historique de versment des frais, ann&eacute;e acad&eacute;mique ".$an_aca."</h3>";
	if(isset($_GET['sms_gerer'])){
		$sms_gerer = $_GET['sms_gerer']; 
		echo "<div style='color:#009900'>".$sms_gerer."</div>";
	}
	else{ 
		echo $sms_gerer;
	}
	echo "</div>";
	echo "<div align='left'><a href='?profil&id=".$_SESSION['matricEtud']."&frais'> &nbsp;&nbsp; &lArr; Retour</a></div>";
	$rqt_slct_fr_vers = "select * from tb_versement where matEtud = '".$_SESSION['matricEtud']."' and idAca = '".$an_aca."' ORDER BY dateVers  DESC";
	if($exe_rqt_slct_fr_vers =$conDb->query($rqt_slct_fr_vers))
		{
		?>
			<table border="0" bgcolor="#FFFFFF" style="width: 100%;">
			  <tr style="background:#5B5B5B; color:#FFFFFF;">
				<th scope="col" width="30%">Date de versement </th>
				<th scope="col">Montant (FC)</th>
				<th scope="col">Frais</th>
				<th scope="col">Action</th>
				<th scope="col">Imprimer</th>
			  </tr>
			  <?php
			  while($rsult_exe_rqt_slct_fr_vers = $exe_rqt_slct_fr_vers->fetch_assoc())
				{?>
				  <tr>
					<td scope="col" style="border-bottom:solid 1px">
						<div align="left">
							<?php echo $rsult_exe_rqt_slct_fr_vers['dateVers'] ;?>
				    	</div>
					</td>
					<td scope="col" style="border-bottom:solid 1px; ">
						<div align="right">
				   			<?php echo $rsult_exe_rqt_slct_fr_vers['montantVers'] ;?>&emsp;
				   		</div>
				   	</td>
					<td scope="col" style="border-bottom:solid 1px">
						<div align="left">
						  <?php 
						$rqt_slct_fr = "select * from tb_frais where idFr = '".$rsult_exe_rqt_slct_fr_vers['idFr']."'";
						if($exe_rqt_slct_fr = $conDb->query($rqt_slct_fr))
							{
							if($exe_rqt_slct_fr = $exe_rqt_slct_fr->fetch_assoc())
								{
								echo $exe_rqt_slct_fr['designFr'] ;
								}
							}
						?>
				        </div>
				    </td>
					<th scope="col" style="border-bottom:solid 1px">
						<div align="justify">
							Modifier
						</div>
					</th>
					<th scope="col" style="border-bottom:solid 1px">
						<div align="justify">
							<a href="<?php echo "?fAculTe&iDfaC=".$iDfaC."&pRomotIon=".$idPromo."&oPtiOn=".$idOp."&rAppoRtfrais&jr&imPRessIoN&recude=".$rsult_exe_rqt_slct_fr_vers['matEtud']."&num=". $rsult_exe_rqt_slct_fr_vers['idVers']?>">Re&ccedil;u</a>	
						</div>
					</th>
				  </tr>
				 <?php 
				 }
				 ?>
			</table>

			
			<?php 
			
		}
		?>
	<br />
	<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&Historiquevers&aca=<?php echo $an_aca;?>">Historique de versement</a>
<?php 
echo "</div>";
	}
												
?>
		