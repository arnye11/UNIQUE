<?php 
include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/makuta/etudiant_en_ordre_pour_la_mi_session.php");
?>