<?php 
if (isset($_POST['BtFixerFr'])){
	$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
	$idFac = filter_input(INPUT_POST,'idFac', FILTER_SANITIZE_SPECIAL_CHARS);
	$idAca = filter_input(INPUT_POST,'idAca', FILTER_SANITIZE_SPECIAL_CHARS);
	$idFr = filter_input(INPUT_POST,'idFr', FILTER_SANITIZE_SPECIAL_CHARS);
	$montantFr = filter_input(INPUT_POST,'montantFr', FILTER_SANITIZE_SPECIAL_CHARS);
	$rqt_insrt_pri_fix_fr = "";
	
	if(($montantFr != "") and($montantFr >= 0)  and $idPromo != "" and $idFac !="" and $idAca !="" and $idFr !="" )
		{
		$rqt_slct_si_fr_fix_pri = "SELECT * FROM tb_fixation_prix WHERE  idPromo = '".$idPromo."' AND idFac = '".$idFac."' AND idAca = '".$_SESSION['idAnAca']."' AND idFr = '".$idFr."'";
		if($exe_rqt_slct_si_fr_fix_pri = $conDb->query($rqt_slct_si_fr_fix_pri))
			{
			if($rsult_exe_rqt_slct_si_fr_fix_pri = $exe_rqt_slct_si_fr_fix_pri->fetch_assoc())
				{
				$rqt_insrt_pri_fix_fr = "UPDATE  tb_fixation_prix SET  idFr = '".$idFr."', idPromo = '".$idPromo."', idFac = '".$idFac."', idAca = '".$idAca."', montantFix = '".$montantFr."' where idFixPrix = '".$rsult_exe_rqt_slct_si_fr_fix_pri['idFixPrix']."'";
				if($exe_rqt_insrt_pri_fix_fr = $conDb->query($rqt_insrt_pri_fix_fr))
					{
					$sms_gerer = "<div style='color:#009900'>".$montantFr." FC&nbsp; sont refix&eacute;s</div>";
					}
				else
					{
					$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration (Refixation). veuillez reaisseyer.</div>";
					}
				}
			else
				{				
				$rqt_insrt_pri_fix_fr = "insert into tb_fixation_prix values (NULL, '".$idPromo."','".$idFac."', '".$idAca."', '".$idFr."', '".$montantFr."')";
				if($exe_rqt_insrt_pri_fix_fr = $conDb->query($rqt_insrt_pri_fix_fr))
					{
					$sms_gerer = "<div style='color:#009900'>".$montantFr." FC&nbsp; sont fix&eacute;s </div>";
					}
				else
					{
					$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration (Fixation). veuillez reaisseyer.</div>";
					}
				}
			}
		else
			{
			$sms_gerer = "<div style='color:#FF0000'>Impossible de v&eacute;rifier si le frais est fix&eacute;.</div>";
			}
			
		}
	else
		{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}
	
	}

//---------------------------------------------------------------------------------------------------------------

?>