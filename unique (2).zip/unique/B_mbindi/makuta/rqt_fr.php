<?php 
//----------------------MDL makuta-----------------------
//----------------------dans rqt-----------------------
//-----------------------------------------------------

include("B_mbindi/makuta/rqt_fixe_fr_slct.php");
include("B_mbindi/makuta/rqt_save_fr.php");
include("B_mbindi/makuta/rqt_updt_fr_slct.php");
include("B_mbindi/makuta/rqt_sup_fr_slct.php");
include("B_mbindi/makuta/rqt_versermrnt_fr.php");


?>