<?php 
if(isset($_GET['ctrl']))
	{
	echo "Frais exig�s pour : ";
	if(isset($_GET['ctrl']) and isset($_GET['misession']))
		{
		$idExam = $_GET['misession'];
		$nbrfr_exige = 0;
		$rqt_nbr_fr_exige = "select count(*) as nbrFrExige from frais_fixe_pour_exam where idExam = '".$idExam."' and idAca = '".$an_aca."'";
			if($exe_rqt_nbr_fr_exige = mysql_query($rqt_nbr_fr_exige))
				{
				if($result_rqt_nbr_fr_exige = mysql_fetch_assoc($exe_rqt_nbr_fr_exige))
					{
					$nbrfr_exige = $result_rqt_nbr_fr_exige['nbrFrExige'];
					}
				else
					{
					$nbrfr_exige = 0;
					}
				}
			else
				{
				$nbrfr_exige = "x";
				}
		
		echo "Mi-Session (".$nbrfr_exige.")";
		echo "<br/>";
		
		$slct_fr_exige_exam = "select * from  frais_fixe_pour_exam where idExam = '".$idExam."' and idAca = '".$an_aca."'";
		if($exe_slct_fr_exige_exam = mysql_query($slct_fr_exige_exam))
			{
			while($result_exe_slct_fr_exige_exam = mysql_fetch_assoc($exe_slct_fr_exige_exam)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{
				
				$slct_fr_exige = "select * from  frais where idFr = '".$result_exe_slct_fr_exige_exam['idFr']."'";
				if($exe_slct_fr_exige = mysql_query($slct_fr_exige))
					{
					while($result_exe_slct_fr_exige = mysql_fetch_assoc($exe_slct_fr_exige)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
						{
						echo $result_exe_slct_fr_exige['designFr'];
						echo "<br/>";
						}
					}
				else
					{
					echo "erreur execution";
					}

				}
			}
		else
			{
			echo "erreur execution";
			}
		}
	}
?>