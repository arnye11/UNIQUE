<?php 
if (isset($_GET['gerer_frais']) and isset($_GET['modifier_fr']) and !isset($_GET['fr']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Modifier un frais </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
	$rqt_list_type_fr_a_modif = "select * from  tb_type_frais";
	if($exe_rqt_list_type_fr_a_modif = $conDb->query($rqt_list_type_fr_a_modif))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Code</th>
			<th scope="col" style="font-size:15px;">D&easignation</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		  <?php 
				while($result_rqt_list_type_fr_a_modif = $exe_rqt_list_type_fr_a_modif->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{ ?>
					<tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
						<th scope="col" style="border-bottom:solid 1px">
						  <?php echo $result_rqt_list_type_fr_a_modif['idTypFr']; ?>
						</th>
						<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_type_fr_a_modif['designTypFr']; ?></th>
						<th scope="col" style="border-bottom:solid 1px"></th>
					</tr>
					<?php 
					$rqt_list_fr_a_modif = "select * from  tb_frais where idTypFr ='".$result_rqt_list_type_fr_a_modif['idTypFr']."'";
					if($exe_rqt_list_fr_a_modif = $conDb->query($rqt_list_fr_a_modif))
						{
						while($result_rqt_list_fr_a_modif = $exe_rqt_list_fr_a_modif->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
							{ ?>
							<tr align="left" style="">
								<th scope="col" style="border-bottom:solid 1px">
								  <?php echo $result_rqt_list_fr_a_modif['idFr']; ?>
								</th>
								<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_fr_a_modif['designFr']; ?></th>
								<th scope="col" style="border-bottom:solid 1px"><a href="?gerer_frais&modifier_fr&fr=<?php echo $result_rqt_list_fr_a_modif['idFr']; ?>">Modifier</a></th>
							</tr>
							<?php 
							}
						}
					}
			 ?>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les types des frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}


?>