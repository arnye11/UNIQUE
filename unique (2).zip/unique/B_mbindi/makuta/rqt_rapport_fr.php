<?php 
if (isset($_GET['rapport']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Situation des frais pour l'ann�e acad�mique ".$_SESSION['idAnAca']."</h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
	
	//echo "1er Cas : versement = motant fix� 			2�me Cas :  versement != motant fix�";
	if (isset($_GET['fr_annuel']))
		{
		include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/Biamunda/rqt/rapport_annuel_fr_cas1.php");
		//include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/Biamunda/rqt/rapport_annuel_fr_cas2.php");
		}
		
	if (isset($_GET['fr_journalier']))
		{
		include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/Biamunda/rqt/rapport_journalier_fr.php");
		}

	}
?>