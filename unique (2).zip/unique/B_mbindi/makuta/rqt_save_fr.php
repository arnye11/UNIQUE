<?php 
if(isset($_POST['BtsaveFr']))
	{
	$codFr = filter_input(INPUT_POST,'codFr', FILTER_SANITIZE_SPECIAL_CHARS);
	$designFr = filter_input(INPUT_POST,'designFr', FILTER_SANITIZE_SPECIAL_CHARS);
	$idTypFr = filter_input(INPUT_POST,'idTypFr', FILTER_SANITIZE_SPECIAL_CHARS);

	if($codFr!="" and $designFr!="" and $idTypFr!="")
		{
		$rqt_insrt_fr = "insert into tb_frais values ('".$codFr."','".$designFr."','".$idTypFr."')";
		if($exe_rqt_insrt_fr = $conDb->query($rqt_insrt_fr))
			{
			$sms_gerer = "<div style='color:#009900'> Frais ajout&eacute; avec succ&egrave;s.</div>";
			}
		else
			{
			$sms_gerer = "<div style='color:#FF0000'>Impossible d'effecuter cette op&eacute;ration. veuillez reaisseyer.</div>";
			}
		}
	else
		{
		$sms_gerer = "<div style='color:#FF0000'>Veuillez remplire tous les champs.</div>";
		}

}
?>