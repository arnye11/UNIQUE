<?php 
if (isset($_GET['gerer_frais']) and isset($_GET['sup_fr']))
	{ 
	echo "<div style='border-bottom:groove; padding: 5px'><h3>Supprimer un frais </h3>";
	if(isset($_GET['sms_gerer'])){$sms_gerer = $_GET['sms_gerer']; echo "<div style='color:#009900'>".$sms_gerer."</div>";}else{ echo $sms_gerer;}
	echo "</div>";
	$rqt_list_type_fr_a_sup = "select * from  tb_type_frais";
	if($exe_rqt_list_type_fr_a_sup = $conDb->query($rqt_list_type_fr_a_sup))
		{
		?>
		<table border="0" style="font-family:Bookman Old Style; font-size:13px;">
		  <tr align="left">
		    <th scope="col" style="font-size:15px;">Code</th>
			<th scope="col" style="font-size:15px;">D�signation</th>
			<th scope="col" style="font-size:15px;">Action</th>
		  </tr>
		  <?php 
				while($result_rqt_list_type_fr_a_sup = $exe_rqt_list_type_fr_a_sup->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
					{ ?>
					<tr align="left" style="background:#5B5B5B; color:#FFFFFF;">
						<th scope="col" style="border-bottom:solid 1px">
						  <?php echo $result_rqt_list_type_fr_a_sup['idTypFr']; ?>
						</th>
						<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_type_fr_a_sup['designTypFr']; ?></th>
						<th scope="col" style="border-bottom:solid 1px"></th>
					</tr>
					<?php 
					$rqt_list_fr_a_sup = "select * from  tb_frais where idTypFr ='".$result_rqt_list_type_fr_a_sup['idTypFr']."'";
					if($exe_rqt_list_fr_a_sup = $conDb->query($rqt_list_fr_a_sup))
						{
						while($result_rqt_list_fr_a_sup = $exe_rqt_list_fr_a_sup->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
							{ 
							//verification de l'id aca dans versement
							$rqt_slct_fr_modif_verse = "select * from  tb_versement where idFr = '".$result_rqt_list_fr_a_sup['idFr']."'";
							if($exe_rqt_slct_fr_modif_verse = $conDb->query($rqt_slct_fr_modif_verse))
								{
								 if($result_rqt_slct_fr_modif_verse = $exe_rqt_slct_fr_modif_verse->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
									{
									$idFr_a_sup = true;
									}
								else
									{
									$idFr_a_sup = false;
									}
								}
							//verification de l'id aca dans inscription
							$rqt_slct_fr_modif_fixe = "select * from tb_fixation_prix where idFr = '".$result_rqt_list_fr_a_sup['idFr']."'";
							if($exe_rqt_slct_fr_modif_fixe = $conDb->query($rqt_slct_fr_modif_fixe))
								{
								 if($result_rqt_slct_fr_modif_fixe = $exe_rqt_slct_fr_modif_fixe->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
									{
									$idFr_a_sup = true;
									}
								else
									{
									$idFr_a_sup = false;
									}
								}
							?>
							
							<tr align="left" style="">
								<th scope="col" style="border-bottom:solid 1px">
								  <?php echo $result_rqt_list_fr_a_sup['idFr']; ?>
								</th>
								<th scope="col" style="border-bottom:solid 1px"><?php echo $result_rqt_list_fr_a_sup['designFr']; ?></th>
								<th scope="col" style="border-bottom:solid 1px">
								  <?php  if($idFr_a_sup == false){ ?><a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?gerer_frais&sup_fr&supprimer=<?php echo $result_rqt_list_fr_a_sup['idFr']; ?>">Supprimer</a> <?php }?>
								</th>
							</tr>
							<?php 
							}
						}
					}
			 ?>
		</table>
		<?php 
		}
	else
		{
		echo  "Impossible d'atteindre les frais. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
		}
			

	}


?>