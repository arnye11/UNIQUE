<?php 
if (isset($_POST['BtSupCeFrFix']))
	{ 
	$idFixPrix = filter_input(INPUT_POST,'idFixPrix', FILTER_SANITIZE_SPECIAL_CHARS);
	if ($idFixPrix != "")
		{
		$rqt_sup_fr_fix = "DELETE FROM tb_fixation_prix WHERE idFixPrix = '".$idFixPrix."'";
		if($exe_rqt_sup_fr_slct = $conDb->query($rqt_sup_fr_fix))
			{
			$sms_gerer = "<div style='color:#009900'><img src='B_mbidndi/Biamunda/icon/info.ico' class='icon' />&nbsp;&nbsp;Le frais est supprim&eacute; avec succ&egrave;s.</div>";
			}
		else
			{
			$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/info.ico' class='icon'/> Impossible de supprimer ce frais. Si le probl&egrave;me persiste, contacter d'urigence l'Administrateur. </div>";
			}
		}
	else
		{
		$sms_gerer = "<div style='color:#ff0000'><img src='B_mbidndi/Biamunda/icon/info.ico' class='icon' />Vous n'avez pas indiqu&eacute; le frais &agrave; Supprimer</div>. &nbsp;<a href='?gerer_frais&sup_fr'>Reaisseyez</a> ";
		}
				

	}

?>