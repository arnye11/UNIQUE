<?php 
if (isset($_GET['gerer_frais']) and isset($_GET['modifier_fr']) and isset($_GET['fr']) and !isset($_POST['BtsUpdtFr']))
	{ 
	$idFr_a_modif = $_GET['fr'];
	if ($idFr_a_modif != "")
		{
		$rqt_slct_fr_a_modif = "select * from  tb_frais where idFr = '".$idFr_a_modif."'";
		if($exe_rqt_slct_fr_a_modif = $conDb->query($rqt_slct_fr_a_modif))
			{
			if($result_exe_rqt_slct_fr_a_modif = $exe_rqt_slct_fr_a_modif->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
				{
				$idFr_a_modif = $result_exe_rqt_slct_fr_a_modif['idFr'];
				$designFr_a_modif = $result_exe_rqt_slct_fr_a_modif['designFr'];
				$idTypFr_a_modif = $result_exe_rqt_slct_fr_a_modif['idTypFr'];
				
				$rqt_slct_typ_fr_a_modif = "select * from  tb_type_frais where idTypFr = '".$idTypFr_a_modif."'";
				if($exe_rqt_slct_typ_fr_a_modif = $conDb->query($rqt_slct_typ_fr_a_modif))
					{
					if($result_exe_rqt_slct_typ_fr_a_modif = $exe_rqt_slct_typ_fr_a_modif->fetch_assoc()) //SI EXECUTION, ON RECUPERE SES INFORMATION 
						{
						$design_TypFr_a_modif = $result_exe_rqt_slct_typ_fr_a_modif['designTypFr'];
						}
					else
						{
						$design_TypFr_a_modif = $idTypFr_a_modif;
						}
					}
				else
					{
					$design_TypFr_a_modif = $idTypFr_a_modif;
					}
	
				//verification de l'id aca dans versement
				$rqt_slct_fr_modif_vers = "select * from  tb_versement where idFr = '".$idFr_a_modif."'";
				if($exe_rqt_slct_fr_modif_vers = $conDb->query($rqt_slct_fr_modif_vers))
					{
					 if($result_rqt_slct_fr_modif_vers = $exe_rqt_slct_fr_modif_vers->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idFr_modif = true;
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad�mique indiqu�e. ";
					}
				//verification de l'id aca dans inscription
				$rqt_slct_fr_modif_fix = "select * from tb_fixation_prix where idFr = '".$idFr_a_modif."'";
				if($exe_rqt_slct_fr_modif_fix = $conDb->query($rqt_slct_fr_modif_fix))
					{
					 if($result_rqt_slct_fr_modif_fix = $exe_rqt_slct_fr_modif_fix->fetch_assoc()) //SI EXECUTION, ON RECUPERE LES INFORMATION 
						{
						$idFr_modif = true;
						}
					}
				else
					{
					$sms_gerer = "Impossible de trouver l'ann�e acad�mique indiqu�e. ";
					}
					
				}
			else
				{
				$sms_gerer = "Nous n'avons pas retrouver le frais indiqu�. &nbsp;<a href='?gerer_frais&modifier_fr'>Reaisseyez</a> ";
				}	
			}
		else
			{
			$sms_gerer =  "Impossible d'atteindre le frais indiqu�. <br/>SVP, contacter urigement l'Administrateur pour l'assistance.";
			}
	
		}
	else
		{
		$sms_gerer = "Vous n'avez pas indiqu� le frais � modifier. &nbsp;<a href='?gerer_frais&modifier_fr'>Reaisseyez</a> ";
		}
				

	}
///____________________________________________________________________________________________________________________________________________
if (isset($_GET['gerer_frais']) and isset($_GET['modifier_fr']) and isset($_GET['fr']) and isset($_POST['BtsUpdtFr']))
	{ 
	$idFr_a_modif = $_GET['fr'];
	$codFr = filter_input(INPUT_POST,'codFr', FILTER_SANITIZE_SPECIAL_CHARS);
	$designFr = filter_input(INPUT_POST,'designFr', FILTER_SANITIZE_SPECIAL_CHARS);
	$idTypFr = filter_input(INPUT_POST,'idTypFr', FILTER_SANITIZE_SPECIAL_CHARS);
	
	$designFr_a_modif = $designFr ;
	$idTypFr_a_modif = $idTypFr ;

	if($idFr_a_modif !="" and $designFr_a_modif!="" and $idTypFr_a_modif!="")
		{
		$rqt_updt_fr_modif = "UPDATE tb_frais  SET idFr = '".$codFr."', designFr = '".$designFr_a_modif."', idTypFr = '".$idTypFr_a_modif."' where idFr = '".$idFr_a_modif."'";
		if($exe_updt_slct_fr_modif = $conDb->query($rqt_updt_fr_modif))
			{
			$sms_gerer = "Les informations du frais (".$designFr.") sont mis � jous.";
			header ('location:?gerer_frais&modifier_fr&sms_gerer='.$sms_gerer.'');
			}
		else
			{
			$sms_gerer = "Impossible de mettre � jour le frais (".$designFr."). Contacter d'urigence l'Administrateur.";	
			}
		}
	else
		{
		$sms_gerer = "Veuillez remplir tous les champs. ";
		

		}
	}				



?>