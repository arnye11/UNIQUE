<?php
$montantvers = "";
if (isset($_GET['ajouter']) and isset($_GET['frais']) and (isset($_POST['BtVerser']))){ 
	 if(($_POST['montVerser'] != "") and ($_POST['montVerser'] !=0))
		 {
		 $montantvers = $_POST['montVerser'];
		 if((($_POST['montVerser'] + $_POST['montV']) <= $_POST['montFx']) )
			 {
				$rqt_insrt_fr_inscription_vers="INSERT INTO tb_versement VALUES(NULL, '".$_GET['id']."','".$_POST['idPromo']."','".$_POST['idOp']."','".$an_aca."','".$_GET['frais']."','".$montantvers."', NOW(), '".$_SESSION['idAutoDec']."')";
				if($exe_rqt_insrt_fr_inscription_vers =$conDb->query($rqt_insrt_fr_inscription_vers))
					{
					$sms = "<div style='color:#009900'>Versement effectu&eacute;.</div>";
					header ("location:?profil&id=".$_SESSION['matricEtud']."&frais");
					}
				else
					{
					$sms = "<div style='color:#FF0000'>Impossible d'enregistrer ce versement.</div>";
					}
			}
		else
			{ 
			$sms = "<div style='color:#FF0000'>Vous avez d&eacute;pass&eacute; le montant qu'il faut.</div>";
			}
		}
	else
		{
		$sms = "<div style='color:#FF0000'>Le champ est vide</div>";
		}
	}
?>