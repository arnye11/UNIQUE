<?php
	if(isset($_GET['profil']) and isset($_GET['apropos'])){
		?>
		<style>	
		<!--
			.profil_modification_photo1, .profil_modification_photo2{
				display:inline; 
				float:left; 
				height:182px; 
				margin:2px; 
				border:solid 1px #9900CC; 
			}

			.profil_modification_photo{
				border:solid 1px #00FF33;
				width:98.5%; height:190px;
				margin:2px; background:#EEEEEE;
			}
			.profil_modification_photo1{ 
				width:180px;
				background:#FFFFFF;
			}
			.zone_titre_photo_profil{
				border:solid 1px #FFCC00; 
				width:96%; 
				height:18px;
				margin:2px; 
				background:#BBBBBB;
			}
			.zone_photo_profil_mod{
				border:solid 1px #FFCC00; 
				width:96%; 
				height:125px; 
				margin:2px;
			}
			.zone_lien_modifier_photo_profil{
				border:solid 1px #FFFFFF; 
				width:96%; 
				height:19px; 
				margin:2px; 
				background:#005500; 
				color:#EEEEEE; 
				box-shadow:0px 5px 5px 0px #003300;
			}
			.profil_modification_photo2{ 
				width:59%; 
			}
			.lien_modifier_photo_profil{
				color:#EEEEEE;
			}
			.ClassBtTelecharger{
				color:#EEEEEE; 
				background:#6666FF; 
				font-family:"Times New Roman", Times, serif; 
				border-radius:12px;
			}
			.ClassAvatarEtud{
				border:solid 1px #BBBBBB; 
				border-radius:12px; 
				background:#FFFFFF;
			}
		-->
		</style>
		<div align="left" style="background:#DDDDDD; padding:2px;">
			<div align="left">
				<h3>IDENTITES</h3>
			</div>
			<div>
				<table border="0">
					<tr>
						<td>Nom  </td>
						<td>: <?php echo $result_slct_etud['nomEtud'];?></td>
					</tr>
						<tr>
						<td>Postnom </td>
						<td>: <?php echo $result_slct_etud['postnomEtud'];?> </td>
					</tr>
					<tr>
						<td>Pr&eacute;nom  </td>
						<td>: <?php echo $result_slct_etud['prenomEtud'];?> </td>
					</tr>
					<tr>
						<td>Sexe  </td>
						<td>: 
							<?php 
								if ($result_slct_etud['sexeEtud']=="M"){ echo "Homme";}else { echo "Femme";}
							?> 
						</td>
					</tr>
					<tr>
						<td>Date de naissance  </td>
						<td>:
							<?php if ($result_slct_etud['jrNais']<10){ echo "0".$result_slct_etud['jrNais'];}else{echo $result_slct_etud['jrNais'];} echo "/" ; if ($result_slct_etud['mmNais']<10){ echo "0".$result_slct_etud['mmNais'];}else{echo $result_slct_etud['mmNais'];} echo "/ ".$result_slct_etud['aaaaNais'];
							?>
						</td>
					</tr>
					<tr>
						<td>Lieu de naissance  </td>
						<td>: <?php echo $result_slct_etud['lieunaisEtud'];?> </td>
					</tr>
					<tr>
						<td>Adresse d'habutation  </td>
						<td>: <?php echo $result_slct_etud['adresseEtud'];?>  </td>
					</tr>
					<tr>
						<td><div align="left">Numéro de téléphone  </div></td>
						<td>
							<div align="left">: <?php echo $result_slct_etud['telEtud'];?></div>
						</td>
					</tr>
					<tr>
						<td><div align="left">E-mail  </div></td>
						<td>
							<div align="left">: <?php echo $result_slct_etud['emailEtud'];?></div>
						</td>
					</tr>
				</table>
			</div>

			<div align="left" style="background:#DDDDDD; padding:2px;">
				<div align="left"><h3>INSCRIPTION </h3></div>
				<table>
					<tr>
						<td><div align="left">Promotion </div></td>
						<td><div align="left">: <?php echo $idPromo; ?></div></td>
					</tr>
					<tr>
						<td><div align="left">Option </div></td>
						<td><div align="left">: <?php echo $designOp; ?></div></td>
					</tr>
				</table>
			</div>
		</div>
		<?php
	}
?>