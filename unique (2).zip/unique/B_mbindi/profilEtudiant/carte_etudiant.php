<?php
	if((isset($_GET["doc"]) or isset($_GET["imPRessIoN"])) and isset($_GET["ce"])){ 
		if ($_SESSION['NivAc'] >= 0 and $_SESSION['NivAc'] <= 5){
			if ($reinscription != false || isset($_GET["aca"]) ){ 
				?>

				<style type="text/css">
					<!--
					.pgrecu{
						width:700px; height:auto; margin:0px; padding:0px;  
					}
					.recu{
						width:99%; height:243px; border:solid 1px #CCCCCC; padding:2px; 
					}
					.soucherecu1, .soucherecu2{
						height:239px; 
						border:solid 1px #CCCCCC; 
						padding:1px; display:inline; 
						width:49%;font-size:12px; 
						background:#FFFFFF;
					}
					.soucherecu1{
						 float:left;  
						 font-size:9px; 
					}
					.soucherecu2{
						 float:right; 
					}
					.rdcc{
						display: inline-block;
						width: 33.3%;
						height: 5px;
						float: left;
					}
					.btPrinter{
						 position:fixed; top:3%; bottom:auto; 
						 left:auto; right:12%; box-shadow:5px #999999; 
					}
					-->
				</style>

				<?php 

				//include("barcode.php")
				//include("barcodeimage.php")

				if(isset($_GET["imPRessIoN"]) || isset($_GET["profil"])){
					if(isset($_GET["imPRessIoN"])){
						$idFc=$_GET['iDfaC'];
						$idOp=$_GET['oPtiOn'];
						$idPromo=$_GET['pRomotIon'];
						$matEtud = $_GET['ce'];
					}
					
					$rqt_fac = "select * from  tb_faculte WHERE idFac = '".$idFc."'";
					if($exe_rqt_fac = $conDb->query($rqt_fac))
						{
						if($result_rqt_fac = $exe_rqt_fac->fetch_assoc()) {
							$designFac = $result_rqt_fac['designFac'] ;
						}
						else{
							$designFac ="INTROUVABLE";
						}
					}
					else{
						$designFac="ERREUR";
					}
					
					$rqt_op = "select * from  tb_option WHERE idOp = '".$idOp."'";
					if($exe_rqt_op = $conDb->query($rqt_op))
						{
						if($result_rqt_op = $exe_rqt_op->fetch_assoc()) {
							$designOp = $result_rqt_op['designOp'] ;
						}
						else{
							$designOp ="INTROUVABLE";
						}
					}
					else{
						$designOp="ERREUR";
					}

					$rqt_list_etud_PromoOp = "SELECT tb_inscription.*, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE tb_etudiant.matricEtud='".$matEtud."'";
				}
				else{
	 
					//$rqt_slct_fr_vers = "SELECT tb_versement.*, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_versement ON tb_etudiant.matricEtud = tb_versement.matEtud WHERE (((tb_versement.idVers)='".$_GET['num']."'))";

					$rqt_list_etud_PromoOp = "SELECT tb_inscription.*, tb_etudiant.* FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$idPromo."') AND ((tb_inscription.idOp)='".$idOp."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";
				}

				//$rqt_slct_fr_vers = "select * from tb_versement where idVers = '".$_GET['num']."'";
				if($exe_rqt_slct_fr_vers =$conDb->query($rqt_list_etud_PromoOp)){
					if($exe_rqt_slct_fr_vers->num_rows>0){
						if($tb_Etud_vers = $exe_rqt_slct_fr_vers->fetch_assoc()){
							$matEtud = $tb_Etud_vers['matricEtud'];
							?>
							<div class="pgrecu">
								<div class="recu">
									<div class="soucherecu1">
										
										<div style="font-size:12px; background:#003758; color:#FFFFFF; padding: 5px;" align="center" >
											<strong>Facult&eacute : <?php echo $designFac; ?></strong>
										</div>
										<div style="width:98%; " align="center">
											<table style="width:100%;" border="0" align="center">
												<tr >
													<td style="width:83px; height:auto;" valign="top">
														<div style="width:99%; height:115px; border:solid 1px #cdcdcd; line-height: 115px; " align="center" >
															<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbindi/Biamunda/media/<?php echo $tb_Etud_vers['matricEtud']."/".$tb_Etud_vers['avantarEtud'];?>" alt="Photo" width="100%" height="98%" />
														</div>
														<div align="center" style="">
															<a href="<?php $_SERVER['DOCUMENT_ROOT'].$url_site;?>?profil&id=<?php echo $tb_Etud_vers['matricEtud'] ?>&doc&ce=<?php echo $matEtud  ?>">
																CID
																<?php echo $tb_Etud_vers["matricEtud"];?>
															</a>
														</div>
														<div align="center" style="margin-top: 19px; font-weight:bold; font-size:1em;">
															UNIQUE
														</div>
													</td>
													<td valign="top" >
														<div style="width:100%;height:115px;border-bottom:solid 1px #000000;font-size:4">
															<div style="width: 100%; height: 13px;">
																<div style="width: 75%; display: inline; float: left;">
																	Nom : 
																	<strong style="text-transform:uppercase;">
																		<?php echo $tb_Etud_vers["nomEtud"];?><br>
																	</strong>
																</div>
																<div style="width: 20%; display: inline; float: right;">
																	Sexe :
																	<strong style="text-transform:uppercase;">
																		<?php echo $tb_Etud_vers["sexeEtud"]; ?><br>
																	</strong>
																</div>
															</div>
															Postnom : 
															<strong style="text-transform:uppercase;">
																<?php echo $tb_Etud_vers["postnomEtud"];?><br>
															</strong>
															Pr&eacutenom : 
															<strong style="text-transform:capitalize;">
																<?php echo $tb_Etud_vers["prenomEtud"]; ?><br>
															</strong>
															 
															Lieu/Date naiss. :
															<strong style="text-transform:uppercase;">
																<?php echo $tb_Etud_vers["lieunaisEtud"]."/".$tb_Etud_vers["datenaissEtud"]; ?><br>
															</strong> 
															Adresse :
															<strong >
																<?php echo $tb_Etud_vers["adresseEtud"] ; ?><br>
															</strong>
															Promotion : 
															<strong >
																<?php echo $idPromo." ".$designOp; ?><br/>
															</strong>
														</div>
														<div style="width:96%; height: 25px; margin: 2px;">	
															Nom du Père :  
															<strong style="text-transform:uppercase;">
																<?php echo $tb_Etud_vers["nomPereEtud"] ; ?>
															</strong> <br> 
															Nom de la Mère :
															<strong style="text-transform:uppercase;">
																<?php echo $tb_Etud_vers["nomMereEtud"]; ?>
															</strong> 
														</div>
														<div align="right" style="margin:4px;" >
															Fait &agrave; <?php echo $_SESSION['villeEts']; ?>, le <?php echo $jour."/".$moi."/".$annee_encours; ?>
														</div>
														<div align="left" style="">
															Sceau et signature de l'autorit&eacute; <br><br>
														</div>
														<div style="font-size: 10px;">
															<?php
															$string = $_SESSION['sigle_tb_etablissement'].$tb_Etud_vers["idInscrit"] ; 
															echo "<img alt='testing' src='barcode.php?codetype=code39&size=18&text=".$string."&print=false'/>";
															?>
														</div> 
														
													</td>
												</tr>
											</table>
										</div>
									</div>
									<div class="soucherecu2">
										<div align="center" style="width:100%; text-transform:uppercase;">
											<table style="width:100%;">
												<tr>											
													<td >
														<div align="center" style="width:12%; display:inline; float: left; ">
															<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" width="90%" height="30"/>
														</div>
														<div align="center" style="width:74%; display:inline; float: left;">
															<?php echo $nom_etablissement ; ?><br />
															<strong style="text-transform:capitalize;">
																Secr&eacute;tariat G&eacute;n&eacute;ral Acad&eacute;mique<br />
															</strong>
															
														</div>
														<div align="center" style="width:13%; display:inline; float: left; ">
															<img src="B_mbindi/Biamunda/icon/rdc.png" alt="logo Ets" width="100%" height="30"/>

														</div>

													</td>
												</tr>
											</table>
										</div>
										<div style="font-size:14px; background:#003758; color:#FFFFFF; padding: 5px;" align="center" >
											<strong>CARTE D'ETUDIANT N° <?php echo $tb_Etud_vers["idInscrit"]."-".$tb_Etud_vers["idAca"] ;?> </strong>
										</div>
										<div style="height:5px;" align="center">
											<div class="rdcc" style="background: #376dfd;"></div>
											<div class="rdcc" style="background: #ffdd29;"></div>
											<div class="rdcc" style="background: #ff0000;"></div>
										</div>
										<div style="">
											<div style="" align="center">
												<img src="B_mbindi/Biamunda/icon/collation.png" alt="logo Ets" width="52%" height="130"/>
											</div>
										</div>
										<div align="center" style=" font-size: 11px;">
											<i>
												Les Autorités tant Civiles, Policières que Militaires sont priées de venir en aide au porteur de la présente en cas de nécessité.
											</i>
										</div>
									</div>
									
								</div>
							</div>

							<?php 
							if(!isset($_GET["imPRessIoN"])){ ?>
								<div align="left" style="width: 90%; margin:40px;">
									<p >
										<?php 	
											echo "<a href='?fAculTe&iDfaC=".$idFc."&pRomotIon=".$idPromo."&oPtiOn=".$idOp."&imPRessIoN&ce=".$matEtud."&aca=".$an_aca."'>";
												echo "<img src='B_mbindi/Biamunda/icon/print.ico' class='ico'>";
												echo "<br>Imprimer";
											echo "</a>";		
										?>
									</p>
								</div>
							
							<?php 
							}
							else{
								?>
								<script type="text/javascript">
								  window.print();
								</script>
								<?php 
							}
						}
					}
					else{
						echo "Pas d'Etudiants inscrits";
					}
				}
				else{
					echo "Erreur de la requete";
				}
			}
			else{
				echo "<h2 class='erreur'> Etudiant non inscrit cette ann&eacute;e et il n'a pas droit &agrave; la carte d'&eacute;tudiant.</h2> ";
			}
		}
		else{
			echo "Vous n'avez pas le droit d'acc&eacute;der &agrave; cette information";
		}
	} 
?>
