<?php 
	if (isset($_GET['doc']) and isset($_GET['Dos'])) {
		?>
		<div>
			<div>
				<div>
					<h1>Dossier d'&eacute;tudiant</h1>
				</div>
				<div style="background:#E9E9E9; padding:20px;">
					Ajouter un autre &eacute;l&eacute;ment du dossier <br><br>
					<?php if (isset($_POST["btAjoutElmDos"])) echo $sms_gerer; ?>
						
				    <form action="" method="post" enctype="multipart/form-data">
						<input type="hidden" name="MAX_FILE_SIZE" value="2000000">
						<input type="file" name="mon_fichier" multiple accept=".png, .jpg, .jpeg, .pdf" required>
						<select name="tyepElmDos" required>
							<?php 
								$rqt_typDos = "SELECT * FROM tb_type_dossier_etud order by designTypDosEtud asc";
								if ($exe_rqt_typDos = mysqli_query($con, $rqt_typDos)) {
									if(mysqli_num_rows($exe_rqt_typDos)>0){
										echo "<option value=''></option>";
										while($tb_typDos = mysqli_fetch_assoc($exe_rqt_typDos)){
											echo "<option value='".$tb_typDos["idTypDosEtud"]."'>";
											echo $tb_typDos["designTypDosEtud"];
											echo "</option>";	
										}
									}
									else{
										echo "<option value=''>Pas d'&eacute;léeacute;ment</option>";
									}
								}
								else{
									echo "<option value='' class='erreur'>Erreur</option>";
								}			
							?>
						</select>
						<input type="submit" name="btAjoutElmDos" value="Ajouter">
					</form>
				</div>
				
			</div>
			
			<?php 
			echo "";

			$rqt_type_dossier_etud = "SELECT * FROM tb_type_dossier_etud";
			if ($exe_rqt_type_dossier_etud = mysqli_query($con, $rqt_type_dossier_etud)) {
				if(mysqli_num_rows($exe_rqt_type_dossier_etud)>0){
					while($tb_type_dossier_etud = mysqli_fetch_assoc($exe_rqt_type_dossier_etud)){
						echo "<h2>".$tb_type_dossier_etud["designTypDosEtud"]."</h2>";
						$rqt_dossier_etud = "SELECT * FROM tb_dossier_etud WHERE idTypDosEtud = '".$tb_type_dossier_etud["idTypDosEtud"]."' AND matricEtud = '".$_SESSION['matricEtud']."' ORDER BY dateDos ASC";
						if($exe_rqt_dossier_etud = mysqli_query($con, $rqt_dossier_etud)){
							if(mysqli_num_rows($exe_rqt_dossier_etud)>0){
								while($tb_dossier_etud = mysqli_fetch_assoc($exe_rqt_dossier_etud)){
									echo $tb_dossier_etud["designDosEtud"]."<br>";
									$extension = substr($tb_dossier_etud["designDosEtud"], -3, 3);
									if ($extension=="pdf" || $extension == "PDF") {
										echo $extension;
										?>"/"
											<iframe src="<?php echo "B_mbindi/Biamunda/media/".$_SESSION['matricEtud']."/dossier/".$tb_dossier_etud["designDosEtud"]; ?> " width="100%" height="500px"> </iframe>
										<?php 
									}
									else{
										echo $extension;
										?>
										<div style="width:99%;" align="center">
											<img src="<?php echo "B_mbindi/Biamunda/media/".$_SESSION['matricEtud']."/dossier/".$tb_dossier_etud["designDosEtud"]; ?> " style="max-width: 90%; max-height:90%">
										</div>
										<?php
									}
									
								}
							}
							else{
								echo "Aucu élément trouvé.";
							}
						}
						else{
							echo "Erreur lors de seléction des élément du dosseir";
						}
					}
				}
				else{
					echo "Pas d'élément du dossier";
				}
			}
			else{
				echo "Erreur lors de seléction d'éléménts";
			}
			?>
		</div>
		<?php 
	}
 ?>