<div class="profil_33" >
					
	<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&cursus">Cursus</a> | 

	<?php if($reinscription == false){ ?>
		<a href="?profil&id=<?php echo $result_slct_etud['matricEtud']?>&reincription">R&eacute;inscription</a> |
	<?php } ?> 

	<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&frais#frais">Frais</a> | 
	<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&doc">Documents</a> | 
	<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&modification_profil">Modifier son profil</a> |

	<?php if($_SESSION['loginSession'] == "DG" || $_SESSION['loginSession'] == "admin"){?>
		<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&formation">Supprimer l'&eacute;tudiant</a> |
	<?php }?> 

	<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&apropos">A propos</a>  |  
					
</div>

<?php if(isset($_GET['profil']) and isset($_GET['doc'])){?>
	<div class="profil_33" >
		<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&doc&recu">Reçu</a> &nbsp;&nbsp; - &nbsp;&nbsp;
		<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&doc&ce=<?php echo $matEtud  ?>">Carte d'&eacute;tudiant</a> &nbsp;&nbsp; - &nbsp;&nbsp;
		<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&doc&rc">Releve de cote</a> &nbsp;&nbsp; - &nbsp;&nbsp;
		<a href="?profil&id=<?php echo $result_slct_etud['matricEtud'] ?>&doc&Dos">Dossier</a> &nbsp;&nbsp; - &nbsp;&nbsp;
	</div>
<?php }?> 