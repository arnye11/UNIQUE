<?php 
	if(isset($_GET['profil']) and isset($_GET['id'])){
		?>
		<style type="text/css">
			/*______PROFIL ETUDIANT_________________*/
			.profilEtudiant1D, .profilEtudiant2C{
				height: auto; 
				padding: 5px; 
				display: inline;
			}
			.profilEtudiant1D{
				width: 67%;
				float: left; 
			}
			.profilEtudiant2C{
				width: 30%;
				border-left: solid 1px #969696;
				float: right; 
			}

			/*MEDIA --------------------------*/
			@media (max-width : 60em){
				
				.profilEtudiant1D, .profilEtudiant2C {
					width: 98%;
				}
			}
		</style>

		<table style="width: 99%;">
			<tr>
				<td>
					<div class="profilEtudiant1D">
						<?php 
							include("B_mbindi/profilEtudiant/profil_etudiant.php");
							include("B_mbindi/Biamunda/list_aca.php");
							include("B_mbindi/Inscription/f_reinscription.php");
							include("B_mbindi/makuta/fr_paye_par_L_etudiant.php");
							include("B_mbindi/profilEtudiant/modification_profil.php");
							include("B_mbindi/pue/releve/releve_des_cotes.php");
							include("B_mbindi/makuta/rqt_Historique_Vers_fr.php");
 							include("B_mbindi/profilEtudiant/carte_etudiant.php");
 							include("B_mbindi/profilEtudiant/dossier_etudiant.php");
							include("B_mbindi/profilEtudiant/apropos_etudiant.php");
							
						?>
					</div></div>

					<div class="profilEtudiant2C">
						<?php 
							include("B_mbindi/profilEtudiant/ses_collegues_etudiants.php");
						?>
					</div>
				</td>
			</tr>	
		</table>
					
		<?php 
	}	

?>