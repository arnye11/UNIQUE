<?php
	 if(isset($_GET['profil']) and isset($_GET['id'])){
		 $idFac ="";
		 $designFac = "";
		 $idOp="";
		 $designOp="";
		 $idPromo="";
		 $matEtud = "";
		 $_SESSION['carteEtud'] = true ;
		 
		 $slct_etud = "select *, DAY(datenaissEtud) AS jrNais, MONTH(datenaissEtud) AS mmNais, YEAR(datenaissEtud) AS aaaaNais from tb_etudiant where matricEtud = '".$_GET['id']."'";
		if($ex_slct_etud = $conDb->query($slct_etud)){
			if($result_slct_etud = $ex_slct_etud->fetch_assoc()){
				$matEtud = $_SESSION['matricEtud']=$result_slct_etud['matricEtud'];
				?>
				<table style="width: 100%;" class="profil_" id="etudiant">
					<tr>
						<td>
							<div class="profil_11" align="center">
								<a href="?profil&id=<?php echo  $result_slct_etud['matricEtud'];?>">
									<img src="B_mbindi/Biamunda/media/<?php echo $result_slct_etud['matricEtud']."/".$result_slct_etud['avantarEtud'];?>" alt="Pas de Photo" width="100%" height="100%" />
								</a>
							</div>
							<div class="profil_22" align="left">
								<?php 
									echo "<a href='?profil&id=".$result_slct_etud['matricEtud']."' style='text-transform:uppercase'>";
									echo $result_slct_etud['nomEtud']."&nbsp;".$result_slct_etud['postnomEtud']."&nbsp;".$result_slct_etud['prenomEtud']."&nbsp;<br/> Matr. : ".$result_slct_etud['matricEtud']."<br/>";
									echo "<span style='text-transform: lowercase;'>";
									if ($result_slct_etud['sexeEtud']=="M"){ 
										echo "N&eacute; &agrave; ";
									}
									else { 
										echo "N&eacute;e &agrave; ";
									} 
									echo "</span>";
									echo $result_slct_etud['lieunaisEtud'] ;
									echo "<span style='text-transform: lowercase;'>, le </span>";
									if($result_slct_etud['jrNais']<10){
										echo "0".$result_slct_etud['jrNais'];
									}
									else{
										echo $result_slct_etud['jrNais'];
									}
									echo "/ ";
									if($result_slct_etud['mmNais']<10){
										echo "0".$result_slct_etud['mmNais'];
									}
									else{
										echo $result_slct_etud['mmNais'];
									}
									echo "/";
									echo $result_slct_etud['aaaaNais']."."; 
									echo "</a><br>";
									/*****************************************/
									//Rqt SELECTION DE LA PROMOTION DE L'ANNEE EN COURS 
									$slct_etud_incrit = "select * from tb_inscription where matricEtud = '".$result_slct_etud['matricEtud']."' and idAca = '".$an_aca."'";
								if($exe_slct_etud_incrit = $conDb->query($slct_etud_incrit))
									{
									if($result_slct_etud_inscrit = $exe_slct_etud_incrit->fetch_assoc())
										{
										$reinscription = true;
										$slct_op = "select * from tb_option where idOp = '".$result_slct_etud_inscrit['idOp']."'";//RQT SELECTION DE L'OPTION
										if($exe_slct_op = $conDb->query($slct_op))
											{
											if($result_slct_op = $exe_slct_op->fetch_assoc())
												{
												$slct_fac = "select * from tb_faculte where idFac = '".$result_slct_op['idFac']."'";//RQT SELECTION DEPARTEMENT
												if($exe_slct_fac = $conDb->query($slct_fac))
													{
													if($result_slct_fac = $exe_slct_fac->fetch_assoc())
														{
														$idFc=$result_slct_fac['idFac'];
														$designFc=$result_slct_fac['designFac'];
														$idOp=$result_slct_op['idOp'];
														$idPromo=$result_slct_etud_inscrit['idProm'];
														$designOp=$result_slct_op['designOp'];
														echo "<br/>";
														echo "<a href='?fAculTe&iDfaC=".$idFc."&pRomotIon=".$idPromo."&oPtiOn=".$idOp."''>".$idPromo."&ensp;".$designOp."</a><br/>";
														}
													}
												}
											}
										}
										else{
											echo "<font color='#FF0000'>";		
											if ($result_slct_etud['sexeEtud']=="M"){ echo "Ancien &eacute;tudiant.";}else { echo "Ancienne &eacute;tudiante.";};
											echo "</font >";
											$_SESSION['carteEtud'] = false ;		
										}
										if($_SESSION['idAnAca'] != $an_aca){
											echo "<font color='#FF0000'>";		
											if ($result_slct_etud['sexeEtud']=="M"){ echo "Ancien &eacute;tudiant.";}else { echo "Ancienne &eacute;tudiante.";};
											echo "</font >";
											$_SESSION['carteEtud'] = false ;		
										}
										$slct_promo = "select * from tb_promotion where idPromo = '".$result_slct_etud_inscrit['idProm']."'";
										if($exe_slct_promo = $conDb->query($slct_promo)){
											if($tb_promo = $exe_slct_promo->fetch_assoc()){
												$_SESSION['systPromo']=$tb_promo["systPromo"];
											}
											else{
												echo "<b class='erreur'>Pas de promotion </b>";
											}
										}
										else{
											echo "<b class='erreur'>Erreur de promotion </b>";
										}
									}
								else
									{
									echo "<p class='erreur'>Erreur</p>";
									}
								?>
							</div>
						</td>
					</tr>
				</table>
				
				<?php
				include("B_mbindi/profilEtudiant/menuProfilEtd.php");
			}
			else{
				echo "<p class='erreur'>Aucune information � singaler</h1>";		
			}
		}
		else{
				echo "<p class='erreur'>Impossible de trouver l'&eacute;tudiant</h1>";		
		}
	}
?>
