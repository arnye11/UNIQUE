<?php 
	if(isset($_POST["btAjoutElmDos"])){
		/************************************************************
		* Creation du repertoire cible si inexistant
		*************************************************************/
		$destination1 = "/B_mbindi/Biamunda/media/".$_SESSION['matricEtud']."/";
		if( !is_dir($_SERVER['DOCUMENT_ROOT'].$destination1) ){
			if( !mkdir( $_SERVER['DOCUMENT_ROOT'].$destination1, 0755) ) {
				echo $_SERVER['DOCUMENT_ROOT'].$destination1;
				exit('Erreur : difficile de créer le répertoire cible!');
			}
		}
		$destination = "/B_mbindi/Biamunda/media/".$_SESSION['matricEtud']."/dossier/";
		if( !is_dir($_SERVER['DOCUMENT_ROOT'].$destination) ){
			if( !mkdir( $_SERVER['DOCUMENT_ROOT'].$destination, 0755) ) {
				echo $_SERVER['DOCUMENT_ROOT'].$destination;
				exit('Erreur : difficile de créer le répertoire cible!');
			}
		}

		/************************************************************
		* Script d'upload
		*************************************************************/
		if ($_FILES['mon_fichier']['error']) {
			switch ($_FILES['mon_fichier']['error']){
				case 1: // UPLOAD_ERR_INI_SIZE (la taillle est definie dans le fichier php.ini)
					$sms_gerer = "Le fichier dépasse la limite autorisée par le serveur  !";
					break;
				case 2: // UPLOAD_ERR_FORM_SIZE
					$sms_gerer = "Le fichier dépasse la limite autorisée dans le formulaire HTML !";
					break;
				case 3: // UPLOAD_ERR_PARTIAL
					$sms_gerer = "L'envoi du fichier a été interrompu pendant le transfert !";
					break;
				case 4: // UPLOAD_ERR_NO_FILE
					$sms_gerer = "Le fichier que vous avez envoyé a une taille nulle !";
					break;
			}
		}
		else{
			$extension = pathinfo($_FILES['mon_fichier']['name'], PATHINFO_EXTENSION);
			$nouveauNom = $_POST['tyepElmDos']."_".$_SESSION['matricEtud'].date("d_m_Y-H_i_s").".".$extension;
			$nom = $_FILES['mon_fichier']['tmp_name'];
			move_uploaded_file($nom, $_SERVER['DOCUMENT_ROOT'].$destination.$nouveauNom);

			$rqt_insrt_dossier = "INSERT INTO tb_dossier_etud VALUES(NULL,'".$nouveauNom."','".$_POST['tyepElmDos']."','".$_SESSION['matricEtud']."', NOW())";
			if($exe_rqt_insrt_dosssier = mysqli_query($con, $rqt_insrt_dossier)){
				$sms_gerer = "Elémént du dossier a été ajouté";
			}
			else{
				$sms_gerer = "Echec d'ajout de l'élément du dossier";
				unlink($_SERVER['DOCUMENT_ROOT'].$destination.$nouveauNom);
			}
		}
	}
?>