<?php 
	if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and isset($_GET['cOTe'])){
		$idPromo = $_GET['pRomotIon'];
		$idOp = $_GET['oPtiOn'];
		$designOp = "";
		$session = "s1";
		$pv = false;
		if(isset($_GET['s1'])){
			$session = "s1";	
		}
		else{
			$session = "s2";
		}
		$rqt_slct_delb = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
		if($exe_rqt_slct_del = $conDb->query($rqt_slct_delb)){
			if($exe_rqt_slct_del->num_rows>0){
				$pv = true;
				} 
			}
		?>
		
		<div align="left" style="width:96.5%; height:45px; border-bottom: solid 0.5px #0000ff; " >
				<div style="display:inline; float:left; margin-right: 10%; height:auto; text-align:center; <?php if (isset($_GET['fIcHe'])){?> border-bottom:solid 3px #0000FF; <?php }?>">
					<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&fIcHe" ?>">Fiches<br/>  de cotation </a> 
				</div>
				<div style="display:inline; float:left;margin-right: 10%; height:auto; text-align:center;<?php if (isset($_GET['gRillDelib'])){?> border-bottom:solid 3px #0000FF;<?php }?>">

					<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&gRillDelib&s1&sEm1" ?>">Grillesde <br/> d&eacute;liberation</a>
				</div>
				<div style="display:inline; float:left; margin-right: 10%; height:auto; text-align:center; <?php if (isset($_GET['palMares'])){?> border-bottom:solid 3px #0000FF; <?php }?>">
					<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&palMares&s1" ?>"><br/>Palmares</a> 
				</div>
		</div>
		
		<div align="center">
		<table width="100%" align="center">
			<tr align="center">
				<td>
				<?php 
				include("B_mbindi/pue/fiche_cote/fichiers_de_cotation.php");
				include("B_mbindi/pue/grille/grille_de_deliberation.php");
				include("B_mbindi/pue/pv/pv.php");
				include("B_mbindi/pue/palmares/palmares.php");
				
				 ?>
				 </td>
			</tr>
		</table>
		</div>
	<?php 
	}
?>