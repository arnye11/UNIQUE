<?php 
	$coursTrouve = false ;
	$cours = $_GET['iDcOurs'];
		
	$rqt_slct_c = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idCours)='".$cours."') AND ((tb_program_cours.idPromo)='".$idPromo."') AND ((tb_program_cours.idOp)='".$idOp."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";
		
	if($exe_rqt_slct_c = $conDb->query($rqt_slct_c)){
		if($exe_rqt_slct_c->num_rows>0){
			if($result_rqt_slct_c = $exe_rqt_slct_c->fetch_assoc()){
				$coursTrouve = true ;
				?>
				<div align="left" style="width:99%; height:auto; border:solid 1px #000000; padding:2px; ">
					<table width="100%" border="0">
               			<tr valign="top">
               				<td>
	               				<div align="left" style="display:inline; float:left; width:55%;height:auto;  ">
	               					<table>
	               						<tr>
	                   						<td>Promo./Option </td>
	                       						<td> : <?php echo $idPromo."&nbsp;&nbsp;".$_SESSION["designOp"]; ?></td>
	                       					</tr>
	                  					<tr>
	               						<td>Cours </td>
	                   						<td> : <?php echo $result_rqt_slct_c['designCours']; ?></td>
	                   					</tr>
	                   					<tr>
	                   						<td>Volume horaire</td>
	                   						<td>
	                   							<table width="100%" border="0">
							               			<tr valign="top">
							               				<td>HT</td>
							               				<td>HP</td>
							               				<td>TOT</td>
							               			</tr>
							               			<tr valign="top">
							               				<td><?php echo $result_rqt_slct_c['ht']; ?></td>
							               				<td><?php echo $result_rqt_slct_c['hp']; ?></td>
							               				<td><?php echo ($result_rqt_slct_c['ht']+$result_rqt_slct_c['hp']); ?></td>
							               			</tr>
												</table>
	                   						</td>
	                   					</tr>
	                   					<tr>
	                   						<td>Ponderation </td>
	                   						<td> : <?php echo round((($result_rqt_slct_c['ht']+$result_rqt_slct_c['hp'])/15), 0); ?></td>
	                   					</tr>
	               					</table>
	               				</div>
	               				<div style="display:inline; float:left; width:44%;height:auto; border-left:solid 1px #CCCCCC; ">
	               					<table width="100%">
	                   					<tr valign="top">
	                   						<td>Ann&eacute;e ac. </td>
	                   						<td ><?php echo  $an_aca;?></td>
	                   					</tr>
	                   					<?php 
											$rqt_slct_ens = "SELECT * FROM tb_enseignant RIGHT JOIN tb_attribution ON tb_enseignant.idEns = tb_attribution.idEns WHERE (((tb_attribution.idCours)='".$result_rqt_slct_c['idCours']."') AND ((tb_attribution.idPromo)='".$idPromo."') AND ((tb_attribution.idOp)='".$idOp."') AND ((tb_attribution.idAnAca)='".$an_aca."')) ";
											if($exe_rqt_slct_ens= $conDb->query($rqt_slct_ens)){
												if($tb_ens = $exe_rqt_slct_ens->fetch_assoc()){
													?>
													<tr valign="top">
			                          					<td>Enseignant </td>
			                          					<td>
									                      	<div>
									                       		<?php 
																	$idEns = $tb_ens['idEns'];
																	echo $tb_ens['prenomEns']."&nbsp;".$tb_ens['nomEns'] ;
																?>
															</div>
				                        				</td>
				                      				</tr>
				                      				<tr valign="top">
								                        <td>Grade </td>
								                        <td>: <?php echo $tb_ens['idGrad'] ; ?> </td>
			                        				</tr>
													<tr valign="top">
				                            			<td>Doaine d'etude</td>
				                            			<td>: <?php echo $tb_ens['domainEtudEns'] ; ?> </td>
				                        			</tr>
													<?php
												}
												else{
													echo "<div class='erreur'>Non attribu&eacute;.</div>";
												}
											}
											else{
												echo "Erreur.";
											}
										?>
									</table>
	                    		</div>
	                    	</td>
               			</tr>
              		</table> 
				</div>
				<?php 
			}
			else{
				echo "Erreur lors de r&eacute;peration des donn&eacute;es .";
			}
		}
		else{
			echo "Le cours que vous avez sel&eacute;ctionn&eacute; n'est au programme de cette ann&eacute;e.";
		}
	}
	else{
		echo "Impossible de retrouver le cours.";
	}


	if(isset($_GET['cours']) and !isset($_POST['BtChargerNomEtd'])){
		$cours = $_GET['cours'];
		switch ($cours){
			case "TFC" :
				echo "TFC";
				break;
			case "STG" :
				echo "STAGE";
				break;
			case "M" :
				echo "Mémoire";
				break; 
		}
	}
				

?>
						