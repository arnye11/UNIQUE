<?php 
	
	if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and (isset($_GET['cOTe']) and isset($_GET['fIcHe']))||(isset($_GET['imPRessIoN']) and isset($_GET['fiche_cote']) and isset($_GET['iDcOurs']))){
		if($_SESSION['idFonctAutoDec']=="ENCODJ" || $_SESSION['idAutoDec']=="admin1"){
			$nbrcours = 0;
			$idFac =  $_GET['iDfaC'];
			$idPromo = $_GET['pRomotIon'];
			$idOp = $_GET['oPtiOn'];
			$Nbr_echec_l=0;
			$Nbr_echec_p=0;
			$Nbr_reus=0;
			$NbrSansCote = 0 ;	
	 
			?>
			<style type="text/css">
				<?php 
					if (isset($_GET["imPRessIoN"])) {
						?>
						.fiche_cotation{
							border:solid 1px #666666; width:99%;  background:#FFFFFF;
						}
						.liste_cours{
							background:#ccccff; display:inline; float:right; border:solid 1px #000000; width:30%; padding:5px; margin-right:1%; margin-bottom:3%;box-shadow:0px 5px 5px 5px #000000; border-radius:15px 15px 0px 0px;
						}
						.cours{
							width:98%; height:auto; padding:1px; color:#000000;margin-bottom:5px; vertical-align:baseline;
						}
						#cours_slct{
							background:#ffffff;
						}
						<?php 
					}
					else{
						?>
						.fiche_cotation{
							display:inline;float:left; border:solid 1px #666666; width:62%;  background:#FFFFFF; padding:2%; margin-bottom:2%;
						}
						.liste_cours{
							background:#ccccff; display:inline; float:right; border:solid 1px #000000; width:30%; padding:5px; margin-right:1%; margin-bottom:3%;box-shadow:0px 5px 5px 5px #000000; border-radius:15px 15px 0px 0px;
						}
						.cours{
							width:98%; height:auto; padding:1px; color:#000000;margin-bottom:5px; vertical-align:baseline;
						}
						#cours_slct{
							background:#ffffff;
						}
						<?php 
					} 
				?>
			
			</style>
			<!--_______________FICHE DE COTATION___________________________ -->
			<div class="fiche_cotation" id="ficheCot">
				<?php 
					if (isset($_GET["imPRessIoN"])) {
						?>
						<div align="left" style="width:99%;">
							<div align="center" style="width:100%; border-bottom:solid 2px #000000; text-transform:uppercase;">
								<table style="width:100%;">	
									<tr >
										<td style="width:100px;height:110px;">	
											<div style="width:100%; height:100%; " >
												<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" style="max-width:100%; max-height:auto;"/>
											</div>
										</td>
										<td style=" " >
											<div align="center" style="font-size:1.1em; text-transform: uppercase; font-weight: bold;" >
												ENSEIGNEMENT SUPERIEUR ET UNIVERSITAIRE
												<br/>
												<?php
													$_SESSION['nom_etablissement']."<br/>";
													echo "&laquo; ".$_SESSION['sigle_tb_etablissement']."&raquo;<br />";
												?> 
												SECRETARIAT GENERAL ACADEMIQUE<br />
											</div>
										</td>
										<td style="width:100px; height:110px; " align="right">
											<div style="width:100%; height:100%; ">
												<img src="B_mbindi/Biamunda/icon/unique.gif" style="max-width:100%; max-height:auto;" />
											</div>
										</td>
									</tr>
								</table>
							</div>
						
							<div align="left" style="width:99%; text-transform:uppercase; font-style:italic;font-size: 20px;  ">
								<?php 
									echo "FACULTE : ".$_SESSION["designFac"];
								?>
							</div>
						</div>
						<?php 
					}
				?>
				<div align="left" style="width:99%;" >
					<h2 align="center">FICHE DE COTATION<br/></h2>
				</div>

				<div style="width:98%;">
					<?php 
						if(isset($_GET['iDcOurs']) and !empty($_GET['iDcOurs'])){
							include("B_mbindi/pue/fiche_cote/detaille_cours_fiche_cote.php");
							include("B_mbindi/pue/fiche_cote/list_etud_fiche_de_cote.php");
							
						}
						else{
							echo "Sel&eacute;ctionner un cours pour charger la fiche de cotation.";
						} 
					?>
				</div>
			</div>
			<?php 	
			if (!isset($_GET["imPRessIoN"])) {
				include("B_mbindi/pue/fiche_cote/list_cours_fiche_cote.php");
			}		
		}
		else{
			echo "<h1 style='color:red;'>Vous n'avez pas le droit d'ouvrire la fiche de cotation eléctonique</h1>";
		}
	}
	
?>
