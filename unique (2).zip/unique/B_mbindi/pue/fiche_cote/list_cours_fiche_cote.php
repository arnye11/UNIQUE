<?php 
		$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromo."') AND ((tb_program_cours.idOp)='".$idOp."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";//COURS 
		if($exe_rqt_slct_cours_Program = mysqli_query($con, $rqt_slct_cours_Program)){
			if(mysqli_num_rows($exe_rqt_slct_cours_Program)>0){
				$num=0;
				$nbrcours=mysqli_num_rows($exe_rqt_slct_cours_Program);
				?>
				
				<!--_______________LISTE DES COURS___________________________ -->
				<div class="liste_cours" >
					<div style="width:99%;padding:1%; text-align:center;">
						<h3>Cours organis&eacute;s (<?php echo $nbrcours; ?>)</h3>
					</div>
					<div align="left" style="border:solid 1px #000000; width:98%; padding:1%;">
						<table>
						<?php 
							while($tb_programme_cours=mysqli_fetch_assoc($exe_rqt_slct_cours_Program)){
								$num = $num+1;
								 ?>
								 <tr <?php if(isset($_GET['iDcOurs']) and $_GET['iDcOurs']==$tb_programme_cours['idCours']){ echo "id='cours_slct'";}?>>
								 	<td>
								 		<?php echo $num ; ?>
									</td>
								 	<td >
										<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&fIcHe&iDcOurs=".$tb_programme_cours['idCours']."#ficheCot"; ?>" style="height:auto;">
											<div class="cours" >
												<?php echo $tb_programme_cours['designCours']; ?>
											</div>
										</a>
									</td>
								</tr>
								<?php
							}
							//include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbidndi/pue/rqt_list_cours_pour_cotes.php"); 
						?>
						</table>
						</div>
					
					</div>
				</div>
				<?php
			}
			else{
				echo "<div style='background:#FFFFFF;margin-top:5%;' class='echec'><h2 >Aucun cours n'est organisé en ".$idPromo."&nbsp;".$designOp."</h2><span>Il semble que l'Option que vous avez choisie n'est pas organée en ".$idPromo."</span><br/><br/></div>";
			}
		}
		else{
			$nbrcours =0;
			echo "<div style='background:#FFFFFF;margin-top:5%;' class='echec'><h2 >Impossible de retrouver le nombre de cours organisés en ".$idPromo."&nbsp;".$designOp."</h2><span>Il semble que l'Option que vous avez choisie n'est pas organée en ".$idPromo."</span><br/><br/></div>";
		}