<style type="text/css">
	.navigaPreced, .navigaSuiv{
		width:30%;
		display: inline-block;
		font-size: 14px;
		margin: 10px;
		border: solid 1px #9d9d9d;
		background:#c3c3c3 ;
		text-align: center;
		border-radius: 8px;
	}
	.navigaPreced{
		float: left;
	}
	.navigaSuiv{
		float: right;
	}
	.ligneFocus:hover{
		background: #bed5e0;
	}
</style>
<div style="margin-top: 20px; padding-bottom:15px; width:auto; height:auto;" align="left" >
	<?php 
		$debut = 0;
		$limite = 20;
		$nbln = "";
		$urlAct = "";
		if (isset($_GET['suivant'])) {
			$debut = $_GET['suivant'];
			$urlAct = "&suivant=".$debut ;
		}
		//RQT ETUDIANTS INSCRIT -- CRITERE : DANS PROMOTION, OPTION, DEPARTEMENT, ANNEE ACADEMIQUE selection
		$rqt_EtudInscrit = "SELECT tb_inscription.matricEtud, tb_etudiant.nomEtud, tb_etudiant.postnomEtud, tb_etudiant.prenomEtud, tb_etudiant.sexeEtud FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud ";
		$rqt_EtudInscritLimete = "SELECT tb_inscription.matricEtud, tb_etudiant.nomEtud, tb_etudiant.postnomEtud, tb_etudiant.prenomEtud, tb_etudiant.sexeEtud FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET['pRomotIon']."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud LIMIT ".$debut.",".$limite;
		

		if($exe_rqt_EtudInscrit = mysqli_query($con, $rqt_EtudInscrit)){
			$nbrEtudInscrit=mysqli_num_rows($exe_rqt_EtudInscrit);
			if($nbrEtudInscrit>0){
				$rqt_EtudSuiv="";
				if (isset($_GET["imPRessIoN"])) {
					$rqt_EtudSuiv=$rqt_EtudInscrit;
				}
				else{
					$rqt_EtudSuiv = $rqt_EtudInscritLimete;
				}
				if($exe_rqt_EtudSuiv = mysqli_query($con, $rqt_EtudSuiv)){
					if($n=mysqli_num_rows($exe_rqt_EtudSuiv)>0){
					 	?>
						<div style="border:solid 1px #999999; ">
						    <table width="100%" border="1" cellpadding="1" cellspacing="0" >
						       	<tr style="background:#999999; color:#FFFFFF;" align="center">
						            <td rowspan="2">N&deg; </td>
						            <td rowspan="2">Noms </td>
						            <td rowspan="2"> Postnom </td>
						            <td rowspan="2"> Prenom</td>
						            <td rowspan="2"> Sexe</td>
						            <td colspan="2">COTE TOTALE/20</td>
						       	</tr>
						       	<tr style="background:#999999; color:#FFFFFF;" align="center">
						           	<td>1<sup>ere</sup> S.</td>
						           	<td>2<sup>&egrave;me</sup> S.</td>
						       	</tr>
				    			<?php 
									$nbr = $debut;
									while($tb_etud_inscrit = mysqli_fetch_assoc($exe_rqt_EtudSuiv)){
										$nbr += 1;
										//$suiv = $nbr;
										$cote1 = "";
										$cote2 = ""; 
										$rqt_slct_cote_etud = "select * from tb_cote where matricEtud ='".$tb_etud_inscrit['matricEtud']."' and idCours = '".$cours."' and idAca = '".$an_aca."'";
										if($ex_rqt_slct_cote_etud=mysqli_query($con,$rqt_slct_cote_etud)){
											if($tab_cote = mysqli_fetch_assoc($ex_rqt_slct_cote_etud)){
												$cote1 = $tab_cote['cote_s1'];
												$cote2 = $tab_cote['cote_s2'];
												if($cote1<10){
													if($cote1>7){$Nbr_echec_l=$Nbr_echec_l+1;}
													else{$Nbr_echec_p=$Nbr_echec_p+1;}	
												}
												else{
													$Nbr_reus = $Nbr_reus+1;
												}
											}
											else{
												$NbrSansCote ++;
											}
										}
										else{
											$cote1 = "x";
											$cote2 = "x";
										}
										
										if(isset($_POST['Btok']) and (isset($_GET['cote_etud']) and $_GET['cote_etud'] == $tb_etud_inscrit['matricEtud'])||(isset($_GET['suiv']) and ($_GET['suiv'] == $nbr)) and isset($_GET['s1'])){ 
											?>
										   	<tr title="<?php echo $tb_etud_inscrit['matricEtud']; ?>" id="<?php echo $tb_etud_inscrit['matricEtud']; ?>">
											   	<td colspan="7">
											   		<div  align="right" > 
											   			<?php echo $sms ;?>&nbsp; 
											   		</div>
											   	</td>
							              	</tr>
									       	<?php
									    } 
									    ?>
					              		<tr title="<?php echo $tb_etud_inscrit['matricEtud']; ?>" id="<?php echo $tb_etud_inscrit['matricEtud']; ?>" style="" class="ligneFocus" >
									        <td id="<?php echo $nbr; ?>">
									           	<div  align="right" style="text-transform:uppercase;"> 
									           		<?php echo $nbr ;?>&nbsp; 
									           	</div>
									        </td>
									        <td>
									          	<div  align="left" style="text-transform:uppercase;"> 
									          		&nbsp; <?php echo $tb_etud_inscrit['nomEtud'];?> 
										       	</div>
									        </td>
									        <td>
										       	<div align="left" style="text-transform:uppercase;">
										       		&nbsp;  <?php echo $tb_etud_inscrit['postnomEtud']; ?> 
										       	</div>
										    </td>
										    <td>
											   	<div align="left">
								             		&nbsp;  <?php echo $tb_etud_inscrit['prenomEtud']; ?> 
								               	</div>
								            </td>
								            <td>
								              	<div align="center" style="text-transform:capitalize;"> 
								              		<?php echo $tb_etud_inscrit['sexeEtud']; ?> 
								            	</div>
								            </td>
								            <td>
								              	<div style="text-align: right; padding-right:10px;<?php if (($cote1!="") && ($cote1>0 && $cote1<10)) { echo "color: #ff0000";} ?>">
									                <?php
									                	//1�re SESSION
									                	if ($_SESSION['idAnAca'] != $an_aca and $_SESSION['idAutoDec']!="admin1") {
															if ($cote1=="" || $cote1==0) 
								                      			echo "&mdash;";
								                      		else
								                      			echo $cote1;
														}
														else{
															if((isset($_GET['cote_etud']) and $_GET['cote_etud'] == $tb_etud_inscrit['matricEtud'])||(isset($_GET['suiv']) and ($_GET['suiv'] == $nbr)) and isset($_GET['s1'])){
																if ($cote1=="-"){$cote1="";}
																?>
											                    <form action="" method="post">
											                       	<input name="MatEtud" type="hidden" value="<?php echo $tb_etud_inscrit['matricEtud'];?>" />
											                       	<input name="idPromo" type="hidden" value="<?php echo $_GET['pRomotIon'];?>" />
											                       	<input name="idOp" type="hidden" value="<?php echo $_GET['oPtiOn'];?>" />
											                       	<input name="idCours" type="hidden" value="<?php echo  $cours; ?>" />
											                       	<input name="idAca" type="hidden" value="<?php echo $an_aca; ?>" />
																	<input name="suiv" type="hidden" value="<?php echo $nbr ?>" />
																	<input name="cote" type="text" size="1.5" maxlength="2" value="<?php echo $cote1;?>" autofocus />
											                       	<input name="Btok" type="submit" value="OK" width="5"/>
											                    </form>
											              		<?php
															}
															else {
																?>
											                    <a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $cours; ?>&suivant=<?php echo $debut; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud']; ?>&s1&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>" style="<?php if (($cote1!="") && ($cote1>0 && $cote1<10)) { echo "color: #ff0000;font-weight: bold;";} ?>">
											                      	<?php 
											                      		if ($cote1=="" || $cote1==0) 
											                      			echo "&mdash;";
											                      		else
											                      			echo $cote1;
											                      	?>
											                   	</a>
											                    <?php 
															}	
														}
													?>
										       	</div>
										    </td>
					                		<td> 
					                			<div style="text-align: right; padding-right:10px;<?php if (($cote2!="") && ($cote2>0 && $cote2<10)) { echo "color: #ff0000";} ?>">
						                			<?php 
						                				//2�me SESSION
														if ($_SESSION['idAnAca'] != $an_aca and $_SESSION['idAutoDec']!="admin1") {
															if ($cote2=="" || $cote2==0) 
								                      			echo "&mdash;";
								                      		else
								                      			echo $cote2;
														}
														else{
															
																if((isset($_GET['cote_etud']) and $_GET['cote_etud'] == $tb_etud_inscrit['matricEtud'])|| (isset($_GET['suiv']) and ($_GET['suiv'] == $nbr)) and isset($_GET['s2'])){
																	?>
												                    <form action="" method="post">
												                       	<input name="MatEtud" type="hidden" value="<?php echo $tb_etud_inscrit['matricEtud'];?>" />
												                       	<input name="idPromo" type="hidden" value="<?php echo $_GET['pRomotIon'];?>" />
												                       	<input name="idOp" type="hidden" value="<?php echo $_GET['oPtiOn'];?>" />
												                       	<input name="idCours" type="hidden" value="<?php echo  $cours; ?>" />
												                       	<input name="idAca" type="hidden" value="<?php echo $an_aca; ?>" />
																		<input name="suiv" type="hidden" value="<?php echo $nbr ?>" />
																		<input name="cote" type="text" size="1.5" maxlength="2" value="<?php echo $cote2;?>" autofocus />
												                       	<input name="Btok" type="submit" value="OK" width="5"/>
												                    </form>
												              		<?php
																}
																else {
																	?>
												                    <a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $cours; ?>&suivant=<?php echo $debut; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud']; ?>&s2&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>" style="<?php if (($cote2!="") && ($cote2>0 && $cote2<10)) { echo "color: #ff0000;font-weight: bold;";} ?>">
												                      	<?php 
													                      	if ($cote2=="" || $cote2==0) 
												                      			echo "&mdash;";
												                      		else
												                      			echo $cote2;
											                      		?>
												                   	</a>
												                    <?php 
																}
															
														}
													?>
												</div>
										    </td>
										</tr>
										<?php 
									}
								?>
			          		</table>
						</div>
						<?php 
							if (!isset($_GET["imPRessIoN"])) {
								?>
								<div style="text-align:center;letter-spacing:6px; margin-top:15px;">
									<?php  
										if(($debut+$limite<=$nbrEtudInscrit)){
											echo ($debut+$limite);
										}
										else{
											echo $nbrEtudInscrit;
										}
										echo "/";
										echo $nbrEtudInscrit ; 
									
									?>
								</div>
								<div style="width:100%; height:50px;" align="center">
									<?php 
										if ($debut>0) { ?>
											<div class="navigaPreced" style="">	
												<a href="?fAculTe&iDfaC=<?php echo  $_GET['iDfaC']; ?>&pRomotIon=<?php echo  $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $_GET['iDcOurs']; ?>&suivant=<?php echo ($debut-$limite) ; ?>&aca=<?php echo $an_aca; ?>#<?php echo ($debut-$limite+1); ?>" style="color: #ffffff;">
													<div style="color:black;"  > 
														<< <b>Pr&eacute;c&eacute;dant</b> <?php echo  "(".$debut.")" ; ?> 
													</div>
												</a>
											</div>
											<?php 
										}
										if (($debut+$limite)<$nbrEtudInscrit) {
											?>
											<div class="navigaSuiv" style="">	
												<a href="?fAculTe&iDfaC=<?php echo  $_GET['iDfaC']; ?>&pRomotIon=<?php echo  $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $_GET['iDcOurs']; ?>&suivant=<?php echo $debut+$limite ; ?>&aca=<?php echo $an_aca; ?>#<?php echo ($debut+$limite+1); ?>" style="color: #ffffff;">
													<div style="color:black;"><?php echo  "(".($nbrEtudInscrit-($debut+$limite)).") " ; ?><b>Suivant</b>  >> </div>
												</a>
											</div>
											<?php 
										}	
									?>
								</div>
								<?php
							} 
						?>
						<div align="left" style="font-style:italic; padding:5px; margin:5px; border:solid 1px #A0A0A4;">
							<table>
								<tr>
									<td>Insctis</td>
									<td><?php echo $nbrEtudInscrit ;?></td>
								</tr>
								<tr>
									<td>Nombre de r&eacute;ussites </td>
									<td><?php echo $Nbr_reus; ?></td>
								</tr>
								<tr>
									<td>Nombre  d'echecs l&eacute;gers  </td>
									<td><?php echo $Nbr_echec_l; ?> </td>
								</tr>
								<tr>
									<td>Nombre d'&eacute;checs gr&acirc;ves </td>
									<td><?php echo $Nbr_echec_p;  ?></td>
								</tr>
								<tr>
									<td>Sans cotes  </td>
									<td><?php echo $NbrSansCote;  ?></td>
								</tr>
							</table>
						</div>
						<div align="right">
						<?php 
							if (isset($_GET["imPRessIoN"])) {
								echo "Fait &agrave; {$_SESSION['villeEts']}, le ".$jour."/".$moi."/".$annee_encours;
								echo "<p></p>";
								echo "<p></p>";
								echo "<p></p>";
								echo "<p align='center'>Sceau et Signature de l'autorit&eacute;</p>";
								echo "<p></p>";
								echo "<p></p>";
							}
							else{
								?>
								<div align="right" style="width: 90%;">
									<p >
										<?php 	
											echo "<a href='?fAculTe&iDfaC=".$idFac."&pRomotIon=".$idPromo."&oPtiOn=".$idOp."&imPRessIoN&fiche_cote&iDcOurs=".$_GET['iDcOurs']."&aca=".$an_aca."'>";
												echo "<img src='B_mbindi/Biamunda/icon/print.ico' class='ico'>";
												echo "<br>Imprimer";
											echo "</a>";		
										?>
									</p>
								</div>
								<?php 
							}
						?>

						
					
							<?php 
								
							?>
						</div>
						<?php
							
					}
				}
				else{
					echo "Impossible de retrouver les �tudiants inscrits ici.";
				}
			}
			else{
				echo "Pas d'�tudiants inscrits ici.";
			}
		}
		else{
			echo "Impossible de retrouver les �tudiants inscrits ici.";
		}
	?>
</div>
				

