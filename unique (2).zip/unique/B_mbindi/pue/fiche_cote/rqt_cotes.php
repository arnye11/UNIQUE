<?php 
include("B_mbindi/pue/fiche_cote/rqt_insrt_cote.php");

?>