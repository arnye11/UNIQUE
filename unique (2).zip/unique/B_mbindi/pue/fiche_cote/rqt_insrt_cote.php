<?php 
	$form_cote = false;
	$cote1="";
	$cote2="";
	$rqt_updt_cote ="";
	
	
	if(isset($_POST['Btok'])){
		$MatEtud = filter_input(INPUT_POST,'MatEtud', FILTER_SANITIZE_SPECIAL_CHARS);
		$idPromo = filter_input(INPUT_POST,'idPromo', FILTER_SANITIZE_SPECIAL_CHARS);
		$idOp = filter_input(INPUT_POST,'idOp', FILTER_SANITIZE_SPECIAL_CHARS);
		$idCours = filter_input(INPUT_POST,'idCours', FILTER_SANITIZE_SPECIAL_CHARS);
		$idAca = filter_input(INPUT_POST,'idAca', FILTER_SANITIZE_SPECIAL_CHARS);
		$cot = filter_input(INPUT_POST,'cote', FILTER_SANITIZE_SPECIAL_CHARS);
		$suiv = filter_input(INPUT_POST,'suiv', FILTER_SANITIZE_SPECIAL_CHARS);

		$debut=0;
		if (isset($_GET["suivant"])) {
			$debut= $_GET['suivant'];
		}
		
		if(($cot!="") and ($cot!="x")){
			if($cot>=0 and $cot<=20){
				$rqt_slct_cote = "SELECT * FROM tb_cote WHERE matricEtud ='".$MatEtud."' AND idPromo = '".$idPromo."' AND idOp = '".$idOp."' AND idCours = '".$idCours."' AND idAca = '".$idAca."'";
				
				if(isset($_GET['s1'])){
					$session = "s1";
					$cote1=$cot;
					$cote2=0;
					$rqt_updt_cote = "update tb_cote set cote_s1 = '".$cote1."' where matricEtud ='".$MatEtud."' and idCours = '".$idCours."' and idAca = '".$idAca."'"; 
				}
				if(isset($_GET['s2'])){
					$session = "s2";
					$cote2=$cot;
					$cote1=0;
					$rqt_updt_cote = "update tb_cote set cote_s2 = '".$cote2."' where matricEtud ='".$MatEtud."' and idCours = '".$idCours."' and idAca = '".$idAca."'";
				}
				if($cot=="-"){
					$suiv ++ ;
					header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$idPromo.'&oPtiOn='.$idOp.'&cOTe&fIcHe&iDcOurs='.$idCours.'&'.$session.'&aca='.$idAca.'&suivant='.$debut.'&suiv='.$suiv.'#'.$MatEtud);
				}
				else{
					if($ex_rqt_slct_cote = mysqli_query($con, $rqt_slct_cote)){
						if(mysqli_num_rows($ex_rqt_slct_cote)>0){
							if($exe_rqt_updt_cote = mysqli_query($con, $rqt_updt_cote)){
								header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$idPromo.'&oPtiOn='.$idOp.'&cOTe&fIcHe&iDcOurs='.$idCours.'&'.$session.'&aca='.$idAca.'&suivant='.$debut.'#'.$MatEtud);
							}
							else{
								$sms ="<span class='erreur'> Echec de modification de cette cote</span>"; 
							}
						}
						else{
							$rqt_insrt_cote="INSERT INTO tb_cote VALUES(NULL, '".$MatEtud."', '".$cote1."', '".$cote2."', '".$idCours."', '".$idPromo."', '".$idOp."', '".$idAca."','".$_SESSION['idAutoDec']."', NOW())";
							if($ex_rqt_insrt_cote=mysqli_query($con, $rqt_insrt_cote)){
								$form_cote = true;
								$suiv ++ ;
								header ('location:?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$idPromo.'&oPtiOn='.$idOp.'&cOTe&fIcHe&iDcOurs='.$idCours.'&'.$session.'&aca='.$idAca.'&suivant='.$debut.'&suiv='.$suiv.'#'.$MatEtud);
							}
							else{
								$sms = "<span class='erreur'>Echec d'enregistrement de la cote ['".$cote1."' , '".$cote2."']</span>";
							}
						}
					}
					else{
						$sms = "<span class='erreur'>Impossible de v&eacute;rifier la cote</span>";
					}
				}
			}
			else{
				$sms = "<span class='erreur'>La cote doit être comprise entre [0 et 20]</span>";
			}
		}
		else{
			$sms = "<span class='erreur'>Veuillez saisir une cote ou un trait</span>";
		}
	}
	

?>