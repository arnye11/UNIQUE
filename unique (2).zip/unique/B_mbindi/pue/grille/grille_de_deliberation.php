<?php 
if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and (isset($_GET['cOTe'])||isset($_GET['imPRessIoN'])) and isset($_GET['gRillDelib'])){
	if(isset($_GET['s1'])){
		$session = "s1";	
	}
	else{
		$session = "s2";
	}
	
	if (isset($_GET["sEmT"])) 
		$sEm = "sEmT";
	else if (isset($_GET["sEm2"])) 
		$sEm = "sEm2";
	if (isset($_GET["sEm1"])) 
		$sEm = "sEm1";
	?>

	<style type="text/css">
		<!--
			.session{
				display:inline;
				margin-right: 20px;
				padding-top: 2px;
				padding-left: 20px;
				padding-right: 20px;
				padding-bottom: 5px;	
			}
			.tbgille{
				width: 100%; border-collapse: collapse;  font-size:10px; 
			}
			.colnCours{
				width:2%;height: 350px; font-size:10px; 
			}
			.cotpp{
				width:3%;height: 350px; font-size:10px;  
			}
			.colnCote{
				width:2%;height: auto; font-size:10px;  
			}
			.colnCoteP{
				width:3%;height: auto; font-size:10px;  
			}
			.pv{
				display: inline-block;
				float: left;
				width: 30%;
				border: solid 1px #67817d;
				border-radius: 12px;
				position: relative;
				background: #afbfb7;
				margin: 20px;  
			}
			.imprimer{
				display: inline-block;
				float: right;
				width: 160px;
				border: solid 1px #67817d;
				border-radius: 12px;
				position: relative;
				background: #afbfb7;  
				margin: 20px;  
			}
			.ico{
				width: 30%;
				height: 100%;  
			}
			-->
	</style>
	<?php 

	if(!empty($_GET['pRomotIon']) and !empty($_GET['oPtiOn'])){
		
		$idPromo = $_GET['pRomotIon'];
		$idOp = $_GET['oPtiOn'];
		
		$sem = "sEm1";
		$debut = 0;
		$limite = 10;
		$nbln = "";
		$urlAct = "";
		if (isset($_GET['suivant'])) {
			$debut = $_GET['suivant'];
			$urlAct = "&suivant=".$debut ;
		}
		
		$nbrcours=0;
		$heureCredit = 15;
		$cotePonderee=0;
		$pourcentage=0;
		$cotePonderee_etud=0;
		$travail=10;
		$stag=20;
		
		$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromo."') AND ((tb_program_cours.idOp)='".$idOp."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";//COURS 
		
		if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
			if($exe_rqt_slct_cours_Program->num_rows>0){
				$num=0;
				$nbrcours=$exe_rqt_slct_cours_Program->num_rows;
				
				if ($_SESSION['systPromo']=="N"){
					if (isset($_GET["sEmT"])) 
						$sEm = "sEmT";
					else if (isset($_GET["sEm2"])) 
						$sEm = "sEm2";
					if (isset($_GET["sEm1"])) 
						$sEm = "sEm1";

					if((!isset($_GET['imPRessIoN'])) || (isset($_GET['imPRessIoN'])and $debut <=10)){
						?>
						<table width="100%" id="g">
							<tr>
								<td align="left">
									<?php 
										if(isset($_GET['imPRessIoN'])){
											?>
											<div class="session">	
												<a href="<?php echo substr($url_Act, 0, (strlen($url_Act)-11)); ?>#g">
													<img src="B_mbindi/Biamunda/icon/arw09lt.ico" class="icon" title="Retour">
												</a>
											</div>
											<?php 
										}
									?>
									<div class="session" style="<?php if($session == 's1'){?>background:#005f7e;<?php } ?>">	
										<?php 
											if(!isset($_GET['imPRessIoN'])){
												?>
												<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&gRillDelib&s1&sEm1#g"; ?>" style="<?php if($session == 's1'){?>color:#FFFFFF;<?php }else{?>color:#4169e1;<?php } ?>">1<sup>&egrave;re</sup> Session</a>
												<?php 
											}
											else{
												?>
												<span style="<?php if($session == 's1'){?>color:#FFFFFF;<?php }else{?>color:#949494;<?php } ?>">
													1<sup>&egrave;re</sup> Session
												</span>
												<?php 
											}
										?>

									</div>
									<div class="session" style="<?php if($session == "s2"){?>border: solid 1px; border-left-color: #ff0000; border-top-color: #ff0000;border-right-color: #ff0000; border-bottom:solid 5px #005f7e;background:#005f7e; <?php } ?>">	
										<?php 
											if(!isset($_GET['imPRessIoN'])){
												?>
												<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&gRillDelib&s2&sEm1#g"; ?>" style="<?php if($session == 's2'){?>color:#FFFFFF;<?php }else{?>color:#4169e1;<?php } ?>">2<sup>&egrave;me</sup> Session </a>
												<?php 
											}
											else{
												?>
												<span style="<?php if($session == 's2'){?>color:#FFFFFF;<?php }else{?>color:#949494;<?php } ?>">2<sup>&egrave;me</sup> Session</span>
												<?php 
											}
										?>
									</div>
									
									
								</td>
							</tr>
						</table>
						<?php
					}
				}
				if ((!isset($_GET['imPRessIoN'])) || (isset($_GET['imPRessIoN'])and $debut <10)) 		
				include("B_mbindi/pue/grille/list_cours_grille.php");
				
				include("B_mbindi/pue/grille/list_etud_grille.php");

				if (!isset($_GET['imPRessIoN'])) {
					if ($pv == true) { 
						?>
						<div style="display:inline; float:left; width:160px; height:auto; text-align:center;<?php if (isset($_GET['pV'])){?> border-bottom:solid 3px #0000FF;<?php }?>">
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&pV&".$session; ?>">PV <br/>  de d&eacute;liberation</a>
						</div>
						<?php 
					} 
					?>

					<div class="imprimer">	
						<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&gRillDelib&".$session."&".$sEm."&aca=".$an_aca."&imPRessIoN#g" ?>" style="color:#ffffff;">
							<img src="B_mbindi/Biamunda/icon/print.ico" class="ico" >
							<br>Imprimer
						</a>		
					</div>
					<?php 
					if(isset($_GET["creationpV"])){ ?>
						<script type="text/javascript">
						  	window.location.replace('?fAculTe&iDfaC='<?php echo $_GET['iDfaC']; ?>'&pRomotIon='<?php echo$_GET['pRomotIon']; ?>'&oPtiOn='<?php echo $_GET['oPtiOn']; ?>'&cOTe&pV');
						</script>
						<?php
					}
					
				}
				else{
					?>
					<script type="text/javascript">
					  	window.print();
					</script>

					<?php 
					//header ('location:?ffAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib');

				}

			}
			else
				{
				echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' class='echec'><h2 >Aucu cours n'est organis&eacute; en <br/>".$idPromo."&nbsp;".$_SESSION['designOp']."</h2><br/><br/></div>";
			}
		}
		else{
			echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'Erreur syst�me d� � la requ�tte</h2></div>";
		}
	}
	else{
		echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'>Pour charger la grille, il faut d'abord indiquer la promotion ainsi que l'option</h2></div>";
	}
}
?>
