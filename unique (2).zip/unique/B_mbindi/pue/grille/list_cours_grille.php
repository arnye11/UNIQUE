<style type="text/css">
	.menuGrille{
		display:inline; 
		margin-left: 20px; 
		margin-right: 20px; 
		padding: 2px ;
	}
	#descision{
		width:99%; 
	}
	<?php 
	if(!isset($_GET["imPRessIoN"])){
		?>
		#descision{
			width:180px; 
		}
		
		<?php
	} 
	?>
	#rdc{
		display: inline-block;
		width: 30%;
		height: 5px;
		margin: 0;
	}
	.barMenuGrille{
		width:100%; height:25px; 
		<?php if($session == "s2"){?>border-top: solid 5px #ff0000;<?php } ?>
		background:#005f7e;
		padding-top: 5px;
		margin-bottom: 8px;
		box-shadow:0px 4px 4px 0px #e6e6e6; 
	}
</style>
<?php 
	$sEm="sEm2";
	if (isset($_GET["sEm1"])||isset($_GET["sEm2"])||isset($_GET["sEmT"])) {
		$nbrURL = strlen($url_Act);
		$url_pour = substr($url_Act, 0, ($nbrURL-5))  ;  
	}    
	// Afficher l'URL
	//echo $url_Act; 

?>
<div id="g" style="" class="barMenuGrille">
	<div style="width:26%; display:inline; float:left; border-right: solid 1px #FFFFFF; color:#cdcdcd; ">UNIQUE</div> 
	<div style="width:70%; display:inline; float:left; height: auto;">
		<?php 
			if ($_SESSION['systPromo']=="N") {
				?>
				<div class="menuGrille"  style="<?php if(isset($_GET['sEm1'])){?>background:#e6e6e6;<?php } ?>">
					<?php 
						if(!isset($_GET['imPRessIoN'])){
							?>
							<a href="<?php echo $url_pour."&sEm1#g"; ?>" style="<?php if(isset($_GET['sEm1'])){?>color:#000000;<?php }else{?>color:#cdcdcd;<?php } ?>">1<sup>er</sup> SEMESTRE</a>
							<?php 
						}
						else{
							?>
							<span>1<sup>er</sup> SEMESTRE</span>
							<?php 
						}
					?>				
				</div>
				<div class="menuGrille" style="<?php if(isset($_GET['sEm2'])){?>background:#e6e6e6;<?php } ?>">	
					<?php 
						if(!isset($_GET['imPRessIoN'])){
							?>
							<a href="<?php echo $url_pour."&sEm2#g"; ?>" style="<?php if(isset($_GET['sEm2'])){?>color:#000000;<?php }else{?>color:#cdcdcd;<?php } ?>">2<sup>&egrave;me</sup> SEMESTRE </a>
							<?php 
						}
						else{
							?>
							<span >2<sup>&egrave;me</sup> SEMESTRE </span>
							<?php 
						}
					?>		
				</div>
				<div class="menuGrille" style="<?php if(isset($_GET['sEmT'])){?>background:#e6e6e6;<?php } ?>">	
					<?php 
						if(!isset($_GET['imPRessIoN'])){
							?>
							<a href="<?php echo $url_pour."&sEmT#g"; ?>" style="<?php if(isset($_GET['sEmT'])){?>color:#000000;<?php }else{?>color:#cdcdcd;<?php } ?>">TOUS LES SEMESTRES </a>
							<?php 
						}
						else{
							?>
							<span>TOUS LES SEMESTRES</span>
							<?php 
						}
					?>		
				</div>
				<?php 
			} 
		?>
	</div>
</div>
<table  border="1" class="tbgille" >
	<tr style="font-size:12px;">
		<td style="width:23%; font-size:14px;" align="center">
			<div style="width:99.8%; height:350px; ">
				<div align="left" style="width:90%; height:84%; margin-bottom:5px; ">
					<div align="center">
						<?php echo $_SESSION['nom_etablissement']; ?>
						<br/> 
						<div style="width:50px; height:50px;">
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&gRillDelib" ?>">
								<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" width="100%" height="100%"/>
							</a>
						</div>
						GRILLE DE DELIBERATION <br/> 
						<?php 
							if($session=="s1"){
								echo "&nbsp; 1<sup>&egrave;re</sup> &nbsp;";
							}
							else{
								echo "&nbsp; 2<sup>&egrave;me</sup> &nbsp;";
							} 
						?>
						SESSION &nbsp;<br/>
						<div  style="text-transform:uppercase;">
							<?php 
								echo $idPromo."&nbsp;&nbsp;".$_SESSION['designOp']."<br/>ANNEE ACADEMIQUE &nbsp;<br/>".$an_aca; 
							?>	
						</div>
					</div>

					<div id="rdc" style="background:#1300dc;"></div>
					<div id="rdc" style="background:#fffa35;"></div>
					<div id="rdc" style="background:#ff2c15;"></div>
					<div align="center">
						<h3>UNIQUE</h3>
					</div>
				</div>
				<div align="right" style="height:26px; line-height:26px; background:#c3c3c3; padding-right: 20px;font-size:12px;">
					<?php 
						if ($_SESSION['systPromo']=="A")
							echo "PONDERATION";
						else
							echo "CREDIT";
					?>
				</div>
				
				<div align="center" style="width:99%; height:20px; font-size:12px;"> 
					<div align="center" style="width:8%; height:20px; line-height:20px;  display: inline-block; float: left; border-right: solid 1px #000000;"> 
						N&deg;
					</div>
					<div align="center" style="width:80%; height:20px; line-height:20px;  display: inline-block; float: left; font-weight: bold; overflow: hidden; "> 
						NOM, POSTNOM ET PRENOM
					</div>
					<div align="center" style="width:10%; height:20px; line-height:20px;  display: inline-block; float: left;"> 
						COTE
					</div>
				</div>
			</div>
		</td>
		<td style="width:76%;">
			<table style="width:100%; border-collapse: collapse;">
				<tr>
					<?php 
						if ($_SESSION['systPromo']=="A"){
							while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){ ?>
								<td class="colnCours" title="<?php echo $tb_programme_cours['idCours']; ?>">
									<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
										<div align="left" style="width:90%; height:84%; writing-mode:sideways-lr; margin-bottom:5px; overflow: hidden; ">
											<?php 
												echo $tb_programme_cours['designCours'];
											?>
										</div>
										<div align="center" style="width:87%; height:8%; background:#c3c3c3; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg); ">
											<?php 
												$ponderation=(($tb_programme_cours['ht']+$tb_programme_cours['hp'])/15);
												echo round($ponderation,0);
											?>
										</div>
										<div align="center" style="width:85%; height:7%; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg);"> 20 
											<?php 
												$cotePonderee=(20*$ponderation)+$cotePonderee;
											?>
										</div>
									</div>
								</td>
								<?php 
							}
							?>

							<td class="cotpp" >
								<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
									<div align="left" style="width:99%; height:82%;padding-bottom:10px;writing-mode:sideways-lr; ">
									Cotes pond&eacute;r&eacute;es 
									</div>
									<div align="center" style="width:100%; height:16%;background:#c3c3c3; writing-mode:sideways-lr; transform:rotate(0deg);">
										<?php 
											echo round($cotePonderee, 0);
										?>
									</div>
								</div>
							</td>
							<td class="cotpp">
								<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
									<div align="left" style="width:99%; height:82%; padding-bottom:10px; writing-mode:sideways-lr;">
									%
									</div>
									<div align="center" style="width:100%; height:16%;background:#c3c3c3; writing-mode:sideways-lr; transform:rotate(0deg);">
										<?php 
											$pourcentage = (($cotePonderee*100)/$cotePonderee);
											echo round($pourcentage, 1);
										?>
									</div>
								</div>
							</td> 
							<!-- pour la promotion G3 ou L2--> 
							<?php 
								/*if(($idPromo =="G3") || ($idPromo=="L2")){?>
									<td style="width:4%; height:300px">
									  	<div align="left" style=" height:81%; padding-bottom:10px; writing-mode:sideways-lr;">
											% &nbsp;<?php if($idPromo =="G3"){echo "TFC";}
											if(($idPromo =="L2")){echo "M�moire";}
											?>
										</div>
										<div align="center" style="width:99%; height:15%; writing-mode:sideways-lr;">
											<?php echo $travail; ?>
										</div>
											
									</td>
									<td style="width:4%; height:300px;">
										<div align="left" style=" height:81%; padding-bottom:10px; writing-mode:sideways-lr; ">
											% &nbsp;STAGE
										</div>
										<div align="center" style="width:99%; height:15%; writing-mode:sideways-lr;">
											<?php echo $stag; ?>
										</div>
									</td>
									<td style="width:4%; height:300px;">
										<div align="left" style=" height:81%; padding-bottom:10px; writing-mode:sideways-lr; ">
											% &nbsp; TOTAL (Cours, Travail et Stage)
										</div>
										<div align="center" style="width:99%; height:15%;  background:#2C2C2C; color:#E2E2E2; writing-mode:sideways-lr;">
											<?php 
												$pourcentage = $pourcentage+$travail+$stag;
												echo $pourcentage;
											?>
										</div>
									</td>
									<?php 
								/*}*/
							?>
							<td class="colnCours">
								<div align="left" style="width:100%; height:99%; writing-mode:sideways-lr; border-right: solid 1px #000000; ">
									Nombre d'&eacute;checs 
								</div>
							</td>
							<td class="colnCours" >
								<div align="left" id="descision" style=" height:99%; writing-mode:sideways-lr; padding-left:30%;">
										D&eacute;cision du jury
								</div>
							</td>
							<?php 

						}


						if($_SESSION['systPromo']=="N"){
							if(isset($_GET['sEm1'])){
								$rqt_slct_Sem = "SELECT * FROM  tb_semestre WHERE idSem = 'SEM1'"; 
							}
							else if(isset($_GET['sEm2'])){
								$rqt_slct_Sem = "SELECT * FROM  tb_semestre WHERE idSem = 'SEM2'"; 
							}
							else{
								$rqt_slct_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem "; 
							}
							
							if($exe_rqt_slct_Sem = $conDb->query($rqt_slct_Sem)){
								$htAnnuel=0;
								$hdAnnuel=0;
								$hpAnnuel=0;
								$htotAnnuel=0;
								$creditAnnuel=0;
								$cotePondereeAnnuel = 0;
								$moyenneAnnuel = 0 ;
								
								while($tb_semestre = $exe_rqt_slct_Sem->fetch_assoc()) {
									$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' AND idPromo ='".$idPromo."' AND idOp ='".$idOp."' ORDER BY designUE "; 
									if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
										if($exe_rqt_slct_ue->num_rows>0){
											$numUE=1;
											$htSem=0;
											$hdSem=0;
											$hpSem=0;
											$htotSem=0;
											$creditSem=0;
											$cotePondereeSem = 0;
											$moyenneSem = 0 ;

											$ue_ec = false;
											while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {
												$num=0;
												$htUE = 0;
												$hdUE = 0;
												$hpUE = 0;
												$htotUE = 0;
												$creditUE = 0;
												$cotePondereeUE = 0;
												$moyenneUE = 0 ;

												$nbrEC = 0 ;

												$rqt_slct_cours_ProgramSEM = "SELECT tb_program_cours.*, tb_cours.* FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$idPromo."') AND ((tb_program_cours.idOp)='".$idOp."') AND ((tb_program_cours.idAnAca)='".$an_aca."') AND ((tb_cours.idUE)='".$tb_ue["idUE"]."')) ORDER BY tb_cours.designCours";
												if($exe_rqt_slct_cours_ProgramSEM = $conDb->query($rqt_slct_cours_ProgramSEM)){
													$nbrEC = $exe_rqt_slct_cours_ProgramSEM->num_rows;
													if($nbrEC>0){
														while($tb_programme_coursSEM = $exe_rqt_slct_cours_ProgramSEM->fetch_assoc()){
															$cote=20; 
															$num  = $num+1;
															$htEC = $tb_programme_coursSEM["ht"];
															$hdEC = $tb_programme_coursSEM["hd"];
															$hpEC = $tb_programme_coursSEM["hp"];
															$htotEC   = ($htEC + $hdEC + $hpEC);
															$creditEC = (int)($htotEC/$heureCredit);
															$cotePondereeEC = ($cote*$creditEC);
															$moyenneEC = ($cotePondereeEC/$creditEC);
															
															$htUE += $htEC ;
															$hdUE += $hdEC ;
															$hpUE += $hpEC ;
															$htotUE  += $htotEC ;
															$creditUE += $creditEC ;
															$creditSem += $creditEC ;
															$cotePondereeUE += $cotePondereeEC;
															
															
															?>
															<td class="colnCours" title="<?php echo $tb_programme_coursSEM['idCours']; ?>">
																<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
																	<div align="left" style="width:90%; height:84%; writing-mode:sideways-lr; margin-bottom:5px; overflow: hidden; ">
																		<?php 
																			echo $tb_programme_coursSEM['designCours'] ;
																		?>
																	</div>
																	<div align="center" style="width:87%; height:8%; background:#c3c3c3; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg); ">
																		<?php echo round($creditEC,0); ?>
																	</div>
																	<div align="center" style="width:85%; height:7%; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg);">  
																		<?php 
																			//$cotePonderee += (20*$creditEC);
																			echo $cote; 
																		?>
																	</div>
																</div>
															</td>
															<?php 
														}

														$cotePondereeSem += $cotePondereeUE;
														$moyenneUE = ($cotePondereeUE/$creditUE);
														
											
														?>
														<td class="colnCours" style="background: #cdcdcd;" title="<?php echo $tb_ue['idUE']; ?>">
															<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
																<div align="left" style="width:90%; height:84%; writing-mode:sideways-lr; margin-bottom:5px; overflow: hidden; ">
																	<?php 
																		echo $tb_ue['designUE'];
																	?>
																</div>
																<div align="center" style="width:87%; height:8%; background:#c3c3c3; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg); ">
																	<?php 
																		//$ponderation=(($tb_programme_coursSEM['ht']+$tb_programme_coursSEM['hp'])/15);
																		echo round($creditUE,0);
																	?>
																</div>
																<div align="center" style="width:85%; height:7%; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg);"> 
																	<?php 
																		
																		echo $moyenneUE ;
																	?>
																</div>
															</div>
														</td>
														<?php 
													}
												}
											}
											$moyenneSem = (int)($cotePondereeSem/$creditSem);

											$creditAnnuel += $creditSem;
											$moyenneAnnuel = ($cotePondereeSem/$creditSem);
											$cotePondereeAnnuel += $cotePondereeSem;
														
											?>
											<td class="colnCours" style="background: #cbf3b3;" title="<?php echo $tb_semestre['designSem']; ?>">
												<div style="width:99%; height:350px; border-right: solid 1px #000000;">
													<div align="left" style="width:90%; height:84%; writing-mode:sideways-lr; margin-bottom:5px; overflow: hidden; ">
														<?php 
															echo "MOYEENNE ".$tb_semestre['designSem'];
														?>
													</div>
													<div align="center" style="width:87%; height:8%; background:#c3c3c3; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg); ">
														<?php 
															echo $creditSem ;
														?>
													</div>
													<div align="center" style="width:85%; height:7%; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg);"> 
														<?php 
															
															echo $moyenneSem ;
														?>
													</div>
												</div>
											</td>
											<?php
										}
									}
								}
							}
							?> 
							<td class="colnCours" style="background: #cbf3b3;" title="TOTAL ANNUEL">
								<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
									<div align="left" style="width:90%; height:84%; writing-mode:sideways-lr; margin-bottom:5px; overflow: hidden; ">
										<?php 
											echo "MOYEENNE ANNUELLE";
										?>
									</div>
									<div align="center" style="width:87%; height:8%; background:#c3c3c3; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg); ">
										<?php 
											//$ponderation=(($tb_programme_coursSEM['ht']+$tb_programme_coursSEM['hp'])/15);
											echo round($creditAnnuel,0);
										?>
									</div>
									<div align="center" style="width:85%; height:7%; padding-left:5px; writing-mode:sideways-lr; transform:rotate(0deg);"> 
										<?php 
											echo $moyenneAnnuel ;
										?>
									</div>
								</div>
							</td>
							
							<td class="cotpp" >
								<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
									<div align="left" style="width:99%; height:82%;padding-bottom:10px;writing-mode:sideways-lr; ">
									Cotes pond&eacute;r&eacute;es 
									</div>
									<div align="center" style="width:100%; height:16%;background:#c3c3c3; writing-mode:sideways-lr; transform:rotate(0deg);">
										<?php 
											echo round($cotePondereeAnnuel, 0);
										?>
									</div>
								</div>
							</td>
							<td class="cotpp">
								<div style="width:99.8%; height:350px; border-right: solid 1px #000000;">
									<div align="left" style="width:99%; height:82%; padding-bottom:10px; writing-mode:sideways-lr;">
									%
									</div>
									<div align="center" style="width:100%; height:16%;background:#c3c3c3; writing-mode:sideways-lr; transform:rotate(0deg);">
										<?php 
											if ($cotePondereeSem!=0) {
												$pourcentage = (($cotePondereeSem*100)/$cotePondereeSem);
												echo round($pourcentage, 1);
											}
										?>
									</div>
								</div>
							</td> 
							
							<td class="colnCours">
								<div align="left" style="width:100%; height:99%; writing-mode:sideways-lr; border-right: solid 1px #000000; ">
									Nombre d'&eacute;checs 
								</div>
							</td>
							<?php  
							if(isset($_GET['sEmT'])){ 
								?>
								<td class="colnCours" >
									<div align="left" id="descision" style=" height:99%; writing-mode:sideways-lr; padding-left:30%;">
											D&eacute;cision du jury
									</div>
								</td>
								<?php  
							}
						}
					?>
					
				</tr>
			</table>
		</td>
	</tr>
				
</table>