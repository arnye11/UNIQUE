<style type="text/css">
	#ligneFocus:hover{
		background: #bed5e0;
	}
	.navigaPreced, .navigaSuiv{
		width:15%;
		display: inline-block;
		font-size: 14px;
		margin: 10px;
		border: solid 1px #9d9d9d;
		background:#c3c3c3 ;
		text-align: center;
		border-radius: 8px;
	}
	.navigaPreced{
		float: left;
	}
	.navigaSuiv{
		float: right;
	}
</style>

<?php 
	$nbrEtudInscrit = 0;
	$Nb_insrit=0;

	$Nbr_reus=0;
	$Nbr_Plus_grde_dist=0;
	$Nbr_grde_dist=0;
	$Nbr_dist=0;
	$Nbr_safti=0;
	$Nbr_aj=0;
	$Nbr_aa=0;
	$Nbr_naf=0;
	$ndelib =0;

	$Nbr_echec_l_c=0;
	$Nbr_echec_p_c=0;
	
	if(isset($_GET['s1']))
		$session=="s1";

	if(isset($_GET['s2']))
		$session=="s2";

	$rqt_EtudInscrit = "SELECT tb_inscription.matricEtud, tb_etudiant.nomEtud, tb_etudiant.postnomEtud, tb_etudiant.prenomEtud, tb_etudiant.sexeEtud FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET["pRomotIon"]."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ";

	if($exe_rqt_EtudInscrit = $conDb->query($rqt_EtudInscrit)){
		//$nbrEtudInscrit = $exe_rqt_EtudInscrit->num_rows ;
		$nbrEtudInscrit=mysqli_num_rows($exe_rqt_EtudInscrit);
		$Nb_insrit = $nbrEtudInscrit ;
		if($nbrEtudInscrit > 0){		 	
			//$Nb_insrit=$exe_rqt_etud_incrit->num_rows;
			if (isset($_GET['imPRessIoN'])) {
				if ($debut <= 10)
					$limite = 12;

				if ($debut > 10)
					$limite = 36;

				$rqt_etud_incrit = "SELECT tb_inscription.matricEtud, tb_etudiant.nomEtud, tb_etudiant.postnomEtud, tb_etudiant.prenomEtud, tb_etudiant.sexeEtud FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET["pRomotIon"]."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud " /*LIMIT ".$debut.",".$limite*/;

			}
			else{
				$rqt_etud_incrit = "SELECT tb_inscription.matricEtud, tb_etudiant.nomEtud, tb_etudiant.postnomEtud, tb_etudiant.prenomEtud, tb_etudiant.sexeEtud FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE (((tb_inscription.idProm)='".$_GET["pRomotIon"]."') AND ((tb_inscription.idOp)='".$_GET['oPtiOn']."') AND ((tb_inscription.idAca)='".$an_aca."')) ORDER BY tb_etudiant.nomEtud LIMIT ".$debut.",".$limite;
			}
			
			if($exe_rqt_etud_incrit = $conDb->query($rqt_etud_incrit)){
				if($exe_rqt_etud_incrit->num_rows>0){		 	
					$Nb_insrit=$exe_rqt_etud_incrit->num_rows;
					//$nbrEtudInscrit = $Nb_insrit;
					?>
					<table  border="1" class="tbgille" >
						<?php 
							$num=$debut;
							while($tb_etud_inscrit = $exe_rqt_etud_incrit->fetch_assoc()) {
								//$Nb_insrit = $Nb_insrit+1;
								$num += 1;
								$MatEtud =$tb_etud_inscrit['matricEtud'];
								$cotePonderee_etud=0;
								$pourcentage=0;
								$Nbr_echec_l_c =0;
								$Nbr_echec_p_c =0;
								
								$etutReussit = false;
								if($session=="s2"){
									if ($_SESSION['systPromo']=="A"){
										$rqt_slct_EtudDelib = "select * from tb_deliberation where matricEtud ='".$MatEtud."' and idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and (mention = 'PGD' or mention = 'GD' or mention = 'D' or mention = 'S') and session != '".$session."'";
									}
									else{
										$rqt_slct_EtudDelib = "select * from tb_deliberation where matricEtud ='".$MatEtud."' and idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and (mention = 'A' or mention = 'B' or mention = 'C' or mention = 'D' or mention = 'E') and session != '".$session."'";
									}
									if($rqt_slct_EtudDelib = $conDb->query($rqt_slct_EtudDelib)){
										if($tb_delibS = $rqt_slct_EtudDelib->fetch_assoc()){
											$etutReussit = true;
										}
									}
								}
								if($etutReussit == false){
									?>
									<tr id="ligneFocus">
										<td style="width:2%;" title="<?php echo $tb_etud_inscrit['matricEtud']; ?>">
											<div align="right" style="" id="<?php echo ($num) ; ?>">
												<?php echo $num ; ?>
											</div>
										</td>

										<td style="width:21%; overflow: hidden;" title="<?php echo $tb_etud_inscrit['matricEtud']; ?>">
											<a href='?profil&id=<?php echo $tb_etud_inscrit['matricEtud']; ?>' style="color: #000000;">
												<div align="left" style="width:98%; height: 100%; padding-left:3px; overflow: hidden;">
													<?php
														echo $tb_etud_inscrit['nomEtud']."&nbsp;".$tb_etud_inscrit['postnomEtud']."&nbsp;".$tb_etud_inscrit['prenomEtud']; 
													?>	
												</div>
											</a>
										</td>
										<td style="width:76%;">
											<table style="width:100%; border-collapse: collapse;" >
												<tr>
												<?php 
													if ($_SESSION['systPromo']=="A"){
														if($exe_rqt_slct_cours = $conDb->query($rqt_slct_cours_Program)){
															if($exe_rqt_slct_cours->num_rows>0){
																while($tb_cours = $exe_rqt_slct_cours->fetch_assoc()) {
																	$rqt_slct_cote_etud = "select * from tb_cote where matricEtud ='".$MatEtud."' and idCours = '".$tb_cours['idCours']."' and idAca = '".$an_aca."'";
																	?>
																	<td class="colnCote" style="" >
																		<?php 
																		//$exe_rqt_slct_cote_etud ="";
																		if($exe_rqt_slct_cote_etud = $conDb->query($rqt_slct_cote_etud)){
																			if($tb_cote = $exe_rqt_slct_cote_etud->fetch_assoc()){
																				$cote1 = $tb_cote['cote_s1'];
																				$cote2 = $tb_cote['cote_s2'];
																				$ponderation = (($tb_cours['ht']+$tb_cours['hp'])/15);
																				if($session == "s2" and $cote2>0){
																					?>
																					<div align="right" title="2ème SESSION" style="background:#FFCCFF; border-right: solid 1px #000000; padding-right: 3px;">
																						<?php 
																							if ($_SESSION['idAnAca'] != $an_aca and $_SESSION['idAutoDec']!="admin1") { 
																								if($cote2<10){
																									if($cote2>7){
																										$Nbr_echec_l_c=$Nbr_echec_l_c+1;
																										$cotePonderee_etud=(($cote2*$ponderation)+$cotePonderee_etud);
																										echo "<span style='color:#FF00FF'>".$cote2."</span>"; 
																									}
																									else{
																										$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																										$cotePonderee_etud=(($cote2*$ponderation)+$cotePonderee_etud);
																										echo "<span style='color:#FF0000'>".$cote2."</span>";
																									}
																								}
																								else{
																									//$Nbr_reus = $Nbr_reus+1;
																									$cotePonderee_etud=(($cote2*$ponderation)+$cotePonderee_etud);
																									echo "<span style='color:#000000'>".$cote2."</span>";
																								} 
																							}
																							else{
																								?>
																								<a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $tb_cours['idCours']; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud'].'&'.$session ; ?>&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>">
																									<?php 
																										if($cote2<10){
																											if($cote2>7){
																												$Nbr_echec_l_c=$Nbr_echec_l_c+1;
																												$cotePonderee_etud=(($cote2*$ponderation)+$cotePonderee_etud);
																												echo "<span style='color:#FF00FF'>".$cote2."</span>"; 
																											}
																											else{
																												$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																												$cotePonderee_etud=(($cote2*$ponderation)+$cotePonderee_etud);
																												echo "<span style='color:#FF0000'>".$cote2."</span>";
																											}
																										}
																										else{
																											//$Nbr_reus = $Nbr_reus+1;
																											$cotePonderee_etud=(($cote2*$ponderation)+$cotePonderee_etud);
																											echo "<span style='color:#000000'>".$cote2."</span>";
																										} 
																									?>
																								</a>
																								<?php 
																							}
																						?>
																					</div>
																				
																					<?php
																				}
																				else{ 
																					?>
																					<div align="right" style="border-right: solid 1px #000000;padding-right: 3px;">
																						<?php 
																							if ($_SESSION['idAnAca'] != $an_aca and $_SESSION['idAutoDec']!="admin1") { 
																								if($cote1<10){
																									if($cote1>7){
																										$Nbr_echec_l_c=$Nbr_echec_l_c+1;
																										$cotePonderee_etud=(($cote1*$ponderation)+$cotePonderee_etud);
																										echo "<span style='color:#FF00FF'>".$cote1."</span>"; 
																									}
																									else{
																										$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																										$cotePonderee_etud=(($cote1*$ponderation)+$cotePonderee_etud);
																										echo "<span style='color:#FF0000'>".$cote1."</span>";
																									}
																								}
																								else{
																									//$Nbr_reus = $Nbr_reus+1;
																									$cotePonderee_etud=(($cote1*$ponderation)+$cotePonderee_etud);
																									echo "<span style='color:#000000'>".$cote1."</span>";
																								} 
																							}
																							else{
																								?>
																								<a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $tb_cours['idCours']; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud'].'&'.$session; ?>&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>">
																									<?php 
																										if($cote1<10){
																											if($cote1>7){
																												$Nbr_echec_l_c=$Nbr_echec_l_c+1;
																												$cotePonderee_etud=(($cote1*$ponderation)+$cotePonderee_etud);
																												echo "<span style='color:#FF00FF'>".$cote1."</span>"; 
																											}
																											else{
																												$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																												$cotePonderee_etud=(($cote1*$ponderation)+$cotePonderee_etud);
																												echo "<span style='color:#FF0000'>".$cote1."</span>";
																											}
																										}
																										else{
																											//$Nbr_reus = $Nbr_reus+1;
																											$cotePonderee_etud=(($cote1*$ponderation)+$cotePonderee_etud);
																											echo "<span style='color:#000000'>".$cote1."</span>";
																										} 
																									?>
																								</a>
																								<?php
																							} 
																						?>
																					</div>
																				
																					<?php
																				}
																			}
																			else{
																				$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																				?>
																			
																				<div align="right" style="background:#fde7fe;border-right: solid 1px #000000;padding-right: 3px;">
																					<a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $tb_cours['idCours']; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud'].'&'.$session; ?>&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>">
																						<?php echo "-";?>
																					</a>
																				</div>
																			
																			<?php 
																			}
																		}
																		else{
																			?>
																			
																			<div align="right" style="background:#FF0000; color:#FFFFFF; border-right: solid 1px #000000;padding-right: 3px;">
																				<?php echo "x";?>
																			</div>
																		
																			<?php 
																		}
																		?>
																	</td>
																	<?php 
																}
															}
															else{ 
																?>
																<td colspan="<?php echo $exe_rqt_slct_cours->num_rows ;?>">
																	<?php echo "<span class='echec'>erreur</span>";?>
																</td>
																<?php
															}
															?>
															<td class="colnCoteP">
																<div align="right" style="width:90%;background:#c3c3c3;padding-right: 3px; ">
																	<?php 
																		//if(($idPromo =="G3") || ($idPromo=="L2")){$pourcentage = (($cotePonderee_etud*70)/$cotePonderee);}
																		//else{$pourcentage = (($cotePonderee_etud*100)/$cotePonderee);}
																		
																		echo round($cotePonderee_etud, 0); 
																	?>
																</div>
															</td>
															<td class="colnCoteP" style="background:#c3c3c3; " >
																<div align="right" style="width:90%; padding-right: 3px; ">
																	<?php 
																		if ($cotePonderee>0){
																			$pourcentage = (($cotePonderee_etud*100)/$cotePonderee);
																			echo round($pourcentage, 1);
																		}
																		//$pourcentage = (($cotePonderee_etud*100)/$cotePonderee);
																		//echo round($pourcentage, 1);
																		//if($pourcentage>49){$Nbr_reus = $Nbr_reus+1;}
																		

																		 
																	?>
																</div>
															</td>
															<?php
																/* 
																if(($idPromo =="G3") || ($idPromo=="L2")){?> 
																	<td style="width:4%;" >
																		<div align="center" style="width:99%;">
																			<?php 
																			$travail = 0;
																			if($idPromo =="G3"){$cours = "TFC";}
																			if($idPromo =="L2"){$cours = "M";}
																			$rqt_slct_cote_Trav = "select * from cote where matricEtud ='".$tb_etud_inscrit['matricEtud']."' and idCours = '".$cours."' and idAca = '".$an_aca."'";
																			if($ex_rqt_slct_cote_Trav = mysql_query($rqt_slct_cote_Trav)){
																				if($result_ex_rqt_slct_cote_Trav = mysql_fetch_assoc($ex_rqt_slct_cote_Trav)){
																					$travail = $result_ex_rqt_slct_cote_Trav['cote_s1'];
																					if($travail<5){
																						if($travail>3){
																							$Nbr_echec_l_c=$Nbr_echec_l_c+1;
																							echo "<span style='color:#FF00FF'>".$travail."</span>"; 
																						}
																						else{
																							$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																							echo "<span style='color:#FF0000'>".$travail."</span>";
																						}	
																					}
																					else{
																						echo $travail;
																					}
																				}
																				else{
																					$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																					?>
																					<a href="?gerer_cote&fIcHeScoTe&idPromo=<?php echo $idPromo; ?>&idOp=<?php echo $idOp ;?>&cours=<?php if($idPromo=="G3"){echo "TFC";}if($idPromo=="L2"){echo "M";} ?>" style="height:auto;">
																					<?php echo "-";?>
																					</a>
																					<?php 
																				}
																			}
																			else{
																				echo "x";
																			}
																			?>
																		</div>
																	</td>
																	<td style="width:4%;" >
																		<div align="center" style="width:99%;">
																			<?php 
																			$stag = 0;
																			$rqt_slct_cote_Trav = "select * from cote where matricEtud ='".$tb_etud_inscrit['matricEtud']."' and idCours = 'STG' and idAca = '".$an_aca."'";
																			if($ex_rqt_slct_cote_Trav = mysql_query($rqt_slct_cote_Trav)){
																				if($result_ex_rqt_slct_cote_Trav = mysql_fetch_assoc($ex_rqt_slct_cote_Trav)){
																					$stag = $result_ex_rqt_slct_cote_Trav['cote_s1'];
																					if($stag<10){
																						if($stag>7){
																							$Nbr_echec_l_c=$Nbr_echec_l_c+1;
																							echo "<span style='color:#FF00FF'>".$stag."</span>"; 
																						}
																						else{
																							$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																							echo "<span style='color:#FF0000'>".$stag."</span>";
																						}	
																					}
																					else{
																						echo $stag;
																					}
																				}
																				else{
																					$Nbr_echec_p_c=$Nbr_echec_p_c+1;
																					?>
																					<a href="?gerer_cote&fIcHeScoTe&idPromo=<?php echo $idPromo; ?>&idOp=<?php echo $idOp ;?>&cours=STG" style="height:auto;">
																					<?php echo "-";?>
																					</a>
																					<?php 
																				}
																			}
																			else{
																				echo "x";
																			}
																			?>
																		</div>
																	</td>
																	<td style="width:4%;" >
																		<div align="right" style="width:99%;">
																			<?php 
																			$pourcentage = $pourcentage+$travail+$stag;
																			echo $pourcentaoge;
																			//include("B_mbidndi/pue/grille/creationPV.php");
																			?>
																		</div>
																	</td>
																	<?php 
																}
																*/
															?>
															<td class="colnCote">
																<div align="center" style="width:99%; border-right: solid 1px #000000; padding-right: 3px;">
																	<?php echo $Nbr_echec_l_c + $Nbr_echec_p_c; ?>
																</div>
															</td>
															<td class="colnCote" >
																<div align="left" id="descision" style="padding-left: 3px;">
																<?php 
																	include("B_mbindi/pue/grille/rqt_deliberation.php");
																	$mention="";
																	$mentions = array("PGD", "GD", "D", "S", "A", "AA", "NAF");

																	
																	$rqt_slct_delb = "select * from tb_deliberation where matricEtud ='".$MatEtud."' and idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
																	if($exe_rqt_slct_del = $conDb->query($rqt_slct_delb)){
																		if($tb_delib = $exe_rqt_slct_del->fetch_assoc()){
																			$mention=$tb_delib ["mention"];
																			if(isset($_GET["mOdifdElib"]) and $_GET["mOdifdElib"]==$MatEtud){
																				foreach($mentions as $mention){
																					?>
																					<a href="<?php echo '?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib&'.$session.'&delib='.$tb_etud_inscrit['matricEtud'].'&mention='.$mention.'&suivant='.$debut.'&aca='.$an_aca.'#'.$tb_etud_inscrit['matricEtud']; ?>"> <?php echo $mention ;?> </a>
																					&nbsp;
																					<?php 
																				}
																			}
																			else{
																				?>
																				<div style="width:25px; float:left;">
																					<?php echo $tb_delib ["mention"]; ?>
																				</div>
																				<div style="width:25px; float:right;<?php if(isset($_GET["imPRessIoN"])){ ?> display: none; <?php } ?>">
																					<a href="<?php echo '?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib&'.$session.'&mOdifdElib='.$tb_etud_inscrit['matricEtud'].'&suivant='.$debut.'&aca='.$an_aca; ?>"> <img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" /> </a>&nbsp;
																				</div>
																				<?php 
																			}
																			
																		}
																		else{
																			if(!isset($_GET["imPRessIoN"])){ 
																				$ndelib=$ndelib+1;
																				foreach($mentions as $mention){
																					?>
																					<a href="<?php echo '?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib&'.$session.'&delib='.$tb_etud_inscrit['matricEtud'].'&mention='.$mention.'&suivant='.$debut.'&aca='.$an_aca ; ?>"> <?php echo $mention ;?> </a>
																					&nbsp;
																					<?php 
																				}
																			}
																		}
																	}
																	else{
																		echo " Erreurde mention <img src='B_mbindi/pue/grille/warning.ico' class='icon'/>";
																	}
																	if(isset($_GET["delib"]) and isset($_GET["mention"])){
																		if($_GET["delib"]==$MatEtud){
																			echo $smsDelib ;
																		}
																	}

																	if($mention == "PGD"){
																		//echo $mention = "PGD"; 
																		$Nbr_Plus_grde_dist =$Nbr_Plus_grde_dist+1; 
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "GD"){
																		//echo $mention ="GD"; 
																		$Nbr_grde_dist =$Nbr_grde_dist+1; 
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "D"){
																		//echo $mention ="D"; 
																		$Nbr_dist =$Nbr_dist+1;
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "S"){
																		//echo $mention ="S"; 
																		$Nbr_safti =$Nbr_safti+1; 
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "A"){
																		//echo $mention ="A"; 
																		$Nbr_aj = $Nbr_aj+1;
																	} 
																	if($mention == "AA"){
																		//echo $mention ="A"; 
																		$Nbr_aa = $Nbr_aa+1;
																	} 
																	if($mention == "NAF"){
																		//echo $mention ="A"; 
																		$Nbr_naf = $Nbr_naf+1;
																	} 

																?>
																</div>
															</td>
															

															<?php
														} 
														else{
															?>
															<tr>
																<td class="colnCote" >
																	<div align="left" style="width:99%;">
																		<?php echo "<span class='echec'>cx</span>"; ?>
																	</div>
																</td>
															</tr>
															<?php
														}
													}

													if ($_SESSION['systPromo']=="N"){

														if(isset($_GET['sEm1'])){
															$rqt_slct_Sem = "SELECT * FROM  tb_semestre WHERE idSem = 'SEM1'"; 
														}
														if(isset($_GET['sEm2'])){
															$rqt_slct_Sem = "SELECT * FROM  tb_semestre WHERE idSem = 'SEM2'"; 
														}
														if(isset($_GET['sEmT'])){
															$rqt_slct_Sem = "SELECT * FROM  tb_semestre ORDER BY idSem "; 
														}
														

														if($exe_rqt_slct_Sem = $conDb->query($rqt_slct_Sem)){
															$htAnnuel=0;
															$hdAnnuel=0;
															$hpAnnuel=0;
															$htotAnnuel=0;
															$creditAnnuel=0;
															$cotePondereeAnnuel = 0;
															$cotePonderee_etudAnnuel=0;
															$moyenneAnnuel = 0 ;
															$moyenneEtudAnnuel=0;

															while($tb_semestre = $exe_rqt_slct_Sem->fetch_assoc()) {
																$rqt_slct_ue = "SELECT * FROM  tb_ue WHERE idSem = '".$tb_semestre["idSem"]."' AND idPromo ='".$idPromo."' AND idOp ='".$idOp."' ORDER BY designUE "; 
																if($exe_rqt_slct_ue = $conDb->query($rqt_slct_ue)){
																	if($exe_rqt_slct_ue->num_rows>0){
																		$numUE=1;
																		$htSem=0;
																		$hdSem=0;
																		$hpSem=0;
																		$htotSem=0;
																		$creditSem=0;
																		$cotePondereeSem = 0;
																		$cotePonderee_etudSem = 0;
																		$moyenneSem = 0 ;
																		$moyenneEtudSem=0;

																		$ue_ec = false;
																		while ($tb_ue = $exe_rqt_slct_ue->fetch_assoc()) {
																			$htUE = 0;
																			$hdUE = 0;
																			$hpUE = 0;
																			$htotUE = 0;
																			$creditUE = 0;
																			$cotePondereeUE = 0;
																			$cotePonderee_etudUE=0;
																			$moyenneUE = 0 ;
																			$moyenneEtudUE=0;

																			$nbrEC = 0 ;

																			$rqt_slct_cours_ProgramSEM = "
																			SELECT tb_program_cours.*, tb_cours.* 
																			FROM tb_cours 
																			RIGHT JOIN tb_program_cours 
																			ON tb_cours.idCours = tb_program_cours.idCours 
																			WHERE (((tb_program_cours.idPromo)='".$idPromo."') AND ((tb_program_cours.idOp)='".$idOp."') AND ((tb_program_cours.idAnAca)='".$an_aca."') AND ((tb_cours.idUE)='".$tb_ue["idUE"]."')) ORDER BY tb_cours.designCours";
																			if($exe_rqt_slct_cours_ProgramSEM = $conDb->query($rqt_slct_cours_ProgramSEM)){
																				$nbrEC = $exe_rqt_slct_cours_ProgramSEM->num_rows;
																				if($nbrEC>0){
																					while($tb_programme_coursSEM = $exe_rqt_slct_cours_ProgramSEM->fetch_assoc()){ 
																						$htEC = $tb_programme_coursSEM["ht"];
																						$hdEC = $tb_programme_coursSEM["hd"];
																						$hpEC = $tb_programme_coursSEM["hp"];
																						$htotEC   = ($htEC + $hdEC + $hpEC);
																						$creditEC = (int)($htotEC/$heureCredit);
																						$cotePondereeEC = (20*$creditEC);
																						$moyenneEC = (int)($cotePondereeEC/$creditEC);
																						
																						$htUE += $htEC ;
																						$hdUE += $hdEC ;
																						$hpUE += $hpEC ;
																						$htotUE  += $htotEC ;
																						$creditUE += $creditEC ;
																						$creditSem += $creditEC ;
																						$cotePondereeUE += $cotePondereeEC;

																						?>
																						<td class="colnCote" style="" >
																							<?php 
																								$rqt_slct_cote_etud = "select * from tb_cote where matricEtud ='".$MatEtud."' and idCours = '".$tb_programme_coursSEM['idCours']."' and idAca = '".$an_aca."'";
																								//$exe_rqt_slct_cote_etud ="";
																								//$cotePonderee_etudEC = 0;
																								if($exe_rqt_slct_cote_etud = $conDb->query($rqt_slct_cote_etud)){
																									if ($exe_rqt_slct_cote_etud->num_rows>0) {
																										if($tb_cote = $exe_rqt_slct_cote_etud->fetch_assoc()){
																											$cote1 = $tb_cote['cote_s1'];
																											$cote2 = $tb_cote['cote_s2'];
																											//$ponderation = (($tb_programme_coursSEM['ht']+$tb_programme_coursSEM['hp'])/15);
																											if($session == "s2" and $cote2>0){
																												$cotePonderee_etudEC =(($cote2*$creditEC));
																												$cotePonderee_etudUE+=$cotePonderee_etudEC;
																												?>
																												<div align="right" title="2ème SESSION" style="background:#FFCCFF; border-right: solid 1px #000000; padding-right: 3px;">
																													<?php 
																														if ($_SESSION['idAnAca'] != $an_aca) { 
																															if($cote2<10){
																																if($cote2>7){
																																	$Nbr_echec_l_c+=1;
																																	
																																	echo "<span style='color:#FF00FF'>".$cote2."</span>"; 
																																}
																																else{
																																	$Nbr_echec_p_c += 1;
																																	echo "<span style='color:#FF0000'>".$cote2."</span>";
																																}
																															}
																															else{
																																echo "<span style='color:#000000'>".$cote2."</span>";
																															} 
																														}
																														else{
																															?>
																															<a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $tb_programme_coursSEM['idCours']; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud'].'&'.$session ; ?>&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>">
																																<?php 
																																	if($cote2<10){
																																		if($cote2>7){
																																			$Nbr_echec_l_c+=1;
																																			echo "<span style='color:#FF00FF'>".$cote2."</span>"; 
																																		}
																																		else{
																																			$Nbr_echec_p_c+=1;
																																			echo "<span style='color:#FF0000'>".$cote2."</span>";
																																		}
																																	}
																																	else{
																																		echo "<span style='color:#000000'>".$cote2."</span>";
																																	} 
																																?>
																															</a>
																															<?php 
																														}
																													?>
																												</div>
																												<?php
																											}
																											else{
																												$cotePonderee_etudEC =(($cote1*$creditEC));
																												$cotePonderee_etudUE+=$cotePonderee_etudEC;
																												?>
																												<div align="right" style="border-right: solid 1px #000000;padding-right: 3px;">
																													<?php 
																														if ($_SESSION['idAnAca'] != $an_aca) { 
																															if($cote1<10){
																																if($cote1>7){
																																	$Nbr_echec_l_c+=1;
																																	echo "<span style='color:#FF00FF'>".$cote1."</span>"; 
																																}
																																else{
																																	$Nbr_echec_p_c+=1;
																																	echo "<span style='color:#FF0000'>".$cote1."</span>";
																																}
																															}
																															else{
																																echo "<span style='color:#000000'>".$cote1."</span>";
																															} 
																														}
																														else{
																															?>
																															<a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $tb_programme_coursSEM['idCours']; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud'].'&'.$session; ?>&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>">
																																<?php 
																																	if($cote1<10){
																																		if($cote1>7){
																																			$Nbr_echec_l_c+=1;
																																			echo "<span style='color:#FF00FF'>".$cote1."</span>"; 
																																		}
																																		else{
																																			$Nbr_echec_p_c+=1;
																																			echo "<span style='color:#FF0000'>".$cote1."</span>";
																																		}
																																	}
																																	else{
																																		echo "<span style='color:#000000'>".$cote1."</span>";
																																	} 
																																?>
																															</a>
																															<?php
																														} 
																													?>
																												</div>
																											
																												<?php
																											}
																										}
																									}
																									else{
																										$Nbr_echec_p_c+=1;
																										?>
																										<div align="right" style="background:#fde7fe;border-right: solid 1px #000000;padding-right: 3px;">
																											<a href="?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&fIcHe&iDcOurs=<?php echo $tb_programme_coursSEM['idCours']; ?>&cote_etud=<?php echo $tb_etud_inscrit['matricEtud'].'&'.$session; ?>&aca=<?php echo $an_aca;?>#<?php echo $tb_etud_inscrit['matricEtud']; ?>">
																												<?php echo "-";?>
																											</a>
																										</div>
																										<?php 
																									}
																								}
																								else{
																									?>
																									<div align="right" style="background:#FF0000; color:#FFFFFF; border-right: solid 1px #000000;padding-right: 3px;">
																										<?php echo "x";?>
																									</div>
																									<?php 
																								}
																							?>
																						</td>
																						<?php 
																					}
																					$cotePondereeSem += $cotePondereeUE;
																					$moyenneUE =round(($cotePondereeUE/$creditUE),0);
																					
																					$cotePonderee_etudSem += $cotePonderee_etudUE;
																					$moyenneEtudUE=round(($cotePonderee_etudUE/$creditUE),0);
																					?>
																					<td class="colnCote" style="background: #cdcdcd;" title="<?php echo $tb_ue['idUE']; ?>">
																						<div>
																							<?php echo $moyenneEtudUE ; ?>
																						</div>
																					</td>
																					<?php
																				}
																			} 
																		}
																		$moyenneEtudSem=(int)($cotePonderee_etudSem/$creditSem);
																		
																		$cotePondereeAnnuel += $cotePondereeSem;
																		$cotePonderee_etudAnnuel += $cotePonderee_etudSem;
																		$creditAnnuel += $creditSem;
																		$moyenneAnnuel = (int)($cotePondereeSem/$creditSem);
																		$moyenneEtudAnnuel=(int)($cotePonderee_etudAnnuel/$creditAnnuel);

																		?>
																		<td class="colnCote" style="background: #cbf3b3;" title="<?php echo $tb_semestre['designSem']; ?>">
																			<div align="right"> 
																				<?php 
																					
																					echo $moyenneEtudSem ;
																				?>
																			</div>
																		</td>
																		<?php
																	}
																}
															}
														}
														
														?>
														<td class="colnCote" style="background: #cbf3b3;" title="TOTALE MOYENNE ANNUELLE">
															<div align="right"> 
																<?php echo $moyenneEtudAnnuel ; ?>
															</div>
														</td>
														<td class="colnCoteP" title="TOTAL PONDERE ANNUEL">
															<div align="right" style="width:90%;background:#c3c3c3;padding-right: 3px; ">
																<?php echo $cotePonderee_etudAnnuel;  ?>
															</div>
														</td>
														<td class="colnCoteP" style="background:#c3c3c3; "  title=" % ANNUEL">
															<div align="right" style="width:90%; padding-right: 3px; ">
																<?php 
																	$pourcentage = (($cotePonderee_etudAnnuel*100)/$cotePondereeAnnuel);
																	echo round($pourcentage, 1);
																?>
															</div>
														</td>
														
														<td class="colnCote" title="TOTAL CREDIT ANNUEL">
															<div align="center" style="width:99%; border-right: solid 1px #000000; padding-right: 3px;">
																<?php echo $Nbr_echec_l_c + $Nbr_echec_p_c; ?>
															</div>
														</td>
														<?php 
														if(isset($_GET['sEmT'])){ 
															$sEm = "sEmT";
															?>
															<td class="colnCote" >
																<div id="descision" align="left" id="descision" style="padding-left: 3px;">
																<?php 
																	include("B_mbindi/pue/grille/rqt_deliberation.php");
																	$mention="";
																	$mentions = array("A", "B", "C", "D", "E", "F", "G");
																	$TbGradeCECT = array("Excellant", "Tr&egrave;s bien", "Bien", "Assez bien", "Passable", "Insuffisant", "Insatisfaisant");
																	
																	
																	$rqt_slct_delb = "select * from tb_deliberation where matricEtud ='".$MatEtud."' and idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
																	if($exe_rqt_slct_del = $conDb->query($rqt_slct_delb)){
																		if($tb_delib = $exe_rqt_slct_del->fetch_assoc()){
																			$mention=$tb_delib ["mention"];
																			if(isset($_GET["mOdifdElib"]) and $_GET["mOdifdElib"]==$MatEtud){
																				$i=0;
																				foreach($mentions as $mention){
																					?>
																					<a href="<?php echo '?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib&'.$session.'&'.$sEm.'&delib='.$tb_etud_inscrit['matricEtud'].'&mention='.$mention.'&suivant='.$debut.'&aca='.$an_aca.'#'.$tb_etud_inscrit['matricEtud'].'&'.$sEm.'#g' ; ?>" title="<?php echo $TbGradeCECT[$i]; ?>"><?php echo $mention ;?> </a>
																					&nbsp;&nbsp;&nbsp;
																					<?php 
																					$i++;
																				}
																			}
																			else{
																				?>
																				<div style=" float:left;">
																					<?php echo $tb_delib ["mention"]; ?>
																				</div>
																				<div style="float:right;<?php if(isset($_GET["imPRessIoN"])){ ?> display: none; <?php } ?>">
																					<a href="<?php echo '?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib&'.$session.'&mOdifdElib='.$tb_etud_inscrit['matricEtud'].'&mention='.$mention.'&suivant='.$debut.'&aca='.$an_aca.'&'.$sEm.'#g'; ?>"> <img src="B_mbindi/Biamunda/icon/edit.gif" class="icon" align="left" alt="Modif." title="Modifier" /> </a>&nbsp;
																				</div>
																				<?php 
																			}									
																		}
																		else{
																			if(!isset($_GET["imPRessIoN"])){ 
																				$ndelib=$ndelib+1;
																				$i=0;
																				foreach($mentions as $mention){
																					?>
																					<b style="font-size:11px;">
																						<a href="<?php echo '?fAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib&'.$session.'&delib='.$tb_etud_inscrit['matricEtud'].'&mention='.$mention.'&suivant='.$debut.'&aca='.$an_aca.'&'.$sEm.'#g' ; ?>" title="<?php echo $TbGradeCECT[$i]; ?>"> <?php echo $mention ;?> </a>
																					</b>
																					&nbsp;&nbsp;&nbsp;
																					<?php 
																					$i++;
																				}
																			}
																		}
																	}
																	else{
																		echo " Erreur de mention <img src='B_mbindi/pue/grille/warning.ico' class='icon'/>";
																	}
																	if(isset($_GET["delib"]) and isset($_GET["mention"])){
																		if($_GET["delib"]==$MatEtud){
																			echo $smsDelib ;
																		}
																	}

																	if($mention == "A"){
																		//echo $mention = "PGD"; 
																		$Nbr_Plus_grde_dist =$Nbr_Plus_grde_dist+1; 
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "B"){
																		//echo $mention ="GD"; 
																		$Nbr_grde_dist =$Nbr_grde_dist+1; 
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "C"){
																		//echo $mention ="D"; 
																		$Nbr_dist =$Nbr_dist+1;
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "D"){
																		//echo $mention ="S"; 
																		$Nbr_safti =$Nbr_safti+1; 
																		$Nbr_reus = $Nbr_reus+1;
																	} 
																	if($mention == "E"){
																		//echo $mention ="A"; 
																		$Nbr_aj = $Nbr_aj+1;
																	} 
																	if($mention == "F"){
																		//echo $mention ="A"; 
																		$Nbr_aa = $Nbr_aa+1;
																	} 
																	if($mention == "G"){
																		//echo $mention ="A"; 
																		$Nbr_naf = $Nbr_naf+1;
																	} 

																?>
																</div>
															</td>
															<?php
														}
													}
												?>
												</tr>
											</table>
										</td>
									</tr>			
									<?php
								}	
							}
						?>
					</table>
					<?php 						
						if (isset($_GET["s2"])) 
							$session = "s2";
						else
							$session = "s1";

						if (isset($_GET["sEmT"])) 
							$sEm = "sEmT";
						else if (isset($_GET["sEm2"])) 
							$sEm = "sEm2";
						if (isset($_GET["sEm1"])) 
							$sEm = "sEm1";
					?>
					<div style="width:100%; height:50px;" align="center">
						<?php 
							if ($debut>0) { ?>
								<div class="navigaPreced" style="width: 70px;">	
									<a href="?fAculTe&iDfaC=<?php echo  $_GET['iDfaC']; ?>&pRomotIon=<?php echo  $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&gRillDelib&<?php echo $session; ?>&<?php echo $sEm; ?>&suivant=0&aca=<?php echo $an_aca; if (isset($_GET['imPRessIoN'])) {echo "&imPRessIoN"; } ?>#<?php echo ($debut-$limite+1); ?>" style="color: #ffffff;">
										<div style="color:black;"  > 
											|< <b>D&eacute;but</b> 
										</div>
									</a>
								</div>
								<div class="navigaPreced" style="">	
									<a href="?fAculTe&iDfaC=<?php echo  $_GET['iDfaC']; ?>&pRomotIon=<?php echo  $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&gRillDelib&<?php echo $session; ?>&<?php echo $sEm; ?>&suivant=<?php if(($debut-$limite)<0){ echo 0;} else{echo ($debut-$limite);} ?>&aca=<?php echo $an_aca; if (isset($_GET['imPRessIoN'])) {echo "&imPRessIoN"; } ?>#<?php if(($debut-$limite+1)<0){ echo 0;} else{echo ($debut-$limite+1);} ?>" style="color: #ffffff;">
										<div style="color:black;"  > 
											<< <b>Pr&eacute;c&eacute;dant</b> <?php echo  "(".$debut.")" ; ?> 
										</div>
									</a>
								</div>
								<?php 
							}
							?>
							<div style="text-align:center;letter-spacing:6px; margin-top:15px; display: inline-block;">
								<?php 
									if(isset($_GET["imPRessIoN"]))
										$limite=$nbrEtudInscrit;

									if(($debut+$limite<=$nbrEtudInscrit)){
										echo ($debut+$limite);
									}
									else{
										echo $nbrEtudInscrit;
									}
									echo "/";
									echo $nbrEtudInscrit ; 
								?>
							</div>
							<?php 
							if (($debut+$limite)<$nbrEtudInscrit) {
								?>

								<div class="navigaSuiv" style="width: 70px; float: right;">	
									<a href="?fAculTe&iDfaC=<?php echo  $_GET['iDfaC']; ?>&pRomotIon=<?php echo  $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&gRillDelib&<?php echo $session; ?>&<?php echo $sEm; ?>&suivant=<?php echo ($nbrEtudInscrit-10) ; ?>&aca=<?php echo $an_aca; if (isset($_GET['imPRessIoN'])) {echo "&imPRessIoN"; } ?>#<?php echo ($debut+$limite+1); ?>" style="color: #ffffff;">
										<div style="color:black;"><b>Fin</b>  >| </div>
									</a>
								</div>
								<div class="navigaSuiv" style="">	
									<a href="?fAculTe&iDfaC=<?php echo  $_GET['iDfaC']; ?>&pRomotIon=<?php echo  $_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&gRillDelib&<?php echo $session; ?>&<?php echo $sEm; ?>&suivant=<?php echo $debut+$limite ; ?>&aca=<?php echo $an_aca; if (isset($_GET['imPRessIoN'])) {echo "&imPRessIoN"; } ?>#<?php echo ($debut+$limite+1); ?>" style="color: #ffffff;">
										<div style="color:black;"><?php echo  "(".($nbrEtudInscrit-($debut+$limite)).") " ; ?><b>Suivant</b>  >> </div>
									</a>
								</div>
								<?php 
							}	
						?>
					</div>
					<?php 
						if ((($debut+$limite)>=$nbrEtudInscrit)||isset($_GET["imPRessIoN"])) {
							?>
							<div align="left" style="width:99%; border:solid 1px #000000; background:#666666; color:#FFFFFF; margin-top:1%; font-style:italic; font-size:12px;">
								Nombre inscrits : &nbsp;<?php echo $Nb_insrit; ?>.&nbsp;&nbsp;&nbsp;
								Nombre de reussites : &nbsp;<?php echo $Nbr_reus; ?>.&nbsp;&nbsp;&nbsp;
								Plus grande distinction : &nbsp;<?php echo $Nbr_Plus_grde_dist; ?>.&nbsp;&nbsp;&nbsp;
								Grande distinction : &nbsp;<?php echo $Nbr_grde_dist;?>.&nbsp;&nbsp;&nbsp;
								Gistinction : &nbsp;<?php echo $Nbr_dist; ?>.&nbsp;&nbsp;&nbsp;
								Safistaction : &nbsp;<?php echo $Nbr_safti; ?>.&nbsp;&nbsp;&nbsp;
								Ajourn&eacute;s : &nbsp;<?php echo $Nbr_aj;?>.&nbsp;
								Assimul&eacute;s aux Ajourn&eacute;s : &nbsp;<?php echo $Nbr_aa;?>.&nbsp;
								Non Admits &agrave; la fili&egrave;re : &nbsp;<?php echo $Nbr_naf;?>.&nbsp;
							</div>
							<div align="right" style="width: 100%; height:auto; padding-right:5%;">
								<p>Fait &agrave; <?php echo $_SESSION['villeEts']; ?>, le <?php echo $jour."/".$moi."/".$annee_encours; ?></p>
							</div>
							<div align="left" style="width:97%;height:210px; border:solid 1px #666666; padding-left:2%;">
								<div style="width:90%;height:150px;  margin-top:2%;">
									<div style="width:25%;  display:inline; float:left; ">
										Pr&eacute;sident du Jury
									</div>
									<div style="width:30%;  display:inline; float:left; ">
										Secr&eacute;taire du Jury
									</div>
									<div style="width:38%; height: auto;  display:inline; float:left; ">
										Membres du jury 
									</div>
								</div>
								
							</div>
							<?php 
						} 
					?>
					<div style="width: 100%; height:auto;position:relative; top:auto; bottom:0%; font-size:12px; color:#000000; <?php if($session == "s2"){?>background:#CC0099;<?php } else{  ?>background:#D0D0D0;<?php }?> ;">
						<b>UNIQUE</b> (Univ&eacute;rsit&eacute; unim&eacute;rique). Tout droit r&eacute;serv&eacute; au <b>CRTN</b> ( <i>Centre des Recherches et des Transformations Num&eacute;riques - arnye</i>).
					</div>
					
					<?php 
				}
				else{
					echo "<div align='center' style='background:#FFFFFF;' class='echec'><h2 >Impossible de retrouver les étudiants inscrits en ".$idPromo."&nbsp;".$designOp."cette année académique.</h2><span>".$an_aca."</span><br/><br/></div>";
				}
			}
			else{
				echo "<div align='center' style='background:#FFFFFF;' class='echec'><h2 >Aucu étudiant n'est inscrit en ".$idPromo."&nbsp;".$designOp." &nbsp; cette année académique.</h2><span>".$an_aca."</span><br/><br/></div>";
			}
		}
	}
?>