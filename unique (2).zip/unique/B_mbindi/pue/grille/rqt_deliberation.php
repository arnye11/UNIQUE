<?php 
	$smsDelib="";
	if ($_SESSION['systPromo']=="N"){
		$pourcentage=$moyenneEtudAnnuel ;
	}
	if(isset($_GET["delib"]) and isset($_GET["mention"])){
		if($_GET["delib"]==$MatEtud){
			$mention=$_GET["mention"];
			if(isset($_GET['s1'])){
				$session = "s1";	
			}
			else{
				$session = "s2";
			}
			$rqt_slct_delb = "select * from tb_deliberation where matricEtud ='".$_GET["delib"]."' and idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
			if($exe_rqt_slct_del = $conDb->query($rqt_slct_delb)){
				if($exe_rqt_slct_del->num_rows>0){
					$tb_delib = $exe_rqt_slct_del->fetch_assoc();
					$rqt_updt_del = "update tb_deliberation set prctg = '".$pourcentage."', mention = '".$_GET["mention"]."', datedel = NOW() where idDel ='".$tb_delib["idDel"]."'";
					if($ex_rqt_update_del=$conDb->query($rqt_updt_del)){
						$smsDelib = "&nbsp; <img src='B_mbindi/pue/grille/tick.ico' class='icon'/>";
					}
					else{
						$smsDelib = "&nbsp; <img src='B_mbindi/pue/grille/plus.ico' class='icon' /> Erreur de mise a jours ";
					} 
				}
				else{
					$rqt_insrt_del="insert into tb_deliberation values(NULL, '".$MatEtud."', '".$idPromo."', '".$idOp."', '".$an_aca."', '".$pourcentage."', '".$mention."', '".$session."', NOW(), '".$_SESSION['idAutoDec']."')";
					if($ex_rqt_insrt_del=$conDb->query($rqt_insrt_del)){
						$smsDelib ="&nbsp; <img src='B_mbindi/pue/grille/tick.ico' class='icon' />";
					}
					else{
						$smsDelib = "&nbsp; <img src='B_mbindi/pue/grille/warning.ico'  class='icon' /> Impossible de deliberer ";
					}
				}
			}
			else{
				$smsDelib = "&nbsp; <img src='B_mbindi/pue/grille/warning.ico' class='icon'/> Erreur de trouver lamention ";
			}
		}
		
	}
	
 ?>