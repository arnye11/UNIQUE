<?php 
	include("palmares_ancien_systeme.php");
	include("palmares_LMD.php");
?>