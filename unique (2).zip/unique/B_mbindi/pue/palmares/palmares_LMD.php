<?php 
if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and (isset($_GET['cOTe'])||isset($_GET['imPRessIoN'])) and isset($_GET['palMares'])){
	if ($_SESSION['systPromo']=="N"){
		?>
		<style type="text/css">
			<!--
				.palmares{
					width: 90%;
				}
				#StatPalm{
					font-size: 14px;
				}
				<?php 
					if (isset($_GET['imPRessIoN'])) {
				 		?>
						.palmares{
							width: 100%; 
						}
						#StatPalm{
							font-size: 10px;
						}
						<?php  
				}?>
				.menuPalmers1, .menuPalmers2{
					display:inline-block; 
					padding-left: 5px;
					padding-right: 5px;
					margin:5px; 
					float: left;
				}
				.menuPalmers1{
					<?php 
					if (isset($_GET['s1'])) {
						$session = "s1";
				 		?>
							background: #003758;
							color: #ffffff;
						<?php  
					}?>
				}
				.menuPalmers2{
					<?php 
					if (isset($_GET['s2'])) {
						$session = "s2";
				 		?>
							background: #003758;
							color: #ffffff;
						<?php  
					}?>
				}
			-->
		</style>
		<?php 
		if (!isset($_GET['imPRessIoN'])) { ?>
			<div>
				<table style="width:100%;">
					<tr>
						<td>
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&palMares&s1" ?>">
								<div class="menuPalmers1" style="">1<sup>ère</sup> Session</div>
							</a>
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&palMares&s2" ?>">
								<div class="menuPalmers2" >2<sup>ème</sup> Session</div>
							</a>
							<div style="display:inline-block; float: right;">
								<?php include("B_mbindi/Biamunda/list_aca.php"); ?>
							</div>	
						</td>
					</tr>
				</table>
					
			</div> 
			<?php 
		}

		if(!empty($_GET['iDfaC']) and !empty($_GET['pRomotIon']) and !empty($_GET['oPtiOn'])){
			
			$idFac= $_GET['iDfaC'];
			$idPromo = $_GET['pRomotIon'];
			$idOp = $_GET['oPtiOn'];
			$designFac = "";
			$nbrcours=0;
			$cotePonderee=0;
			$pourcentage=0;
			$cotePonderee_etud=0;
			$nbrReussite = 0;
					
			$rqt_slct_fac = "select * from tb_faculte where idFac = '".$idFac."'";
			
			if($exe_rqt_slct_fac= $conDb->query($rqt_slct_fac)){
				if($tb_fac = $exe_rqt_slct_fac->fetch_assoc()){
					$designFac = $tb_fac['designFac'];
				}
			}
			
			$rqt_slct_delb = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
			
			if($exe_rqt_slct_delb = $conDb->query($rqt_slct_delb)){
				if($exe_rqt_slct_delb->num_rows>0){
					$nbEtud = $exe_rqt_slct_delb->num_rows;
					?>
					<div class="palmares">
						
						<table style="width:100%;">	
							<tr>
								<td>
									<div style="width:60%; display: inline-block; float: left;">
										<div align="center" style="width:100%; height: auto; font-size:1em; font-weight:bold;">
											<div align="center" style="width:90%; height: auto;  border:solid 2px #000000; border-radius:16px 16px; margin-top: 10px; margin-bottom:10px; padding:5px; background: #dcdcdc;text-transform: uppercase;">
												PALMARES DE LA 
												<?php 
													if($session=="s1"){
														echo "&nbsp; 1<sup>ère</sup> &nbsp;";
													}
													else{
														echo "&nbsp; 2<sup>ème</sup> &nbsp;";
													} 
												?>
												SESSION
											</div>
										</div>
										<div>Année académique : <?php echo $an_aca ; ?></div>
										<div style="text-transform: uppercase;">
											<?php 
												if($_SESSION['typEts']=="UN") {
													echo "FACULTE : " ;
												}
												else{
													echo "SECTION : "; 
												}
												echo $designFac;  
											?>
										</div>
										
										<div>PROMOTION : <?php echo $idPromo." ".$_SESSION['designOp']; ?><br></div>
										
									</div>	
									<div style="width:35%; display: inline-block; float: right; text-align: right;">	
										<div align="center">Tableau statistique</div>
											<table border="1" cellspacing="0" cellpadding="1" style="width: 100%;" id="StatPalm" >
												<tr style="background:#cfcfcf; font-weight: bold;">
													<td>Grade CECT/Appreciations</td>
													<td>Effectif</td>
												</tr>
												<tr title="Note ≥ 18/20">
													<td><div align="right" >Excellence (A) : </div></td>
													<td>
														<?php 
															$rqt_slct_pgd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='A'";
															if($exe_rqt_slct_pgd = $conDb->query($rqt_slct_pgd)){
																if($exe_rqt_slct_pgd->num_rows>0){
																	$nbrReussite=$nbrReussite+1;
																	echo $exe_rqt_slct_pgd->num_rows;
																}
																else{
																	echo 0;
																}
															}
															else{
																echo "Erreur";
															}
														?>	
													</td>
												</tr>
												<tr title="Note ≥ 16/20">
													<td><div align="right">Très Bien (B) : </div></td>
													<td>
														<?php 
															$rqt_slct_gd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='B'";
															if($exe_rqt_slct_gd = $conDb->query($rqt_slct_gd)){
																if($exe_rqt_slct_gd->num_rows>0){
																	$nbrReussite=$nbrReussite+1;
																	echo $exe_rqt_slct_gd->num_rows;
																}
																else{
																	echo 0;
																}
															}
															else{
																echo "Erreur";
															}
														?>
													</td>
												</tr>
												<tr title="Note ≥ 14/20">
													<td><div align="right">BIEN (C) : </div></td>
													<td>
														<?php 
															$rqt_slct_d = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='C'";
															if($exe_rqt_slct_d = $conDb->query($rqt_slct_d)){
																if($exe_rqt_slct_d->num_rows>0){
																	$nbrReussite=$nbrReussite+1;
																	echo $exe_rqt_slct_d->num_rows ;
																}
																else{
																	echo 0;
																}
															}
															else{
																echo "Erreur";
															}
														?>
													</td>
												</tr>
												<tr title="Note ≥ 12/20">
													<td><div align="right">Assez Bien (D) : </div></td>
													<td>
														<?php 
															$rqt_slct_s = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='D'";
															if($exe_rqt_slct_s = $conDb->query($rqt_slct_s)){
																if($exe_rqt_slct_s->num_rows>0){
																	$nbrReussite=$nbrReussite+1;
																	echo $exe_rqt_slct_s->num_rows ;
																}
																else{
																	echo 0 ;
																}
															}
															else{
																echo "Erreur";
															}
														?>
													</td>
												</tr>
												<tr title="Note ≥ 10/20">
													<td><div align="right">Passable (E)  : </div></td>
													<td>
														<?php 
															$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='E'";
															if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
																if($exe_rqt_slct_a->num_rows>0){
																	$nbrReussite+=1;
																	echo $exe_rqt_slct_a->num_rows ;
																}
																else{
																	echo 0 ;
																}
															}
															else{
																echo "Erreur";
															}
														?>
													</td>
												</tr>
												<tr title="Note ≥ 8/20">
													<td><div align="right">Insuffisant (F)  : </div></td>
													<td>
														<?php 
															$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='F'";
															if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
																if($exe_rqt_slct_a->num_rows>0){
																	echo $exe_rqt_slct_a->num_rows ;
																}
																else{
																	echo 0 ;
																}
															}
															else{
																echo "Erreur";
															}
														?>
													</td>
												</tr>
												<tr title="Note ≥ 7/20">
													<td><div align="right">Insatisfaisant (G)  : </div></td>
													<td>
														<?php 
															$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='G'";
															if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
																if($exe_rqt_slct_a->num_rows>0){
																	echo $exe_rqt_slct_a->num_rows ;
																}
																else{
																	echo 0 ;
																}
															}
															else{
																echo "Erreur";
															}
														?>
													</td>
												</tr>
												<tr title="Absent/frais">
													<td><div align="right">Assimilés aux Insatisfaisants (AI)  :</div></td>
													<td>
														<?php 
															$rqt_slct_aa = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='AI'";
															if($exe_rqt_slct_aa = $conDb->query($rqt_slct_aa)){
																if($exe_rqt_slct_aa->num_rows>0){
																	echo $exe_rqt_slct_aa->num_rows ;
																}
																else{
																	echo 0;
																}
															}
															else{
																echo "Erreur";
															}
														?>
													</td>
												</tr>
											</table>
									</div>				
								</td>
							</tr>
						</table>
						
						
						<div align="justify">
							<?php 
								if ($nbrReussite>0) {
									$rqt_slct_notation_grade = "SELECT * FROM tb_notation_grade ORDER BY grade ASC";
									if($rslt_notation_grade = $conDb->query($rqt_slct_notation_grade)){
										while($tb_notation_grade = $rslt_notation_grade->fetch_assoc()){
											$rqt_slct_etud_delibere = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.mention )='".$tb_notation_grade["grade"]."')) ORDER BY tb_deliberation.prctg DESC";
											if($rslt_rqt_slct_etud_delibere = $conDb->query($rqt_slct_etud_delibere)){
												if($rslt_rqt_slct_etud_delibere->num_rows>0){
													if($rslt_rqt_slct_etud_delibere->num_rows>1){
														echo "<p><strong>Ont obtenus la note ".$tb_notation_grade["grade"]." (".$tb_notation_grade["Appreciations"].") : </strong></p>";
													}
													else{
														echo "<p><strong>A obtenu la note ".$tb_notation_grade["grade"]." (".$tb_notation_grade["Appreciations"].") : </strong></p>";
													}
													?>
													<p> 
														<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
															<tr style="background:#cfcfcf; font-weight: bold;">
																<td rowspan="2">N°</td>
																<td rowspan="2">NOM</td>
																<td rowspan="2">POSTNOM</td>
																<td rowspan="2">PRENOM</td>	
																<td rowspan="2">SEXE</td>
																<td rowspan="2">MATRICULE</td>
																<td rowspan="2">NATIONALITE</td>
																<td colspan="2"><div align="center">APPRECIATION ANNUELLE</div></td>
															</tr>
															<tr style="background:#cfcfcf; font-weight: bold;">
																<td><div align="center">Moyenne</div></td>
																<td><div align="center">Mention</div></td>
															</tr>
															<?php 	
																$num=0;
																while($tb_etud_delibere = $rslt_rqt_slct_etud_delibere->fetch_assoc()) {
																	?>
																	<tr>
																		<td><div align="right"><?php echo $num+=1; ?></div></td>
																		<td><?php echo $tb_etud_delibere["nomEtud"]; ?></td>
																		<td><?php echo $tb_etud_delibere["postnomEtud"]; ?></td>
																		<td><?php echo $tb_etud_delibere["prenomEtud"]; ?></td>
																		<td>
																			<div align="center">
																				<?php echo $tb_etud_delibere["sexeEtud"]; ?>
																			</div>
																		</td>
																		<td><?php echo $tb_etud_delibere["matricEtud"]; ?></td>
																		<td><?php echo "Congolaise"; ?></td>
																		<td><div align="right"><?php echo $tb_etud_delibere["prctg"]; ?>/20</div></td>
																		<td><div align="center"><?php echo $tb_notation_grade["Appreciations"]."(".$tb_etud_delibere["mention"].")"; ?></div></td>
																	</tr>
																	<?php
																}
															?>
														</table>
													</p>
													<?php
												}
												
											}
											else{
												echo "<div class='erreur'>Erreur</div>";
											}
										}
									}
									else{
										echo "Echoc de récupération des notes";
									}
								} 
							?>
							
						</div>
					</div>
					<?php 
					if (!isset($_GET['imPRessIoN'])) {
						echo "<p  align='right'>";	
						echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$idPromo."&oPtiOn=".$idOp."&imPRessIoN&palMares&".$session."&aca=".$an_aca."'>"; 
						?>
						<div style="width:60px; padding: 50px; float: right;">
							<img src="B_mbindi/Biamunda/icon/print.ico" class="ico"><br>
							Imprimer
						</div>
						<?php 
						echo "</a>";		
						echo "</p>";
						
					}
					else{
						?>

						<script type="text/javascript">
						  	window.print();
						  	//window.location.replace('?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo$_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&pV&');
						</script>

						<?php 
						//header ('location:?ffAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib');

					}

				}
				else
					{
					echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' class='echec'><h2 >Aucu cours n'est organis&eacute; en <br/>".$idPromo."&nbsp;".$_SESSION['designOp']."</h2><br/><br/></div>";
				}
			}
			else{
				echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'Erreur système dû à la requêtte</h2></div>";
			}

		}
		else{
			echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'>Pour charger le palmares, il faut d'abord indiquer la promotion ainsi que l'option</h2></div>";
		}
	}
}
?>
