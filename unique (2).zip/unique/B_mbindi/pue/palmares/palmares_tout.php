<?php 
if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['palMaresFac'])){
	$idFac= $_GET['iDfaC'];
	$session = "s1";
	if (isset($_GET['s2'])) {
		$session = "s2";
	}
		
	
		?>
		<style type="text/css">
			<!--
				.palmares{
					width: 90%;
				}
				#StatPalm{
					font-size: 14px;
				}
				.logoEts{
					max-width:5%; 
				}
				<?php 
					if (isset($_GET['imPRessIoN'])) {
				 		?>
						.palmares{palMaresFac
							width: 100%; 
						}
						#StatPalm{
							font-size: 10px;
						}
						<?php  
				}?>
				.menuPalmers1, .menuPalmers2{
					display:inline-block; 
					padding-left: 5px;
					padding-right: 5px;
					margin:5px; 
					float: left;
				}
				.menuPalmers1{
					<?php 
					if ($session == "s1") {
						?>
							background: #003758;
							color: #ffffff;
						<?php  
					}?>
				}
				.menuPalmers2{
					<?php 
					if ($session == "s2") {
						?>
							background: #003758;
							color: #ffffff;
						<?php  
					}?>
				}
				@media print {
			      .nouvelle_page {
			        page-break-before: always;
			      }
			    }
			-->
		</style>
		<?php 
		if (!isset($_GET['imPRessIoN'])) { ?>
			<div>
				<table style="width:100%;">
					<tr>
						<td>
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&palMaresFac&s1" ?>">
								<div class="menuPalmers1" style="">1<sup>ère</sup> Session</div>
							</a>
							<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&palMaresFac&s2" ?>">
								<div class="menuPalmers2" >2<sup>ème</sup> Session</div>
							</a>
							<div style="display:inline-block; float: right;">
								<?php include("B_mbindi/Biamunda/list_aca.php"); ?>
							</div>	
						</td>
					</tr>
				</table>
					
			</div> 
			<?php 
		}
		if (isset($_GET['imPRessIoN'])) {
			?>
			<div style="height: 100vh;">
				<div style="float:left; width: 90px;height: 80px;position: absolute;">
					<a href="?accueil"><img src="armoiri-rdc.jpg" style="width:100%;height: auto;"></a>
				</div>
				<div style="float:right; width: 90px;height: 80px;position: absolute;margin-top:20px;right: 40px;">
					<a href="?accueil"><img src="drapeau.png" style="width:100%;height: auto;"></a>
				</div>
				
				<table style="width:100%;">
					<tr>
						<td>
							<div align="center" style="">
								REPUBLIQUE DEMOCRATIQUE DU CONGO <br>
								ENSEIGNEMENT SUPERIEUR ET UNIVERSITAIRE <br>
								<?php echo $_SESSION['nom_etablissement']; ?><br>
								<strong><?php echo $_SESSION['sigle_tb_etablissement']; ?></strong> <br>
								<div class="z_logo_ets">
									<a href="?accueil">
										<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="Logo Ets" class="logoEts" />
									</a>
								</div>
							</div>
						</td>
					</tr>
				</table>
				<div style="background:#005bc3;display: inline-block;width: 32%;height: 4px;"></div>
				<div style="background:#fff809;display: inline-block;width: 34%;height: 4px;"></div>
				<div style="background:2px #ff0000;display: inline-block;width: 32%;height: 4px;"></div>
				
				<div align="center" style="top: 40%;left: 50%;transform: translate(-50%, 50%); position: absolute;">
					<div style="padding:20px; font-weight: bold; font-size: 1.5em; border:solid 2px #6b1f00; border-radius:10px;">
						PALMARES DE LA 
						<?php 
							if($session=="s1"){
								echo "&nbsp; 1<sup>ère</sup> &nbsp;";
							}
							else{
								echo "&nbsp; 2<sup>ème</sup> &nbsp;";
							} 
						?>
						SESSION	 <br>
						<?php echo $an_aca ; ?><br>
						
					</div>
				</div>	
				<div class="toutdroit" align="center" style="background: #6b1f00; color:#ffff; padding:20px;bottom: 0px;position: absolute; width: 100%;box-sizing: border-box;">
				    TOUT DROIT RESERVE | © <?php echo $date_encour['year']; ?> <a href="#" style="text-decoration: none; color:#fff; font-weight: bold;"><?php echo $_SESSION['sigle_tb_etablissement']; ?> </a>| Designed by <a href="https://arnye.net" style="text-decoration: none; color:#ffffff; font-weight: bold;">CRTN</a>
				</div>	
			</div>
			
			<?php 
		}
		else{
			?>
			<h1 align="center" style="">
				PALMARES DE LA 
				<?php 
					if($session=="s1"){
						echo "&nbsp; 1<sup>ère</sup> &nbsp;";
					}
					else{
						echo "&nbsp; 2<sup>ème</sup> &nbsp;";
					} 
				?>
				SESSION	 <br>
				<?php echo $an_aca ; ?>
			</h1>		
			<?php 
		}

		$rqt_slct_op = "select * from  tb_option where idFac = '".$idFac."' ORDER BY designOp ASC";
		if($exe_rqt_slct_op = mysqli_query($con, $rqt_slct_op)){
			if(mysqli_num_rows($exe_rqt_slct_op)>0){
				while($tb_option = mysqli_fetch_assoc($exe_rqt_slct_op)){
					$idOp = $tb_option['idOp'];
					$designOp = $tb_option['designOp'];
					$designFac = "";

					$rqt_slct_fac = "select * from tb_faculte where idFac = '".$idFac."'";
					if($exe_rqt_slct_fac= $conDb->query($rqt_slct_fac)){
						if($tb_fac = $exe_rqt_slct_fac->fetch_assoc()){
							$designFac = $tb_fac['designFac'];
						}
					}
					?>
					<div style="padding:20px; font-weight: bold; font-size: 2em; border-top:solid 1px #000; border-bottom: solid 1px #000;">
						<?php echo $designOp; ?>
					</div>
					<?php 
					$rqt_promo_org = "SELECT * FROM tb_organisation_option  where idOp ='".$idOp."' AND  idAnAca = '".$an_aca."' ORDER BY idPromo ASC ";
					if($exe_rqt_promo_org = mysqli_query($con, $rqt_promo_org)){
						if(mysqli_num_rows($exe_rqt_promo_org)>0){
							while($tb_promo_org = mysqli_fetch_assoc($exe_rqt_promo_org)) {			
			
								$idPromo = $tb_promo_org['idPromo'];
								$rqt_slct_promo = "select * from tb_promotion where idPromo = '".$idPromo."'";
								if($exe_rqt_slct_promo= $conDb->query($rqt_slct_promo)){
									if($tb_promotion = $exe_rqt_slct_promo->fetch_assoc()){
										$_SESSION['systPromo'] = $tb_promotion['systPromo'];
									}
								}
			
								$pourcentage=0;
								$nbrReussite = 0;								
								
								$rqt_slct_delb = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
								
								if($exe_rqt_slct_delb = $conDb->query($rqt_slct_delb)){
									if($exe_rqt_slct_delb->num_rows>0){
										$nbEtud = $exe_rqt_slct_delb->num_rows;
										?>
										<div class="palmares">
											
											<table style="width:100%;">	
												<tr>
													<td>
														<div style="width:60%; display: inline-block; float: left;">
															<div align="center" style="width:100%; height: auto; font-size:1em; font-weight:bold;">
																<div align="center" style="width:90%; height: auto;  border:solid 2px #000000; border-radius:16px 16px; margin-top: 10px; margin-bottom:10px; padding:5px; background: #dcdcdc;text-transform: uppercase;">
																	PALMARES DE LA 
																	<?php 
																		if($session=="s1"){
																			echo "&nbsp; 1<sup>ère</sup> &nbsp;";
																		}
																		else{
																			echo "&nbsp; 2<sup>ème</sup> &nbsp;";
																		} 
																	?>
																	SESSION
																</div>
															</div>
															<div>Année académique : <?php echo $an_aca ; ?></div>
															<div style="text-transform: uppercase;">
																<?php 
																	if($_SESSION['typEts']=="UN") {
																		echo "FACULTE : " ;
																	}
																	else{
																		echo "SECTION : "; 
																	}
																	echo $designFac;  
																?>
															</div>
															
															<div>PROMOTION : <?php echo $idPromo." ".$designOp; ?><br></div>
															
														</div>	
														
														<div style="width:35%; display: inline-block; float: right; text-align: right;">	
															<div align="center">Tableau statistique</div>
															<?php 
																if ($_SESSION['systPromo']=="A"){
																	?>		
																	<table border="1" cellspacing="0" cellpadding="1" style="width: 100%;" id="StatPalm" >
																		<tr style="background:#cfcfcf; font-weight: bold;">
																			<td>Mentions</td>
																			<td>Effectif</td>
																		</tr>
																		<tr>
																			<td><div align="right">Plus Grande Distinction : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_pgd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=90 and mention='PGD'";
																					if($exe_rqt_slct_pgd = $conDb->query($rqt_slct_pgd)){
																						if($exe_rqt_slct_pgd->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_pgd->num_rows;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>	
																			</td>
																		</tr>
																		<tr>
																			<td><div align="right">Grande Gistinction : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_gd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=80 and mention='GD'";
																					if($exe_rqt_slct_gd = $conDb->query($rqt_slct_gd)){
																						if($exe_rqt_slct_gd->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_gd->num_rows;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr>
																			<td><div align="right">Distinction : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_d = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=70 and mention='D'";
																					if($exe_rqt_slct_d = $conDb->query($rqt_slct_d)){
																						if($exe_rqt_slct_d->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_d->num_rows ;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr>
																			<td><div align="right">Satisfaction : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_s = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=50 and mention='S'";
																					if($exe_rqt_slct_s = $conDb->query($rqt_slct_s)){
																						if($exe_rqt_slct_s->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_s->num_rows ;
																						}
																						else{
																							echo 0 ;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr>
																			<td><div align="right">Ajournés  : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg <100 and mention='A'";
																					if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
																						if($exe_rqt_slct_a->num_rows>0){
																							echo $exe_rqt_slct_a->num_rows ;
																						}
																						else{
																							echo 0 ;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr>
																			<td><div align="right">Assimilés aux Ajournés  :</div></td>
																			<td>
																				<?php 
																					$rqt_slct_aa = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg <100 and mention='AA'";
																					if($exe_rqt_slct_aa = $conDb->query($rqt_slct_aa)){
																						if($exe_rqt_slct_aa->num_rows>0){
																							echo $exe_rqt_slct_aa->num_rows ;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																	</table>
																	<?php 
																}
																if ($_SESSION['systPromo']=="N"){
																	?>
																
																	<table border="1" cellspacing="0" cellpadding="1" style="width: 100%;" id="StatPalm" >
																		<tr style="background:#cfcfcf; font-weight: bold;">
																			<td>Grade CECT/Appreciations</td>
																			<td>Effectif</td>
																		</tr>
																		<tr title="Note ≥ 18/20">
																			<td><div align="right" >Excellence (A) : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_pgd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='A'";
																					if($exe_rqt_slct_pgd = $conDb->query($rqt_slct_pgd)){
																						if($exe_rqt_slct_pgd->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_pgd->num_rows;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>	
																			</td>
																		</tr>
																		<tr title="Note ≥ 16/20">
																			<td><div align="right">Très Bien (B) : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_gd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='B'";
																					if($exe_rqt_slct_gd = $conDb->query($rqt_slct_gd)){
																						if($exe_rqt_slct_gd->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_gd->num_rows;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr title="Note ≥ 14/20">
																			<td><div align="right">BIEN (C) : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_d = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='C'";
																					if($exe_rqt_slct_d = $conDb->query($rqt_slct_d)){
																						if($exe_rqt_slct_d->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_d->num_rows ;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr title="Note ≥ 12/20">
																			<td><div align="right">Assez Bien (D) : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_s = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='D'";
																					if($exe_rqt_slct_s = $conDb->query($rqt_slct_s)){
																						if($exe_rqt_slct_s->num_rows>0){
																							$nbrReussite=$nbrReussite+1;
																							echo $exe_rqt_slct_s->num_rows ;
																						}
																						else{
																							echo 0 ;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr title="Note ≥ 10/20">
																			<td><div align="right">Passable (E)  : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='E'";
																					if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
																						if($exe_rqt_slct_a->num_rows>0){
																							$nbrReussite+=1;
																							echo $exe_rqt_slct_a->num_rows ;
																						}
																						else{
																							echo 0 ;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr title="Note ≥ 8/20">
																			<td><div align="right">Insuffisant (F)  : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='F'";
																					if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
																						if($exe_rqt_slct_a->num_rows>0){
																							echo $exe_rqt_slct_a->num_rows ;
																						}
																						else{
																							echo 0 ;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr title="Note ≥ 7/20">
																			<td><div align="right">Insatisfaisant (G)  : </div></td>
																			<td>
																				<?php 
																					$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='G'";
																					if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
																						if($exe_rqt_slct_a->num_rows>0){
																							echo $exe_rqt_slct_a->num_rows ;
																						}
																						else{
																							echo 0 ;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																		<tr title="Absent/frais">
																			<td><div align="right">Assimilés aux Insatisfaisants (AI)  :</div></td>
																			<td>
																				<?php 
																					$rqt_slct_aa = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='AI'";
																					if($exe_rqt_slct_aa = $conDb->query($rqt_slct_aa)){
																						if($exe_rqt_slct_aa->num_rows>0){
																							echo $exe_rqt_slct_aa->num_rows ;
																						}
																						else{
																							echo 0;
																						}
																					}
																					else{
																						echo "Erreur";
																					}
																				?>
																			</td>
																		</tr>
																	</table>
																	<?php 
																}

															?>
														</div>				
													</td>
												</tr>
											</table>
											
											
											<div align="justify">
												<?php 
													if ($nbrReussite>0) {
														if ($_SESSION['systPromo']=="A"){									
															$rqt_slct_etud_PGD = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=90) AND ((tb_deliberation.mention )='PGD')) ORDER BY tb_deliberation.prctg DESC";
															if($rslt_etud_PGD = $conDb->query($rqt_slct_etud_PGD)){
																if($rslt_etud_PGD->num_rows>0){
																	if($rslt_etud_PGD->num_rows>1){
																		echo "<p><strong>Ont réussi avec Plus Grande Distinction : </strong></p>";
																	}
																	else{
																		echo "<p><strong>A réussi avec Plus Grande Distinction : </strong></p>";
																	}
																	?>
																	<p> 
																		<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
																			<tr style="background:#cfcfcf; font-weight: bold;">
																				<td>N°</td>
																				<td>NOM</td>
																				<td>POSTNOM</td>
																				<td>PRENOM</td>	
																				<td>SEXE</td>
																				<td>MATRICULE</td>
																				<td>NATIONALITE</td>
																				<td>%</td>
																			</tr>
																			<?php 	
																				while($tb_etud_PGD = $rslt_etud_PGD->fetch_assoc()) {
																					?>
																					<tr>
																						<td><div align="right"><?php echo $num+=1; ?></div></td>
																						<td><?php echo $tb_etud_PGD["nomEtud"]; ?></td>
																						<td><?php echo $tb_etud_PGD["postnomEtud"]; ?></td>
																						<td><?php echo $tb_etud_PGD["prenomEtud"]; ?></td>
																						<td>
																							<div align="center">
																								<?php echo $tb_etud_PGD["sexeEtud"]; ?>
																							</div>
																						</td>
																						<td><?php echo $tb_etud_PGD["matricEtud"]; ?></td>
																						<td><?php echo "Congolaise"; ?></td>
																						<td><div align="right"><?php echo $tb_etud_PGD["prctg"]; ?></div></td>
																					</tr>
																					<?php
																				}
																			?>
																		</table>
																	</p>
																	<?php
																}
																
															}
															else{
																echo "<div class='erreur'>Erreur</div>";
															}
																
															$rqt_slct_etud_GD = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=80) AND ((tb_deliberation.mention )='GD')) ORDER BY tb_deliberation.prctg DESC";
															if($rslt_etud_GD = $conDb->query($rqt_slct_etud_GD)){
																if($rslt_etud_GD->num_rows>0){
																	if($rslt_etud_GD->num_rows>1){
																		echo "<p><strong>Ont réussi avec Grande Distinction : </strong></p>";
																	}
																	else{
																		echo "<p><strong>A réussi avec Grande Distinction : </strong></p>";
																	}
																	?>
																	<p>
																		<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
																			<tr style="background:#cfcfcf; font-weight: bold;">
																				<td>N°</td>
																				<td>NOM</td>
																				<td>POSTNOM</td>
																				<td>PRENOM</td>	
																				<td>SEXE</td>
																				<td>MATRICULE</td>
																				<td>NATIONALITE</td>
																				<td>%</td>
																			</tr>
																			<?php
																				while($tb_etud_GD = $rslt_etud_GD->fetch_assoc()) {
																					?>
																					<tr>
																						<td><div align="right"><?php echo $num+=1; ?></div></td>
																						<td><?php echo $tb_etud_GD["nomEtud"]; ?></td>
																						<td><?php echo $tb_etud_GD["postnomEtud"]; ?></td>
																						<td><?php echo $tb_etud_GD["prenomEtud"]; ?></td>
																						<td><div align="center"><?php echo $tb_etud_GD["sexeEtud"]; ?></div></td>
																						<td><?php echo $tb_etud_GD["matricEtud"]; ?></td>
																						<td><?php echo "Congolaise"; ?></td>
																						<td><div align="right"><?php echo $tb_etud_GD["prctg"]; ?></div></td>
																					</tr>
																					<?php
																				}
																			?>
																		</table>
																	</p>
																	<?php
																}
																
															}
															else{
																echo "<div class='erreur'>Erreur</div>";
															}

															$rqt_slct_etud_D = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=70) AND ((tb_deliberation.mention )='D')) ORDER BY tb_deliberation.prctg DESC";
															if($rslt_etud_D = $conDb->query($rqt_slct_etud_D)){
																if($rslt_etud_D->num_rows>0){
																	if($rslt_etud_D->num_rows>1){
																		echo "<p><strong>Ont réussi avec Distinction : </strong></p>";
																	}
																	else{
																		echo "<p><strong>A réussi avec Distinction : </strong></p>";
																	}
																	?>
																	<p>
																		<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
																			<tr style="background:#cfcfcf; font-weight: bold;">
																				<td>N°</td>
																				<td>NOM</td>
																				<td>POSTNOM</td>
																				<td>PRENOM</td>	
																				<td>SEXE</td>
																				<td>MATRICULE</td>
																				<td>NATIONALITE</td>
																				<td>%</td>
																			</tr>
																			<?php
																			$num=0;
																			while($tb_etud_D=$rslt_etud_D->fetch_assoc()){?>
																				<tr>
																					<td><div align="right"><?php echo $num+=1; ?></div></td>
																					<td><?php echo $tb_etud_D["nomEtud"]; ?></td>
																					<td><?php echo $tb_etud_D["postnomEtud"]; ?></td>
																					<td><?php echo $tb_etud_D["prenomEtud"]; ?></td>
																					<td><div align="center"><?php echo $tb_etud_D["sexeEtud"]; ?></div></td>
																					<td><?php echo $tb_etud_D["matricEtud"]; ?></td>
																					<td><?php echo "Congolaise"; ?></td>
																					<td><div align="right"><?php echo $tb_etud_D["prctg"]; ?></div></td>
																				</tr>
																				<?php
																			}
																		?>
																		</table>
																	</p>
																	<?php
																}
																
															}
															else{
																echo "<div class='erreur'>Erreur</div>";
															}

															$rqt_slct_etud_S = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=50) AND ((tb_deliberation.mention )='S')) ORDER BY tb_deliberation.prctg DESC";
															if($rslt_etud_S = $conDb->query($rqt_slct_etud_S)){
																if($rslt_etud_S->num_rows>0){
																	if($rslt_etud_S->num_rows>1){
																		echo "<p><strong>Ont réussi avec Satisfaction : </strong></p>";
																	}
																	else{
																		echo "<p><strong>A réussi avec Satisfaction : </strong></p>";
																	}
																	?>
																	<p>
																		<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
																			<tr style="background:#cfcfcf; font-weight: bold;">
																				<td>N°</td>
																				<td>NOM</td>
																				<td>POSTNOM</td>
																				<td>PRENOM</td>	
																				<td>SEXE</td>
																				<td>MATRICULE</td>
																				<td>NATIONALITE</td>
																				<td>%</td>
																			</tr>
																			<?php
																			$num=0;
																			while($tb_etud_S = $rslt_etud_S->fetch_assoc()) {
																				?>
																					<tr>
																						<td><div align="right"><?php echo $num+=1; ?></div></td>
																						<td><?php echo $tb_etud_S["nomEtud"]; ?></td>
																						<td><?php echo $tb_etud_S["postnomEtud"]; ?></td>
																						<td><?php echo $tb_etud_S["prenomEtud"]; ?></td>
																						<td><div align="center"><?php echo $tb_etud_S["sexeEtud"]; ?></div></td>
																						<td><?php echo $tb_etud_S["matricEtud"]; ?></td>
																						<td><?php echo "Congolaise"; ?></td>
																						<td><div align="right"><?php echo $tb_etud_S["prctg"]; ?></div></td>
																					</tr>
																				<?php
																			}
																		?>
																		</table>
																	</p>
																	<?php
																}
																
															}
															else{
																echo "<div class='erreur'>Erreur</div>";
															}
															$rqt_slct_etud_A = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )<100) AND ((tb_deliberation.mention )='A')) ORDER BY tb_deliberation.prctg DESC";
															//$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg <100 and mention='A'";
															if($rslt_etud_A = $conDb->query($rqt_slct_etud_A)){
																if($rslt_etud_A->num_rows>0){
																	if($rslt_etud_A->num_rows>1){
																		echo "<p><strong>Sont Ajournés : </strong></p>";
																	}
																	else{
																		echo "<p><strong>Est ajourné: </strong></p>";
																	}
																	?>
																	<p>
																		<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
																			<tr style="background:#cfcfcf; font-weight: bold;">
																				<td>N°</td>
																				<td>NOM</td>
																				<td>POSTNOM</td>
																				<td>PRENOM</td>	
																				<td>SEXE</td>
																				<td>MATRICULE</td>
																				<td>NATIONALITE</td>
																				<td>%</td>
																			</tr>
																			<?php
																			$num=0;
																			while($tb_etud_A = $rslt_etud_A->fetch_assoc()) {
																				?>
																					<tr>
																						<td><div align="right"><?php echo $num+=1; ?></div></td>
																						<td><?php echo $tb_etud_A["nomEtud"]; ?></td>
																						<td><?php echo $tb_etud_A["postnomEtud"]; ?></td>
																						<td><?php echo $tb_etud_A["prenomEtud"]; ?></td>
																						<td><div align="center"><?php echo $tb_etud_A["sexeEtud"]; ?></div></td>
																						<td><?php echo $tb_etud_A["matricEtud"]; ?></td>
																						<td><?php echo "Congolaise"; ?></td>
																						<td><div align="right"><?php //echo $tb_etud_A["prctg"]; ?>-</div></td>
																					</tr>
																				<?php
																			}
																		?>
																		</table>
																	</p>
																	<?php
																}
																
															}
															else{
																echo "<div class='erreur'>Erreur</div>";
															}
															$rqt_slct_etud_AA = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )<100) AND ((tb_deliberation.mention )='AA')) ORDER BY tb_deliberation.prctg DESC";
															//$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg <100 and mention='A'";
															if($rslt_etud_AA = $conDb->query($rqt_slct_etud_AA)){
																if($rslt_etud_AA->num_rows>0){
																	if($rslt_etud_AA->num_rows>1){
																		echo "<p><strong>Sont assimilés aux ajournés : </strong></p>";
																	}
																	else{
																		echo "<p><strong>Est assimilés aux ajournés : </strong></p>";
																	}
																	?>
																	<p>
																		<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
																			<tr style="background:#cfcfcf; font-weight: bold;">
																				<td>N°</td>
																				<td>NOM</td>
																				<td>POSTNOM</td>
																				<td>PRENOM</td>	
																				<td>SEXE</td>
																				<td>MATRICULE</td>
																				<td>NATIONALITE</td>
																				<td>%</td>
																			</tr>
																			<?php
																			$num=0;
																			while($tb_etud_AA = $rslt_etud_AA->fetch_assoc()){
																				?>
																					<tr>
																						<td><div align="right"><?php echo $num+=1; ?></div></td>
																						<td><?php echo $tb_etud_AA["nomEtud"]; ?></td>
																						<td><?php echo $tb_etud_AA["postnomEtud"]; ?></td>
																						<td><?php echo $tb_etud_AA["prenomEtud"]; ?></td>
																						<td><div align="center"><?php echo $tb_etud_AA["sexeEtud"]; ?></div></td>
																						<td><?php echo $tb_etud_AA["matricEtud"]; ?></td>
																						<td><?php echo "Congolaise"; ?></td>
																						<td><div align="right"><?php //echo $tb_etud_AA["prctg"]; ?>-</div></td>
																					</tr>
																				<?php
																			}
																		?>
																		</table>
																	</p>
																	<?php
																}
																
															}
															else{
																echo "<div class='erreur'>Erreur</div>";
															}
														}
														if ($_SESSION['systPromo']=="N"){
															$rqt_slct_notation_grade = "SELECT * FROM tb_notation_grade WHERE grade ='A' OR  grade ='B' OR  grade ='C' OR  grade ='D' OR grade ='E' ORDER BY grade ASC";
															if($rslt_notation_grade = $conDb->query($rqt_slct_notation_grade)){
																while($tb_notation_grade = $rslt_notation_grade->fetch_assoc()){
																	
																	$rqt_slct_etud_delibere = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.mention )='".$tb_notation_grade["grade"]."')) ORDER BY tb_deliberation.prctg DESC";
																	if($rslt_rqt_slct_etud_delibere = $conDb->query($rqt_slct_etud_delibere)){
																		if($rslt_rqt_slct_etud_delibere->num_rows>0){

																			if($rslt_rqt_slct_etud_delibere->num_rows>1){
																				echo "<p><strong>Ont réussi avec la mention ".$tb_notation_grade["Appreciations"]." (".$tb_notation_grade["grade"].") : </strong></p>";
																			}
																			else{
																				echo "<p><strong>A réussi avec la mention ".$tb_notation_grade["Appreciations"]." (".$tb_notation_grade["grade"].") : </strong></p>";
																			}
																			?>
																			<p> 
																				<table style="width:100%;" cellspacing="0" cellpadding="1" border="1">
																					<tr style="background:#cfcfcf; font-weight: bold;">
																						<td rowspan="2">N°</td>
																						<td rowspan="2">NOM</td>
																						<td rowspan="2">POSTNOM</td>
																						<td rowspan="2">PRENOM</td>	
																						<td rowspan="2">SEXE</td>
																						<td rowspan="2">MATRICULE</td>
																						<td rowspan="2">NATIONALITE</td>
																						<td colspan="2"><div align="center">APPRECIATION ANNUELLE</div></td>
																					</tr>
																					<tr style="background:#cfcfcf; font-weight: bold;">
																						<td><div align="center">Moyenne</div></td>
																						<td><div align="center">Mention</div></td>
																					</tr>
																					<?php 	
																						$num=0;
																						while($tb_etud_delibere = $rslt_rqt_slct_etud_delibere->fetch_assoc()) {
																							?>
																							<tr>
																								<td><div align="right"><?php echo $num+=1; ?></div></td>
																								<td><?php echo $tb_etud_delibere["nomEtud"]; ?></td>
																								<td><?php echo $tb_etud_delibere["postnomEtud"]; ?></td>
																								<td><?php echo $tb_etud_delibere["prenomEtud"]; ?></td>
																								<td>
																									<div align="center">
																										<?php echo $tb_etud_delibere["sexeEtud"]; ?>
																									</div>
																								</td>
																								<td><?php echo $tb_etud_delibere["matricEtud"]; ?></td>
																								<td><?php echo "Congolaise"; ?></td>
																								<td><div align="right"><?php echo $tb_etud_delibere["prctg"]; ?>/20</div></td>
																								<td><div align="center"><?php echo $tb_notation_grade["Appreciations"]."(".$tb_etud_delibere["mention"].")"; ?></div></td>
																							</tr>
																							<?php
																						}
																					?>
																				</table>
																			</p>
																			<?php
																		}
																		
																	}
																	else{
																		echo "<div class='erreur'>Erreur</div>";
																	}
																}
															}
															else{
																echo "Echoc de récupération des notes";
															}
														}

													} 
												?>
												
											</div>
										</div>
										
										<div class="nouvelle_page" id="contentToMove" ></div>
									
										<?php 
									}
									else{
										echo "<div align='center' style='background:#FFFFFF;padding:20px;font-size:1.3em;' class='echec'>";
										echo $idPromo."&nbsp;".$designOp." <br/> Pas d'&eacutetudiants d&eacuteliber&eacutes à la " ;
										if($session=="s1"){ echo " 1<sup>ère</sup>";}else{ echo " 2<sup>ème</sup>";}
										echo " Session<br/></div>";
									}

								}
								else{
									echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'>Echec de retrouver les étudiants déliberés</h2></div>";
								}

							}
						}

						
					}
					else{
						echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'>Echec de trouver les promotions</h2></div>";
					}
					
				}
				 
				if (!isset($_GET['imPRessIoN'])) {
					echo "<p  align='right'>";	
					echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&palMaresFac&".$session."&aca=".$an_aca."&imPRessIoN'>"; 
					?>
					<div style="width:60px; padding: 50px; float: right;">
						<img src="B_mbindi/Biamunda/icon/print.ico" class="ico"><br>
						Imprimer
					</div>
					<?php 
					echo "</a>";		
					echo "</p>";
					
				}
				else{
					?>
					<script type="text/javascript">
						window.addEventListener('beforeprint', function() {
					      document.getElementById('contentToMove').classList.add('new-page');
					    });

					    window.addEventListener('afterprint', function() {
					      document.getElementById('contentToMove').classList.remove('new-page');
					    });

					  window.print();
					</script>
					
					
					<script type="text/javascript">
					  	window.print();
					  	//window.location.replace('?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo$_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&pV&');
					</script>

					<?php 
					//header ('location:?ffAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib');

				}
			}

		}
		else{
			echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'>Echec de trouver les options</h2></div>";
		}
	
}
?>
