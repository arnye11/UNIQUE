<?php 
if(isset($_GET['fAculTe']) and isset($_GET['iDfaC']) and isset($_GET['pRomotIon']) and isset($_GET['oPtiOn']) and (isset($_GET['cOTe'])||isset($_GET['imPRessIoN'])) and isset($_GET['pV'])){
	//ANCIEN SYSTEME
	if ($_SESSION['systPromo']=="A"){
		?>

		<style type="text/css">
				<!--
				<?php 
					if (isset($_GET['imPRessIoN'])) {
				 		?>
						.pv{
							width: 700px; 
						}
						<?php  
					}
					else{
						?>
						.pv{
							width: 80%; 
							border: solid 1px #c3c3c3;
							padding: 5%;
							box-shadow: 5px 5px 20px #c3c3c3;
						}
						<?php  
					}
				?>
				-->
		</style>
		<?php 

		if(!empty($_GET['iDfaC']) and !empty($_GET['pRomotIon']) and !empty($_GET['oPtiOn'])){
			
			$idFac= $_GET['iDfaC'];
			$idPromo = $_GET['pRomotIon'];
			$idOp = $_GET['oPtiOn'];
			$designFac = "";
			if (isset($_GET['s1'])) {
				$session = "s1";
			}
			else{
				$session = "s2";
			}
			$nbrcours=0;
			$cotePonderee=0;
			$pourcentage=0;
			$cotePonderee_etud=0;
			$nbrReussite = 0;
					
			$rqt_slct_fac = "select * from tb_faculte where idFac = '".$idFac."'";
			
			if($exe_rqt_slct_fac= $conDb->query($rqt_slct_fac)){
				if($tb_fac = $exe_rqt_slct_fac->fetch_assoc()){
					$designFac = $tb_fac['designFac'];
				}
			}
			
			$rqt_slct_delb = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
			
			if($exe_rqt_slct_delb = $conDb->query($rqt_slct_delb)){
				if($exe_rqt_slct_delb->num_rows>0){
					$nbEtud = $exe_rqt_slct_delb->num_rows;
					if (!isset($_GET['imPRessIoN'])) {
						echo "<br>";
					}
					?>
					<div class="pv">
						<div align="center" style="text-transform:uppercase;">
							ENSEIGNEMENT SUPERIEURET UNIVERSITAIRE <br>
							<?php echo $nom_etablissement ; ?><br />
							&laquo; <?php echo $sigle_tb_etablissement ; ?> &raquo;<br>
							<div style="width:50px; height:50px;">
								<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&gRillDelib" ?>">
									<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" width="100%" height="100%"/>
								</a>
							</div>SECRETARIAT GENERAL ACADEMIQUE <br>	
							<?php 
								if($_SESSION['typEts']=="UN") {
									echo "FACULTE : " ;
								}
								else{
									echo "SECTION : "; 
								}
								echo $designFac;  
							?>
							<br/>
							<br/>
						</div>
						<div align="center" style="width:100%; height: auto; font-size:2em; font-weight:bold;">
							<div align="center" style="width:90%; height: auto;  border:solid 2px #000000; border-radius:16px 16px; margin-top: 10px; margin-bottom:10px; padding:5px; background: #dcdcdc;">
								PROCES-VERBAL DE DELIBERATION
							</div>
						</div>

						<div align="justify">
							<p>Le jury chargé de l'organisation des épreuves de la
								<?php 
									if($session=="s1"){
										echo "&nbsp; 1<sup>ère</sup> &nbsp;";
									}
									else{
										echo "&nbsp; 2<sup>ème</sup> &nbsp;";
									} 
								?>
								Session de l'année académique <strong> <?php echo $an_aca ; ?></strong> en <strong> <?php echo $idPromo." ".$_SESSION['designOp']; ?></strong> a reçu les examens de <?php echo $nbEtud; ?> candidats.</p>
							<p>Après délibération à huis clos, le Jury a pris les décisions suivantes :</p> 
							<ul>
								<li> 
									<?php 
										$rqt_slct_pgd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=90 and mention='PGD'";
										if($exe_rqt_slct_pgd = $conDb->query($rqt_slct_pgd)){
											if($exe_rqt_slct_pgd->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_pld->num_rows>1)
													echo "Ont réussi avec Plus Grande Distinction : ".$exe_rqt_slct_pgd->num_rows. " Etudiants";
												else
													echo "A réussi avec Plus Grande Distinction : ".$exe_rqt_slct_pgd->num_rows. " Etudiant";
											}
											else{
												echo "Ont réussi avec Plus Grande Distinction : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_gd = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=80 and mention='GD'";
										if($exe_rqt_slct_gd = $conDb->query($rqt_slct_gd)){
											if($exe_rqt_slct_gd->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_gd->num_rows>1)
													echo "Ont réussi avec Grande Gistinction : ".$exe_rqt_slct_gd->num_rows. " Etudiants";
												else
													echo "A réussi avec  Grande Gistinction : ".$exe_rqt_slct_gd->num_rows. " Etudiant";
											}
											else{
												echo "Ont réussi avec Grande Distinction : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_d = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=70 and mention='D'";
										if($exe_rqt_slct_d = $conDb->query($rqt_slct_d)){
											if($exe_rqt_slct_d->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_d->num_rows>1)
													echo "Ont réussi avec Distinction : ".$exe_rqt_slct_d->num_rows. " Etudiants";
												else
													echo "A réussi avec Distinction : ".$exe_rqt_slct_d->num_rows. " Etudiant";
											}
											else{
												echo "Ont réussi avec Distinction :  NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_s = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg >=50 and mention='S'";
										if($exe_rqt_slct_s = $conDb->query($rqt_slct_s)){
											if($exe_rqt_slct_s->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_s->num_rows>1)
													echo " Ont réussi avec Satisfaction : ".$exe_rqt_slct_s->num_rows. " Etudiants";
												else
													echo "A réussi avec Satisfaction : ".$exe_rqt_slct_s->num_rows. " Etudiant";
											}
											else{
												echo "Ont réussi avec Satisfaction : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_a = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg <100 and mention='A'";
										if($exe_rqt_slct_a = $conDb->query($rqt_slct_a)){
											if($exe_rqt_slct_a->num_rows>0){
												if($exe_rqt_slct_a->num_rows>1)
													echo "Sont Ajournés  : ".$exe_rqt_slct_a->num_rows. " Etudiants";
												else
													echo "Est Ajourné  : ".$exe_rqt_slct_a->num_rows. " Etudiant";
											}
											else{
												echo "Sont Ajournés  : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li>
									<?php 
										$rqt_slct_aa = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and prctg <100 and mention='AA'";
										if($exe_rqt_slct_aa = $conDb->query($rqt_slct_aa)){
											if($exe_rqt_slct_aa->num_rows>0){
												if($exe_rqt_slct_aa->num_rows>1)
													echo "Sont Assimilés aux Ajournés  : ".$exe_rqt_slct_aa->num_rows. " Etudiants";
												else
													echo "Est Assimilé aux Ajournés  : ".$exe_rqt_slct_aa->num_rows. " Etudiant";
											}
											else{
												echo "Est Assimilé aux Ajournés  : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
							</ul>

							<?php 
								if ($nbrReussite>0) {
									echo "<p>Ainsi : </p>";

									$rqt_slct_etud_PGD = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=90) AND ((tb_deliberation.mention )='PGD')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_PGD = $conDb->query($rqt_slct_etud_PGD)){
										if($rslt_etud_PGD->num_rows>0){
											echo "<ul>";
												if($rslt_etud_PGD->num_rows>1){
													echo "<li> ";
													echo "Ont réussi avec Plus Grande Distinction : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A réussi avec Plus Grande Distinction : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_PGD = $rslt_etud_PGD->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_PGD["nomEtud"]."&nbsp;&nbsp;".$tb_etud_PGD["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_PGD["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}
										
									$rqt_slct_etud_GD = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=80) AND ((tb_deliberation.mention )='GD')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_GD = $conDb->query($rqt_slct_etud_GD)){
										if($rslt_etud_GD->num_rows>0){
											echo "<ul>";
												if($rslt_etud_GD->num_rows>1){
													echo "<li> ";
													echo "Ont réussi avec Grande Distinction : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A réussi avec Grande Distinction : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_GD = $rslt_etud_GD->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_GD["nomEtud"]."&nbsp;&nbsp;".$tb_etud_GD["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_GD["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}

									$rqt_slct_etud_D = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=70) AND ((tb_deliberation.mention )='D')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_D = $conDb->query($rqt_slct_etud_D)){
										if($rslt_etud_D->num_rows>0){
											echo "<ul>";
												if($rslt_etud_D->num_rows>1){
													echo "<li> ";
													echo "Ont réussi avec Distinction : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A réussi avec Distinction : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_D = $rslt_etud_D->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_D["nomEtud"]."&nbsp;&nbsp;".$tb_etud_D["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_D["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}

									$rqt_slct_etud_S = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.prctg )>=50) AND ((tb_deliberation.mention )='S')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_S = $conDb->query($rqt_slct_etud_S)){
										if($rslt_etud_S->num_rows>0){
											echo "<ul>";
												if($rslt_etud_S->num_rows>1){
													echo "<li> ";
													echo "Ont réussi avec Satisfaction : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A réussi avec Satisfaction : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_S = $rslt_etud_S->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_S["nomEtud"]."&nbsp;&nbsp;".$tb_etud_S["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_S["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}
								} 
							?>
							<p>
								En foi de quoi, nous déclarons close la 
								<?php 
									if($session=="s1"){
										echo "&nbsp; 1<sup>ère</sup> &nbsp;";
									}
									else{
										echo "&nbsp; 2<sup>ème</sup> &nbsp;";
									} 
								?>
								 Session de l'année académique <strong> <?php echo $an_aca ; ?></strong> en <strong> <?php echo $idPromo." ".$_SESSION['designOp']; ?></strong>

							</p>
							<p>
								<div align="right">
									Fait &agrave; <?php echo $_SESSION['villeEts']; ?>, le <?php echo $jour."/".$moi."/".$annee_encours; ?>
								</div>
							</p>
							<p>
								<div style="width:100%; height:auto;">
									<table width="100%">	
										<tr>
											<td><div align="center">Le Président du Jury</div></td>
											<td><div align="center">Le Secrétaire du Jury</div></td>
											<td><div align="center">Les Membres du Jury</div></td>
										</tr>
									</table>
									
								</div>
							</p>
						</div>
					</div>
					<?php 
					if (!isset($_GET['imPRessIoN'])) {
						echo "<p  align='right'>";	
						echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$idPromo."&oPtiOn=".$idOp."&imPRessIoN&pV&".$session."&aca=".$an_aca."'>"; 
						?>
						<div style="width:60px; padding: 50px; float: right;">
							<img src="B_mbindi/Biamunda/icon/print.ico" class="ico"><br>
							Imprimer
						</div>
						<?php 
						echo "</a>";		
						echo "</p>";
						
					}
					else{
						?>

						<script type="text/javascript">
						  	window.print();
						  	//window.location.replace('?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo$_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&pV&');
						</script>

						<?php 
						//header ('location:?ffAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib');

					}

				}
				else
					{
					echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' class='echec'><h2 >Aucu cours n'est organis&eacute; en <br/>".$idPromo."&nbsp;".$_SESSION['designOp']."</h2><br/><br/></div>";
				}
			}
			else{
				echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'Erreur système dû à la requêtte</h2></div>";
			}
		}
		else{
			echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'>Pour charger la grille, il faut d'abord indiquer la promotion ainsi que l'option</h2></div>";
		}
	}
	//ANCIEN SYSTEME
	if ($_SESSION['systPromo']=="N"){
		?>
		<style type="text/css">
				<!--
				<?php 
					if (isset($_GET['imPRessIoN'])) {
				 		?>
						.pv{
							width: 700px; 
						}
						<?php  
					}
					else{
						?>
						.pv{
							width: 80%; 
							border: solid 1px #c3c3c3;
							padding: 5%;
							box-shadow: 5px 5px 20px #c3c3c3;
						}
						<?php  
					}
				?>
				-->
		</style>
		<?php 

		if(!empty($_GET['iDfaC']) and !empty($_GET['pRomotIon']) and !empty($_GET['oPtiOn'])){
			
			$idFac= $_GET['iDfaC'];
			$idPromo = $_GET['pRomotIon'];
			$idOp = $_GET['oPtiOn'];
			$designFac = "";
			$nbrcours=0;
			$cotePonderee=0;
			$pourcentage=0;
			$cotePonderee_etud=0;
			$nbrReussite = 0;
			if (isset($_GET["s2"])) {
				$session = "s2";		
			}
			else{
				$session = "s1";
			}		
			$rqt_slct_fac = "select * from tb_faculte where idFac = '".$idFac."'";
			
			if($exe_rqt_slct_fac= $conDb->query($rqt_slct_fac)){
				if($tb_fac = $exe_rqt_slct_fac->fetch_assoc()){
					$designFac = $tb_fac['designFac'];
				}
			}
			
			$rqt_slct_delb = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."'";
			
			if($exe_rqt_slct_delb = $conDb->query($rqt_slct_delb)){
				if($exe_rqt_slct_delb->num_rows>0){
					$nbEtud = $exe_rqt_slct_delb->num_rows;
					if (!isset($_GET['imPRessIoN'])) {
						echo "<br>";
					}
					?>
					<div class="pv">
						<div align="center" style="text-transform:uppercase;">
							ENSEIGNEMENT SUPERIEURET UNIVERSITAIRE <br>
							<?php echo $nom_etablissement ; ?><br />
							&laquo; <?php echo $sigle_tb_etablissement ; ?> &raquo;<br>
							<div style="width:50px; height:50px;">
								<a href="<?php echo "?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$_GET['pRomotIon']."&oPtiOn=".$_GET['oPtiOn']."&cOTe&gRillDelib" ?>">
									<img src="B_mbindi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" width="100%" height="100%"/>
								</a>
							</div>SECRETARIAT GENERAL ACADEMIQUE <br>	
							<?php 
								if($_SESSION['typEts']=="UN") {
									echo "FACULTE : " ;
								}
								else{
									echo "SECTION : "; 
								}
								echo $designFac;  
							?>
							<br/>
							<br/>
						</div>
						<div align="center" style="width:100%; height: auto; font-size:2em; font-weight:bold;">
							<div align="center" style="width:90%; height: auto;  border:solid 2px #000000; border-radius:16px 16px; margin-top: 10px; margin-bottom:10px; padding:5px; background: #dcdcdc;">
								PROCES-VERBAL DE DELIBERATION
							</div>
						</div>

						<div align="justify">
							<p>Le jury chargé de l'organisation des épreuves de la
								<?php 
									if($session=="s1"){
										echo "&nbsp; 1<sup>ère</sup> &nbsp;";
									}
									else{
										echo "&nbsp; 2<sup>ème</sup> &nbsp;";
									} 
								?>
								Session de l'année académique <strong> <?php echo $an_aca ; ?></strong> en <strong> <?php echo $idPromo." ".$_SESSION['designOp']; ?></strong> a reçu les examens de <?php echo $nbEtud; ?> candidats.</p>
							<p>Après délibération à huis clos, le Jury a pris les décisions suivantes :</p> 
							<ul>
								<li> 
									<?php 
										$rqt_slct_A = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='A'";
										if($exe_rqt_slct_A = $conDb->query($rqt_slct_A)){
											if($exe_rqt_slct_A->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_pld->num_rows>1)
													echo "Ont obtenus la note A (EXCELLANT) : ".$exe_rqt_slct_A->num_rows. " Etudiants";
												else
													echo "A obtenu la note A (EXCELLANT) : ".$exe_rqt_slct_A->num_rows. " Etudiant";
											}
											else{
												echo "Ont obtenus la note A (EXCELLANT) : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_B = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='B'";
										if($exe_rqt_slct_B = $conDb->query($rqt_slct_B)){
											if($exe_rqt_slct_B->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_B->num_rows>1)
													echo "Ont obtenus la note B (TRES BIEN)  : ".$exe_rqt_slct_B->num_rows. " Etudiants";
												else
													echo "A obtenu  la note B (TRES BIEN)  : ".$exe_rqt_slct_B->num_rows. " Etudiant";
											}
											else{
												echo "Ont obtenus la note B (TRES BIEN)  : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_C = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='C'";
										if($exe_rqt_slct_C = $conDb->query($rqt_slct_C)){
											if($exe_rqt_slct_C->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_C->num_rows>1)
													echo "Ont obtenus la note C (BIEN) : ".$exe_rqt_slct_C->num_rows. " Etudiants";
												else
													echo "A obtenu la note C (BIEN) : ".$exe_rqt_slct_C->num_rows. " Etudiant";
											}
											else{
												echo "Ont obtenus la note C (BIEN) :  NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_D = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='D'";
										if($exe_rqt_slct_D = $conDb->query($rqt_slct_D)){
											if($exe_rqt_slct_D->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_D->num_rows>1)
													echo " Ont obtenus la note D (ASSEZ BIEN)  : ".$exe_rqt_slct_D->num_rows. " Etudiants";
												else
													echo "A obtenu la note D (ASSEZ BIEN)  : ".$exe_rqt_slct_D->num_rows. " Etudiant";
											}
											else{
												echo "Ont obtenus la note D (ASSEZ BIEN)  : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li> 
									<?php 
										$rqt_slct_E = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='E'";
										
										//$rqt_slct_E = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='E'";
										if($exe_rqt_slct_E = $conDb->query($rqt_slct_E)){
											if($exe_rqt_slct_E->num_rows>0){
												$nbrReussite=$nbrReussite+1;
												if($exe_rqt_slct_E->num_rows>1)
													echo "Ont obtenus la note E (PASSABLE)   : ".$exe_rqt_slct_E->num_rows. " Etudiants";
												else
													echo "A obtenu la note E (PASSABLE)   : ".$exe_rqt_slct_E->num_rows. " Etudiant";
											}
											else{
												echo "Ont obtenus la note E (PASSABLE)   : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li>
									<?php 
										$rqt_slct_F = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='F'";
										if($exe_rqt_slct_F = $conDb->query($rqt_slct_F)){
											if($exe_rqt_slct_F->num_rows>0){
												if($exe_rqt_slct_F->num_rows>1)
													echo "Sont Ajournés avec la note F (INSUFFISANT) : ".$exe_rqt_slct_F->num_rows. " Etudiants";
												else
													echo "Est Ajourné avec la note F (INSUFFISANT)  : ".$exe_rqt_slct_F->num_rows. " Etudiant";
											}
											else{
												echo "Sont Ajournés avec la note F (INSUFFISANT)  : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>
								<li>
									<?php 
										$rqt_slct_G = "select * from tb_deliberation where idPromo = '".$idPromo."' and idOp = '".$idOp."' and idAnAca = '".$an_aca."' and session = '".$session."' and mention='G'";
										if($exe_rqt_slct_G = $conDb->query($rqt_slct_G)){
											if($exe_rqt_slct_G->num_rows>0){
												if($exe_rqt_slct_G->num_rows>1)
													echo "Sont Ajournés avec la note G (INSATISFAISANT) : ".$exe_rqt_slct_G->num_rows. " Etudiants";
												else
													echo "Est Ajourné avec la note G (INSATISFAISANT)  : ".$exe_rqt_slct_G->num_rows. " Etudiant";
											}
											else{
												echo "Sont Ajournés avec la note G (INSATISFAISANT)  : NEANT";
											}
										}
										else{
											echo "Erreur";
										}
									 ?>
								</li>

							</ul>

							<?php 
								if ($nbrReussite>0) {
									echo "<p>Ainsi : </p>";

									$rqt_slct_etud_A = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.mention )='A')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_A = $conDb->query($rqt_slct_etud_A)){
										if($rslt_etud_A->num_rows>0){
											echo "<ul>";
												if($rslt_etud_A->num_rows>1){
													echo "<li> ";
													echo "Ont obtenus la note A (EXCELLANT) : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A obtenu la note A (EXCELLANT) : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_A = $rslt_etud_A->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_A["nomEtud"]."&nbsp;&nbsp;".$tb_etud_A["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_A["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}
										
									$rqt_slct_etud_B = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.mention )='B')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_B = $conDb->query($rqt_slct_etud_B)){
										if($rslt_etud_B->num_rows>0){
											echo "<ul>";
												if($rslt_etud_B->num_rows>1){
													echo "<li> ";
													echo "Ont obtenus la note B (TRES BIEN) : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A obtenu la note B (TRES BIEN) : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_B = $rslt_etud_GD->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_B["nomEtud"]."&nbsp;&nbsp;".$tb_etud_B["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_B["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}

									$rqt_slct_etud_C = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.mention )='C')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_C = $conDb->query($rqt_slct_etud_C)){
										if($rslt_etud_C->num_rows>0){
											echo "<ul>";
												if($rslt_etud_C->num_rows>1){
													echo "<li> ";
													echo "Ont obtenus la note C (BIEN) : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A obtenu la note C (BIEN) : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_C = $rslt_etud_C->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_C["nomEtud"]."&nbsp;&nbsp;".$tb_etud_C["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_C["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}

									$rqt_slct_etud_D = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.mention )='D')) ORDER BY tb_etudiant.nomEtud";
									if($rslt_etud_D = $conDb->query($rqt_slct_etud_D)){
										if($rslt_etud_D->num_rows>0){
											echo "<ul>";
												if($rslt_etud_D->num_rows>1){
													echo "<li> ";
													echo "Ont obtenus la note D (ASSEZ BIEN)  : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A obtenu la note D (ASSEZ BIEN)  : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_D = $rslt_etud_D->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_D["nomEtud"]."&nbsp;&nbsp;".$tb_etud_D["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_D["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}
									$rqt_slct_etud_E = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.idPromo)='".$idPromo."') AND ((tb_deliberation.idOp)='".$idOp."') AND ((tb_deliberation.idAnAca)='".$an_aca."') AND ((tb_deliberation.session)='".$session."') AND ((tb_deliberation.mention )='E')) ORDER BY tb_etudiant.nomEtud";
									if($rqt_slct_etud_E = $conDb->query($rqt_slct_etud_E)){
										if($rqt_slct_etud_E->num_rows>0){
											echo "<ul>";
												if($rqt_slct_etud_E->num_rows>1){
													echo "<li> ";
													echo "Ont obtenus la note E (PASSABLE) : ";
													echo "</li>";
												}
												else{
													echo "<li> ";
													echo "A obtenu la note E (PASSABLE) : ";
													echo "</li>";
												}
												echo "<ol>";
													while($tb_etud_E = $rqt_slct_etud_E->fetch_assoc()) {
														echo "<li>";
														echo $tb_etud_E["nomEtud"]."&nbsp;&nbsp;".$tb_etud_E["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_E["prenomEtud"];
														echo "</li>";
													}
												echo "</ol>";
											echo "</ul>";
										}
										
									}
									else{
										echo "<ul><il class='erreur'>Erreur</il></ul>";
									}
								} 
							?>
							<p>
								En foi de quoi, nous déclarons close la 
								<?php 
									if($session=="s1"){
										echo "&nbsp; 1<sup>ère</sup> &nbsp;";
									}
									else{
										echo "&nbsp; 2<sup>ème</sup> &nbsp;";
									} 
								?>
								 Session de l'année académique <strong> <?php echo $an_aca ; ?></strong> en <strong> <?php echo $idPromo." ".$_SESSION['designOp']; ?></strong>

							</p>
							<p>
								<div align="right">
									Fait &agrave; <?php echo $_SESSION['villeEts']; ?>, le <?php echo $jour."/".$moi."/".$annee_encours; ?>
								</div>
							</p>
							<p>
								<div style="width:100%; height:auto;">
									<table width="100%">	
										<tr>
											<td><div align="center">Le Président du Jury</div></td>
											<td><div align="center">Le Secrétaire du Jury</div></td>
											<td><div align="center">Les Membres du Jury</div></td>
										</tr>
									</table>
									
								</div>
							</p>
						</div>
					</div>
					<?php 
					if (!isset($_GET['imPRessIoN'])) {
						echo "<p  align='right'>";	
						echo "<a href='?fAculTe&iDfaC=".$_GET['iDfaC']."&pRomotIon=".$idPromo."&oPtiOn=".$idOp."&imPRessIoN&pV&".$session."&aca=".$an_aca."'>"; 
						?>
						<div style="width:60px; padding: 50px; float: right;">
							<img src="B_mbindi/Biamunda/icon/print.ico" class="ico"><br>
							Imprimer
						</div>
						<?php 
						echo "</a>";		
						echo "</p>";
						
					}
					else{
						?>

						<script type="text/javascript">
						  	window.print();
						  	//window.location.replace('?fAculTe&iDfaC=<?php echo $_GET['iDfaC']; ?>&pRomotIon=<?php echo$_GET['pRomotIon']; ?>&oPtiOn=<?php echo $_GET['oPtiOn']; ?>&cOTe&pV&');
						</script>

						<?php 
						//header ('location:?ffAculTe&iDfaC='.$_GET['iDfaC'].'&pRomotIon='.$_GET['pRomotIon'].'&oPtiOn='.$_GET['oPtiOn'].'&cOTe&gRillDelib');

					}

				}
				else
					{
					echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' class='echec'><h2 >Aucu cours n'est organis&eacute; en <br/>".$idPromo."&nbsp;".$_SESSION['designOp']."</h2><br/><br/></div>";
				}
			}
			else{
				echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'Erreur système dû à la requêtte</h2></div>";
			}
		}
		else{
			echo "<div align='center' style='background:#FFFFFF;margin-top:5%;' ><h2 class='echec'>Pour charger la grille, il faut d'abord indiquer la promotion ainsi que l'option</h2></div>";
		}
	}
}
?>
