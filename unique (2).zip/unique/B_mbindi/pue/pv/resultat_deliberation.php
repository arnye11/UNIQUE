<?php 
	if (isset($_GET["resultat_de_deliberation"])){
		$cid="";
		$idAca="";
		$session="";
		$resultDelib = false;
		if (isset($_POST["btChercherRslt"])){
			$cid = filter_input(INPUT_POST,'cid', FILTER_SANITIZE_SPECIAL_CHARS);
			$idAca = filter_input(INPUT_POST,'idAca', FILTER_SANITIZE_SPECIAL_CHARS);
			$session = filter_input(INPUT_POST,'session', FILTER_SANITIZE_SPECIAL_CHARS);
		}
		?>
		<style type="text/css">
			.resultat{
				width: 60%;
				border: solid 1px #C3C3C3C3;
			}

			.x{
				display: inline-block;
				float: right;
				position: relative;
				width: 50px;
				height: 50px; 
				line-height: 50px;
				background:#003858; 
				color:#FFFFFF; 
				font-size:1.5em; 
				text-align: center;
				
			}
			.x:hover{
				background: #ff0000;
			}
			@media (max-width : 60em){
				.resultat{
					width: 94%;
				}

			}
			
		</style>

		<div class="resultat">
			<a href="?accueil"><div class="x">x</div></a>
			<div style="background:#003858; color:#FFFFFF; font-size:1.5em; text-align: center;height: 50px; line-height: 50px; ">Veuillez saisire votre CID 
			</div>
			<div >
				<form method="post">
					<div style="margin:20px;">
						<input type="text" name="cid" style="width:40%;" placeholder="Code d'identification (CID)" value="<?php echo $cid; ?>" autofocus >&nbsp;
						<select name="idAca"  style="width:20%;">
							<?php 
								$rqtaca = "select * from  tb_an_aca ORDER BY idAnAca asc";
								if($exe_rqtaca = $conDb->query($rqtaca)){
								  	echo "<option value=''>Ann&eacute;e</option>";
									while($tb_aca = $exe_rqtaca->fetch_assoc()) {
										?>
					        				<option value="<?php echo $tb_aca['idAnAca']; ?>"><?php echo $tb_aca['idAnAca']; ?></option>
					        			<?php 
									}
								}
								else{
									echo  "<option value=''>Désolé! Il y a erreur</option>";
								}
							?>
					    </select> &nbsp;
					    <select name="session"  style="width:20%;">
					        <option value="">Session</option>
					        <option value="s1">1ere Session</option>
					        <option value="s2">2eme Session</option>		
					    </select>
					
						<input type="submit" name="btChercherRslt" value="OK" style="width:10%;">
					</div>
				</form>
			</div>

			<?php 
				if (isset($_POST["btChercherRslt"])){
					$cid = filter_input(INPUT_POST,'cid', FILTER_SANITIZE_SPECIAL_CHARS);
					$idAca = filter_input(INPUT_POST,'idAca', FILTER_SANITIZE_SPECIAL_CHARS);
					$session = filter_input(INPUT_POST,'session', FILTER_SANITIZE_SPECIAL_CHARS);

					
					if($cid =="" || $idAca =="" || $session ==""){
						echo "<div class='erreur'>Veuillez remplire tous les champs</div>";
					}
					else{
						//$rqt_slct_etud_delib = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE ((tb_deliberation.matricEtud)='".$cid."')";
						$rqt_slct_etud_delib = "SELECT tb_deliberation.*, tb_etudiant.* FROM tb_deliberation RIGHT JOIN tb_etudiant ON tb_deliberation.matricEtud = tb_etudiant.matricEtud WHERE (((tb_deliberation.matricEtud)='".$cid."') AND ((tb_deliberation.idAnAca)='".$idAca."') AND ((tb_deliberation.session)='".$session."'))";
						if($rslt_etud_delib = $conDb->query($rqt_slct_etud_delib)){
							if($rslt_etud_delib->num_rows>0){
								if($tb_etud_delib = $rslt_etud_delib->fetch_assoc()) {
									$resultDelib=true;
									?>
									<div align="left" style="font-weight:bold; color:#009745; width:90%;">Resultat : </div><br>
									<table style="width:90%;">
									 	<tr>
									 		<td>
									 			<div style="width:80px; height: 90px; display:inline-block; float:left;line-height: 90px; border:solid 1px #c3c3c3; text-align: center;">
									 				<img src="B_mbindi/Biamunda/media/<?php echo $tb_etud_delib['matricEtud']."/".$tb_etud_delib['avantarEtud'];?>" alt="PHOTO" style="max-width:90%; max-height: 100%;">
									 			</div>
									 			<div style="height: 90px; display:inline-block; float:left;margin-left: 7px;">
									 				<?php 
									 					echo $tb_etud_delib["nomEtud"]."&nbsp;&nbsp;".$tb_etud_delib["postnomEtud"]."&nbsp;&nbsp;".$tb_etud_delib["prenomEtud"]."<br><br>";
														if ($tb_etud_delib["mention"]=="PGD") {
															echo "Plus grande distinction";
														}
														if ($tb_etud_delib["mention"]=="GD") {
															echo "Grande distinction";
														}
														if ($tb_etud_delib["mention"]=="D") {
															echo "Distinction";
														}
														if ($tb_etud_delib["mention"]=="S") {
															echo "Satisfaction";
														}
														if ($tb_etud_delib["mention"]=="A") {
															echo "Ajourné";
														}
														if ($tb_etud_delib["mention"]=="AA") {
															echo "Assumulé aux ajournés";
														}
														echo " avec ".$tb_etud_delib["prctg"]." % ";
									 					echo "<br> à la ";
									 					if ($session=="s1") echo "1ère ";
									 					else echo "2ème ";

									 					echo " Session.";
									 				?>

									 			</div>
									 			<div align='right' style="display:inline-block;float: right; position: relative;">
									 				<a href='?resultat_de_deliberation'>Un autre</a>
									 			</div>
									 		</td>
									 	</tr>
									</table>
									<p>Détailles</p>
									
									<?php
									
									$Nbr_echec=0;
									$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$tb_etud_delib['idPromo']."') AND ((tb_program_cours.idOp)='".$tb_etud_delib['idOp']."') AND ((tb_program_cours.idAnAca)='".$idAca."')) ORDER BY tb_cours.designCours";
									if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
										if($exe_rqt_slct_cours_Program->num_rows>0){
											$num=0;
											$nbrcours=$exe_rqt_slct_cours_Program->num_rows;
											?>
											<table style="width:90%;" border="1" cellpadding="1" cellspacing="0" >
												<tr style="background:#bababa;">
													<th>N&deg;</th>
													<th>D&eacute;signation du cours</th>
													<th>C&ocirc;te</th>
												</tr>
												<?php
												while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){ 
													$num=$num+1;
													?>
													<tr style="background:#efefef;">
														<td>
															<div align="right">
																<?php echo $num; ?>
															</div>
														</td>
														<td>
															<?php echo $tb_programme_cours['designCours'];?>
														</td>
														<td>
															<div align="center">
																<?php 
																	$rqt_cote_etud = "select * from tb_cote where matricEtud ='".$tb_etud_delib['matricEtud']."' and idCours = '".$tb_programme_cours['idCours']."' and idAca = '".$idAca."'";
																	if($ex_rqt_cote_etud = $conDb->query($rqt_cote_etud)){
																		if($tb_cote = $ex_rqt_cote_etud->fetch_assoc()){
																			$cote1 = $tb_cote['cote_s1'];
																			$cote2 = $tb_cote['cote_s2'];
																			if($cote2>0){
																				if($cote2<10){
																					$Nbr_echec = $Nbr_echec+1;
																					echo "<div class='erreur'>";
																					echo $cote2 ;
																					echo "</div>";
																				}
																				else{
																					echo $cote2 ;
																				}
																			}
																			else{
																				if($cote1<10){
																					$Nbr_echec = $Nbr_echec+1;
																					echo "<div class='erreur'>";
																					echo $cote1 ;
																					echo "</div>";
																				}
																				else{
																					echo $cote1 ;
																				}
																			}
																		}
																		else{
																			echo "-";
																			$Nbr_echec=$Nbr_echec+1;
																		}
																	}
																	else{
																		echo "<span class='echec'>Erreur</span>";
																		$Nbr_echec=$Nbr_echec+1;
																	}			
																?>
															</div>
														</td>
													</tr>
													<?php 
												}
												?>
												<tr>
									                <td colspan="2">
									                	<div align="right" style="width:90%; margin-right: 3%;">NOMBRE D'ECHECS </div>
									                </td>
									                <td colspan="4"  style="background:#efefef;">
									                	<div align="right" style="font-weight: bold;margin-right: 10px;">
									                		<?php echo $Nbr_echec; ?></div>
									                </td>
												</tr>
											<table>
											<?php
										}
									}
									else{
										?>
										<tr>
						                    <td colspan="6">
						                    	<?php echo "Erruer de requete"; ?>
						                    </td>
						                </tr>
							            <?php
									}
								}
							}
							else{
								echo "<div class='erreur'>Pas d'information</div>";
							}
						}
						else{
							echo "<div class='erreur'>Erreur</div>";
						}
					}
				}

				
			?>
		</div>
		<?php
			
	}
 ?>


