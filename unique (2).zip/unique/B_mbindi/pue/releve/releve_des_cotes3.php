<?php
	if((isset($_GET['profil']) || isset($_GET['imPRessIoN'])) and isset($_GET['id']) and isset($_GET['rc'])){
		$cote1 =0;
		$cote2 =0;
		$cote_pond = 0;
		$tot_cote_pond=0;
		$ponderation=0;
		$tot_ponderation=0;
		$pourcentage =0;
		$Nbr_echec=0;
		$matriculEtud = $_GET['id'];
		$impression = false;
		$idInscrit=""; 

		$rqt_slct_etud = "SELECT tb_inscription.*, tb_etudiant.*, DAY(datenaissEtud) AS jrNais, MONTH(datenaissEtud) AS mmNais, YEAR(datenaissEtud) AS aaaaNais  FROM tb_etudiant INNER JOIN tb_inscription ON tb_etudiant.matricEtud = tb_inscription.matricEtud WHERE tb_etudiant.matricEtud='".$matriculEtud."'";
		if($exe_rqt_slct_etud =$conDb->query($rqt_slct_etud)){
			if($exe_rqt_slct_etud->num_rows>0){
				if($tb_Etud = $exe_rqt_slct_etud->fetch_assoc()){
					$matEtud = $tb_Etud['matricEtud'];
					$idInscrit = $tb_Etud['idInscrit'];
					?>
					<div <?php if(isset($_GET['imPRessIoN'])){?>  style="width: 100%; height:29.6em;" <?php  }?>>
						<?php
							if(!isset($_GET['imPRessIoN'])){
								?>
								<h3 align="center">Ap&eacute;r&ccedil;u du r&eacute;lev&eacute; des cotes</h3>
								<?php
							}
						?>
						<div style="
							<?php 
								if(isset($_GET['imPRessIoN'])){?> 
									width:99%; height: auto; 
									<?php 
								}
								else{ 
									?> 
									width:80%; border:solid 1px #000000; padding:8%; background:#FFCC66; 
									<?php 
								} ?>">
							<div style="width:100%; height:115px; border-bottom:ridge 5px #666666;">
								<table style="width:100%;">	
									<tr >
										<td style="width:100px;height:110px;">	
											<div style="width:100%; height:100%; " >
												<img src="B_mbidndi/Biamunda/icon/<?php echo $logo; ?>" alt="logo Ets" width="100%" height="100%"/>
											</div>
										</td>
										<td style=" " >
											<div align="center" style="font-size:1.1em; text-transform: uppercase; font-weight: bold;" >
												REPUBLIQUE DEMOCRATIQUE DU CONGO<br/>
												ENSEIGNEMENT SUPERIEUR ET UNIVERSITAIRE
												<br/>
												<?php echo $nom_etablissement ; ?><br />
												&laquo; <?php echo $sigle_tb_etablissement ; ?> &raquo;
											</div>
										</td>
										<td style="width:100px; height:110px; " align="right">
											<div style="width:100%; height:100%; ">
												<img src="<?php $_SERVER['DOCUMENT_ROOT'];?>/B_mbidndi/Biamunda/media/<?php echo $tb_Etud['matricEtud']."/".$tb_Etud['avantarEtud'];?>" alt="Pas de Photo" width="90%" height="100%" />
											</div>
										</td>
									</tr>
								</table>
							</div>

							<div align="right" style="width: 100%; height: 15px; font-size:11px; font-style:italic; ">
								<div align="left" style="width: 60%; display: inline;float: left; ">
									SECRETARIAT GENERAL ACADEMIQUE
								</div>
								<div align="right" style="width: 30%; display: inline;float: right;">
									<span> N&deg; <?php echo $tb_Etud['matricEtud']; ?></span>
								</div>
							</div>

							<div align="center" style="width:100%; height: auto; font-size:1.2em; font-weight:bold;">
								<div align="center" style="width:90%; height: auto;  border:solid 2px #000000; border-radius:16px 16px; margin-top: 10px; margin-bottom:10px; padding:5px;">
									RELEVE DES COTES N° <?php echo $tb_Etud['idInscrit']."-".$an_aca;?>
								</div>
							</div>

							<div style="font-size:12px; text-align:justify">
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								Je soussign&eacute;, <strong>Chef de Travaux EPUPUA MUSENDUE Dieudonn&eacute;</strong>, Secr&eacute;taire G&eacute;n&eacute;ral Acad&eacute;mique de l'<?php echo $nom_etablissement ; ?>, <?php echo $sigle_tb_etablissement ; ?> en sigle, d&eacute;clare que &nbsp;
								<?php 
									if ($tb_Etud['sexeEtud']=="M"){ 
										echo "le nomm&eacute; ";
									}
									else { 
										echo "la nomm&eacute;e ";
									}

									echo "&nbsp;<strong style='text-transform:uppercase;'>";
									echo $tb_Etud['nomEtud']."&nbsp;".$tb_Etud['postnomEtud']."&nbsp;".$tb_Etud['prenomEtud'];
									echo "</strong>, &nbsp;"; 

									if($tb_Etud['sexeEtud']=="M"){ 
										echo "n&eacute; &agrave; ";
									}
									else { 
										echo "n&eacute;e &agrave; ";
									} 
									echo  $tb_Etud['lieunaisEtud'].", &nbsp; le ";
									if($tb_Etud['jrNais']<10){echo 0;} echo $tb_Etud['jrNais']."/ "; 
									if($tb_Etud['mmNais']<10){echo 0;} echo $tb_Etud['mmNais']."/ ".$tb_Etud['aaaaNais']."&nbsp;";
									
									
									echo "a r&eacute;ussi &agrave; l'issue de la "; 
									
									$rqt_slct_cote_etud_s2 = "select * from tb_cote where matricEtud ='".$tb_Etud['matricEtud']."'  and idAca = '".$an_aca."' and cote_s2 >0 ";
									if($ex_rqt_slct_cote_etud_s2 = $conDb->query($rqt_slct_cote_etud_s2)){
										if($tb_cote2 = $ex_rqt_slct_cote_etud_s2->fetch_assoc()){
											echo "&nbsp; DEUXIEME &nbsp;";
										}
										else{
											echo "&nbsp; PREMIERE &nbsp; ";
										}
									}
									else{
										echo "&nbsp; <span class='erreur'>ERREUR SESSION</span> &nbsp; ";
										}
									
									
									echo "SESSION de l'ann&eacute;e acad&eacute;mique ".$an_aca." aux examens portant sur les mati&egrave;res suivantes du programme de <span style='text-transform:uppercase;'>"; 
									
									$rqt_promo = "select * from tb_promotion where idPromo ='".$tb_Etud['idProm']."'";
									if($ex_rqt_promo = $conDb->query($rqt_promo)){
										if($tb_promotion = $ex_rqt_promo->fetch_assoc()){
											echo "&nbsp; ".$tb_promotion['designPromo']." &nbsp;";
										}
										else{
											echo "&nbsp; <span class='erreur'>PAS DE PROMOTION</span> &nbsp; ";
										}
									}
									else{
										echo "&nbsp; <span class='erreur'> ERREUR PROMOTION </span> &nbsp; ";
									}

									$rqt_op = "select * from tb_option where idOp ='".$tb_Etud['idOp']."'";
									if($ex_rqt_op = $conDb->query($rqt_op)){
										if($tb_op = $ex_rqt_op->fetch_assoc()){
											echo "&nbsp; ".$tb_op['designOp']." &nbsp;";
										}
										else{
											echo "&nbsp; <span class='erreur'>PAS DE PROMOTION</span> &nbsp; ";
										}
									}
									else{
										echo "&nbsp; <span class='erreur'> ERREUR PROMOTION </span> &nbsp; ";
									}

									echo "</span>";
								?>
							</div>

							<div align="center" style="width:100%; ">
							  	<table width="100%" align="center" border="0" style="">
						            <tr style="text-align:center;color:#FFFFFF;font-size:10;">
						            	<td colspan="2">&nbsp;</td>
						                <td colspan="2" style="background:#666666;">VOL. HORAIRE </td>
						                <td colspan="2" style="background:#666666;  ">COTES</td>
						            </tr>
						            <tr style="background:#666666; color:#FFFFFF; text-align:center;font-size:10;">
						                <td>N&deg;</td>
						                <td>COURS</td>
						                <td>H.T</td>
						                <td>H.P</td>
						                <td>Brut.</td>
						                <td>Pond.</td>
						            </tr>
									<?php
										$rqt_slct_cours_Program = "SELECT tb_program_cours.*, tb_cours.designCours FROM tb_cours RIGHT JOIN tb_program_cours ON tb_cours.idCours = tb_program_cours.idCours WHERE (((tb_program_cours.idPromo)='".$tb_Etud['idProm']."') AND ((tb_program_cours.idOp)='".$tb_Etud['idOp']."') AND ((tb_program_cours.idAnAca)='".$an_aca."')) ORDER BY tb_cours.designCours";//COURS 
		
										if($exe_rqt_slct_cours_Program = $conDb->query($rqt_slct_cours_Program)){
											if($exe_rqt_slct_cours_Program->num_rows>0){
												$num=0;
												$nbrcours=$exe_rqt_slct_cours_Program->num_rows;
				
												while($tb_programme_cours = $exe_rqt_slct_cours_Program->fetch_assoc()){ 
													$num=$num+1;
													$cote_pond=0;
													$ponderation=0;
													$ponderation=(($tb_programme_cours['ht']+$tb_programme_cours['hp'])/15);
													$tot_ponderation = $tot_ponderation+($ponderation*20);
													?> 
													<tr style="background:#efefef;<?php if($nbrcours>20){?>  font-size: 11px;<?php  }?>">
														<td>
															<div align="right">
																<?php echo $num; ?>
															</div>
														</td>
														<td>
															<div align="justify" style="padding-left:4px;">
																<?php echo $tb_programme_cours['designCours'];?> 
															</div>
														</td>
														<td><div align="center"><?php echo $tb_programme_cours['ht'];?></div></td>
														<td><div align="center"><?php echo $tb_programme_cours['hp'];?></div></td>
														<td>
															<div align="center">
															<?php 
															$rqt_cote_etud = "select * from tb_cote where matricEtud ='".$tb_Etud['matricEtud']."' and idCours = '".$tb_programme_cours['idCours']."' and idAca = '".$an_aca."'";
															if($ex_rqt_cote_etud = $conDb->query($rqt_cote_etud)){
																if($tb_cote = $ex_rqt_cote_etud->fetch_assoc()){
																	$cote1 = $tb_cote['cote_s1'];
																	$cote2 = $tb_cote['cote_s2'];
																	if($cote2>0){
																		if($cote2<10){
																			$cote_pond = ($cote2*$ponderation);
																			$tot_cote_pond =$tot_cote_pond+$cote_pond;
																			$Nbr_echec = $Nbr_echec+1;
																			echo $cote2 ;
																		}
																		else{
																			$cote_pond = ($cote2*$ponderation);
																			$tot_cote_pond =$tot_cote_pond+$cote_pond;
																			echo $cote2 ;
																		}
																	}
																	else{
																		if($cote1<10){
																			$cote_pond = ($cote1*$ponderation);
																			$tot_cote_pond =$tot_cote_pond+$cote_pond;
																			$Nbr_echec = $Nbr_echec+1;
																			echo $cote1 ;
																		}
																		else{
																			$cote_pond = ($cote1*$ponderation);
																			$tot_cote_pond =$tot_cote_pond+$cote_pond;
																			echo $cote1 ;
																		}
																	}
																}
																else{
																	echo "-";
																	$Nbr_echec=$Nbr_echec+1;
																}
															}
															else{
																echo "<span class='echec'>Erreur</span>";
																$Nbr_echec=$Nbr_echec+1;
															}			
															?>
															</div>
														</td>
														<td>
															<div align="right" style="margin-right: 10px;">
																<?php echo round($cote_pond, 0)."/".round($ponderation*20); ?>
															</div>
														</td>
													</tr>
													<?php 
												}
												?>

												<tr >
									                <td colspan="2">
									                	<div align="right" style="width:90%; margin-right: 3%;">COTE TOTALE PONDEREE OBTENUE</div>	 
									                </td>
									                <td colspan="4"  style="background:#e9e9e9;">
														<div align="right" style="font-weight: bold;margin-right: 10px;">
															<?php 
															if($tot_cote_pond!=0){
																$pourcentage=(($tot_cote_pond*100)/$tot_ponderation);
																echo round($tot_cote_pond,0)."/".round($tot_ponderation,0);
																}
															else{
																echo 0;
															} 
															?>
														</div>
													</td>
									            </tr>
												<tr>
									                <td colspan="2">
									                	<div align="right" style="width:90%; margin-right: 3%;">NOMBRE D'ECHECS </div>
									                </td>
									                <td colspan="4"  style="background:#efefef;">
									                	<div align="right" style="font-weight: bold;margin-right: 10px;">
									                		<?php echo $Nbr_echec; ?></div>
									                </td>
												</tr>
												<tr>
									                <td colspan="2">
									                	<div align="right" style="width:90%; margin-right: 3%;">POURCENTAGE</div>
									                </td>
									                <td colspan="4"  style="background:#efefef;">
									                	<div align="right" style="font-weight: bold;margin-right: 10px;">
									                		<?php echo round($pourcentage,1)."&nbsp;" ; ?>%
									                	</div>
									                </td>
												</tr>
												<tr>
									                <td colspan="2">
									                	<div align="right" style="width:90%; margin-right: 3%;">MENTION</div>
									                </td>
									                <td colspan="4" style="background:#efefef;">
														<div align="right" style="text-transform:uppercase;font-weight: bold;margin-right: 10px;">
															<?php 
															if($pourcentage>=90){
																echo "Plus grande Distinction"; 
																$impression = true;
															} 
															if($pourcentage>=80 and $pourcentage<90){
																echo "Grande Distinction"; 
																$impression = true;
															} 
															if($pourcentage>=70 and $pourcentage<80){
																echo "Distinction"; 
																$impression = true;
															} 
															if($pourcentage>=50 and $pourcentage<70){
																echo "Satisfaction";  
															} 
															if($pourcentage<50){
																echo "Ajourn&eacute;";
															} 
																					
															?>
														</div>				
													</td>
												</tr>

												<tr>
							                      	<td colspan="6">
							                      		<div align="right" style="width:100%; ">
															<p>
																Fait &agrave; Kabinda, le <?php echo $jour."/".$moi."/".$annee_encours; ?>
															</p>
														</div>
														<div style="width:100%; height:60px;">
															<div align="center" style="width:48%; height:60px; display: inline; float: left;">
																<strong> </strong>
															</div>
															<div align="center" style="width:48%; height:60px;isplay: inline; float: right;">
																<p>
																	<strong>Secrétaire Général Académique</strong>
																</p>
																<br>
																<p>
																	<strong style="border-bottom: solid 1px;">EPUPUA MUSENDWE Dieudonn&eacute;</strong><br>
																	<strong>Chef de Travaux</strong> 
																</p>
															</div>
														</div>
							                    	</td>
							                    </tr>
												<?php
											}
											else{
												?>
												
								                <?php
											}
										}
										else{
											?>
											<tr>
							                    <td colspan="6">
							                    	<?php echo "Erruer de requete"; ?>
							                    </td>
							                </tr>
								            <?php
										}
									?>           
								</table>
							</div>


							
						</div>
					</div>

					<?php 
					if (isset($_GET["imPRessIoN"])) {
						?> 
						<div  align="center" style="width:350px;height:25px; border-radius:50px; position:fixed; top:auto; bottom:1%; left:2%; right:auto; font-size:20px; font-family:'Century Schoolbook'; border:solid 1px #A0A0A4; color:#A0A0A4; ">
							<?php
								$string = $sigle_tb_etablissement.$idInscrit."-".$_GET["id"] ; 
								echo "<img alt='testing' src='barcode.php?codetype=code39&size=18&text=".$string."&print=true'/>";
							?>
						</div>
						<?php
					}
					
					if (!isset($_GET["imPRessIoN"])) {
						?>
						 
						 <a href="?imPRessIoN&id=<?php echo $tb_Etud['matricEtud'];?>&doc&rc">Imprimer</a> 
						<?php
					}
				}
			}
		}
	}
?>
