<?php 
	$rqt_list_cours = "select * from  tb_cours where idOp = '".$idOp."' and idPromo = '".$idPromo."' ORDER BY designCours ";//COURS 
	if($exe_rqt_list_cours = mysql_query($rqt_list_cours))
		{
		while($result_rqt_list_cours = mysql_fetch_assoc($exe_rqt_list_cours)) //SI EXECUTION, ON RECUPERE SES INFORMATION 
			{
			 ?>
			 <a href="?gerer_cote&fIcHeScoTe&idPromo=<?php echo $idPromo; ?>&idOp=<?php echo $idOp; ?>&cours=<?php echo $result_rqt_list_cours['idCours']; ?>" style="height:auto;">
			 <div style="background:#333333; border:solid 1px #000000; width:98%; height:auto; padding:1px; color:#FFFFFF;margin-bottom:5px; vertical-align:baseline;">
			 <?php 
			echo $result_rqt_list_cours['designCours'];
			?>
			</div>
			</a>
			<?php
			}
		if(($idPromo =="G3") || ($idPromo=="L2"))
			{
			?>
			 <a href="?gerer_cote&fIcHeScoTe&idPromo=<?php echo $idPromo; ?>&idOp=<?php echo $idOp; ?>&cours=<?php if($idPromo =="G3"){echo "TFC";}else if($idPromo=="L2") {echo "M";}?>" style="height:auto;">
			 <div style="background:#333333; border:solid 1px #000000; width:98%; height:auto; padding:1px; color:#FFFFFF;margin-bottom:5px; vertical-align:baseline;">
			 <?php 
			if($idPromo =="G3"){echo "TFC";}else if($idPromo=="L2") {echo "M�moire";}
			?>
			</div>
			</a>
			<?php
			
			?>
			 <a href="?gerer_cote&fIcHeScoTe&idPromo=<?php echo $idPromo; ?>&idOp=<?php echo $idOp; ?>&cours=STG" style="height:auto;">
			 <div style="background:#333333; border:solid 1px #000000; width:98%; height:auto; padding:1px; color:#FFFFFF;margin-bottom:5px; vertical-align:baseline;">
			 STAGE
			</div>
			</a>
			<?php
			
			}
		}
	else
		{
		echo "Impossible de retrouver les cours";
		}
?>