<style type="text/css">
<!--
.icon{width:16px; height:16px;}
a:link, a:visited {font-weight:inherit; text-decoration:none;}	
body {
	margin:0px; 
	text-align:center; 
	font-family: 'Century Gothic';  
	<?php 
		if(!isset($_GET["imPRessIoN"])){ ?>
			background:#f2f0f0; 
			<?php 
		}
		//POUR L'ANNEE ACADEMIQUE DIFFERENTE DE LANNEE ENCOURS, body couleur rouge
		if($_SESSION['idAnAca'] != $an_aca){
		 	?>
			/*background:#FF0000;*/
			<?php 
		}
	?>
} 
#listAca{
	width:95px; 
	border:solid 1px #c52363; 
	float: right;
	position: relative;
	position: sticky;
	top:8px;
	right: 20px;
}

div.et_unique, div.divformAut {
		DISPLAY: block; visibility: hidden;position: absolute;
	}
<?php 
		if($_SESSION['idAnAca'] != $an_aca){
	 	?>
		.aca_pas {
		background:#7F0000;
		}
	<?php }?>
/******__________AUTHATIFICATION___________________________________*******/


/*_________________ CORPS ___________________________________*/
/*_________________  2 DIV : LIST_INFO ET FORM_AMS ___________________*/

.divList_Info, .div_Form_AMS{display:inline; border:solid 1px #A5A5A5;}
.divList_Info{width:25%; float:left;  padding-left: 5px; padding-right: 5px;}
.div_Form_AMS{width:73%; float:right;}
@media (max-width : 60em){
   	.divList_Info, .div_Form_AMS{
	width:99%; 
	}
}
/*_________________   DIV :  profil_apercu_inscrit  ___________________________________*/
.profil_apercu_inscrit1{border:solid 1px #FF66CC; display:inline; float:left; width:29%; height:75px;}
.profil_apercu_inscrit2{border:solid 1px #FF66CC; display:inline; float:left; width:67%; height:75px; padding-left:5px;}
/*_________________   DIV :  profil_apercu_liste_inscrit  ___________________________________*/
.profil_apercu_inscrit11{border:solid 1px #FF66CC; display:inline; float:left; width:13%; height:58px;}
.profil_apercu_inscrit22{border:solid 1px #FF66CC; display:inline; float:left; width:75%; height:58px; padding-left:5px;}
.profil_apercu_inscrit33{border:solid 1px #FF66CC; display:inline; float:left; width:8%; height:58px; text-align:center;}

/*_________________   DIV :  profil_  ___________________________________*/
.profil_{
	width:100%; 
	height:auto;
	border:solid 1px #969696;
	background:#F4F4F4;
}
.profil_11, .profil_22 {
	overflow: hidden; 
	display:inline; 
	float:left; 
	height:190px;
	font-size:22px;
	color: #000000;
}
.profil_11{
	width:140px; 
	margin:0px;
	border:solid 1px #DDDDDD; 
	
}
.profil_22 a{
	color: #000000;

}
.profil_22{
	width:77%; 
	margin-left:4px;
}
.profil_33{
	border:solid 1px #969696; 
	width:99.3%; 
	height:auto; 
	padding:2px;
	font-size:18px;
	text-align: left;
	/* margin-top:62px;*/
}

/**************************************************************/
/*________profilInscriRec___________*/
.profilInscriRec{
	width:100%; 
	height:auto;
	border:solid 1px #969696;
	background:#F4F4F4;
}
.profilInscriRec11, .profilInscriRec12{
	border:solid 1px #DDDDDD; 
	overflow: hidden; 
	display:inline; 
	float:left; 
	height:110px;
	font-size:14px;
}
.profilInscriRec11{
	width:20%; 
	margin:0px;
	
}
.profilInscriRec12{
	width:77%; 
	margin-left:4px; 
	
}
/*********************************************/

-->
</style>
