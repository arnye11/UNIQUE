<style type="text/css">
<!--
	.piedpg{
		height:auto; 
		color: #000000;
		font-size: 1em; 
		text-align: center; 
		top: auto;
	}
	.toutdroit{
        background: #000000; 
        color:#ffff; 
        padding:20px;
    }
    @media (max-width: 48em){
        footer  .rubrique{
            display: block;
            width: 98%;
        }
        .toutdroit{
            font-size: 12px;
        }
    }
-->
</style>

<div class="piedpg">
	<div class="toutdroit">
		UNIQUE -  <?php echo $annee_encours; ?> | Tout droit r&eacute;serv&eacute; au 
		<a href="?apropos#arnye" style="color:#003958;"><strong>CRTN</strong></a> |
		<a href="licence/Contrat_licence_UNIQUE_UKA_21082023.pdf">Lisez le termes de licence</a>
		| Pour tout probl&egrave;me, appeler : +243 823664195,  +243 847423368,  +243 998022336
	</div>
	
	<div  align="center" style="width:72px;height:33px; border-radius:50px; position:fixed; top:auto; bottom:2%; left:auto; right:1%; font-size:12px; font-family:'Century Schoolbook'; border:solid 1px #A0A0A4; color:#A0A0A4; ">
		UNIQUE <br>v.<?php echo $version; ?>
	</div>
</div>
