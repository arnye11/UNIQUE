-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 06 fév. 2023 à 09:11
-- Version du serveur :  8.0.18
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `kitako_kia_bintu`
--
CREATE DATABASE IF NOT EXISTS `kitako_kia_bintu` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kitako_kia_bintu`;

-- --------------------------------------------------------

--
-- Structure de la table `tb_an_aca`
--

DROP TABLE IF EXISTS `tb_an_aca`;
CREATE TABLE IF NOT EXISTS `tb_an_aca` (
  `idAnAca` varchar(9) NOT NULL,
  `datedebutAnAca` date NOT NULL,
  `datefinAnAca` date NOT NULL,
  `tauxannuel` int(10) NOT NULL,
  PRIMARY KEY (`idAnAca`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_an_aca`
--

INSERT INTO `tb_an_aca` (`idAnAca`, `datedebutAnAca`, `datefinAnAca`, `tauxannuel`) VALUES
('2021-2022', '2021-12-01', '2023-02-28', 0);

-- --------------------------------------------------------

--
-- Structure de la table `tb_attribution`
--

DROP TABLE IF EXISTS `tb_attribution`;
CREATE TABLE IF NOT EXISTS `tb_attribution` (
  `idAt` int(11) NOT NULL AUTO_INCREMENT,
  `idCours` varchar(10) NOT NULL,
  `idEns` varchar(15) NOT NULL,
  `idPromo` varchar(10) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAnAca` varchar(10) NOT NULL,
  `dateAt` date NOT NULL,
  PRIMARY KEY (`idAt`)
) ENGINE=MyISAM AUTO_INCREMENT=555 DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_auto_dec`
--

DROP TABLE IF EXISTS `tb_auto_dec`;
CREATE TABLE IF NOT EXISTS `tb_auto_dec` (
  `idAutoDec` varchar(20) NOT NULL,
  `nomAutoDec` varchar(20) NOT NULL,
  `postnomAutoDec` varchar(20) NOT NULL,
  `prenomAutoDec` varchar(20) NOT NULL,
  `sexeAutoDec` varchar(1) NOT NULL,
  `telAutoDec` varchar(20) NOT NULL,
  `avantarAutoDec` varchar(200) NOT NULL,
  `loginAutoDec` varchar(50) NOT NULL,
  `paswordAutoDec` varchar(50) NOT NULL,
  `idFonctAutoDec` varchar(10) NOT NULL,
  `NivAc` int(1) NOT NULL,
  `NivInter` int(11) NOT NULL,
  `idFac` varchar(20) NOT NULL,
  PRIMARY KEY (`idAutoDec`),
  UNIQUE KEY `loginAutoDec` (`loginAutoDec`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure de la table `tb_cote`
--

DROP TABLE IF EXISTS `tb_cote`;
CREATE TABLE IF NOT EXISTS `tb_cote` (
  `matricEtud` varchar(13) NOT NULL,
  `cote_s1` int(2) NOT NULL,
  `cote_s2` int(2) NOT NULL,
  `idCours` varchar(20) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAca` varchar(20) NOT NULL,
  `idAutoDec` varchar(20) NOT NULL,
  `dateAjoutCote` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_cours`
--

DROP TABLE IF EXISTS `tb_cours`;
CREATE TABLE IF NOT EXISTS `tb_cours` (
  `idCours` varchar(20) NOT NULL,
  `designCours` varchar(200) NOT NULL,
  `idUE` varchar(20) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  PRIMARY KEY (`idCours`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_deliberation`
--

DROP TABLE IF EXISTS `tb_deliberation`;
CREATE TABLE IF NOT EXISTS `tb_deliberation` (
  `idDel` int(11) NOT NULL AUTO_INCREMENT,
  `matricEtud` varchar(20) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAnAca` varchar(20) NOT NULL,
  `prctg` int(11) NOT NULL,
  `mention` varchar(4) NOT NULL,
  `session` varchar(4) NOT NULL,
  `datedel` datetime NOT NULL,
  `idAutoDec` varchar(20) NOT NULL,
  PRIMARY KEY (`idDel`)
) ENGINE=MyISAM AUTO_INCREMENT=1140 DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_enseignant`
--

DROP TABLE IF EXISTS `tb_enseignant`;
CREATE TABLE IF NOT EXISTS `tb_enseignant` (
  `idEns` varchar(15) NOT NULL,
  `nomEns` varchar(50) NOT NULL,
  `postnomEns` varchar(50) NOT NULL,
  `prenomEns` varchar(50) NOT NULL,
  `sexeEns` varchar(1) NOT NULL,
  `domainEtudEns` varchar(100) NOT NULL,
  `telEns` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `idGrad` varchar(10) NOT NULL,
  `idFac` varchar(10) NOT NULL,
  `typeEns` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dateEngagEns` varchar(10) NOT NULL,
  PRIMARY KEY (`idEns`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_etablissement`
--

DROP TABLE IF EXISTS `tb_etablissement`;
CREATE TABLE IF NOT EXISTS `tb_etablissement` (
  `idEts` varchar(20) NOT NULL,
  `nom_univers` varchar(200) NOT NULL,
  `sigle_univers` varchar(30) NOT NULL,
  `adresse_univers` varchar(200) NOT NULL,
  `tel_univers` varchar(60) NOT NULL,
  `email_univers` varchar(100) NOT NULL,
  `etat_univers` tinyint(1) NOT NULL,
  `typEts` varchar(20) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `dateCreationEts` date NOT NULL,
  PRIMARY KEY (`idEts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_etudiant`
--

DROP TABLE IF EXISTS `tb_etudiant`;
CREATE TABLE IF NOT EXISTS `tb_etudiant` (
  `matricEtud` varchar(13) NOT NULL,
  `nomEtud` varchar(20) NOT NULL,
  `postnomEtud` varchar(20) NOT NULL,
  `prenomEtud` varchar(20) NOT NULL,
  `sexeEtud` varchar(2) NOT NULL,
  `datenaissEtud` date NOT NULL,
  `lieunaisEtud` varchar(100) NOT NULL,
  `sectionSuiviEtud` varchar(100) NOT NULL,
  `pourctgEtud` varchar(5) NOT NULL,
  `telEtud` varchar(20) NOT NULL,
  `emailEtud` varchar(50) NOT NULL,
  `adresseEtud` mediumtext NOT NULL,
  `avantarEtud` varchar(5000) NOT NULL,
  `dateinscritEtud` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nomPereEtud` varchar(50) NOT NULL,
  `nomMereEtud` varchar(50) NOT NULL,
  PRIMARY KEY (`matricEtud`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure de la table `tb_examens`
--

DROP TABLE IF EXISTS `tb_examens`;
CREATE TABLE IF NOT EXISTS `tb_examens` (
  `idExem` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `designExem` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`idExem`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_examens`
--

INSERT INTO `tb_examens` (`idExem`, `designExem`) VALUES
('E1', 'Mi-Session'),
('E2', '1ere Session'),
('E3', 'D?liberation'),
('E4', '2?me Session');

-- --------------------------------------------------------

--
-- Structure de la table `tb_faculte`
--

DROP TABLE IF EXISTS `tb_faculte`;
CREATE TABLE IF NOT EXISTS `tb_faculte` (
  `idFac` varchar(10) NOT NULL,
  `designFac` varchar(200) NOT NULL,
  PRIMARY KEY (`idFac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_faculte`
--

INSERT INTO `tb_faculte` (`idFac`, `designFac`) VALUES
('FACINFO', 'Informatique'),
('FACAGRO', 'Agronomie'),
('FACDROIT', 'Droit'),
('FACECO', 'Economie'),
('FACPSYSCED', 'Psychologie et Scienes de l&#39;Education');

-- --------------------------------------------------------

--
-- Structure de la table `tb_fixation_prix`
--

DROP TABLE IF EXISTS `tb_fixation_prix`;
CREATE TABLE IF NOT EXISTS `tb_fixation_prix` (
  `idFixPrix` int(11) NOT NULL AUTO_INCREMENT,
  `idPromo` varchar(20) NOT NULL,
  `idFac` varchar(10) NOT NULL,
  `idAca` varchar(9) NOT NULL,
  `idFr` varchar(20) NOT NULL,
  `montantFix` int(10) NOT NULL,
  PRIMARY KEY (`idFixPrix`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tb_fonction`
--

DROP TABLE IF EXISTS `tb_fonction`;
CREATE TABLE IF NOT EXISTS `tb_fonction` (
  `idFonct` varchar(15) NOT NULL,
  `designFonc` varchar(100) NOT NULL,
  PRIMARY KEY (`idFonct`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_fonction`
--

INSERT INTO `tb_fonction` (`idFonct`, `designFonc`) VALUES
('OPS', 'Opérateur de saisie'),
('APPARIT_C', 'Apparitaire Central'),
('CPTBL', 'Comptable'),
('SECFAC', 'Secrétaire facultaire');

-- --------------------------------------------------------

--
-- Structure de la table `tb_frais`
--

DROP TABLE IF EXISTS `tb_frais`;
CREATE TABLE IF NOT EXISTS `tb_frais` (
  `idFr` varchar(20) NOT NULL,
  `designFr` varchar(50) NOT NULL,
  `idTypFr` varchar(20) NOT NULL,
  PRIMARY KEY (`idFr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_frais`
--

INSERT INTO `tb_frais` (`idFr`, `designFr`, `idTypFr`) VALUES
('FAT1', '1ère TRANCHE', 'TF1'),
('FAT2', '2ème TRANCHE', 'TF1'),
('FAT3', '3ème TRANCHE', 'TF1'),
('FCIRol', 'Inscription au rôle ', 'TF2'),
('FCIMiS', 'Inscription à la Mi-Session', 'TF2');

-- --------------------------------------------------------

--
-- Structure de la table `tb_frais_fixe_pour_exam`
--

DROP TABLE IF EXISTS `tb_frais_fixe_pour_exam`;
CREATE TABLE IF NOT EXISTS `tb_frais_fixe_pour_exam` (
  `idFr_Fix_Exam` int(100) NOT NULL AUTO_INCREMENT,
  `idFr` varchar(10) NOT NULL,
  `idExam` varchar(11) NOT NULL,
  `idAca` varchar(10) NOT NULL,
  PRIMARY KEY (`idFr_Fix_Exam`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_grade`
--

DROP TABLE IF EXISTS `tb_grade`;
CREATE TABLE IF NOT EXISTS `tb_grade` (
  `idGrad` varchar(10) NOT NULL,
  `designGrad` varchar(50) NOT NULL,
  PRIMARY KEY (`idGrad`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_grade`
--

INSERT INTO `tb_grade` (`idGrad`, `designGrad`) VALUES
('AS1', 'Assistant 1er mandat'),
('AS2', 'Assistant 2&egrave; mandat'),
('CT', 'Chef des Travaux'),
('PA', 'Professeur Associé'),
('P', 'Professeur'),
('PO', 'Professeur Ordinnaire');

-- --------------------------------------------------------

--
-- Structure de la table `tb_inscription`
--

DROP TABLE IF EXISTS `tb_inscription`;
CREATE TABLE IF NOT EXISTS `tb_inscription` (
  `idInscrit` int(11) NOT NULL AUTO_INCREMENT,
  `matricEtud` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idProm` varchar(5) NOT NULL,
  `idAca` varchar(9) NOT NULL,
  `idAutoDec` varchar(50) NOT NULL,
  `dateInscrit` datetime NOT NULL,
  PRIMARY KEY (`idInscrit`)
) ENGINE=MyISAM AUTO_INCREMENT=1149 DEFAULT CHARSET=utf8;


--
-- Structure de la table `tb_option`
--

DROP TABLE IF EXISTS `tb_option`;
CREATE TABLE IF NOT EXISTS `tb_option` (
  `idOp` varchar(20) NOT NULL,
  `designOp` varchar(500) NOT NULL,
  `idFac` varchar(50) NOT NULL,
  PRIMARY KEY (`idOp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Structure de la table `tb_organisation_option`
--

DROP TABLE IF EXISTS `tb_organisation_option`;
CREATE TABLE IF NOT EXISTS `tb_organisation_option` (
  `idOrgOp` int(10) NOT NULL AUTO_INCREMENT,
  `idPromo` varchar(10) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAnAca` varchar(10) NOT NULL,
  PRIMARY KEY (`idOrgOp`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_program_cours`
--

DROP TABLE IF EXISTS `tb_program_cours`;
CREATE TABLE IF NOT EXISTS `tb_program_cours` (
  `idProgC` int(11) NOT NULL AUTO_INCREMENT,
  `idCours` varchar(20) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `ht` int(11) NOT NULL,
  `hp` int(11) NOT NULL,
  `idAnAca` varchar(10) NOT NULL,
  `dateProgC` date NOT NULL,
  PRIMARY KEY (`idProgC`)
) ENGINE=MyISAM AUTO_INCREMENT=676 DEFAULT CHARSET=latin1;


--
-- Structure de la table `tb_promotion`
--

DROP TABLE IF EXISTS `tb_promotion`;
CREATE TABLE IF NOT EXISTS `tb_promotion` (
  `idPromo` varchar(5) NOT NULL,
  `designPromo` varchar(50) NOT NULL,
  PRIMARY KEY (`idPromo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_promotion`
--

INSERT INTO `tb_promotion` (`idPromo`, `designPromo`) VALUES
('G1', '1er Graduat'),
('G2', '2ème Graduat'),
('G3', '3ème Graduat'),
('L1', '1ère Licence'),
('L2', '2ème Licence'),
('BAC1', '1ère Licence LMD'),
('BAC2', '2ème Licence LMD'),
('BAC3', '3ème Licence LMD'),
('BAC4', '4ème Licence LMD'),
('M1', 'Master 1'),
('M2', 'Master 2'),
('M2', 'Master 3');

-- --------------------------------------------------------

--
-- Structure de la table `tb_type_frais`
--

DROP TABLE IF EXISTS `tb_type_frais`;
CREATE TABLE IF NOT EXISTS `tb_type_frais` (
  `idTypFr` varchar(10) NOT NULL,
  `designTypFr` varchar(50) NOT NULL,
  PRIMARY KEY (`idTypFr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_type_frais`
--

INSERT INTO `tb_type_frais` (`idTypFr`, `designTypFr`) VALUES
('TF1', 'FRAIS ACADEMIQUES'),
('TF2', 'FRAIS CONNEXES'),
('TF3', 'AUTRES FRAIS CONNEXES');

-- --------------------------------------------------------

--
-- Structure de la table `tb_ue`
--

DROP TABLE IF EXISTS `tb_ue`;
CREATE TABLE IF NOT EXISTS `tb_ue` (
  `idUE` varchar(20) NOT NULL,
  `designUE` varchar(200) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  PRIMARY KEY (`idUE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_universite`
--

DROP TABLE IF EXISTS `tb_universite`;
CREATE TABLE IF NOT EXISTS `tb_universite` (
  `code_univers` int(5) NOT NULL,
  `nom_univers` varchar(200) NOT NULL,
  `sigle_univers` varchar(30) NOT NULL,
  `adresse_univers` varchar(200) NOT NULL,
  `tel_univers` varchar(60) NOT NULL,
  `email_univers` varchar(100) NOT NULL,
  `etat_univers` tinyint(1) NOT NULL,
  `logo` varchar(100) NOT NULL,
  PRIMARY KEY (`code_univers`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_universite`
--

INSERT INTO `tb_universite` (`code_univers`, `nom_univers`, `sigle_univers`, `adresse_univers`, `tel_univers`, `email_univers`, `etat_univers`, `logo`) VALUES
(11, 'Universit&eacute; Notre Dame de Lomami', 'UNILO', 'Ville Kabinda', '0823664195', '', 1, 'logoUNILO.gif');

-- --------------------------------------------------------

--
-- Structure de la table `tb_versement`
--

DROP TABLE IF EXISTS `tb_versement`;
CREATE TABLE IF NOT EXISTS `tb_versement` (
  `idVers` int(100) NOT NULL AUTO_INCREMENT,
  `matEtud` varchar(20) NOT NULL,
  `idPromo` varchar(10) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAca` varchar(10) NOT NULL,
  `idFr` varchar(20) NOT NULL,
  `montantVers` int(10) NOT NULL,
  `dateVers` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idAutoDec` varchar(10) NOT NULL,
  PRIMARY KEY (`idVers`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
