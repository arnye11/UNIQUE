-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 11 déc. 2022 à 15:45
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bdnico`
--
CREATE DATABASE IF NOT EXISTS `bdnico` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bdnico`;

-- --------------------------------------------------------

--
-- Structure de la table `rr`
--

DROP TABLE IF EXISTS `rr`;
CREATE TABLE IF NOT EXISTS `rr` (
  `g` varchar(22) NOT NULL,
  `e` varchar(22) NOT NULL,
  `f` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`f`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_cours`
--

DROP TABLE IF EXISTS `tb_cours`;
CREATE TABLE IF NOT EXISTS `tb_cours` (
  `codeC` varchar(20) NOT NULL,
  `designC` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_cours`
--

INSERT INTO `tb_cours` (`codeC`, `designC`) VALUES
('A001', 'ANGLAIS'),
('A002', 'algo');

-- --------------------------------------------------------

--
-- Structure de la table `tb_perso`
--

DROP TABLE IF EXISTS `tb_perso`;
CREATE TABLE IF NOT EXISTS `tb_perso` (
  `nom` varchar(50) NOT NULL,
  `postnom` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_perso`
--

INSERT INTO `tb_perso` (`nom`, `postnom`) VALUES
('hfhfh', ''),
('KABAMBA', 'KABAMBA'),
('A001', 'ANGLAIS');

-- --------------------------------------------------------

--
-- Structure de la table `tt`
--

DROP TABLE IF EXISTS `tt`;
CREATE TABLE IF NOT EXISTS `tt` (
  `nn` int(11) NOT NULL AUTO_INCREMENT,
  `hhfd` varchar(22) NOT NULL,
  `rdq` varchar(22) NOT NULL,
  `zz` varchar(22) NOT NULL,
  PRIMARY KEY (`nn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
--
-- Base de données : `kitako_kia_bintu`
--
CREATE DATABASE IF NOT EXISTS `kitako_kia_bintu` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kitako_kia_bintu`;

-- --------------------------------------------------------

--
-- Structure de la table `tb_an_aca`
--

DROP TABLE IF EXISTS `tb_an_aca`;
CREATE TABLE IF NOT EXISTS `tb_an_aca` (
  `idAnAca` varchar(9) NOT NULL,
  `datedebutAnAca` date NOT NULL,
  `datefinAnAca` date NOT NULL,
  `tauxannuel` int(10) NOT NULL,
  PRIMARY KEY (`idAnAca`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tb_attribution`
--

DROP TABLE IF EXISTS `tb_attribution`;
CREATE TABLE IF NOT EXISTS `tb_attribution` (
  `idAt` int(11) NOT NULL AUTO_INCREMENT,
  `idCours` varchar(10) NOT NULL,
  `idEns` varchar(15) NOT NULL,
  `idPromo` varchar(10) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAnAca` varchar(10) NOT NULL,
  `dateAt` date NOT NULL,
  PRIMARY KEY (`idAt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_auto_dec`
--

DROP TABLE IF EXISTS `tb_auto_dec`;
CREATE TABLE IF NOT EXISTS `tb_auto_dec` (
  `idAutoDec` varchar(20) NOT NULL,
  `nomAutoDec` varchar(20) NOT NULL,
  `postnomAutoDec` varchar(20) NOT NULL,
  `prenomAutoDec` varchar(20) NOT NULL,
  `sexeAutoDec` varchar(1) NOT NULL,
  `telAutoDec` varchar(20) NOT NULL,
  `avantarAutoDec` varchar(200) NOT NULL,
  `loginAutoDec` varchar(50) NOT NULL,
  `paswordAutoDec` varchar(50) NOT NULL,
  `idFonctAutoDec` varchar(10) NOT NULL,
  `NivAc` int(1) NOT NULL,
  `NivInter` int(11) NOT NULL,
  `idFac` varchar(20) NOT NULL,
  PRIMARY KEY (`idAutoDec`),
  UNIQUE KEY `loginAutoDec` (`loginAutoDec`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_auto_dec`
--

INSERT INTO `tb_auto_dec` (`idAutoDec`, `nomAutoDec`, `postnomAutoDec`, `prenomAutoDec`, `sexeAutoDec`, `telAutoDec`, `avantarAutoDec`, `loginAutoDec`, `paswordAutoDec`, `idFonctAutoDec`, `NivAc`, `NivInter`, `idFac`) VALUES
('admin1', 'NYEMBO', 'MPAMPI', 'Augu Roger', 'M', '0823664195', 'admin1ed34b3346c83777dbbd8bb57c2e6eda0.jpg', 'admin', 'admin2', 'admin', 2, 4, 'TOUTES'),
('opsDROIT', 'KIMBAMBLE', 'KIUNGU', 'Cecile', 'F', '0815511776', '', 'cecileKIM2022', 'cecile2022Droit', 'OPS', 4, 0, 'FACDROIT'),
('opsAgro', 'NKIMA', 'OSUMBA', 'Albertine', 'F', '0826690045', 'opsAgroa5e26b3f6c2acd966e73e5decb402d97.jpg', 'albertineNK', 'albertine2021f', 'OPS', 4, 0, 'FACAGRO'),
('opsAPP', 'MUTUAL', 'MUSONGIELA', 'Marcel', 'M', '0811605295', '', 'marcelMut', 'opsAPparit2022', 'OPS', 4, 0, 'TOUTES'),
('opsECO', 'MBOMBO', 'KABEMBA', 'Marleine', 'F', '0820076770', '', 'marleineMBO2022', 'marleineM22', 'OPS', 4, 0, 'FACECO'),
('SecFacInfo', 'NSAPU', 'KIKUDI', 'Dorothée', 'F', '0817418789', '', 'dorotheeNs2022', 'dorotheeNs22', 'SECFAC', 4, 0, 'FACINFO'),
('opsPsychSE', 'NSAPU', 'MUTALE', 'Paulin', 'M', '0816067324', '', 'paulinNsapu22', '2020paulinNsa', 'OPS', 4, 0, 'FACPSYSCED'),
('admin2', 'Isctkab', 'gdg', 'ydgyd', 'M', 'hfb', '', 'admin1', 'adminI', 'APPARIT_C', 1, 2, 'TOUTES'),
('admin3', 'Isctkab', 'gdg', 'ydgyd', 'M', 'hfb', '', 'admin3', 'adminI', 'CPTBL', 1, 2, '12F3'),
('OPS111', 'LOMBE', 'NSOMUE', 'CHARLE', 'M', '0829661118', '', 'LOMBNSO', '1234ISCTKAB', 'OPS', 2, 2, '12S7');

-- --------------------------------------------------------

--
-- Structure de la table `tb_cote`
--

DROP TABLE IF EXISTS `tb_cote`;
CREATE TABLE IF NOT EXISTS `tb_cote` (
  `matricEtud` varchar(13) NOT NULL,
  `cote_s1` int(2) NOT NULL,
  `cote_s2` int(2) NOT NULL,
  `idCours` varchar(20) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAca` varchar(20) NOT NULL,
  `idAutoDec` varchar(20) NOT NULL,
  `dateAjoutCote` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_cours`
--

DROP TABLE IF EXISTS `tb_cours`;
CREATE TABLE IF NOT EXISTS `tb_cours` (
  `idCours` varchar(20) NOT NULL,
  `designCours` varchar(200) NOT NULL,
  `idUE` varchar(20) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  PRIMARY KEY (`idCours`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_enseignant`
--

DROP TABLE IF EXISTS `tb_enseignant`;
CREATE TABLE IF NOT EXISTS `tb_enseignant` (
  `idEns` varchar(15) NOT NULL,
  `nomEns` varchar(50) NOT NULL,
  `postnomEns` varchar(50) NOT NULL,
  `prenomEns` varchar(50) NOT NULL,
  `sexeEns` varchar(1) NOT NULL,
  `domainEtudEns` varchar(100) NOT NULL,
  `telEns` varchar(100) CHARACTER SET utf8 NOT NULL,
  `idGrad` varchar(10) NOT NULL,
  `idFac` varchar(10) NOT NULL,
  `typeEns` varchar(1) CHARACTER SET utf8 NOT NULL,
  `dateEngagEns` varchar(10) NOT NULL,
  PRIMARY KEY (`idEns`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_etablissement`
--

DROP TABLE IF EXISTS `tb_etablissement`;
CREATE TABLE IF NOT EXISTS `tb_etablissement` (
  `idEts` varchar(20) NOT NULL,
  `nom_univers` varchar(200) NOT NULL,
  `sigle_univers` varchar(30) NOT NULL,
  `adresse_univers` varchar(200) NOT NULL,
  `tel_univers` varchar(60) NOT NULL,
  `email_univers` varchar(100) NOT NULL,
  `etat_univers` tinyint(1) NOT NULL,
  `typEts` varchar(20) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `dateCreationEts` date NOT NULL,
  PRIMARY KEY (`idEts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_etudiant`
--

DROP TABLE IF EXISTS `tb_etudiant`;
CREATE TABLE IF NOT EXISTS `tb_etudiant` (
  `matricEtud` varchar(13) NOT NULL,
  `nomEtud` varchar(20) NOT NULL,
  `postnomEtud` varchar(20) NOT NULL,
  `prenomEtud` varchar(20) NOT NULL,
  `sexeEtud` varchar(2) NOT NULL,
  `datenaissEtud` date NOT NULL,
  `lieunaisEtud` varchar(100) NOT NULL,
  `sectionSuiviEtud` varchar(100) NOT NULL,
  `pourctgEtud` varchar(5) NOT NULL,
  `telEtud` varchar(20) NOT NULL,
  `emailEtud` varchar(50) NOT NULL,
  `adresseEtud` mediumtext NOT NULL,
  `avantarEtud` varchar(5000) NOT NULL,
  `dateinscritEtud` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nomPereEtud` varchar(50) NOT NULL,
  `nomMereEtud` varchar(50) NOT NULL,
  PRIMARY KEY (`matricEtud`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tb_examens`
--

DROP TABLE IF EXISTS `tb_examens`;
CREATE TABLE IF NOT EXISTS `tb_examens` (
  `idExem` varchar(11) CHARACTER SET latin1 NOT NULL,
  `designExem` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`idExem`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_examens`
--

INSERT INTO `tb_examens` (`idExem`, `designExem`) VALUES
('E1', 'Mi-Session'),
('E2', '1ere Session'),
('E3', 'D?liberation'),
('E4', '2?me Session');

-- --------------------------------------------------------

--
-- Structure de la table `tb_faculte`
--

DROP TABLE IF EXISTS `tb_faculte`;
CREATE TABLE IF NOT EXISTS `tb_faculte` (
  `idFac` varchar(10) NOT NULL,
  `designFac` varchar(200) NOT NULL,
  `idEts` varchar(20) NOT NULL,
  PRIMARY KEY (`idFac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tb_fixation_prix`
--

DROP TABLE IF EXISTS `tb_fixation_prix`;
CREATE TABLE IF NOT EXISTS `tb_fixation_prix` (
  `idFixPrix` int(11) NOT NULL AUTO_INCREMENT,
  `idPromo` varchar(20) NOT NULL,
  `idFac` varchar(10) NOT NULL,
  `idAca` varchar(9) NOT NULL,
  `idFr` varchar(20) NOT NULL,
  `montantFix` int(10) NOT NULL,
  PRIMARY KEY (`idFixPrix`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tb_fonction`
--

DROP TABLE IF EXISTS `tb_fonction`;
CREATE TABLE IF NOT EXISTS `tb_fonction` (
  `idFonct` varchar(15) NOT NULL,
  `designFonc` varchar(100) NOT NULL,
  PRIMARY KEY (`idFonct`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_fonction`
--

INSERT INTO `tb_fonction` (`idFonct`, `designFonc`) VALUES
('OPS', 'Opérateur de saisie'),
('APPARIT_C', 'Apparitaire Central'),
('CPTBL', 'Comptable'),
('SECFAC', 'Secrétaire facultaire');

-- --------------------------------------------------------

--
-- Structure de la table `tb_frais`
--

DROP TABLE IF EXISTS `tb_frais`;
CREATE TABLE IF NOT EXISTS `tb_frais` (
  `idFr` varchar(20) NOT NULL,
  `designFr` varchar(50) NOT NULL,
  `idTypFr` varchar(20) NOT NULL,
  PRIMARY KEY (`idFr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_frais`
--

INSERT INTO `tb_frais` (`idFr`, `designFr`, `idTypFr`) VALUES
('FAT1', '1ère TRANCHE', 'TF1'),
('FAT2', '2ème TRANCHE', 'TF1'),
('FAT3', '3ème TRANCHE', 'TF1'),
('FCIRol', 'Inscription au rôle ', 'TF2'),
('FCIMiS', 'Inscription à la Mi-Session', 'TF2');

-- --------------------------------------------------------

--
-- Structure de la table `tb_frais_fixe_pour_exam`
--

DROP TABLE IF EXISTS `tb_frais_fixe_pour_exam`;
CREATE TABLE IF NOT EXISTS `tb_frais_fixe_pour_exam` (
  `idFr_Fix_Exam` int(100) NOT NULL AUTO_INCREMENT,
  `idFr` varchar(10) NOT NULL,
  `idExam` varchar(11) NOT NULL,
  `idAca` varchar(10) NOT NULL,
  PRIMARY KEY (`idFr_Fix_Exam`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_grade`
--

DROP TABLE IF EXISTS `tb_grade`;
CREATE TABLE IF NOT EXISTS `tb_grade` (
  `idGrad` varchar(10) NOT NULL,
  `designGrad` varchar(50) NOT NULL,
  PRIMARY KEY (`idGrad`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_grade`
--

INSERT INTO `tb_grade` (`idGrad`, `designGrad`) VALUES
('ASS1', 'Assistant 1er mandat'),
('ASS2', 'Assistant 2&egrave; mandat'),
('CT', 'Chef des Travaux'),
('PA', 'Professeur Associé'),
('Prof', 'Professeur'),
('PO', 'Professeur Ordinnaire');

-- --------------------------------------------------------

--
-- Structure de la table `tb_inscription`
--

DROP TABLE IF EXISTS `tb_inscription`;
CREATE TABLE IF NOT EXISTS `tb_inscription` (
  `idInscrit` int(11) NOT NULL AUTO_INCREMENT,
  `matricEtud` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idProm` varchar(5) NOT NULL,
  `idAca` varchar(9) NOT NULL,
  `idAutoDec` varchar(50) NOT NULL,
  `dateInscrit` datetime NOT NULL,
  PRIMARY KEY (`idInscrit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tb_organisation_option`
--

DROP TABLE IF EXISTS `tb_organisation_option`;
CREATE TABLE IF NOT EXISTS `tb_organisation_option` (
  `idOrgOp` int(10) NOT NULL AUTO_INCREMENT,
  `idPromo` varchar(10) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAnAca` varchar(10) NOT NULL,
  PRIMARY KEY (`idOrgOp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_program_cours`
--

DROP TABLE IF EXISTS `tb_program_cours`;
CREATE TABLE IF NOT EXISTS `tb_program_cours` (
  `idProgC` int(11) NOT NULL AUTO_INCREMENT,
  `idCours` varchar(20) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `ht` int(11) NOT NULL,
  `hp` int(11) NOT NULL,
  `idAnAca` varchar(10) NOT NULL,
  `dateProgC` date NOT NULL,
  PRIMARY KEY (`idProgC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_promotion`
--

DROP TABLE IF EXISTS `tb_promotion`;
CREATE TABLE IF NOT EXISTS `tb_promotion` (
  `idPromo` varchar(5) NOT NULL,
  `designPromo` varchar(50) NOT NULL,
  PRIMARY KEY (`idPromo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tb_type_etablissement`
--

DROP TABLE IF EXISTS `tb_type_etablissement`;
CREATE TABLE IF NOT EXISTS `tb_type_etablissement` (
  `idTypEts` varchar(20) NOT NULL,
  `designTypEts` varchar(60) NOT NULL,
  PRIMARY KEY (`idTypEts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tb_type_etablissement`
--

INSERT INTO `tb_type_etablissement` (`idTypEts`, `designTypEts`) VALUES
('UN', 'Universit&eacute;'),
('IS', 'Institut sup&eacute;rieur');

-- --------------------------------------------------------

--
-- Structure de la table `tb_type_frais`
--

DROP TABLE IF EXISTS `tb_type_frais`;
CREATE TABLE IF NOT EXISTS `tb_type_frais` (
  `idTypFr` varchar(10) NOT NULL,
  `designTypFr` varchar(50) NOT NULL,
  PRIMARY KEY (`idTypFr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_type_frais`
--

INSERT INTO `tb_type_frais` (`idTypFr`, `designTypFr`) VALUES
('TF1', 'FRAIS ACADEMIQUES'),
('TF2', 'FRAIS CONNEXES'),
('TF3', 'AUTRES FRAIS CONNEXES');

-- --------------------------------------------------------

--
-- Structure de la table `tb_ue`
--

DROP TABLE IF EXISTS `tb_ue`;
CREATE TABLE IF NOT EXISTS `tb_ue` (
  `idUE` varchar(20) NOT NULL,
  `designUE` varchar(200) NOT NULL,
  `idPromo` varchar(20) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  PRIMARY KEY (`idUE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_universite`
--

DROP TABLE IF EXISTS `tb_universite`;
CREATE TABLE IF NOT EXISTS `tb_universite` (
  `code_univers` int(5) NOT NULL,
  `nom_univers` varchar(200) NOT NULL,
  `sigle_univers` varchar(30) NOT NULL,
  `adresse_univers` varchar(200) NOT NULL,
  `tel_univers` varchar(60) NOT NULL,
  `email_univers` varchar(100) NOT NULL,
  `etat_univers` tinyint(1) NOT NULL,
  `logo` varchar(100) NOT NULL,
  PRIMARY KEY (`code_univers`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tb_versement`
--

DROP TABLE IF EXISTS `tb_versement`;
CREATE TABLE IF NOT EXISTS `tb_versement` (
  `idVers` int(100) NOT NULL AUTO_INCREMENT,
  `matEtud` varchar(20) NOT NULL,
  `idPromo` varchar(10) NOT NULL,
  `idOp` varchar(20) NOT NULL,
  `idAca` varchar(10) NOT NULL,
  `idFr` varchar(20) NOT NULL,
  `montantVers` int(10) NOT NULL,
  `dateVers` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idAutoDec` varchar(10) NOT NULL,
  PRIMARY KEY (`idVers`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- Base de données : `unilo_db`
--
CREATE DATABASE IF NOT EXISTS `unilo_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `unilo_db`;

-- --------------------------------------------------------

--
-- Structure de la table `tb_actualites`
--

DROP TABLE IF EXISTS `tb_actualites`;
CREATE TABLE IF NOT EXISTS `tb_actualites` (
  `idActua` int(11) NOT NULL AUTO_INCREMENT,
  `titreActua` varchar(150) NOT NULL,
  `imageActua` varchar(200) NOT NULL,
  `contenuActua` longtext NOT NULL,
  `dateActua` datetime NOT NULL,
  PRIMARY KEY (`idActua`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_actualites`
--

INSERT INTO `tb_actualites` (`idActua`, `titreActua`, `imageActua`, `contenuActua`, `dateActua`) VALUES
(1, '\r\n\r\nLe mot du recteur', 'RecteurDiscour.webp', '&quot;Dans un monde o&ugrave; les id&eacute;ologies fondamentalistes attisent la violence, je souhaite r&eacute;affirmer les missions fondamentales de notre universit&eacute;. Contre les extr&eacute;mismes et contre les simplifications que propagent diverses formes de populisme, il importe de rappeler notre attachement au dialogue, &agrave; la raison et &agrave; l&rsquo;intelligence.&quot;', '2022-11-16 00:00:00'),
(2, '\r\n\r\nLe mot du recteur', 'RecteurDiscour.webp', '&quot;Dans un monde o&ugrave; les id&eacute;ologies fondamentalistes attisent la violence, je souhaite r&eacute;affirmer les missions fondamentales de notre universit&eacute;. Contre les extr&eacute;mismes et contre les simplifications que propagent diverses formes de populisme, il importe de rappeler notre attachement au dialogue, &agrave; la raison et &agrave; l&rsquo;intelligence.&quot;', '2022-11-16 00:00:00'),
(11, 'MSLDFJFBFBD', '10d8db3738a4cdaab89f1a898a93a025.jpg', 'Dans un monde oÃ¹ les idÃ©ologies fondamentalistes attisent la violence, je souhaite rÃ©affirmer les missions fondamentales de notre universitÃ©. Contre les extrÃ©mismes et ', '2022-12-08 00:00:00'),
(10, 'hfhdf', '0fbf7cd87f532364f741249fa3eddb6c.png', '&#9;&#9;ftyfduy', '2022-12-07 00:00:00'),
(9, 'hfhdf', '945bde67c8b0916e298b6b655525ba2e.png', '&#9;&#9;ftyfduy', '2022-12-07 00:00:00'),
(12, 'ssss', '0678688067e12f1119d9cf26146972e3.PNG', 'AVANT-PROPS&#13;&#10;La rÃ©daction dâ€™un travail de fin dâ€™Ã©tude en Informatique de Gestion demande beaucoup de sacrifices de la part du rÃ©cipiendaire dâ€™une part et dâ€™autre part de la part dâ€™un certain nombre des personnes. Raison pour laquelle nous avons voulu ici tenir un propos afin de signifier notre gratitude Ã  leur endroit. Leur abnÃ©gation nous a permis dâ€™arriver au bout de celle-ci. Nous en sommes trÃ¨s reconnaissants.&#13;&#10;Nous aimerions dâ€™abord exprimer notre gratitude Ã  lâ€™Ã©gard de lâ€™universitÃ© de Kabinda, en sigle UNIKAB, pour les enseignements dont nous sommes bÃ©nÃ©ficiaires ; mais dâ€™avantage encore Ã  lâ€™Ã©gard de bien des Professeurs, des Chefs de Travaux, des Assistants et des chargÃ©s de pratique professionnelle, sans lâ€™aide desquels nous nâ€™aurions jamais pu la mener Ã  terme. &#13;&#10;En tout premier lieu, nous adressons notre gratitude Ã  lâ€™endroit du Professeur Ordinaire Jean KILUILA NTAMBUE le Recteur de notre universitÃ©, et au professeur Ordinaire LUBAMBA KIBAMBE LANGAYI le secrÃ©taire acadÃ©mique de la dite universitÃ©, et Ã  lâ€™Assistant Augu Roger NYEMBO MPAMPI qui a assurÃ© la direction et dont les conseils et lâ€™encadrement nous furent Ã  tout point de vue prÃ©cieux ; en suite au Chefs de Travaux et Assistants de la facultÃ© de lâ€™informatique, et pour terminer Ã  mon petit frÃ¨re de tous les jours Jean-Marie IBANGA.&#13;&#10;Notre reconnaissance se doit Ã©galement Ã  lâ€™Ã©gard de notre pÃ¨re Olivier NSAPIDI MABUISHA et notre chÃ¨re mÃ¨re ThÃ©rÃ¨se MUISANGIE NGOYI, qui nous ont donnÃ© la vie et nous y ont initiÃ©s.&#13;&#10;Nous nâ€™oublierons jamais dâ€™exprimer notre gratitude Ã  lâ€™endroit de nos frÃ¨res et sÅ“urs, cousins et cousines, amis et connaissances qui nous ont exprimÃ© leur amour et surtout du respect quâ€™ils nous ont toujours donnÃ©.&#13;&#10;En outre, nous sommes redevables Ã  certaines chÃ¨res personnes dont les conseils et lâ€™encadrement nous ont permis de bosser dur et espÃ©rer dans la vie. Elles sont tellement nombreuses que nous ne saurons les citer nommÃ©ment toutes.&#13;&#10;Toutefois nous adressons nos remerciements Ã  GÃ©dÃ©on NGOYI LUKUSA que nous nâ€™oublierons jamais &#13;&#10;Nous ne voudrions pas terminer ces lignes sans penser Ã  notre chÃ©rie amie, notre amour : celle qui fait notre bonheur. Elle nous a tellement marquÃ© dans ce parcours que nous ne songerons jamais de lâ€™oublier : JaÃ©l MUJINGA.&#13;&#10;', '2022-12-08 00:00:00'),
(13, 'aaaaa', 'b999c0e33e8bb52afe9bd36bcda63561.jpg', '<h2>AVANT-PROPSv</h2>La rÃ©daction dâ€™un travail de fin dâ€™Ã©tude en Informatique de Gestion demande beaucoup de sacrifices de la part du rÃ©cipiendaire dâ€™une part et dâ€™autre part de la part dâ€™un certain nombre des personnes. Raison pour laquelle nous avons voulu ici tenir un propos afin de signifier notre gratitude Ã  leur endroit. Leur abnÃ©gation nous a permis dâ€™arriver au bout de celle-ci. Nous en sommes trÃ¨s reconnaissants.&#13;&#10;Nous aimerions dâ€™abord exprimer notre gratitude Ã  lâ€™Ã©gard de lâ€™universitÃ© de Kabinda, en sigle UNIKAB, pour les enseignements dont nous sommes bÃ©nÃ©ficiaires ; mais dâ€™avantage encore Ã  lâ€™Ã©gard de bien des Professeurs, des Chefs de Travaux, des Assistants et des chargÃ©s de pratique professionnelle, sans lâ€™aide desquels nous nâ€™aurions jamais pu la mener Ã  terme. &#13;&#10;En tout premier lieu, nous adressons notre gratitude Ã  lâ€™endroit du Professeur Ordinaire Jean KILUILA NTAMBUE le Recteur de notre universitÃ©, et au professeur Ordinaire LUBAMBA KIBAMBE LANGAYI le secrÃ©taire acadÃ©mique de la dite universitÃ©, et Ã  lâ€™Assistant Augu Roger NYEMBO MPAMPI qui a assurÃ© la direction et dont les conseils et lâ€™encadrement nous furent Ã  tout point de vue prÃ©cieux ; en suite au Chefs de Travaux et Assistants de la facultÃ© de lâ€™informatique, et pour terminer Ã  mon petit frÃ¨re de tous les jours Jean-Marie IBANGA.&#13;&#10;Notre reconnaissance se doit Ã©galement Ã  lâ€™Ã©gard de notre pÃ¨re Olivier NSAPIDI MABUISHA et notre chÃ¨re mÃ¨re ThÃ©rÃ¨se MUISANGIE NGOYI, qui nous ont donnÃ© la vie et nous y ont initiÃ©s.&#13;&#10;Nous nâ€™oublierons jamais dâ€™exprimer notre gratitude Ã  lâ€™endroit de nos frÃ¨res et sÅ“urs, cousins et cousines, amis et connaissances qui nous ont exprimÃ© leur amour et surtout du respect quâ€™ils nous ont toujours donnÃ©.&#13;&#10;En outre, nous sommes redevables Ã  certaines chÃ¨res personnes dont les conseils et lâ€™encadrement nous ont permis de bosser dur et espÃ©rer dans la vie. Elles sont tellement nombreuses que nous ne saurons les citer nommÃ©ment toutes.&#13;&#10;Toutefois nous adressons nos remerciements Ã  GÃ©dÃ©on NGOYI LUKUSA que nous nâ€™oublierons jamais &#13;&#10;Nous ne voudrions pas terminer ces lignes sans penser Ã  notre chÃ©rie amie, notre amour : celle qui fait notre bonheur. Elle nous a tellement marquÃ© dans ce parcours que nous ne songerons jamais de lâ€™oublier : JaÃ©l MUJINGA.&#13;&#10;', '2022-12-08 00:00:00'),
(14, 'hdtjd', '21a50edb858368cfd6583f1d4878df32.png', '&#9;&#9;hdthhtdhd', '2022-12-08 00:00:00'),
(15, 'hdtjd', '7e05691240a84d4c12a6ac4e2ad147b7.png', '&#9;&#9;hdthhtdhd', '2022-12-11 11:59:02');

-- --------------------------------------------------------

--
-- Structure de la table `tb_admin`
--

DROP TABLE IF EXISTS `tb_admin`;
CREATE TABLE IF NOT EXISTS `tb_admin` (
  `login` varchar(20) NOT NULL,
  `motdepasse` varchar(20) NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_admin`
--

INSERT INTO `tb_admin` (`login`, `motdepasse`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Structure de la table `tb_faculte`
--

DROP TABLE IF EXISTS `tb_faculte`;
CREATE TABLE IF NOT EXISTS `tb_faculte` (
  `idFac` varchar(20) NOT NULL,
  `titreFac` varchar(100) NOT NULL,
  `objetFac` varchar(500) NOT NULL,
  `imgFac` varchar(100) NOT NULL,
  PRIMARY KEY (`idFac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tb_faculte`
--

INSERT INTO `tb_faculte` (`idFac`, `titreFac`, `objetFac`, `imgFac`) VALUES
('FAC01', 'Sciences agronomiques', 'La facult&eacute; des sciences agronomique entant que facult&eacute; m&egrave;re est le pilier de notre universit&eacute;. Elle r&eacute;pond aux besoins du milieu qui est essentiellement agropastorale. ', 'agronomie1.jpeg'),
('FAC02', 'Sciences &eacute;conomiques ', 'La facult&eacute; des sciences agronomique entant que facult&eacute; m&egrave;re est le pilier de notre universit&eacute;. Elle r&eacute;pond aux besoins du milieu qui est essentiellement agropastorale. ', 'economie3.jpeg'),
('FAC03', 'Sciences informatiques', 'La facult&eacute; des sciences agronomique entant que facult&eacute; m&egrave;re est le pilier de notre universit&eacute;. Elle r&eacute;pond aux besoins du milieu qui est essentiellement agropastorale. ', 'informatique1.jpeg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
