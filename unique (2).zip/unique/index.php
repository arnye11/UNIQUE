<?php 
	//cr�e jeudi le 28-d�cembre-2017, 14:29:18.
	//Par Ir. NYEMBO MPAMPI AUGUSTIN
	//+243823664195
	//augurogernyembo@gmail.com
	//include("install.php"); 

	session_start();
	include("var.php");  

	include("B_mbindi/Biamunda/rqt/rqt_creer_etablissement.php");
	$rqt_slct_univers = "SELECT * FROM tb_etablissement WHERE etatEts='1'";
	if($exe_rqt_slct_univers = mysqli_query($con, $rqt_slct_univers)){
		if(mysqli_num_rows($exe_rqt_slct_univers)>0){
			if($tb_etablissement = mysqli_fetch_assoc($exe_rqt_slct_univers)){
				$idEts = $_SESSION['idEts']= $tb_etablissement["idEts"];
				$_SESSION['nom_etablissement']=$nom_etablissement = $tb_etablissement["nomEts"];
				$_SESSION['sigle_tb_etablissement']=$sigle_tb_etablissement = $tb_etablissement["sigleEts"];
				$_SESSION['logo']=$logo = $tb_etablissement["logoEts"];
				$_SESSION['villeEts'] = $tb_etablissement["villeEts"];
				$_SESSION['typEts']=$typEts = $tb_etablissement["typEts"];

				include("B_mbindi/Biamunda/deconx.php");
				include("B_mbindi/Biamunda/rqt/rqt.php");
				include("B_mbindi/Biamunda/titres_pages.php");
				include("B_mbindi/Biamunda/etablissement.php");
			}
			else{
				?>
				<div style="border:solid 1px #FF99CC; background:#FFCCCC; " >
					<p>
						D&eacute;sol&eacute; ! Nous n'arrivons pas &agrave; trouver les informations de votre Etablissement. <br /> 
						Veuillez appler Ir. Augu Roger NYEMBO pour l'assistance au :
							<ol>
								<li> +243 823664195 </li>
								<li> +243 847423368 </li>
								<li> +243 998022336 </li>
								<li> auguroger@gmail.com </li>
							</ol>
						<h3>Merci.</h3> 
					</p>
				</div>
				<?php
			}
		}
		else{
			include("B_mbindi/Biamunda/creation_etablissement.php");
		}
	}
	else{
			echo "Erreur";
	}
?>
