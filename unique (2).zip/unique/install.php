<?php 
	$serv = "localhost";
	$db = "arnyenet_db";
	
	//en ligne
	//$user = "arnyenet";
	//$pw = "3YU#eGx10Uaj4:";
	
	//en local
	$user = "root";
	$pw = "mysarnye";
	

	$cnx = mysqli_connect($serv,$user,$pw);
	//mysql_select_db(BDD_NAME,$bdd);
	$requetes="";
	 
	$sql=file("dbb/db_unique.sql"); // on charge le fichier SQL
	foreach($sql as $l){ // on le lit
		if (substr(trim($l),0,2)!="--"){ // suppression des commentaires
			$requetes .= $l;
		}
	}
	 
	$reqs = explode(";",$requetes);// on sépare les requêtes
	foreach($reqs as $req){	// et on les éxécute
		if (!mysqli_query($cnx, $req) && trim($req)!=""){
			die("ERROR : ".$req); // stop si erreur 
		}
	}
	echo "base restaurée";
 ?>