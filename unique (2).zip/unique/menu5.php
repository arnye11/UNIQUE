<div id="mbmcpebul_wrapper">
  <ul id="mbmcpebul_table" class="mbmcpebul_menulist css_menu">
    <li><div class="buttonbg" style="width: 132px;"><a href="?accueil" target="_blank" class="button_1">Accueil</a></div></li>

    <?php if ($_SESSION['NivAc']>1) {  ?>
    <li><div class="arrow buttonbg" style="width: 160px;"><div class="icon_2 with_img_32"><a target="_parent">Gérer</a></div></div>
      <ul>
      <li><a href='?gerer_departement&ajouter_dep' class="with_img_32" title=""><img src="menu5_files/mbico_mbmcp_1.png" alt="" />Facult&eacute;</a></li>
      <li><a href='?gerer_option&ajouter_op' class="with_img_24" title=""><img src="menu5_files/mbico_mbmcp_2.png" alt="" />Option</a></li>
      <li><a href='?gerer_promotion&ajouter_pro' class="with_img_24" title=""><img src="menu5_files/mbico_mbmcp_3.png" alt="" />Promotion</a></li>
      <li><a href='?gerer_aca&ajouter_aca' class="with_img_24"  title=""><img src="menu5_files/mbico_mbmcp_4.png" alt="" />Ann&eacute;e Acad&eacute;mique</a></li>
      <li><a href='?gerer_admin&aDmini5TratIF' class="with_img_24" title=""><img src="menu5_files/mbico_mbmcp_5.png" alt="" />Utilisateurs</a></li>
      </ul></li>
    <?php } ?>

    <li><div class="arrow buttonbg"><div class="icon_3 with_img_24"><a class="button_3"><?php echo $_SESSION['prenom']; ?><br /></a></div></div>
      <ul>
      <li><a href='?gerer_admin&aDmini5TratIF&id=<?php echo $_SESSION['idAutoDec']; ?>' class="with_img_24" title=""><img src="menu5_files/mbico_mbmcp_6.png" alt="" />Profil</a></li>
      
      <li class="separator"><div></div></li>
      <li><a href="?dc10=10f0000010" title="" class="with_img_24"><img src="menu5_files/mbico_mbmcp_7.png" alt="" />Se déconnecter</a></li>
      </ul></li>
  </ul>
</div>
<script type="text/javascript" src="menu5_files/mbjsmbmcp.js"></script>
