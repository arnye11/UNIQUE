<div id="mbmcpebul_wrapper" style="max-width: 100%;">
  <ul id="mbmcpebul_table" class="mbmcpebul_menulist css_menu">
    <li>
      <div class="buttonbg">
        <a  href="?accueil" class="button_1">Accueil</a>
      </div>
    </li>
      <?php
        if ($_SESSION['NivAc']>1) {  ?>
          <li>
            <div class="arrow buttonbg" >
              <a><img class="icon" src="A_mutue/parametr.png" />&nbsp; Gérer </a>
            </div>
            <ul>
              <li>
                <a href='?gerer_departement&ajouter_dep' title="">Facult&eacute;</a>
              </li>
              <li>
                <a href='?gerer_option&ajouter_op' title="">Option</a>
              </li>
              <li>
                <a href='?gerer_promotion&ajouter_pro' title="">Promotion</a>
              </li>
              <li>
                <a href='?gerer_aca&ajouter_aca' title="">Ann&eacute;e Acad&eacute;mique</a>
              </li>
              <li>
                <a href='?gerer_admin&aDmini5TratIF' title="">
                  <img class='icon' src='A_mutue/cote.png'/>&nbsp;Utilisateurs
                </a>
              </li>
              
            </ul>
          </li>
          <?php
        }
      ?>
    <li>
      <div class="arrow buttonbg" style="width: 263px;">
        <a><img style="width: 25px; height: auto;" src="logoprofil3.png" />&nbsp;<?php echo $_SESSION['prenom']; ?></a>
      </div>
      <ul>
        <li>
          <a href='?gerer_admin&aDmini5TratIF&id=<?php echo $_SESSION['idAutoDec']; ?>' title="">Profil</a>
        </li>
        <li>
          <a href="?dc10=10f0000010" title="">Se déconnecter</a>
        </li>
      
      </ul>
    </li>
  </ul>
</div>

<script type="text/javascript" src="menus4_files/mbjsmbmcp.js"></script>
