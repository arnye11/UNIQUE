<?php 
	//crée jeudi le 28-décembre-2017, 14:29:18.
	//Par Ir. NYEMBO MPAMPI AUGUSTIN
	//+243823664195
	//augurogernyembo@gmail.com
	//dans index
	//------------------------------------------------------------------------------------
	$version = "02";
	$url_site="/";
	$site="unique/";
	$url="/";
	$idEts = ""; 
	$nom_univers = ""; 
	$sigle_univers = "";  
	$logo = ""; 
	$an_aca = "";
	$titrePg=" UNIQUE";
	
	$login = "";
	$password = "";
	
	$ip_visiteur = $_SERVER['REMOTE_ADDR'];
	$ip_serveur = "192.168.100.3";
	
	$iddep = "";
	$designDep = "";
	$sms_gerer = "";
	$iddep_modif_op = "";
	$idOp_modif_inscrit = "";
	
	$idFr_a_modif = "";
	$designFr_a_modif = "";
	$idTypFr_a_modif = "";
	$design_TypFr_a_modif = "";
	
	$contenu = "Matricule de l&#39;Etudiant";
	$idOp = "";
	$sms = "";
	$sms_authatification = "";
	$sms_avatar = ""; 
	$sms_inscription = "";
	$matriculEtud = "";
	$photoEtud ="";
	$promotion = "G1";
	$Option = "";
	$IdOption = "";
	$sms_reinscription = "";
	
	$inscription_etud = false;
	$idAca_modif = false;
	$idFr_modif = false;
	$idFr_a_sup = false;
	$champsLog = false;
	$champs = false;
	$recherche = false;
	$conx = false;
	$login==false;
	$reinscription = false;
	$anne_academique = false;
	$accueil=true;
	$idfac_modif_op=false;
	
	$montant_fixeG1 = 0;
	$tot_montant_fixe_fr_acaG1 =0;
	$tot_montant_fixe_fr_conxG1 =0;

	$montant_fixeG2 = 0;
	$tot_montant_fixe_fr_acaG2 =0;
	$tot_montant_fixe_fr_conxG2 =0;

	$montant_fixeG3 = 0;
	$tot_montant_fixe_fr_acaG3 =0;
	$tot_montant_fixe_fr_conxG3 =0;

	$montant_fixeL1 = 0;
	$tot_montant_fixe_fr_acaL1 =0;
	$tot_montant_fixe_fr_conxL1 =0;

	$montant_fixeL2 = 0;
	$tot_montant_fixe_fr_acaL2 =0;
	$tot_montant_fixe_fr_conxL2 =0;
	
	$montant_vers = 0;
	$sous_tot_montant_vers =0;
	$tot_montant_vers =0;
	
	$montant_fixe = 0;
	$sous_tot_montant_fixe =0;
	$tot_montant_fixe = 0 ;

	/******************************************************************************************************************************/
	$date_encour = getdate();
	$jour = $date_encour['mday'];
	$moi = $date_encour['mon'];
	$annee_encours = $date_encour['year'];
	
	$date_encours = $annee_encours.'-'.$moi.'-'.$jour;	
	
	$mois = "";
	if($moi < 10){$mois = '0'.$moi;}else{$mois=$moi;}
	$date_ojrd8 = $annee_encours.'-'.$mois.'-'.$jour;
	$date_moins = new DateTime($date_ojrd8);
	$date_moins->sub(new DateInterval('P3M'));
	//$date_moins_3 -> sub($interval);
	$date_moins_3 = $date_moins->format('Y-m-d');
	
	$sms_an_aca = "";
	

	//_______LES FONCTIONS_____________________________________________
	
	function jours_select_option(){
		for($i = 1; $i<=31; $i++){
			$j = $i;
			if($j<10){
				$j = "0".$j;
			}
			echo "<option value='".$j."'>".$j."</option>";
		} 
	}
	
	function mois_selct_option(){
		echo "<option value='01'>Janvier</option>";
		echo "<option value='02'>F&eacute;vrier</option>";
		echo "<option value='03'>Mars</option>";
		echo "<option value='04'>Avril</option>";
		echo "<option value='05'>Mai</option>";
		echo "<option value='06'>Juin</option>";
		echo "<option value='07'>Juillet</option>";
		echo "<option value='08'>Ao&ucirc;t</option>";
		echo "<option value='09'>Septembre</option>";
		echo "<option value='10'>Octobre</option>";
		echo "<option value='11'>Novembre</option>";
		echo "<option value='12'>D&eacute;cembre</option>";
	}
	
	include($_SERVER['DOCUMENT_ROOT'].$url_site."B_mbindi/Biamunda/rqt/conx_srvr.php");


	if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
		$url_Act = "https"; 
	else
		$url_Act = "http"; 
		    
	// Ajoutez // à l'URL.
	$url_Act .= "://"; 

	// Ajoutez l'hôte (nom de domaine, ip) à l'URL.
	$url_Act .= $_SERVER['HTTP_HOST']; 

	// Ajouter l'emplacement de la ressource demandée à l'URL
	$url_Act .= $_SERVER['REQUEST_URI']; 
	
	$url_pour = $url_Act;

	
?>